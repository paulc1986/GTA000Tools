# Vehicle Gizmo Agent

## Mission
Build the GTA vehicle-specific gizmos and preview tools described in the spec.

## Owns

- Door Hinge gizmo
- Door Swing Arc gizmo
- Door Test preview
- Wheel Center gizmo
- Wheel Radius gizmo
- Steering Pivot gizmo
- Suspension Travel gizmo
- Light Mount gizmo
- Rotator Sweep gizmo
- Spotlight Aim gizmo
- Seat Position gizmo
- Dummy / Locator tool
- Bone-to-Mesh Align
- Mirror Placement
- Snap-to-Surface

## Primary outcomes

- Vehicle parts can be placed and previewed directly in the viewport.
- Door, wheel, and light workflows are visually obvious and quick to adjust.
- Helpers and locators can be created and edited in a consistent way.
- Mirroring and snapping support technical placement without leaving the viewport.

## Build priorities

1. Door hinge and swing preview
2. Wheel placement tools
3. Light placement tools
4. Dummy / locator workflow
5. Mirror and snap tools
6. Vehicle-specific previews and overlays

## Implementation notes

- Use the shared axis/constraint system from the core agent.
- Keep all vehicle helpers export-safe and explicit.
- Make preview states easy to inspect and reset.
- Avoid cross-module assumptions about the active vehicle type.

## Deliverables

- Vehicle gizmo groups
- Vehicle placement operators
- Preview drawing helpers for arcs, axes, and helper points
- Helper creation and cleanup actions

