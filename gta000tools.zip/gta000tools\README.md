# GTA 000 Tools User Guide

## Overview
`GTA 000 Tools` is a Blender add-on for building, previewing, importing, and exporting GTA V non-ELS siren configurations.

It is designed to help you:
- build a non-ELS siren setup from scratch
- import an existing `carcols.meta`
- manage flash patterns and colours
- link sirens to meshes and bones
- preview siren flashing and lightbar timing inside Blender
- export a usable `carcols.meta`

This guide is written for Blender users who may be working with a full vehicle model, or with a blank scene and only a `carcols.meta` file.

---

## What The Add-on Includes
The add-on is split into these main sections in the Blender sidebar:
- `Lightbar Configuration`
- `Flash Patterns Library`
- `Colours`
- `Car Functions`
- `Simulation Preview`

It appears in both sidebar tabs:
- `Tool`
- `GTA 000`

---

## Installation
1. Open Blender.
2. Go to `Edit > Preferences > Add-ons`.
3. Click `Install from Disk...`.
4. Select the add-on zip.
5. Enable `GTA 000 Tools`.

### Screenshot Placeholder 01
`Blender Preferences > Add-ons > Install from Disk with gta000tools.zip selected`

---

## First Launch
After enabling the add-on:
1. Open the `3D Viewport`.
2. Open the right sidebar with `N` if it is hidden.
3. Open either the `Tool` tab or the `GTA 000` tab.
4. Expand `Lightbar Configuration`.

### Screenshot Placeholder 02
`Viewport sidebar showing the GTA 000 Tools panels collapsed`

---

## Recommended Basic Workflow
If you are creating a new setup from scratch, use this order:
1. Configure the lightbar name, vehicle name, siren ID, BPM, and scale factor.
2. Build or edit your flash pattern library.
3. Build or edit your colour library.
4. Add sirens.
5. Configure each siren.
6. Link each siren to its mesh and bone.
7. Use preview tools to confirm flashing and scale behavior.
8. Export `carcols.meta`.

If you are importing an existing setup:
1. Import `carcols.meta`.
2. Check the imported flash patterns and siren list.
3. Use `Refresh Pattern Previews` if needed.
4. Save any `Unsaved Pattern` entries you want to keep in the library.
5. Link meshes and bones if you are also working with a model.

---

## Lightbar Configuration
This is the main section for vehicle-wide settings.

### Fields
- `Saved`: load an existing saved Blender-side configuration.
- `config_name`: the internal configuration name.
- `vehicle_name`: this maps to `<name>` in `carcols.meta`.
- `siren_id`: the `<id value="..."/>` value in `carcols.meta`.
- `BPM`: beats per minute for flash timing.
- `Scale Factor`: shared hidden-scale factor for the siren setup.
- `Head/Tail Flash Preview`: enables the headlight and taillight swatch previews.
- `Headlight Flash Patterns`: left and right headlight flash pattern selectors.
- `Taillight Flash Patterns`: left and right taillight flash pattern selectors.
- `Advanced Configurations`: additional exported `carcols.meta` attributes.

### Refresh Pattern Previews
There is a `Refresh Pattern Previews` button beside `Head/Tail Flash Preview`.
Use this if:
- imported previews appear stuck
- siren list swatches do not update
- you changed patterns and want to force the UI to refresh

### Screenshot Placeholder 03
`Lightbar Configuration expanded, showing BPM, Scale Factor, Headlight Flash Patterns, Taillight Flash Patterns, and the Refresh Pattern Previews button`

---

## Flash Patterns Library
This section manages reusable flash patterns.

### What A Pattern Contains
Each saved pattern includes:
- `name`
- `bits` as a 32-bit sequence
- `sequencer` numeric value
- duplicate handling state

### Available Actions
- `+`: add a new pattern
- duplicate action: duplicate the selected pattern
- remove action: remove the selected pattern
- `Repeat to 32`: repeats a shorter bit sequence until it reaches 32 bits
- `Generate Opposite`: inverts the current bit pattern
- import and export library actions

### Duplicate Names
If two patterns share the same name:
- the list will show a warning icon
- you can choose to keep both or keep one

### Unsaved Pattern
When a `carcols.meta` import contains a siren flash pattern that does not already exist in the library:
- the siren will show `Unsaved Pattern`
- you can click `Save to Library` from that siren entry

### Screenshot Placeholder 04
`Flash Patterns Library showing a selected pattern, bits field, sequencer field, and pattern management buttons`

---

## Colours
This section manages reusable siren colours.

### Default Colours
The add-on ships with built-in colour presets, including:
- amber
- blue
- red
- white
- green
- pink
- purple
- no colour

### Available Actions
- add a new custom colour
- rename a colour
- edit the colour value
- select saved colours on each siren
- use `Custom` on a siren if a saved colour is not suitable

### Screenshot Placeholder 05
`Colours panel showing the colour library list and a selected custom colour`

---

## Non-ELS Sirens
This is where individual sirens are configured.

### Siren List
Each siren row shows:
- a status icon
- the siren name
- a flash preview swatch

### Status Icon Meaning
- `Light icon`: mesh and bone are linked correctly
- `Error icon`: something is missing

Hover the error icon to see what is missing.
Examples:
- missing mesh
- missing bone
- missing parent skeleton
- linked object not found
- linked bone not found

### Screenshot Placeholder 06
`Siren list showing both a correct light icon and an error icon with mixed siren states`

### Siren Actions Menu
This menu includes siren count actions such as:
- add 20 sirens
- add 32 sirens
- add sirens 21-32
- remove sirens 21-32
- remove all sirens

There is also a `Refresh Pattern Previews` button beside `Siren Actions`.
Use this if the siren swatches stop updating after import or after heavy edits.

### Screenshot Placeholder 07
`Non-ELS Sirens header row showing Siren Actions, Refresh Pattern Previews, preview visibility toggle, and siren count`

---

## Configuring A Siren
Select a siren from the list and configure it below.

### Main Siren Fields
- `siren_type`: `Flasher` or `Rotator`
- `Pattern`: choose a saved pattern or `Unsaved Pattern`
- `Colour`: choose a saved colour or `Custom`
- `Flash Preview`: enables the swatch preview for that siren
- `Direction`: preset direction or custom direction
- `sync_to_bpm`

### Rotators
If the siren is set to `Rotator`:
- flash pattern selection is replaced by rotator settings
- the rotator speed uses the BPM-based options
- clockwise rotation can be toggled

### Flashers
If the siren is set to `Flasher`:
- choose a pattern from the saved library
- if the imported pattern is not saved, it appears as `Unsaved Pattern`
- click `Save to Library` if you want to reuse it later

### Screenshot Placeholder 08
`Selected flasher siren showing Pattern, Colour, Flash Preview, and Direction`

### Screenshot Placeholder 09
`Selected rotator siren showing rotator speed options and clockwise rotation`

---

## Object/Bone Linking
Each siren can be linked to a mesh object and a bone.

### Fields And Actions
- `Parent Skeleton`: the armature the siren bone belongs to
- `Auto-Detect Sirens/Bones`: finds siren meshes and bones by name
- `Assign Selected Object to Siren`: links the selected mesh to the active siren
- `Place Bone at Selected Origin`: creates or places the siren bone at the selected object's origin
- `Mesh`: currently linked siren mesh
- `Bone`: currently linked siren bone

### Status Warning
If the active siren has a mesh but no linked bone, the add-on shows an inline warning under `Bone`.

### Recommended Linking Method
1. Select the correct siren in the list.
2. Set the `Parent Skeleton`.
3. Select the siren mesh object.
4. Click `Assign Selected Object to Siren`.
5. Select the anchor object if needed.
6. Click `Place Bone at Selected Origin`.
7. Confirm the siren status icon becomes a light icon.

### Screenshot Placeholder 10
`Object/Bone Linking box showing Parent Skeleton, assign object, place bone, Mesh, Bone, and warning placement`

---

## Importing carcols.meta
The add-on supports importing an existing `carcols.meta`.

### What Gets Imported
- vehicle name
- siren ID
- BPM
- headlight flash patterns
- taillight flash patterns
- siren flash or rotator setup
- colours
- many siren-level advanced values
- shared scale factor

### Important Import Notes
- if a siren pattern already exists in the library, it is matched automatically
- if a siren pattern does not exist, it becomes `Unsaved Pattern`
- headlight and taillight patterns are imported separately
- imported previews may require `Refresh Pattern Previews` in some workflows

### Blank Scene Workflow
You can import a `carcols.meta` into a completely blank scene.
That lets you:
- inspect patterns
- edit BPM and siren settings
- manage flash pattern libraries
- save imported patterns to the library

A blank scene will not have meshes or bones, so the siren list status icons will show errors until those links exist.

### Screenshot Placeholder 11
`Import carcols.meta action from the Lightbar Configuration panel`

### Screenshot Placeholder 12
`Blank scene after carcols import, showing sirens populated and imported headlight patterns`

---

## Simulation Preview
This section controls the siren simulation tools.

### Options
- `Simulate Siren Off`
- `Simulate Siren On`
- `Simulate All Sirens Off`
- `Simulate All Sirens On`
- `Clear Timeline`
- `Generate Individual Siren Preview`
- `Generate All Sirens Preview`

### What It Does
This section helps preview:
- hidden vs shown scale behavior
- timeline flashing
- siren state changes
- position behavior relative to linked bones and meshes

### Screenshot Placeholder 13
`Simulation Preview panel showing simulate buttons and timeline preview tools`

---

## Car Functions
This section is for simple vehicle-side visibility simulation.

### Vehicle Lights
You can toggle:
- headlights
- taillights
- left indicator
- right indicator
- extra lights

### Extras
If extras exist in the current scene, they appear in the list.
You can:
- show individual extras
- hide individual extras
- show all extras
- hide all extras

### Screenshot Placeholder 14
`Car Functions panel showing light toggles and detected extras`

---

## Exporting carcols.meta
When you are ready:
1. Set the export path.
2. Click `Export carcols.meta`.
3. The add-on will write the file and show a confirmation message.

### Export Behavior
- configured sirens export with their selected settings
- inactive sirens export with default inactive entries
- comments are added for each siren item

### Screenshot Placeholder 15
`Export path field and Export carcols.meta button`

---

## Saving And Loading Blender Configurations
The add-on also supports its own saved configuration format.

### Available Actions
- create new configuration
- save configuration
- load configuration
- import configuration
- export configuration
- delete configuration
- reset current configuration

These are separate from `carcols.meta` import/export.
They are for add-on-side workflow and library management inside Blender.

### Screenshot Placeholder 16
`Saved configuration controls and configuration actions menu`

---

## Troubleshooting
### Pattern previews do not move
Try this in order:
1. Click `Refresh Pattern Previews`.
2. Toggle `Flash Preview` off and back on for the siren.
3. Toggle `Head/Tail Flash Preview` off and back on.
4. Re-import the `carcols.meta`.
5. Restart Blender and reload the add-on.

### Siren status shows error
Hover the icon to read what is missing.
Typical fixes:
- assign the mesh
- set the parent skeleton
- place or link the siren bone
- ensure the linked mesh or armature is in the current scene

### Imported pattern is blank or unavailable
If a siren shows `Unsaved Pattern`:
1. select the siren
2. click `Save to Library`
3. reuse the newly saved pattern as needed

### Headlight or taillight previews look wrong
Check:
- the selected left/right patterns
- BPM
- whether the left/right patterns are actually opposite
- `Head/Tail Flash Preview` is enabled
- `Refresh Pattern Previews` has been used after import

---

## Screenshot Capture Checklist
If you want to add screenshots manually, capture these in Blender:
1. Preferences install screen with `gta000tools.zip`
2. Viewport sidebar with all GTA 000 Tools panels collapsed
3. Lightbar Configuration main setup section
4. Flash Patterns Library with a selected pattern
5. Colours panel with a selected colour
6. Siren list showing both success and error icons
7. Siren Actions header row with refresh button
8. Flasher siren configuration view
9. Rotator siren configuration view
10. Object/Bone Linking section with warning example
11. Import `carcols.meta` button and file browser step
12. Blank scene after import with sirens populated
13. Simulation Preview panel
14. Car Functions panel with lights and extras
15. Export section
16. Saved configuration actions menu

### Suggested Screenshot Filenames
- `01_install_addon.png`
- `02_sidebar_overview.png`
- `03_lightbar_configuration.png`
- `04_flash_patterns_library.png`
- `05_colours_panel.png`
- `06_siren_status_icons.png`
- `07_siren_actions_refresh.png`
- `08_siren_flasher.png`
- `09_siren_rotator.png`
- `10_object_bone_linking.png`
- `11_import_carcols.png`
- `12_blank_scene_imported.png`
- `13_simulation_preview.png`
- `14_car_functions.png`
- `15_export_panel.png`
- `16_saved_config_actions.png`

---

## File Locations
Recommended project file locations:
- Add-on zip: `E:\ChatGPT\GTA 000 Tools\gta000tools.zip`
- Add-on source: `E:\ChatGPT\GTA 000 Tools\gta000tools\__init__.py`
- This guide: `E:\ChatGPT\GTA 000 Tools\USERGUIDE.md`

---

## Final Notes
For best results:
- keep your flash pattern library clean and named consistently
- save imported unsaved patterns you want to reuse
- use the siren status icons to catch missing mesh or bone links quickly
- use `Refresh Pattern Previews` whenever the swatches appear stale
