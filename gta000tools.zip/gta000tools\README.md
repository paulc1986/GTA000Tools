# GTA 000 Tools (Blender Add-on)

This add-on provides a **GTA 000** workflow panel for building and exporting GTA V `carcols.meta` siren configs.

## Install
1. Zip the `gta000tools` folder (keep `__init__.py` at folder root inside zip).
2. In Blender: `Edit > Preferences > Add-ons > Install...`
3. Select the zip and enable **GTA 000 Tools**.

## Open
- `3D Viewport > Sidebar (N) > GTA 000`.
- Extra quick menu: `Object > GTA 000 Tools`.

## Main features implemented
- Lightbar configuration section with save/load/new local JSON configs.
- Flash pattern library with:
  - default patterns
  - custom names
  - visibility mode (Rotator / Flasher / Both)
  - binary pattern entry, repeat-to-32, binary<->integer conversion
- Siren slot manager:
  - Add 20, Add 32, Add 12 additional (21-32)
  - per-siren type, rotator speed mode/formulas, pattern selection/custom pattern
  - colour presets + custom picker (output `0xFFRRGGBB`)
  - direction presets/custom radians
  - scale presets/custom values
  - advanced siren flags
- Object/bone tools:
  - assign selected object as active siren mesh (rename `sirenX`)
  - place/update bone `sirenX` at selected anchor origin in selected armature
  - bone-parent siren mesh
- Simulation:
  - active/all siren on/off (scale + orientation)
  - timeline preview keyframes from flash pattern
- Export:
  - exports GTA-style `carcols.meta`
  - inactive siren slots output with default inactive values

## Notes
- The add-on is designed to work alongside Sollumz in Blender, but does not directly call Sollumz APIs.
- Validate a generated `carcols.meta` in game/mod workflow and adjust defaults as needed.



