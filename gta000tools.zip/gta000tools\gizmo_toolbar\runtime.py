"""Runtime helpers for the GTA 000 gizmo toolbar scaffold."""

from __future__ import annotations

import bpy
import blf
import gpu
from bpy.types import SpaceView3D
from gpu_extras.batch import batch_for_shader

from .properties import GIZMO_BUILD_ORDER, GIZMO_MODE_ITEMS, GIZMO_MODE_LABELS


_OVERLAY_HANDLE = None


def get_settings(context=None):
    context = context or bpy.context
    scene = getattr(context, "scene", None)
    return getattr(scene, "gta000_gizmo_toolbar", None) if scene else None


def get_runtime_state(context=None):
    context = context or bpy.context
    wm = getattr(context, "window_manager", None)
    return getattr(wm, "gta000_gizmo_toolbar_runtime", None) if wm else None


def set_status(context, text: str, level: str = "INFO") -> None:
    settings = get_settings(context)
    if settings is not None:
        settings.last_action = text
        if level in {"WARN", "ERROR"}:
            settings.last_warning = text
        elif level == "INFO":
            settings.last_warning = ""

    runtime_state = get_runtime_state(context)
    if runtime_state is not None:
        runtime_state.status_text = text
        runtime_state.status_level = level
        runtime_state.overlay_dirty = True

    request_redraw(context)


def mode_label(mode: str) -> str:
    return GIZMO_MODE_LABELS.get(mode, mode.title())


def mode_items():
    return GIZMO_MODE_ITEMS


def compact_mode_label(mode: str) -> str:
    short = {
        "CURSOR": "CUR",
        "ORIGIN": "ORG",
        "MESH": "MSH",
        "PIVOT": "PIV",
        "DOOR": "DR",
        "WHEEL": "WHL",
        "LIGHT": "LGT",
        "VALIDATE": "VAL",
    }
    return short.get(mode, mode[:3].upper())


def request_redraw(context=None) -> None:
    context = context or bpy.context
    window = getattr(context, "window", None)
    if window is None:
        return

    for area in getattr(window.screen, "areas", []):
        if area.type != "VIEW_3D":
            continue
        for region in area.regions:
            if region.type == "WINDOW":
                region.tag_redraw()


def _overlay_anchor(settings, region_width: int, strip_width: int, margin: int) -> int:
    position = getattr(settings, "overlay_position", "TOP_LEFT")
    if position == "TOP_CENTER":
        return max(margin, (region_width - strip_width) // 2)
    if position == "TOP_RIGHT":
        return max(margin, region_width - strip_width - margin)
    return margin


def _set_font_size(font_id: int, size_px: int) -> None:
    try:
        blf.size(font_id, size_px)
    except TypeError:
        blf.size(font_id, size_px, 72)


def _draw_rect(shader, verts, color):
    batch = batch_for_shader(shader, "TRIS", {"pos": verts})
    shader.bind()
    shader.uniform_float("color", color)
    batch.draw(shader)


def draw_overlay_strip() -> None:
    context = bpy.context
    settings = get_settings(context)
    if settings is None or not settings.show_overlay:
        return

    space = getattr(context, "space_data", None)
    region = getattr(context, "region", None)
    if space is None or region is None or space.type != "VIEW_3D":
        return

    font_id = 0
    scale = max(0.75, min(float(getattr(settings, "overlay_scale", 1.0)), 2.0))
    pad_x = int(12 * scale)
    pad_y = int(7 * scale)
    gap = int(8 * scale)
    chip_gap = int(6 * scale)
    font_px = int(12 * scale)
    _set_font_size(font_id, font_px)

    status_text = getattr(settings, "last_action", "Ready") if settings.show_status_text else "GTA 000"
    active_mode = getattr(settings, "active_mode", "CURSOR")
    active_label = f"Mode: {mode_label(active_mode)}"
    helper_text = "Use the GTA 000 header tabs or the sidebar panel to switch tools."

    status_tw, _ = blf.dimensions(font_id, status_text)
    mode_tw, _ = blf.dimensions(font_id, active_label)
    helper_tw, _ = blf.dimensions(font_id, helper_text)
    width = max(360, int(status_tw) + int(mode_tw) + int(helper_tw) + pad_x * 6 + gap * 2)

    margin = int(16 * scale)
    x = _overlay_anchor(settings, region.width, width, margin)
    y = region.height - int(42 * scale)
    height = int(28 * scale)

    shader = gpu.shader.from_builtin("UNIFORM_COLOR")
    _draw_rect(
        shader,
        ((x, y), (x + width, y), (x + width, y + height), (x, y), (x + width, y + height), (x, y + height)),
        (0.08, 0.08, 0.09, 0.80),
    )

    cursor_x = x + pad_x
    text_y = y + pad_y
    blf.color(font_id, 0.92, 0.94, 0.97, 1.0)
    blf.position(font_id, cursor_x, text_y, 0)
    blf.draw(font_id, status_text)
    cursor_x += int(status_tw) + gap + pad_x

    chip_w = int(mode_tw) + pad_x * 2
    chip_h = height - 6
    chip_y = y + 3
    _draw_rect(
        shader,
        (
            (cursor_x, chip_y),
            (cursor_x + chip_w, chip_y),
            (cursor_x + chip_w, chip_y + chip_h),
            (cursor_x, chip_y),
            (cursor_x + chip_w, chip_y + chip_h),
            (cursor_x, chip_y + chip_h),
        ),
        (0.17, 0.43, 0.80, 0.95),
    )
    blf.color(font_id, 0.98, 0.98, 0.99, 1.0)
    blf.position(font_id, cursor_x + pad_x, text_y, 0)
    blf.draw(font_id, active_label)
    cursor_x += chip_w + gap

    blf.color(font_id, 0.70, 0.73, 0.78, 1.0)
    blf.position(font_id, cursor_x, text_y, 0)
    blf.draw(font_id, helper_text)


def register() -> None:
    global _OVERLAY_HANDLE
    if _OVERLAY_HANDLE is not None:
        try:
            SpaceView3D.draw_handler_remove(_OVERLAY_HANDLE, "WINDOW")
        except Exception:
            pass
        _OVERLAY_HANDLE = None

    _OVERLAY_HANDLE = SpaceView3D.draw_handler_add(draw_overlay_strip, (), "WINDOW", "POST_PIXEL")
    set_status(bpy.context, f"Gizmo toolbar scaffold ready ({len(GIZMO_BUILD_ORDER)} phases)")


def unregister() -> None:
    global _OVERLAY_HANDLE
    if _OVERLAY_HANDLE is not None:
        try:
            SpaceView3D.draw_handler_remove(_OVERLAY_HANDLE, "WINDOW")
        except Exception:
            pass
        _OVERLAY_HANDLE = None
