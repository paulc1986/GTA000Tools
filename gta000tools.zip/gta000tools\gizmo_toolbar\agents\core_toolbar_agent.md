# Core Toolbar Agent

## Mission
Build the shared gizmo framework and the top-of-viewport GTA toolbar layer described in the spec.

## Owns

- Top viewport GTA toolbar
- Floating overlay strip
- Shared axis/constraint system
- Shared gizmo drawing helpers
- Shared transform-target abstraction
- Reusable snapping/orientation helpers for later gizmos

## Primary outcomes

- A compact GTA-focused toolbar appears at the top of the 3D viewport.
- The toolbar exposes the core workflow modes and quick-access controls.
- Gizmo groups can reuse a common target/constraint system.
- Overlay rendering can show axes, labels, warnings, and active target state.

## Build priorities

1. Toolbar shell and layout
2. Shared transform-target model
3. Axis and plane constraint helpers
4. Gizmo group registration pattern
5. Overlay draw helpers

## Implementation notes

- Keep the toolbar lightweight and stable.
- Prefer reusable helper functions over one-off operator code.
- Make registration local to the owned module set.
- Avoid depending on the rest of the addon being present.

## Deliverables

- Toolbar UI classes
- Shared gizmo helper module
- Axis/constraint helper system
- Minimal overlay draw framework

