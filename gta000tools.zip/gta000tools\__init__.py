﻿
bl_info = {
    "name": "GTA 000 Tools",
    "author": "Codex",
    "version": (0, 2, 17),
    "blender": (3, 6, 0),
    "location": "View3D > Sidebar > Tool and GTA 000",
    "description": "Build non-ELS lightbar configs and export carcols.meta",
    "category": "Object",
}

import io
import json
import math
import os
import re
import shutil
import tempfile
import textwrap
import threading
import time as _time
import urllib.error
import urllib.request
import xml.dom.minidom
import xml.etree.ElementTree as ET
import zipfile

try:
    import blf
    import gpu
    from gpu_extras.batch import batch_for_shader
except Exception:
    blf = None
    gpu = None
    batch_for_shader = None

import bmesh
import bpy
import bpy.utils.previews
import addon_utils
from bpy.app.handlers import persistent
from mathutils import Euler, Matrix, Vector
from bpy.props import (
    BoolProperty,
    CollectionProperty,
    EnumProperty,
    FloatProperty,
    FloatVectorProperty,
    IntProperty,
    PointerProperty,
    StringProperty,
)
from bpy.types import AddonPreferences, Menu, Operator, Panel, PropertyGroup, UIList

MAX_SIRENS = 32
NO_SAVED_CFG = "__NONE__"
UNSAVED_PATTERN_KEY = "__UNSAVED__"
UPDATE_REPO_URL = "https://github.com/paulc1986/GTA000Tools"
UPDATE_ZIP_URL = "https://raw.githubusercontent.com/paulc1986/GTA000Tools/main/gta000tools.zip"
SOLLUMZ_REPO_URL = "https://github.com/Sollumz/Sollumz"
SOLLUMZ_RELEASE_API_URL = "https://api.github.com/repos/Sollumz/Sollumz/releases/latest"
UPDATE_REQUEST_TIMEOUT = 20

BODY_OPENING_TYPES = [
    ("HINGED", "Hinged", "Rotation-based opening"),
    ("SLIDING", "Sliding", "Translation-based opening"),
    ("HINGED_SLIDING", "Hinged + Sliding", "Rotation and translation opening"),
]

DEFAULT_BODY_OPENINGS = [
    ("bonnet", "Bonnet", "HINGED"),
    ("boot", "Boot", "HINGED"),
    ("door_dside_f", "Driver Front Door", "HINGED"),
    ("door_pside_f", "Passenger Front Door", "HINGED"),
    ("door_dside_r", "Driver Rear Door", "HINGED"),
    ("door_pside_r", "Passenger Rear Door", "HINGED"),
]

_UPDATE_LOCK = threading.Lock()
_UPDATE_THREAD = None
_UPDATE_RESULT = None
_UPDATE_STARTUP_SCHEDULED = False

PANEL_ICON_FILES = {
    "lightbar": "lightbar",
    "patterns": "patterns",
    "colors": "colours",
    "body_openings": "body_openings",
    "car_functions": "car_functions",
    "simulation": "simulation",
    "useful_tools": "useful_tools",
    "updates": "updates",
}

PANEL_ICON_EXTENSIONS = (".png", ".gif")

PANEL_FALLBACK_ICONS = {
    "lightbar": "LIGHT",
    "patterns": "FILE_TEXT",
    "colors": "MATERIAL",
    "body_openings": "ARMATURE_DATA",
    "car_functions": "SCENE_DATA",
    "simulation": "ANIM",
    "useful_tools": "TOOL_SETTINGS",
    "updates": "IMPORT",
}

_PREVIEW_COLLECTIONS = {}
_CUSTOM_PREVIEW_DRAW_HANDLE = None
_UI_PANEL_DRAW_TIMESTAMPS = {}


ADDON_MODULE_NAME = __package__ or os.path.basename(os.path.dirname(__file__)) or "gta000tools"


def get_addon_preferences(context=None):
    try:
        prefs = getattr(context, "preferences", None) if context else getattr(bpy.context, "preferences", None)
        addons = getattr(prefs, "addons", None) if prefs else None
        addon = addons.get(ADDON_MODULE_NAME) if addons else None
        return getattr(addon, "preferences", None) if addon else None
    except Exception:
        return None


def alpha_rotators_enabled(context=None):
    prefs = get_addon_preferences(context)
    return bool(getattr(prefs, "alpha_rotators", False)) if prefs else False


def panel_location_mode(context=None):
    prefs = get_addon_preferences(context)
    return str(getattr(prefs, "panel_location", "VIEWPORT") or "VIEWPORT") if prefs else "VIEWPORT"


def panel_location_visible(target, context=None):
    mode = panel_location_mode(context)
    if mode == "BOTH":
        return True
    return mode == str(target or "")


def update_addon_preferences_ui(self, context):
    tag_all_ui_redraw()


def _ui_panel_draw_key(scene, panel_key):
    try:
        return (int(scene.as_pointer()), str(panel_key or ""))
    except Exception:
        return (str(getattr(scene, "name", "")), str(panel_key or ""))


def mark_panel_drawn(scene, panel_key):
    if not scene:
        return
    _UI_PANEL_DRAW_TIMESTAMPS[_ui_panel_draw_key(scene, panel_key)] = _time.time()


def panel_drawn_recently(scene, panel_key, max_age=0.75):
    if not scene:
        return False
    ts = float(_UI_PANEL_DRAW_TIMESTAMPS.get(_ui_panel_draw_key(scene, panel_key), 0.0) or 0.0)
    if ts <= 0.0:
        return False
    return (_time.time() - ts) <= max(0.05, float(max_age))


class GTA000TOOLS_Preferences(AddonPreferences):
    bl_idname = ADDON_MODULE_NAME

    panel_location: EnumProperty(
        name="Panel Location",
        description="Choose where GTA 000 Tools panels appear in the viewport sidebar",
        items=[
            ("VIEWPORT", "Viewport Menu (Default)", "Show panels only in the GTA 000 viewport tab"),
            ("TOOL", "Item/Tool Menu", "Show panels only in the built-in Tool tab"),
            ("BOTH", "Both", "Show panels in both GTA 000 and Tool tabs"),
        ],
        default="VIEWPORT",
        update=update_addon_preferences_ui,
    )

    alpha_rotators: BoolProperty(
        name="Rotators",
        description="Show experimental rotator controls in the siren editor",
        default=False,
        update=update_addon_preferences_ui,
    )

    def draw(self, context):
        layout = self.layout
        panel_box = layout.box()
        panel_box.label(text="Panel Location")
        panel_box.prop(self, "panel_location", expand=False)
        panel_box.label(text="Viewport Menu uses the GTA 000 tab", icon="INFO")

        box = layout.box()
        box.label(text="Alpha Features")
        box.prop(self, "alpha_rotators")
        box.label(text="Untick to keep the siren editor flasher-only", icon="INFO")


def addon_version_tuple():
    try:
        return tuple(int(v) for v in bl_info.get("version", (0, 0, 0)))
    except Exception:
        return (0, 0, 0)


def version_to_str(version):
    try:
        return ".".join(str(int(v)) for v in tuple(version))
    except Exception:
        return "0.0.0"


def compare_versions(a, b):
    av = tuple(int(v) for v in tuple(a))
    bv = tuple(int(v) for v in tuple(b))
    if av == bv:
        return 0
    return 1 if av > bv else -1


def update_timestamp_string(ts=None):
    if ts is None:
        ts = _time.time()
    try:
        return _time.strftime("%Y-%m-%d %H:%M:%S", _time.localtime(float(ts)))
    except Exception:
        return ""


def parse_version_tuple_from_init_text(text):
    if not text:
        return None
    m = re.search(r'"version"\s*:\s*\(\s*(\d+)\s*,\s*(\d+)\s*,\s*(\d+)\s*\)', str(text))
    if not m:
        return None
    return tuple(int(m.group(i)) for i in range(1, 4))


def parse_version_tuple_from_string(text):
    if not text:
        return None
    m = re.search(r'(\d+)\.(\d+)\.(\d+)', str(text))
    if not m:
        return None
    return tuple(int(m.group(i)) for i in range(1, 4))


def normalize_update_state(s):
    if not s:
        return

    current = addon_version_tuple()
    current_str = version_to_str(current)
    remote = parse_version_tuple_from_string(getattr(s, "update_remote_version", ""))
    status = str(getattr(s, "update_status", "") or "")

    if remote and compare_versions(current, remote) >= 0:
        s.update_available = False
        s.update_remote_version = current_str
        if getattr(s, "update_restart_required", False):
            s.update_restart_required = False
            s.update_check_in_progress = False
            s.update_install_in_progress = False
            if status.startswith("Update installed:") or status.startswith("Update available:"):
                s.update_status = f"GTA 000 Tools is up to date ({current_str})"
        elif status.startswith("Update available:"):
            s.update_status = f"GTA 000 Tools is up to date ({current_str})"


def displayed_update_version(s):
    current = addon_version_tuple()
    current_str = version_to_str(current)
    remote_str = str(getattr(s, "update_remote_version", "") or "").strip()
    remote = parse_version_tuple_from_string(remote_str)
    if not remote:
        return remote_str or current_str
    return current_str if compare_versions(current, remote) >= 0 else remote_str


def update_request_headers():
    return {"User-Agent": f"GTA000Tools/{version_to_str(addon_version_tuple())}"}


def find_sollumz_module_name():
    try:
        for mod in addon_utils.modules():
            name = str(getattr(mod, "__name__", "") or "")
            info = getattr(mod, "bl_info", {}) or {}
            label = str(info.get("name", "") or "")
            if name.lower() == "sollumz" or "sollumz" in name.lower() or "sollumz" in label.lower():
                return name
    except Exception:
        pass
    return ""


def sollumz_enabled():
    module_name = find_sollumz_module_name()
    if not module_name:
        return False
    try:
        prefs = getattr(getattr(bpy.context, "preferences", None), "addons", None)
        return bool(prefs and module_name in prefs)
    except Exception:
        return False


def sollumz_status():
    module_name = find_sollumz_module_name()
    return {
        "module": module_name,
        "installed": bool(module_name),
        "enabled": bool(module_name) and sollumz_enabled(),
    }


def download_url_bytes(url):
    req = urllib.request.Request(str(url), headers=update_request_headers() | {"Accept": "application/vnd.github+json"})
    with urllib.request.urlopen(req, timeout=UPDATE_REQUEST_TIMEOUT) as resp:
        return resp.read()


def fetch_sollumz_release_asset_info():
    data = download_url_bytes(SOLLUMZ_RELEASE_API_URL)
    payload = json.loads(data.decode("utf-8", errors="ignore"))
    tag_name = str(payload.get("tag_name", "") or payload.get("name", "") or "")
    assets = payload.get("assets", []) or []
    for asset in assets:
        name = str(asset.get("name", "") or "")
        url = str(asset.get("browser_download_url", "") or "")
        if name.lower().endswith(".zip") and url:
            return {"tag": tag_name, "name": name, "url": url}
    raise RuntimeError("Could not find a Sollumz release zip in the latest GitHub release")


def addon_roots_from_zip_bytes(data):
    roots = []
    with zipfile.ZipFile(io.BytesIO(data)) as zf:
        for name in zf.namelist():
            norm = str(name or "").strip("/")
            if not norm.endswith("__init__.py"):
                continue
            if "/" not in norm:
                continue
            root = norm.split("/", 1)[0]
            if root and root not in roots:
                roots.append(root)
    return roots


def install_addon_from_zip_bytes(data, name_hint=""):
    fd, tmp_path = tempfile.mkstemp(suffix=".zip")
    os.close(fd)
    try:
        with open(tmp_path, "wb") as fh:
            fh.write(data)
        bpy.ops.preferences.addon_install(filepath=tmp_path, overwrite=True)
        try:
            addon_utils.modules_refresh()
        except Exception:
            pass

        candidates = []
        for root in addon_roots_from_zip_bytes(data):
            if root not in candidates:
                candidates.append(root)
        hint = str(name_hint or "").strip().lower()
        try:
            for mod in addon_utils.modules():
                mod_name = str(getattr(mod, "__name__", "") or "")
                info = getattr(mod, "bl_info", {}) or {}
                label = str(info.get("name", "") or "")
                if hint and (hint in mod_name.lower() or hint in label.lower()):
                    if mod_name not in candidates:
                        candidates.append(mod_name)
        except Exception:
            pass

        enabled_module = ""
        for mod_name in candidates:
            try:
                bpy.ops.preferences.addon_enable(module=mod_name)
                enabled_module = mod_name
                break
            except Exception:
                continue
        return enabled_module
    finally:
        try:
            os.remove(tmp_path)
        except Exception:
            pass


def download_update_zip_bytes():
    req = urllib.request.Request(UPDATE_ZIP_URL, headers=update_request_headers())
    with urllib.request.urlopen(req, timeout=UPDATE_REQUEST_TIMEOUT) as resp:
        return resp.read()


def inspect_update_zip_bytes(data):
    if not data:
        raise RuntimeError("Downloaded update file was empty")
    with zipfile.ZipFile(io.BytesIO(data)) as zf:
        names = [name for name in zf.namelist() if name.lower().endswith("/__init__.py") or name == "__init__.py"]
        names.sort(key=lambda name: ("gta000tools/__init__.py" not in name.lower(), len(name)))
        for name in names:
            try:
                text = zf.read(name).decode("utf-8", errors="ignore")
            except Exception:
                continue
            version = parse_version_tuple_from_init_text(text)
            if version:
                root = name.rsplit("/", 1)[0] if "/" in name else ""
                return version, root
    raise RuntimeError("Could not locate GTA 000 Tools package inside the downloaded zip")


def addon_install_target_dir():
    return os.path.dirname(os.path.abspath(__file__))


def iter_relative_files(root_dir):
    rels = {}
    for current_root, dirs, files in os.walk(root_dir):
        dirs[:] = [d for d in dirs if d != "__pycache__"]
        for name in files:
            if name.endswith((".pyc", ".pyo")):
                continue
            full = os.path.join(current_root, name)
            rel = os.path.relpath(full, root_dir)
            rels[rel] = full
    return rels


def prune_empty_dirs(root_dir):
    for current_root, dirs, files in os.walk(root_dir, topdown=False):
        dirs[:] = [d for d in dirs if d != "__pycache__"]
        if current_root == root_dir:
            continue
        try:
            if not os.listdir(current_root):
                os.rmdir(current_root)
        except Exception:
            pass


def sync_addon_directory(source_dir, target_dir):
    if not os.path.isdir(source_dir):
        raise RuntimeError("Update package did not contain a valid addon directory")
    os.makedirs(target_dir, exist_ok=True)
    source_files = iter_relative_files(source_dir)
    target_files = iter_relative_files(target_dir)

    stale_files = sorted(set(target_files) - set(source_files), reverse=True)
    for rel in stale_files:
        try:
            os.remove(os.path.join(target_dir, rel))
        except FileNotFoundError:
            pass

    for rel, src in source_files.items():
        dst = os.path.join(target_dir, rel)
        os.makedirs(os.path.dirname(dst), exist_ok=True)
        shutil.copy2(src, dst)

    prune_empty_dirs(target_dir)


def install_update_from_zip_bytes(data, target_dir=None):
    target_dir = target_dir or addon_install_target_dir()
    version, root = inspect_update_zip_bytes(data)
    temp_parent = os.path.dirname(os.path.abspath(target_dir)) or os.path.abspath(target_dir)
    stage_name = f"gta000tools_update_{int(_time.time() * 1000)}"
    temp_dir = os.path.join(temp_parent, stage_name)
    os.makedirs(temp_dir, exist_ok=True)
    try:
        with zipfile.ZipFile(io.BytesIO(data)) as zf:
            zf.extractall(temp_dir)
        source_dir = os.path.join(temp_dir, root) if root else temp_dir
        if not os.path.isfile(os.path.join(source_dir, "__init__.py")):
            for current_root, dirs, files in os.walk(temp_dir):
                if "__init__.py" in files:
                    source_dir = current_root
                    break
        sync_addon_directory(source_dir, target_dir)
    finally:
        shutil.rmtree(temp_dir, ignore_errors=True)
    return version


def set_update_ui_state(message="", available=None, remote_version=None, checking=None, installing=None, restart_required=None, checked_at=None, set_status=False):
    scenes = getattr(bpy.data, "scenes", None) or []
    for scene in scenes:
        s = getattr(scene, "nels", None)
        if not s:
            continue
        if message is not None:
            s.update_status = str(message or "")
            if set_status:
                s.status_message = str(message or "")
        if available is not None:
            s.update_available = bool(available)
        if remote_version is not None:
            s.update_remote_version = str(remote_version or "")
        if checking is not None:
            s.update_check_in_progress = bool(checking)
        if installing is not None:
            s.update_install_in_progress = bool(installing)
        if restart_required is not None:
            s.update_restart_required = bool(restart_required)
        if checked_at is not None:
            s.update_last_checked = str(checked_at or "")


def start_update_job(kind):
    global _UPDATE_THREAD, _UPDATE_RESULT
    with _UPDATE_LOCK:
        if _UPDATE_THREAD and _UPDATE_THREAD.is_alive():
            return False
        _UPDATE_RESULT = None

        def worker():
            global _UPDATE_THREAD, _UPDATE_RESULT
            result = {"kind": kind, "ok": False}
            try:
                data = download_update_zip_bytes()
                remote_version, _root = inspect_update_zip_bytes(data)
                result["remote_version"] = remote_version
                if kind == "INSTALL":
                    installed_version = install_update_from_zip_bytes(data)
                    result["installed_version"] = installed_version
                result["ok"] = True
            except Exception as ex:
                result["error"] = str(ex)
            with _UPDATE_LOCK:
                _UPDATE_RESULT = result
                _UPDATE_THREAD = None

        _UPDATE_THREAD = threading.Thread(target=worker, name=f"gta000tools_update_{kind.lower()}", daemon=True)
        _UPDATE_THREAD.start()
    return True


def apply_update_job_result():
    global _UPDATE_RESULT
    with _UPDATE_LOCK:
        result = _UPDATE_RESULT
        _UPDATE_RESULT = None
    if not result:
        return False

    checked_at = update_timestamp_string()
    current_version = addon_version_tuple()
    kind = str(result.get("kind", "CHECK") or "CHECK")
    remote_version = tuple(result.get("remote_version") or ())
    remote_version_str = version_to_str(remote_version) if remote_version else ""

    if not result.get("ok"):
        message = f"Update {kind.lower()} failed: {result.get('error', 'Unknown error')}"
        set_update_ui_state(message=message, checking=False, installing=False, checked_at=checked_at, set_status=True)
        tag_preview_ui_redraw()
        return True

    if kind == "INSTALL":
        installed_version = tuple(result.get("installed_version") or remote_version or current_version)
        message = f"Update installed: {version_to_str(installed_version)}. Restart Blender to load the new version."
        set_update_ui_state(message=message, available=False, remote_version=version_to_str(installed_version), checking=False, installing=False, restart_required=True, checked_at=checked_at, set_status=True)
        tag_preview_ui_redraw()
        return True

    available = bool(remote_version and compare_versions(remote_version, current_version) > 0)
    if available:
        message = f"Update available: {version_to_str(current_version)} -> {remote_version_str}"
        set_update_ui_state(message=message, available=True, remote_version=remote_version_str, checking=False, installing=False, restart_required=False, checked_at=checked_at, set_status=True)
    else:
        message = f"GTA 000 Tools is up to date ({version_to_str(current_version)})"
        set_update_ui_state(message=message, available=False, remote_version=remote_version_str or version_to_str(current_version), checking=False, installing=False, restart_required=False, checked_at=checked_at, set_status=False)
    tag_preview_ui_redraw()
    return True


def begin_update_operation(kind, automatic=False):
    message = "Checking GitHub for updates..." if kind == "CHECK" else "Installing update from GitHub..."
    started = start_update_job(kind)
    if not started:
        if not automatic:
            set_update_ui_state(message="An update task is already running", set_status=True)
            tag_preview_ui_redraw()
        return False

    set_update_ui_state(
        message=message,
        checking=(kind == "CHECK"),
        installing=(kind == "INSTALL"),
        restart_required=False if kind == "INSTALL" else None,
        set_status=(not automatic),
    )
    tag_preview_ui_redraw()
    return True


def schedule_startup_update_check(scene=None):
    global _UPDATE_STARTUP_SCHEDULED
    if _UPDATE_STARTUP_SCHEDULED:
        return
    s = getattr(scene, "nels", None) if scene else None
    if s and not bool(getattr(s, "update_check_on_startup", True)):
        return
    _UPDATE_STARTUP_SCHEDULED = True

    def deferred():
        try:
            begin_update_operation("CHECK", automatic=True)
        except Exception:
            pass
        return None

    try:
        bpy.app.timers.register(deferred, first_interval=2.0)
    except Exception:
        _UPDATE_STARTUP_SCHEDULED = False


VISIBILITY_ITEMS = [
    ("BOTH", "Rotator + Flasher", ""),
    ("ROTATOR", "Rotator", ""),
    ("FLASHER", "Flasher", ""),
]

SIREN_TYPES = [("FLASHER", "Flasher", ""), ("ROTATOR", "Rotator", "")]

ROT_SPEED = {
    "P50": 8.0,
    "P25": 4.0,
    "P12_5": 2.0,
    "P6_25": 1.0,
    "P3_125": 0.5,
}

ROT_SPEED_ITEMS = [
    ("P50", "Rotate at 50% BPM", "BPM/100*8"),
    ("P25", "Rotate at 25% BPM", "BPM/100*4"),
    ("P12_5", "Rotate at 12.5% BPM", "BPM/100*2"),
    ("P6_25", "Rotate at 6.25% BPM", "BPM/100"),
    ("P3_125", "Rotate at 3.125% BPM", "BPM/100*0.5"),
    ("CUSTOM", "Enter custom % of BPM", ""),
]

DIRECTIONS = {
    "FRONT": 0.0,
    "DRIVER": -1.57079633,
    "PASSENGER": 1.57079633,
    "BACK": 3.14159265,
    "BACK_LEFT": 2.35619449,
    "BACK_RIGHT": -2.35619449,
    "FRONT_LEFT": 0.78539816,
    "FRONT_RIGHT": -0.78539816,
}

DIRECTION_ITEMS = [
    ("FRONT", "Front", "0.00000000"),
    ("DRIVER", "Driver Side", "-1.57079633"),
    ("PASSENGER", "Passenger Side", "1.57079633"),
    ("BACK", "Back", "3.14159265"),
    ("BACK_LEFT", "Back Left", "2.35619449"),
    ("BACK_RIGHT", "Back Right", "-2.35619449"),
    ("FRONT_LEFT", "Front Left", "0.78539816"),
    ("FRONT_RIGHT", "Front Right", "-0.78539816"),
]

SCALES = {"SCALE_50": 0.5, "SCALE_10": 0.1, "SCALE_01": 0.01}
SCALE_ITEMS = [
    ("SCALE_50", "Scale to 50% (0.5)", ""),
    ("SCALE_10", "Scale to 10% (0.1)", ""),
    ("SCALE_01", "Scale to 1% (0.01)", ""),
]
SCALE_FACTOR_PRESET_ITEMS = [
    ("SF_2", "Scale Factor 2 (0.5)", "Stored value: 0.5"),
    ("SF_10", "Scale Factor 10 (0.1)", "Stored value: 0.1"),
    ("SF_100", "Scale Factor 100 (0.01)", "Stored value: 0.01"),
    ("CUSTOM", "Custom", "Use a custom stored value"),
]
SCALE_FACTOR_PRESET_VALUES = {"SF_2": 0.5, "SF_10": 0.1, "SF_100": 0.01}

COLORS = {
    "LED_AMBER": "0xFFFF4800",
    "LED_BLUE": "0xFF000AFF",
    "LED_RED": "0xFFFF0300",
    "HALOGEN_BLUE": "0xFF2130FF",
    "HALOGEN_RED": "0xFFFF1405",
    "GENERAL_AMBER": "0xFFFF6400",
    "GENERAL_AMBER_BRIGHT": "0xFFFFFF00",
    "GENERAL_BLUE": "0xFF0000FF",
    "GENERAL_GREEN": "0xFF00C853",
    "GENERAL_PINK": "0xFFFF2D95",
    "GENERAL_PURPLE": "0xFF673AB7",
    "GENERAL_RED": "0xFFFF0000",
    "GENERAL_WHITE": "0xFFFFFFFF",
    "NO_COLOUR": "0xFF000000",
}

COLOR_ITEMS = [
    ("LED_AMBER", "LED - Amber", COLORS["LED_AMBER"]),
    ("LED_BLUE", "LED - Blue", COLORS["LED_BLUE"]),
    ("LED_RED", "LED - Red", COLORS["LED_RED"]),
    ("HALOGEN_BLUE", "Halogen - Blue", COLORS["HALOGEN_BLUE"]),
    ("HALOGEN_RED", "Halogen - Red", COLORS["HALOGEN_RED"]),
    ("GENERAL_AMBER", "General - Amber", COLORS["GENERAL_AMBER"]),
    ("GENERAL_AMBER_BRIGHT", "General - Amber Bright", COLORS["GENERAL_AMBER_BRIGHT"]),
    ("GENERAL_BLUE", "General - Blue", COLORS["GENERAL_BLUE"]),
    ("GENERAL_GREEN", "General - Green", COLORS["GENERAL_GREEN"]),
    ("GENERAL_PINK", "General - Pink", COLORS["GENERAL_PINK"]),
    ("GENERAL_PURPLE", "General - Purple", COLORS["GENERAL_PURPLE"]),
    ("GENERAL_RED", "General - Red", COLORS["GENERAL_RED"]),
    ("GENERAL_WHITE", "General - White", COLORS["GENERAL_WHITE"]),
    ("NO_COLOUR", "No Colour", COLORS["NO_COLOUR"]),
]

DEFAULT_COLOR_LIBRARY = [(label, value) for _, label, value in COLOR_ITEMS]

DEFAULT_PATTERNS = [
    ("Always On / Steady Burn", 4294967295),
    ("Code 3 Pursuit - Stage 1 - Blue", 4042322160),
    ("Code 3 Pursuit - Stage 1 - Red", 252645135),
    ("Code 3 Pursuit - Stage 2 - Blue", 1840278960),
    ("Code 3 Pursuit - Stage 2 - Red", 115017435),
    ("Code 3 Pursuit - Stage 3 - Blue", 1426085120),
    ("Code 3 Pursuit - Stage 3 - Red", 5570645),
    ("Code 3 Pursuit - Sweep - LED 1", 2147581953),
    ("Code 3 Pursuit - Sweep - LED 2", 1073889282),
    ("Code 3 Pursuit - Sweep - LED 3", 537141252),
    ("Code 3 Pursuit - Sweep - LED 4", 268963848),
    ("Code 3 Pursuit - Sweep - LED 5", 135268368),
    ("Code 3 Pursuit - Sweep - LED 6", 69207072),
    ("Code 3 Pursuit - Sweep - LED 7", 37749312),
    ("Code 3 Pursuit - Sweep - LED 8", 25166208),
    ("Double Flash Blue", 168430090),
    ("Double Flash Red", 2694881440),
    ("ECCO Split Double - Left - LED 1", 2684395520),
    ("ECCO Split Double - Right - LED 1", 167774720),
    ("ECCO Split Double - Left - LED 2", 10485920),
    ("ECCO Split Double - Right - LED 2", 655370),
    ("ED3790 - Blue", 2818615296),
    ("ED3790 - Red", 2752554),
    ("ED3790 - White", 41943680),
    ("Strobe - Blue", 9044106),
    ("Strobe - Red", 2315291136),
    ("Tripple Flash - Right", 2852170240),
    ("Tripple Flash - Left", 11141290),
    ("Tripple Flash - Gap - Blue", 2818615296),
    ("Tripple Flash - Gap - Red", 11010216),
    ("Wig Wag - Left", 8323199),
    ("Wig Wag - Right", 2130738944),
    ("Off", 0),
]

LEGACY_DEFAULT_PATTERNS = [
    ("Alternating Quad", 4042264335),
    ("Split 50/50", 4278255360),
    ("Rapid 2x2", 3435973836),
    ("Single Sweep", 4278190080),
    ("Pulsed", 252645135),
    ("Off", 0),
]

HEADLIGHT_KEYS = ("headlight", "head_light", "hl_", "light_head")
TAILLIGHT_KEYS = ("taillight", "tail_light", "rear_light", "brake_light")
LEFT_INDICATOR_KEYS = ("indicator_l", "left_indicator", "turn_l", "blinker_l")
RIGHT_INDICATOR_KEYS = ("indicator_r", "right_indicator", "turn_r", "blinker_r")
EXTRA_LIGHT_KEYS = ("extra_light", "aux_light", "warning_light")
LEFT_SIDE_TOKENS = {"left", "driver", "l", "lf", "lr"}
RIGHT_SIDE_TOKENS = {"right", "passenger", "r", "rf", "rr"}
WHEEL_PREVIEW_PREFIX = "_gta000_wheel_preview_"
LIGHT_ID_PREVIEW_PREFIX = "_gta000_lightid_preview_"
SOLLUMZ_LIGHT_ID_NAME_TO_VALUE = {
    "always_on": 0,
    "headlight_l": 1,
    "headlight_r": 2,
    "taillight_l": 3,
    "taillight_r": 4,
    "indicator_lf": 5,
    "indicator_rf": 6,
    "indicator_lr": 7,
    "indicator_rr": 8,
    "brakelight_l": 9,
    "brakelight_r": 10,
    "brakelight_m": 11,
    "reversinglight_l": 12,
    "reversinglight_r": 13,
    "extralight_1": 14,
    "extralight_2": 15,
    "extralight_3": 16,
    "extralight_4": 17,
}
SOLLUMZ_LIGHT_ID_VALUE_TO_NAME = {v: k for k, v in SOLLUMZ_LIGHT_ID_NAME_TO_VALUE.items()}
SOLLUMZ_LIGHT_ID_COLOR = {
    "always_on": (1.0, 1.0, 1.0),
    "headlight_l": (1.0, 1.0, 1.0),
    "headlight_r": (1.0, 1.0, 1.0),
    "taillight_l": (1.0, 0.08, 0.08),
    "taillight_r": (1.0, 0.08, 0.08),
    "brakelight_l": (1.0, 0.08, 0.08),
    "brakelight_r": (1.0, 0.08, 0.08),
    "brakelight_m": (1.0, 0.08, 0.08),
    "indicator_lf": (1.0, 0.42, 0.0),
    "indicator_rf": (1.0, 0.42, 0.0),
    "indicator_lr": (1.0, 0.42, 0.0),
    "indicator_rr": (1.0, 0.42, 0.0),
    "reversinglight_l": (1.0, 1.0, 1.0),
    "reversinglight_r": (1.0, 1.0, 1.0),
    "extralight_1": (1.0, 1.0, 1.0),
    "extralight_2": (1.0, 1.0, 1.0),
    "extralight_3": (1.0, 1.0, 1.0),
    "extralight_4": (1.0, 1.0, 1.0),
}
SOLLUMZ_LIGHT_ID_ATTR_NAMES = {
    "lightid",
    "lightids",
    "light_id",
    "light_ids",
    "vehiclelightid",
    "vehiclelightids",
    "vehicle_light_id",
    "vehicle_light_ids",
    "externallightid",
    "external_light_id",
    "externalstateid",
    "external_state_id",
}
SOLLUMZ_LIGHT_ID_UI_ITEMS = [
    ("always_on", "Always On", "Always-on polygons"),
    ("headlight_l", "Left Headlight (headlight_l)", ""),
    ("headlight_r", "Right Headlight (headlight_r)", ""),
    ("taillight_l", "Left Taillight (taillight_l)", ""),
    ("taillight_r", "Right Taillight (taillight_r)", ""),
    ("indicator_lf", "Front Left Indicator (indicator_lf)", ""),
    ("indicator_rf", "Front Right Indicator (indicator_rf)", ""),
    ("indicator_lr", "Rear Left Indicator (indicator_lr)", ""),
    ("indicator_rr", "Rear Right Indicator (indicator_rr)", ""),
    ("brakelight_l", "Left Brakelight (brakelight_l)", ""),
    ("brakelight_r", "Right Brakelight (brakelight_r)", ""),
    ("brakelight_m", "Center Brakelight (brakelight_m)", ""),
    ("reversinglight_l", "Left Reversing Light (reversinglight_l)", ""),
    ("reversinglight_r", "Right Reversing Light (reversinglight_r)", ""),
    ("extralight_1", "Extra Front Left (extralight_1)", ""),
    ("extralight_2", "Extra Front Right (extralight_2)", ""),
    ("extralight_3", "Extra Rear Left (extralight_3)", ""),
    ("extralight_4", "Extra Rear Right (extralight_4)", ""),
    ("CUSTOM", "Custom", "Use a custom numeric Light ID"),
]
def f8(v):
    return f"{float(v):.8f}"


def b(v):
    return "true" if v else "false"


def clean_bits(txt):
    return "".join(ch for ch in str(txt) if ch in "01")[:32]


def repeat_32(txt):
    bits = clean_bits(txt)
    if not bits:
        return "0" * 32
    if len(bits) == 32:
        return bits
    return (bits * ((32 + len(bits) - 1) // len(bits)))[:32]


def bits_to_int(txt):
    return int(repeat_32(txt), 2)

def invert_bits(txt):
    bits = repeat_32(txt)
    return "".join("1" if ch == "0" else "0" for ch in bits)



def parse_u32(v):
    txt = str(v).strip()
    try:
        n = int(txt, 10)
    except Exception:
        try:
            n = int(txt, 0)
        except Exception:
            n = 0
    return n & 0xFFFFFFFF


def int_to_bits(v):
    return format(parse_u32(v), "032b")


def cfg_dir():
    candidates = []
    names = ["gta000tools", "non_els_lightbar_tool"]

    for name in names:
        try:
            p = bpy.utils.user_resource("CONFIG", path=name, create=False)
            if p:
                candidates.append(p)
        except Exception:
            pass

    try:
        base = bpy.utils.user_resource("CONFIG")
        if base:
            for name in names:
                candidates.append(os.path.join(base, name))
    except Exception:
        pass

    for name in names:
        candidates.append(os.path.join(tempfile.gettempdir(), name))

    for p in candidates:
        target = p
        if os.path.isfile(target):
            target = target + "_data"
        try:
            os.makedirs(target, exist_ok=True)
            return target
        except Exception:
            continue

    return tempfile.gettempdir()


def safe_name(name):
    return re.sub(r"[^A-Za-z0-9_\- ]+", "", str(name)).strip().replace(" ", "_") or "lightbar_config"



_LIBRARY_FILE = "library.json"
_LIBRARY_SYNC_GUARD = False
_LIVE_PREVIEW_GUARD = False
_SCALE_FACTOR_SYNC_GUARD = False
_PREVIEW_UPDATE_SUSPEND = 0

def library_path():
    return os.path.join(cfg_dir(), _LIBRARY_FILE)

def load_global_library_data():
    fp = library_path()
    if not os.path.exists(fp):
        return {}
    try:
        with open(fp, "r", encoding="utf-8") as h:
            data = json.load(h)
        return data if isinstance(data, dict) else {}
    except Exception:
        return {}

def save_global_library(s):
    global _LIBRARY_SYNC_GUARD
    if _LIBRARY_SYNC_GUARD or not s:
        return
    try:
        data = {
            "patterns": [
                {
                    "name": p.name,
                    "visibility": p.visibility,
                    "bits": repeat_32(p.bits),
                    "value": parse_u32(p.value),
                    "allow_duplicate": bool(getattr(p, "allow_duplicate", False)),
                }
                for p in s.patterns
            ],
            "colors": [
                {
                    "name": c.name,
                    "value": clean_color_value(c.value),
                }
                for c in s.colors
            ],
        }
        with open(library_path(), "w", encoding="utf-8") as h:
            json.dump(data, h, indent=2)
    except Exception:
        pass

def save_library_from_context(context):
    scene = getattr(context, "scene", None) if context else None
    s = getattr(scene, "nels", None) if scene else None
    if s:
        save_global_library(s)


def config_json_files():
    files = []
    for n in sorted(os.listdir(cfg_dir())):
        if not n.lower().endswith(".json"):
            continue
        if n.lower() == _LIBRARY_FILE.lower():
            continue
        files.append(n)
    return files
def generate_siren_id(seed_text=""):
    base = 25000
    try:
        rnd = int.from_bytes(os.urandom(2), "little")
    except Exception:
        rnd = sum(ord(ch) for ch in str(seed_text))
    return base + (rnd % 50000)

def pattern_key_index(key):
    txt = str(key).strip()
    if txt.startswith("PAT_"):
        txt = txt[4:]
    try:
        return int(txt)
    except Exception:
        return 0


def normalize_pattern_key(key):
    return f"PAT_{max(0, pattern_key_index(key))}"



def find_pattern_key_by_name(s, name):
    if not s or not getattr(s, "patterns", None):
        return "PAT_0"
    target = str(name or "").strip().lower()
    for i, p in enumerate(s.patterns):
        if (p.name or "").strip().lower() == target:
            return f"PAT_{i}"
    return "PAT_0"


def pattern_duplicate_key(name):
    return re.sub(r"\s+", " ", str(name or "").strip()).lower()


def pattern_duplicate_indices(s, idx):
    if not s or not getattr(s, "patterns", None):
        return []
    if idx < 0 or idx >= len(s.patterns):
        return []
    key = pattern_duplicate_key(getattr(s.patterns[idx], "name", ""))
    if not key:
        return []
    matches = [i for i, p in enumerate(s.patterns) if pattern_duplicate_key(getattr(p, "name", "")) == key]
    return matches if len(matches) > 1 else []


def pattern_duplicate_is_allowed(s, idx):
    matches = pattern_duplicate_indices(s, idx)
    return bool(matches) and all(bool(getattr(s.patterns[i], "allow_duplicate", False)) for i in matches)


def pattern_display_name(s, idx):
    p = s.patterns[idx]
    base = str(getattr(p, "name", "") or f"Pattern {idx + 1}")
    matches = pattern_duplicate_indices(s, idx)
    if not matches:
        return base
    try:
        pos = matches.index(idx) + 1
    except ValueError:
        pos = 1
    return f"{base} [{pos}]"


def set_pattern_duplicate_allowed(s, idx, allowed):
    matches = pattern_duplicate_indices(s, idx)
    if not matches:
        return 0
    for i in matches:
        s.patterns[i].allow_duplicate = bool(allowed)
    return len(matches)


def remove_pattern_duplicates_keep_selected(s, idx):
    matches = pattern_duplicate_indices(s, idx)
    if not matches:
        return 0, idx
    removed = 0
    keep_idx = idx
    for i in reversed(matches):
        if i == idx:
            continue
        s.patterns.remove(i)
        removed += 1
        if i < keep_idx:
            keep_idx -= 1
    if 0 <= keep_idx < len(s.patterns):
        s.patterns[keep_idx].allow_duplicate = False
    return removed, keep_idx


def populate_default_patterns(s):
    s.patterns.clear()
    for name, value in DEFAULT_PATTERNS:
        p = s.patterns.add()
        p.name = name
        p.visibility = "BOTH"
        p.bits = int_to_bits(value)
        p.value = str(parse_u32(value))
        p.allow_duplicate = False
    s.active_pattern = 0


def patterns_match_defaults(s, defaults):
    actual = [(pattern_duplicate_key(getattr(p, "name", "")), parse_u32(getattr(p, "value", 0))) for p in getattr(s, "patterns", [])]
    expected = [(pattern_duplicate_key(name), parse_u32(value)) for name, value in defaults]
    return actual == expected


def migrate_legacy_default_patterns(s):
    legacy_sigs = {(pattern_duplicate_key(name), parse_u32(value)) for name, value in LEGACY_DEFAULT_PATTERNS}
    default_sigs = {(pattern_duplicate_key(name), parse_u32(value)) for name, value in DEFAULT_PATTERNS}
    seen_legacy = set()
    extras = []
    for p in getattr(s, "patterns", []):
        sig = (pattern_duplicate_key(getattr(p, "name", "")), parse_u32(getattr(p, "value", 0)))
        if sig in legacy_sigs:
            seen_legacy.add(sig)
            continue
        if sig in default_sigs:
            continue
        extras.append({
            "name": p.name,
            "allow_duplicate": bool(getattr(p, "allow_duplicate", False)),
            "visibility": "FLASHER" if getattr(p, "visibility", "BOTH") == "FLASHER" else "BOTH",
            "bits": repeat_32(getattr(p, "bits", "0")),
            "value": str(parse_u32(getattr(p, "value", 0))),
        })

    if not seen_legacy:
        return False

    populate_default_patterns(s)
    for pd in extras:
        p = s.patterns.add()
        p.name = pd["name"]
        p.allow_duplicate = pd["allow_duplicate"]
        p.visibility = pd["visibility"]
        p.bits = pd["bits"]
        p.value = pd["value"]
    s.active_pattern = min(max(0, s.active_pattern), max(0, len(s.patterns) - 1))
    return True
def clean_color_value(txt):
    raw = str(txt).strip().upper().replace("#", "")
    if raw.startswith("0X"):
        raw = raw[2:]
    raw = "".join(ch for ch in raw if ch in "0123456789ABCDEF")
    if len(raw) == 6:
        raw = "FF" + raw
    if len(raw) != 8:
        return "0xFFFF0000"
    return "0x" + raw


def color_to_rgb(value):
    v = clean_color_value(value)
    hx = v[4:]
    return (int(hx[0:2], 16) / 255.0, int(hx[2:4], 16) / 255.0, int(hx[4:6], 16) / 255.0)


def rgb_to_color(rgb):
    r = int(round(max(0.0, min(1.0, float(rgb[0]))) * 255))
    g = int(round(max(0.0, min(1.0, float(rgb[1]))) * 255))
    b0 = int(round(max(0.0, min(1.0, float(rgb[2]))) * 255))
    return f"0xFF{r:02X}{g:02X}{b0:02X}"


def color_key_index(key):
    txt = str(key).strip()
    if txt.startswith("COL_"):
        txt = txt[4:]
    try:
        return int(txt)
    except Exception:
        return 0


def normalize_color_key(key):
    return f"COL_{max(0, color_key_index(key))}"



def find_color_key_by_value(s, value):
    if not s or not getattr(s, "colors", None):
        return "COL_0"
    target = clean_color_value(value)
    for i, c in enumerate(s.colors):
        if clean_color_value(getattr(c, "value", "0xFFFF0000")) == target:
            return f"COL_{i}"
    return "COL_0"
def color_items(self, context):
    try:
        scene = getattr(context, "scene", None) if context else None
        s = getattr(scene, "nels", None) if scene else None
        if not s or not s.colors:
            return [("COL_0", "Colour 1", "")]
        items = []
        for i, c in enumerate(s.colors):
            nm = str(c.name or f"Colour {i + 1}")
            vv = clean_color_value(getattr(c, "value", "0xFFFF0000"))
            items.append((f"COL_{i}", nm, vv))
        return items or [("COL_0", "Colour 1", "")]
    except Exception:
        return [("COL_0", "Colour 1", "")]


def get_color(s, key):
    if not s.colors:
        return None
    i = max(0, min(color_key_index(key), len(s.colors) - 1))
    return s.colors[i]

def pattern_items(self, context):
    s = getattr(context.scene, "nels", None) if context and context.scene else None
    if not s or not s.patterns:
        return [("PAT_0", "(No Patterns)", "")]
    return [(f"PAT_{i}", pattern_display_name(s, i), p.visibility) for i, p in enumerate(s.patterns)]


def pattern_select_items(self, context):
    return list(pattern_items(self, context)) + [(UNSAVED_PATTERN_KEY, "Unsaved Pattern", "")]


def color_select_items(self, context):
    return list(color_items(self, context)) + [("__CUSTOM__", "Custom", "")]


def direction_select_items(self, context):
    return list(DIRECTION_ITEMS) + [("__CUSTOM__", "Custom", "")]

def saved_cfg_items(self, context):
    items = [(NO_SAVED_CFG, "(No Saved Configs)", "")]
    for n in config_json_files():
        items.append((n, os.path.splitext(n)[0], ""))
    return items


def get_pattern(s, key):
    if not s.patterns:
        return None
    i = max(0, min(pattern_key_index(key), len(s.patterns) - 1))
    return s.patterns[i]


def normalize_pattern_visibility(visibility):
    return "FLASHER" if str(visibility or "").upper() == "FLASHER" else "BOTH"


def pattern_matches_visibility(pattern_visibility, requested_visibility):
    pattern_vis = normalize_pattern_visibility(pattern_visibility)
    requested_vis = normalize_pattern_visibility(requested_visibility)
    return pattern_vis == requested_vis or (requested_vis == "FLASHER" and pattern_vis == "BOTH")


def find_pattern_key_by_bits(s, bits, visibility="BOTH"):
    bits32 = repeat_32(bits)
    for i, p in enumerate(getattr(s, "patterns", [])):
        if repeat_32(getattr(p, "bits", "0")) != bits32:
            continue
        if pattern_matches_visibility(getattr(p, "visibility", "BOTH"), visibility):
            return f"PAT_{i}"
    return ""


def next_pattern_name(s, base_name="Unsaved Pattern"):
    base = str(base_name or "Unsaved Pattern").strip() or "Unsaved Pattern"
    existing = {str(getattr(p, "name", "") or "").strip().casefold() for p in getattr(s, "patterns", [])}
    if base.casefold() not in existing:
        return base
    i = 2
    while f"{base} {i}".casefold() in existing:
        i += 1
    return f"{base} {i}"


def get_or_add_pattern(s, name, visibility, bits):
    bits32 = repeat_32(bits)
    vis = normalize_pattern_visibility(visibility)
    existing_key = find_pattern_key_by_bits(s, bits32, vis)
    if existing_key:
        return existing_key
    p = s.patterns.add()
    p.name = name or f"Pattern {len(s.patterns)}"
    p.visibility = vis
    p.bits = bits32
    p.value = str(bits_to_int(bits32))
    s.active_pattern = len(s.patterns) - 1
    save_global_library(s)
    return f"PAT_{s.active_pattern}"


def off_pattern_key(s):
    return find_pattern_key_by_name(s, "off")


def white_color_key(s):
    return find_color_key_by_value(s, COLORS["GENERAL_WHITE"])


def playback_seconds(scene=None, now=None):
    if now is not None:
        try:
            return float(now)
        except Exception:
            pass

    scn = scene if scene is not None else getattr(bpy.context, "scene", None)
    if scn and timeline_playing():
        try:
            fps_base = float(getattr(scn.render, "fps_base", 1.0) or 1.0)
            fps = float(getattr(scn.render, "fps", 24.0))
            fps_real = fps / fps_base if fps_base != 0.0 else fps
            if fps_real <= 0.0:
                fps_real = 24.0
            return float(scn.frame_current) / fps_real
        except Exception:
            pass
    return _time.time()


def pattern_is_on(s, key, bpm, now=None, scene=None):
    p = get_pattern(s, key)
    bits = repeat_32(p.bits) if p else ("0" * 32)
    ts = playback_seconds(scene=scene, now=now)
    steps_per_second = max(1.0, float(bpm)) / 60.0
    idx = int(ts * steps_per_second) % 32
    return bits[idx] == "1"


def preview_seconds(scene=None, now=None):
    ts = playback_seconds(scene=scene, now=now)
    scn = scene if scene is not None else getattr(bpy.context, "scene", None)
    if scn and (not timeline_playing()):
        s = getattr(scn, "nels", None)
        if s:
            origin = float(getattr(s, "preview_time_origin", 0.0) or 0.0)
            if origin > 0.0:
                return max(0.0, ts - origin)
    return ts


def preview_pattern_is_on(bits, bpm, scene=None, now=None):
    bits32 = repeat_32(bits)
    ts = preview_seconds(scene=scene, now=now)
    steps_per_second = max(1.0, float(bpm)) / 60.0
    idx = int(ts * steps_per_second) % 32
    return bits32[idx] == "1"


def scale_factor_choice_from_value(val):
    try:
        fv = float(val)
    except Exception:
        return "CUSTOM"
    for key, pv in SCALE_FACTOR_PRESET_VALUES.items():
        if abs(fv - pv) <= 0.000001:
            return key
    return "CUSTOM"

def siren_index_from_name(name):
    m = re.match(r"^siren\s*(\d+)", str(name or "").strip().lower())
    if not m:
        return 0
    try:
        idx = int(m.group(1))
    except Exception:
        return 0
    return idx if 1 <= idx <= MAX_SIRENS else 0



def extra_index_from_name(name):
    m = re.match(r"^extra[_\-\s]?(\d+)(?:\..*)?$", str(name or "").strip().lower())
    if not m:
        return 0
    try:
        return int(m.group(1))
    except Exception:
        return 0


def scene_extra_objects(scene):
    if not scene:
        return []
    found = []
    for obj in scene.objects:
        idx = extra_index_from_name(obj.name)
        if idx > 0:
            found.append((idx, obj.name, obj))
    found.sort(key=lambda it: (it[0], it[1].lower()))
    return [it[2] for it in found]


def is_object_visible(obj):
    try:
        return not obj.hide_get()
    except Exception:
        return not bool(getattr(obj, "hide_viewport", False))


def set_object_visible(obj, show):
    hide = not bool(show)
    try:
        obj.hide_set(hide)
    except Exception:
        pass
    try:
        obj.hide_viewport = hide
    except Exception:
        pass
    try:
        obj.hide_render = hide
    except Exception:
        pass


def extra_display_name(obj):
    idx = extra_index_from_name(getattr(obj, "name", ""))
    if idx <= 0:
        return getattr(obj, "name", "")
    base = f"extra_{idx}".lower()
    nm = str(getattr(obj, "name", ""))
    if nm.lower() == base:
        return f"Extra {idx}"
    return f"Extra {idx} ({nm})"


def _name_has_any(name, keys):
    txt = str(name or "").lower()
    return any(k in txt for k in keys)


def scene_objects_by_keywords(scene, keywords):
    if not scene:
        return []
    out = []
    for obj in scene.objects:
        nm = str(getattr(obj, "name", ""))
        if nm.startswith(WHEEL_PREVIEW_PREFIX) or nm.startswith(LIGHT_ID_PREVIEW_PREFIX):
            continue
        if _name_has_any(nm, keywords):
            out.append(obj)
    return out

def object_side(name):
    nm = str(name or "").lower()
    tokens = [t for t in re.split(r"[^a-z0-9]+", nm) if t]

    left = any(t in LEFT_SIDE_TOKENS for t in tokens) or bool(re.search(r"(?:^|[_\-.])(l|lf|lr)(?:$|[_\-.])", nm))
    right = any(t in RIGHT_SIDE_TOKENS for t in tokens) or bool(re.search(r"(?:^|[_\-.])(r|rf|rr)(?:$|[_\-.])", nm))

    if left and not right:
        return "LEFT"
    if right and not left:
        return "RIGHT"
    return "CENTER"


def split_side_objects(objs):
    left = []
    right = []
    center = []
    for obj in objs:
        side = object_side(getattr(obj, "name", ""))
        if side == "LEFT":
            left.append(obj)
        elif side == "RIGHT":
            right.append(obj)
        else:
            center.append(obj)
    return left, right, center


def normalize_light_id_name(value):
    txt = str(value or "").strip().lower().replace("-", "_").replace(" ", "_")
    txt = re.sub(r"[^a-z0-9_]+", "", txt)
    return txt


def light_id_name_from_raw(value):
    if value is None:
        return ""
    txt = normalize_light_id_name(value)
    if txt in SOLLUMZ_LIGHT_ID_NAME_TO_VALUE:
        return txt
    try:
        iv = int(float(value))
    except Exception:
        return ""
    return SOLLUMZ_LIGHT_ID_VALUE_TO_NAME.get(iv, "")


def current_light_id_name(s):
    if not s:
        return "always_on"
    key = str(getattr(s, "car_light_id_target", "always_on") or "always_on")
    if key == "CUSTOM":
        custom_key = light_id_name_from_raw(getattr(s, "car_light_id_custom_value", 0))
        return custom_key or ""
    key = normalize_light_id_name(key)
    return key if key in SOLLUMZ_LIGHT_ID_NAME_TO_VALUE else "always_on"


def current_light_id_value(s):
    if not s:
        return 0
    key = str(getattr(s, "car_light_id_target", "always_on") or "always_on")
    if key == "CUSTOM":
        try:
            return max(0, int(getattr(s, "car_light_id_custom_value", 0) or 0))
        except Exception:
            return 0
    return int(SOLLUMZ_LIGHT_ID_NAME_TO_VALUE.get(normalize_light_id_name(key), 0))


def light_id_face_select_ready(context):
    obj = getattr(context, "active_object", None)
    if not obj or getattr(obj, "type", "") != "MESH":
        return False
    if getattr(context, "mode", "") != "EDIT_MESH":
        return False
    try:
        mode = getattr(context.tool_settings, "mesh_select_mode", (False, False, False))
        return bool(mode[2])
    except Exception:
        return False


def editable_light_id_face_layer(bm, create=False):
    if not bm:
        return None
    layers = getattr(getattr(bm, "faces", None), "layers", None)
    ints = getattr(layers, "int", None) if layers else None
    if ints is None:
        return None

    for name in ("light_id", "lightid", "vehicle_light_id", "vehiclelightid", "external_light_id", "externallightid"):
        try:
            layer = ints.get(name)
        except Exception:
            layer = None
        if layer is not None:
            return layer

    try:
        for name in ints.keys():
            if normalize_light_id_name(name) in SOLLUMZ_LIGHT_ID_ATTR_NAMES:
                layer = ints.get(name)
                if layer is not None:
                    return layer
    except Exception:
        pass

    if not create:
        return None
    try:
        return ints.new("light_id")
    except Exception:
        return None

def remove_object_and_mesh_data(obj):
    if not obj:
        return
    mesh = getattr(obj, "data", None)
    try:
        bpy.data.objects.remove(obj, do_unlink=True)
    except Exception:
        return
    try:
        if mesh and getattr(mesh, "users", 0) <= 0:
            bpy.data.meshes.remove(mesh)
    except Exception:
        pass


def light_id_preview_material(light_key):
    key = normalize_light_id_name(light_key)
    mat_name = f"_gta000_lightid_mat_{key}"
    mat = bpy.data.materials.get(mat_name)
    if mat is None:
        mat = bpy.data.materials.new(mat_name)
    rgb = SOLLUMZ_LIGHT_ID_COLOR.get(key, (1.0, 1.0, 1.0))
    mat.use_nodes = True
    nodes = mat.node_tree.nodes
    links = mat.node_tree.links
    nodes.clear()
    out = nodes.new("ShaderNodeOutputMaterial")
    emit = nodes.new("ShaderNodeEmission")
    emit.inputs[0].default_value = (rgb[0], rgb[1], rgb[2], 1.0)
    emit.inputs[1].default_value = 6.0
    out.location = (220.0, 0.0)
    emit.location = (0.0, 0.0)
    links.new(emit.outputs[0], out.inputs[0])
    if hasattr(mat, "shadow_method"):
        try:
            mat.shadow_method = "NONE"
        except Exception:
            pass
    return mat


def _mesh_light_id_attr_values(mesh, attr):
    data = getattr(attr, "data", None)
    domain = str(getattr(attr, "domain", "") or "").upper()
    if not data:
        return []
    if domain == "FACE":
        return [light_id_name_from_raw(getattr(item, "value", None)) for item in data[:len(mesh.polygons)]]
    if domain == "CORNER":
        values = []
        data_len = len(data)
        for poly in mesh.polygons:
            names = []
            start = int(getattr(poly, "loop_start", 0) or 0)
            total = int(getattr(poly, "loop_total", 0) or 0)
            for li in range(start, min(start + total, data_len)):
                key = light_id_name_from_raw(getattr(data[li], "value", None))
                if key:
                    names.append(key)
            if not names:
                values.append("")
            else:
                counts = {}
                for key in names:
                    counts[key] = counts.get(key, 0) + 1
                values.append(max(counts.items(), key=lambda item: item[1])[0])
        return values
    return []


def mesh_light_id_face_groups(obj):
    mesh = getattr(obj, "data", None)
    if not obj or getattr(obj, "type", "") != "MESH" or mesh is None:
        return {}

    candidates = []
    attrs = getattr(mesh, "attributes", None)
    if attrs:
        for attr in attrs:
            domain = str(getattr(attr, "domain", "") or "").upper()
            if domain not in {"FACE", "CORNER"}:
                continue
            name_key = normalize_light_id_name(getattr(attr, "name", ""))
            values = _mesh_light_id_attr_values(mesh, attr)
            hits = sum(1 for key in values if key)
            if hits <= 0:
                continue
            score = min(hits, 50)
            if name_key in SOLLUMZ_LIGHT_ID_ATTR_NAMES:
                score += 200
            if "light" in name_key:
                score += 40
            if "id" in name_key:
                score += 20
            if "external" in name_key or "state" in name_key:
                score += 10
            candidates.append((score, values))

    if not candidates and hasattr(mesh, "polygon_layers_int"):
        try:
            for layer in mesh.polygon_layers_int:
                name_key = normalize_light_id_name(getattr(layer, "name", ""))
                values = [light_id_name_from_raw(getattr(item, "value", None)) for item in layer.data[:len(mesh.polygons)]]
                hits = sum(1 for key in values if key)
                if hits <= 0:
                    continue
                score = min(hits, 50)
                if name_key in SOLLUMZ_LIGHT_ID_ATTR_NAMES:
                    score += 200
                if "light" in name_key:
                    score += 40
                if "id" in name_key:
                    score += 20
                candidates.append((score, values))
        except Exception:
            pass

    if not candidates:
        return {}

    candidates.sort(key=lambda item: item[0], reverse=True)
    values = candidates[0][1]
    groups = {}
    for poly_index, light_key in enumerate(values):
        if not light_key:
            continue
        groups.setdefault(light_key, []).append(poly_index)
    return groups


def light_id_preview_object_name(src_obj, light_key):
    return f"{LIGHT_ID_PREVIEW_PREFIX}{safe_name(src_obj.name)}_{normalize_light_id_name(light_key)}"


def clear_light_id_preview_objects(scene):
    if not scene:
        return 0
    removed = 0
    for obj in list(scene.objects):
        if str(getattr(obj, "name", "")).startswith(LIGHT_ID_PREVIEW_PREFIX):
            remove_object_and_mesh_data(obj)
            removed += 1
    return removed


def light_id_preview_signature(scene):
    if not scene:
        return ""
    parts = []
    for obj in scene.objects:
        if getattr(obj, "type", "") != "MESH":
            continue
        nm = str(getattr(obj, "name", ""))
        if nm.startswith(LIGHT_ID_PREVIEW_PREFIX) or nm.startswith(WHEEL_PREVIEW_PREFIX):
            continue
        mesh = getattr(obj, "data", None)
        if mesh is None:
            continue
        attrs = []
        for attr in getattr(mesh, "attributes", []) or []:
            domain = str(getattr(attr, "domain", "") or "").upper()
            if domain in {"FACE", "CORNER"}:
                attrs.append(f"{attr.name}:{domain}")
        if hasattr(mesh, "polygon_layers_int"):
            try:
                for layer in mesh.polygon_layers_int:
                    attrs.append(f"{layer.name}:FACE")
            except Exception:
                pass
        if not attrs:
            continue
        parts.append(f"{obj.name}|{mesh.name}|{len(mesh.polygons)}|{','.join(sorted(set(attrs)))}")
    parts.sort()
    return "\n".join(parts)


def build_light_id_preview_object(scene, src_obj, light_key, poly_indices):
    if not scene or not src_obj or not poly_indices:
        return None

    name = light_id_preview_object_name(src_obj, light_key)
    existing = bpy.data.objects.get(name)
    if existing and getattr(existing, "type", "") == "MESH":
        existing["_gta000_lightid_key"] = normalize_light_id_name(light_key)
        existing["_gta000_lightid_source"] = src_obj.name
        existing.parent = src_obj
        existing.matrix_parent_inverse = src_obj.matrix_world.inverted()
        existing.hide_select = True
        return existing

    bm = bmesh.new()
    bm.from_mesh(src_obj.data)
    bm.faces.ensure_lookup_table()
    keep = set(int(i) for i in poly_indices)
    delete_faces = [face for idx, face in enumerate(bm.faces) if idx not in keep]
    if delete_faces:
        bmesh.ops.delete(bm, geom=delete_faces, context="FACES")
    if not bm.faces:
        bm.free()
        return None

    for vert in bm.verts:
        if not vert.link_faces:
            continue
        normal = Vector((0.0, 0.0, 0.0))
        for face in vert.link_faces:
            normal += face.normal
        if normal.length > 0.0:
            normal.normalize()
            vert.co += normal * 0.0003

    mesh = bpy.data.meshes.new(name)
    bm.to_mesh(mesh)
    bm.free()
    mesh.materials.clear()
    mesh.materials.append(light_id_preview_material(light_key))
    for poly in mesh.polygons:
        poly.material_index = 0

    preview = bpy.data.objects.new(name, mesh)
    preview["_gta000_lightid_key"] = normalize_light_id_name(light_key)
    preview["_gta000_lightid_source"] = src_obj.name
    preview.hide_select = True
    preview.parent = src_obj
    preview.matrix_parent_inverse = src_obj.matrix_world.inverted()
    preview.show_in_front = True

    linked = False
    for col in getattr(src_obj, "users_collection", []) or []:
        try:
            col.objects.link(preview)
            linked = True
        except Exception:
            pass
    if (not linked) and getattr(scene, "collection", None):
        scene.collection.objects.link(preview)
    return preview


def rebuild_light_id_preview_objects(scene, s):
    if not scene or not s:
        return 0
    clear_light_id_preview_objects(scene)
    created = 0
    for obj in scene.objects:
        if getattr(obj, "type", "") != "MESH":
            continue
        nm = str(getattr(obj, "name", ""))
        if nm.startswith(LIGHT_ID_PREVIEW_PREFIX) or nm.startswith(WHEEL_PREVIEW_PREFIX):
            continue
        groups = mesh_light_id_face_groups(obj)
        if not groups:
            continue
        for light_key, poly_indices in groups.items():
            if build_light_id_preview_object(scene, obj, light_key, poly_indices):
                created += 1
    s.car_light_id_signature = light_id_preview_signature(scene)
    return created


def apply_light_id_preview(scene, s, states):
    if not scene or not s:
        return 0

    now_ts = _time.time()
    last_checked = float(getattr(s, "car_light_id_checked_at", 0.0) or 0.0)
    has_preview = any(str(getattr(obj, "name", "")).startswith(LIGHT_ID_PREVIEW_PREFIX) for obj in scene.objects)
    if (not has_preview) or (now_ts - last_checked >= 1.0):
        signature = light_id_preview_signature(scene)
        s.car_light_id_checked_at = now_ts
        if signature != str(getattr(s, "car_light_id_signature", "") or ""):
            rebuild_light_id_preview_objects(scene, s)

    touched = 0
    for obj in scene.objects:
        if not str(getattr(obj, "name", "")).startswith(LIGHT_ID_PREVIEW_PREFIX):
            continue
        key = normalize_light_id_name(obj.get("_gta000_lightid_key", ""))
        show = bool(states.get(key, False))
        if is_object_visible(obj) != show:
            set_object_visible(obj, show)
            touched += 1
    return touched

def wheel_bone_key(name):
    nm = str(name or "").lower()
    m = re.search(r"wheel[_\-]?(lf|rf|lr|rr)", nm)
    if not m:
        return ""
    return f"wheel_{m.group(1)}"


def wheel_pose_bones(scene):
    s = getattr(scene, "nels", None) if scene else None
    if not s or not s.armature_name:
        return (None, [])
    arm = bpy.data.objects.get(s.armature_name)
    if not arm or arm.type != "ARMATURE":
        return (None, [])

    all_wheel = [pb for pb in arm.pose.bones if "wheel" in pb.name.lower()]
    keyed = {}
    for pb in all_wheel:
        key = wheel_bone_key(pb.name)
        if key and key not in keyed:
            keyed[key] = pb

    if keyed:
        ordered = [keyed[k] for k in ("wheel_lf", "wheel_rf", "wheel_lr", "wheel_rr") if k in keyed]
        if ordered:
            return (arm, ordered)
    return (arm, all_wheel)


def has_real_wheel_for_bone(scene, arm, bone_name):
    for obj in scene.objects:
        if obj.type != "MESH" or obj.name.startswith(WHEEL_PREVIEW_PREFIX):
            continue
        nm = obj.name.lower()
        if "wheel" not in nm or "steer" in nm:
            continue
        if obj.parent == arm and obj.parent_type == "BONE" and obj.parent_bone == bone_name:
            return True
    return False
def clear_wheel_preview_objects(scene):
    if not scene:
        return 0
    removed = 0
    for obj in list(scene.objects):
        if obj.name.startswith(WHEEL_PREVIEW_PREFIX):
            try:
                bpy.data.objects.remove(obj, do_unlink=True)
                removed += 1
            except Exception:
                pass
    return removed


def find_source_wheel_object(context, arm, bones):
    scene = getattr(context, "scene", None) if context else None
    if not scene:
        return None

    bone_names = {pb.name for pb in bones}
    active = getattr(context, "active_object", None)
    if (
        active
        and active.type == "MESH"
        and (not active.name.startswith(WHEEL_PREVIEW_PREFIX))
        and active.parent == arm
        and active.parent_type == "BONE"
        and active.parent_bone in bone_names
    ):
        return active

    preferred = ("wheel_lf", "wheel_rf", "wheel_lr", "wheel_rr")
    candidates = []
    for obj in scene.objects:
        if obj.type != "MESH" or obj.name.startswith(WHEEL_PREVIEW_PREFIX):
            continue
        if obj.parent == arm and obj.parent_type == "BONE" and obj.parent_bone in bone_names:
            pb = obj.parent_bone.lower()
            prio = preferred.index(pb) if pb in preferred else 99
            candidates.append((prio, obj.name.lower(), obj))

    if candidates:
        candidates.sort(key=lambda it: (it[0], it[1]))
        return candidates[0][2]

    # Fallback: choose a likely wheel mesh by name/proximity, but explicitly ignore steering wheels.
    bone_world_positions = [arm.matrix_world @ pb.head for pb in bones]
    loose = []
    for obj in scene.objects:
        nm = obj.name.lower()
        if obj.type != "MESH" or obj.name.startswith(WHEEL_PREVIEW_PREFIX):
            continue
        if "steer" in nm:
            continue
        if "wheel" not in nm:
            continue
        if not bone_world_positions:
            continue
        pos = obj.matrix_world.translation
        dist = min((pos - bp).length for bp in bone_world_positions)
        loose.append((dist, nm, obj))

    if loose:
        loose.sort(key=lambda it: (it[0], it[1]))
        return loose[0][2]
    return None


def _copy_obj_rotation(dst, src):
    dst.rotation_mode = src.rotation_mode
    if src.rotation_mode == "QUATERNION":
        dst.rotation_quaternion = src.rotation_quaternion.copy()
    elif src.rotation_mode == "AXIS_ANGLE":
        dst.rotation_axis_angle = tuple(src.rotation_axis_angle)
    else:
        dst.rotation_euler = src.rotation_euler.copy()


def simulate_tyres_on_wheel_bones(context, arm, bones):
    scene = getattr(context, "scene", None) if context else None
    try:
        vl = getattr(context, "view_layer", None) if context else getattr(bpy.context, "view_layer", None)
        if vl:
            vl.update()
    except Exception:
        pass

    if not scene:
        return (0, 0, "Scene not available")

    src = find_source_wheel_object(context, arm, bones)
    if not src:
        return (0, 0, "Warning: Could not find a source wheel mesh (select/use a real wheel mesh, not steering wheel)")

    # Determine source wheel bone robustly (explicit parent > name key > nearest).
    bone_head_world = {}
    for pb in bones:
        bd = arm.data.bones.get(pb.name)
        if bd:
            bone_head_world[pb.name] = arm.matrix_world @ bd.head_local
        else:
            bone_head_world[pb.name] = arm.matrix_world @ pb.head

    source_bone_name = ""
    if src.parent == arm and src.parent_type == "BONE" and src.parent_bone in bone_head_world:
        source_bone_name = src.parent_bone

    if not source_bone_name:
        src_key = wheel_bone_key(src.name)
        if src_key:
            for pb in bones:
                if wheel_bone_key(pb.name) == src_key:
                    source_bone_name = pb.name
                    break

    if not source_bone_name:
        src_pos = src.matrix_world.translation
        ref_bone = min(bones, key=lambda pb: (src_pos - bone_head_world[pb.name]).length)
        source_bone_name = ref_bone.name

    src_world = src.matrix_world.copy()
    src_head = bone_head_world[source_bone_name]
    source_pose_bone = arm.pose.bones.get(source_bone_name)
    source_bone_world = (arm.matrix_world @ source_pose_bone.matrix.copy()) if source_pose_bone else Matrix.Translation(src_head)
    source_local = source_bone_world.inverted() @ src_world

    linked = 0
    skipped = 0
    cleaned = 0
    for pb in bones:
        nm = f"{WHEEL_PREVIEW_PREFIX}{pb.name}"
        is_source_bone = pb.name == source_bone_name
        has_real = has_real_wheel_for_bone(scene, arm, pb.name)
        if is_source_bone or has_real:
            stale = bpy.data.objects.get(nm)
            if stale:
                try:
                    bpy.data.objects.remove(stale, do_unlink=True)
                    cleaned += 1
                except Exception:
                    pass
            skipped += 1
            continue

        dup = bpy.data.objects.get(nm)
        if not dup:
            dup = src.copy()
            dup.data = src.data
            dup.name = nm
            linked_to_any = False
            if src.users_collection:
                for col in src.users_collection:
                    try:
                        col.objects.link(dup)
                        linked_to_any = True
                    except Exception:
                        pass
            if (not linked_to_any) and scene.collection:
                scene.collection.objects.link(dup)

        dup.parent = None
        dup.parent_type = "OBJECT"
        dup.parent_bone = ""
        target_pose_world = arm.matrix_world @ pb.matrix.copy()
        target_world = target_pose_world @ source_local
        dup.matrix_world = target_world
        _copy_obj_rotation(dup, src)
        dup.scale = src.scale.copy()
        set_object_visible(dup, True)
        linked += 1

    msg = f"Tyre simulation updated using '{src.name}': {linked} wheel previews linked, {cleaned} stale removed"
    return linked, skipped, msg


def normalize_import_scale_factor(value):
    try:
        sc = float(value)
    except Exception:
        sc = 0.5
    if sc > 1.0:
        sc = 1.0 / sc
    return max(0.0, sc)


def apply_scale_to_settings(s, factor):
    if not s:
        return
    s.scale_factor = normalize_import_scale_factor(factor)
    sync_scale_factor_controls(s)


def apply_scale_to_siren(si, factor):
    # Legacy compatibility for older saved configs; runtime scale now uses scene-level scale_factor.
    sc = normalize_import_scale_factor(factor)
    if abs(sc - 0.5) < 0.000001:
        si.scale_mode = "PRESET"
        si.scale_preset = "SCALE_50"
    elif abs(sc - 0.1) < 0.000001:
        si.scale_mode = "PRESET"
        si.scale_preset = "SCALE_10"
    elif abs(sc - 0.01) < 0.000001:
        si.scale_mode = "PRESET"
        si.scale_preset = "SCALE_01"
    else:
        si.scale_mode = "CUSTOM"
        si.custom_scale = sc


def auto_detect_scene_sirens(scene, create_missing=True, sync_direction=False):
    s = getattr(scene, "nels", None)
    if not s:
        return (0, 0, 0)

    scene_objects = list(getattr(scene, "objects", [])) if scene else list(bpy.data.objects)

    arm = None
    if s.armature_name:
        arm = next((obj for obj in scene_objects if obj.name == s.armature_name and obj.type == "ARMATURE"), None)

    best_arm = arm
    best_bones = {}
    best_count = 0
    for obj in scene_objects:
        if obj.type != "ARMATURE":
            continue
        bone_map = {}
        for b in obj.data.bones:
            idx = siren_index_from_name(b.name)
            if idx and idx not in bone_map:
                bone_map[idx] = b.name
        if len(bone_map) > best_count:
            best_count = len(bone_map)
            best_arm = obj
            best_bones = bone_map

    if best_arm and s.armature_name != best_arm.name:
        s.armature_name = best_arm.name
    if not best_bones and best_arm and best_arm.type == "ARMATURE":
        for b in best_arm.data.bones:
            idx = siren_index_from_name(b.name)
            if idx and idx not in best_bones:
                best_bones[idx] = b.name

    obj_map = {}
    for obj in scene_objects:
        idx = siren_index_from_name(obj.name)
        if idx and idx not in obj_map:
            obj_map[idx] = obj.name
        if best_arm and obj.parent == best_arm and obj.parent_type == "BONE":
            bidx = siren_index_from_name(obj.parent_bone)
            if bidx and bidx not in obj_map:
                obj_map[bidx] = obj.name

    max_idx = max([0, len(s.sirens)] + list(obj_map.keys()) + list(best_bones.keys()))
    if create_missing and max_idx > len(s.sirens):
        ensure_sirens(s, max_idx)

    linked = 0
    for i, si in enumerate(s.sirens, start=1):
        if (not si.bone_name) and i in best_bones:
            si.bone_name = best_bones[i]
            linked += 1

        if (not si.object_name) and i in obj_map:
            si.object_name = obj_map[i]
            o = bpy.data.objects.get(si.object_name)
            if o:
                _store_rest_loc(o)
            linked += 1

        if si.object_name and (not si.bone_name) and best_arm:
            o = bpy.data.objects.get(si.object_name)
            if o and o.parent == best_arm and o.parent_type == "BONE":
                bidx = siren_index_from_name(o.parent_bone)
                if bidx == i:
                    si.bone_name = o.parent_bone

        si.enabled = bool(si.object_name or si.bone_name)

    ensure_body_opening_defaults(s)
    for op in s.body_openings:
        if op.object_name and op.object_name not in bpy.data.objects:
            op.object_name = ""
        if op.anchor_name and op.anchor_name not in bpy.data.objects:
            op.anchor_name = ""
        if op.bone_name:
            has_bone = bool(arm and op.bone_name in arm.data.bones)
            if not has_bone:
                for obj in bpy.data.objects:
                    if obj.type != "ARMATURE":
                        continue
                    if op.bone_name in obj.data.bones:
                        has_bone = True
                        if not arm:
                            arm = obj
                            s.armature_name = obj.name
                        break
            if not has_bone:
                op.bone_name = ""

    if sync_direction:
        apply_all_siren_directions(scene)

    return (len(obj_map), len(best_bones), linked)

def siren_obj(si):
    if si.object_name and si.object_name in bpy.data.objects:
        return bpy.data.objects[si.object_name]
    n = f"siren{si.index}"
    return bpy.data.objects.get(n)



def siren_pose_bone(scene, si):
    s = getattr(scene, "nels", None) if scene else None
    candidates = []
    if s and s.armature_name:
        arm = bpy.data.objects.get(s.armature_name)
        if arm and arm.type == "ARMATURE":
            candidates.append(arm)
    for obj in bpy.data.objects:
        if obj.type == "ARMATURE" and obj not in candidates:
            candidates.append(obj)

    names = []
    if si and si.bone_name:
        names.append(si.bone_name)
    if si:
        names.append(f"siren{si.index}")

    for arm in candidates:
        for bn in names:
            if not bn:
                continue
            pb = arm.pose.bones.get(bn)
            if pb:
                if si and not si.bone_name:
                    si.bone_name = pb.name
                if s and not s.armature_name:
                    s.armature_name = arm.name
                return arm, pb
    return None, None


def swappable_siren_items(self, context):
    scene = getattr(context, "scene", None) if context else getattr(bpy.context, "scene", None)
    s = getattr(scene, "nels", None) if scene else None
    items = []
    if s:
        for si in s.sirens:
            obj = siren_obj(si)
            arm, pb = siren_pose_bone(scene, si)
            if obj and obj.type == "MESH" and arm and pb:
                items.append((str(si.index), f"Siren {si.index}", f"{obj.name} on {arm.name}:{pb.name}"))
    if items:
        return items
    return [("__NONE__", "(No complete sirens found)", "Link mesh and bone for at least two sirens first")]


def siren_slot_by_index(s, idx):
    if not s:
        return None
    try:
        needle = int(idx)
    except Exception:
        return None
    for si in s.sirens:
        if int(getattr(si, "index", 0)) == needle:
            return si
    return None


SIREN_SNAPSHOT_FIELDS = [
    "enabled", "siren_type", "rotator_speed_mode", "rotator_custom_percent", "rotator_clockwise",
    "pattern_source", "pattern_choice", "custom_visibility", "custom_bits", "custom_value",
    "color_mode", "color_preset", "direction_mode", "direction_preset", "custom_direction",
    "scale_mode", "scale_preset", "custom_scale", "sync_to_bpm", "flash_preview",
    "flash", "light", "spot_light", "cast_shadows", "light_group", "start_delay",
    "light_speed", "light_multiples", "corona_intensity", "corona_size", "corona_pull",
    "light_intensity", "corona_face_camera", "object_name", "anchor_name", "bone_name",
]


def capture_siren_slot_snapshot(si):
    data = {}
    for key in SIREN_SNAPSHOT_FIELDS:
        try:
            value = getattr(si, key)
            if isinstance(value, (list, tuple)):
                value = tuple(value)
            data[key] = value
        except Exception:
            pass
    try:
        data["custom_color"] = tuple(si.custom_color)
    except Exception:
        data["custom_color"] = (1.0, 1.0, 1.0)
    return data


def apply_siren_slot_snapshot(s, si, idx, data):
    add_siren(s, si, idx)
    for key, value in dict(data or {}).items():
        if key in {"index", "name"}:
            continue
        try:
            setattr(si, key, value)
        except Exception:
            pass
    si.index = idx
    si.name = f"siren{idx}"
    sync_siren_selector_controls(si)


def scene_present_siren_indices(scene, s=None):
    used = set()
    if scene:
        for obj in scene.objects:
            try:
                idx = siren_index_from_name(getattr(obj, "name", ""))
                if idx > 0:
                    used.add(idx)
                if getattr(obj, "parent_type", "") == "BONE":
                    idx = siren_index_from_name(getattr(obj, "parent_bone", ""))
                    if idx > 0:
                        used.add(idx)
                if getattr(obj, "type", "") == "ARMATURE":
                    for bone in getattr(getattr(obj, "data", None), "bones", []):
                        idx = siren_index_from_name(getattr(bone, "name", ""))
                        if idx > 0:
                            used.add(idx)
            except Exception:
                continue
    if s:
        for si in getattr(s, "sirens", []):
            try:
                if siren_obj(si) or siren_pose_bone(scene, si)[1]:
                    used.add(int(getattr(si, "index", 0) or 0))
            except Exception:
                pass
    return used


def renumber_target_items(self, context):
    scene = getattr(context, "scene", None) if context else getattr(bpy.context, "scene", None)
    s = getattr(scene, "nels", None) if scene else None
    if not s or not s.sirens:
        return [("__NONE__", "(No sirens configured)", "")]
    source = resolve_context_siren(scene, s, require_linked=False, update_active=False)
    used = scene_present_siren_indices(scene, s=s)
    limit = max(0, min(int(getattr(s, "siren_count", len(s.sirens)) or len(s.sirens)), len(s.sirens)))
    items = [(str(idx), f"Siren {idx}", f"Rename the selected siren hierarchy to siren{idx}") for idx in range(1, limit + 1) if idx not in used]
    return items if items else [("__NONE__", "(No available siren numbers)", "All configured siren numbers already exist in the scene")]


def selected_siren_root_object(context, fallback=None):
    obj = getattr(getattr(context, "view_layer", None), "objects", None)
    active = getattr(obj, "active", None) if obj else getattr(bpy.context, "active_object", None)
    cur = active or fallback
    while cur and getattr(cur, "parent", None) and getattr(cur.parent, "type", "") != "ARMATURE" and getattr(cur, "parent_type", "") != "BONE":
        cur = cur.parent
    return cur or fallback


def bone_tree_names(arm, root_name):
    if not arm or getattr(arm, "type", "") != "ARMATURE" or not root_name:
        return []
    root = getattr(getattr(arm, "data", None), "bones", {}).get(root_name) if hasattr(getattr(arm, "data", None), "bones") else None
    if not root:
        return []
    found = []
    stack = [root]
    while stack:
        cur = stack.pop(0)
        if not cur or cur.name in found:
            continue
        found.append(cur.name)
        stack.extend(list(getattr(cur, "children", [])))
    return found


def rename_pose_rest_keys(arm, name_map):
    if not arm:
        return
    for old_name, new_name in dict(name_map or {}).items():
        old_key = _pose_rest_key(old_name)
        new_key = _pose_rest_key(new_name)
        if old_key == new_key:
            continue
        try:
            if old_key in arm:
                arm[new_key] = list(arm[old_key])
                del arm[old_key]
        except Exception:
            pass


def capture_bone_parent_links(scene, arm, bone_names):
    links = []
    if not scene or not arm:
        return links
    names = set(bone_names or [])
    for obj in scene.objects:
        try:
            if obj.parent == arm and obj.parent_type == "BONE" and obj.parent_bone in names:
                _store_rest_loc(obj)
                links.append((obj, arm, obj.parent_bone, obj.matrix_world.copy()))
        except Exception:
            continue
    return links


def restore_bone_parent_links(links, name_map):
    for obj, arm, old_bone, matrix_world in list(links or []):
        try:
            obj.parent = arm
            obj.parent_type = "BONE"
            obj.parent_bone = name_map.get(old_bone, old_bone)
            obj.matrix_world = matrix_world
            _store_rest_loc(obj, force=True)
        except Exception:
            continue


def siren_bone_subtree_objects(scene, arm, root_bone_name, exclude=None):
    names = set(bone_tree_names(arm, root_bone_name))
    found = []
    exclude = set(exclude or [])
    if not scene or not arm or not names:
        return found
    for obj in scene.objects:
        try:
            if obj in exclude:
                continue
            if obj.parent == arm and obj.parent_type == "BONE" and obj.parent_bone in names:
                found.append(obj)
        except Exception:
            continue
    return found


def rename_siren_bone_hierarchy(scene, arm, root_bone_name, old_index, new_index):
    bone_names = bone_tree_names(arm, root_bone_name)
    if not bone_names:
        return {}, ""

    desired_map = {}
    for old_name in bone_names:
        desired = retarget_siren_name_token(old_name, old_index, new_index)
        desired = re.sub(r'\.\d{3}$', '', desired)
        if old_name == root_bone_name:
            desired = f"siren{int(new_index)}"
        desired_map[old_name] = desired

    conflicts = []
    existing = getattr(getattr(arm, "data", None), "bones", None)
    for old_name, new_name in desired_map.items():
        if not new_name:
            continue
        bone = existing.get(new_name) if existing else None
        if bone and bone.name not in desired_map:
            conflicts.append(new_name)
    if conflicts:
        raise RuntimeError(f"Target bone name already exists: {conflicts[0]}")

    child_links = capture_bone_parent_links(scene, arm, bone_names)
    old_active = getattr(bpy.context.view_layer.objects, "active", None)
    old_mode = getattr(bpy.context, "mode", "OBJECT")
    stamp = _time.time_ns()
    temp_map = {old_name: f"__nels_ren_{stamp}_{i}" for i, old_name in enumerate(bone_names, start=1)}

    try:
        if old_mode != "OBJECT":
            bpy.ops.object.mode_set(mode="OBJECT")
        bpy.ops.object.select_all(action="DESELECT")
        arm.select_set(True)
        bpy.context.view_layer.objects.active = arm
        bpy.ops.object.mode_set(mode="EDIT")
        for old_name in bone_names:
            eb = arm.data.edit_bones.get(old_name)
            if eb:
                eb.name = temp_map[old_name]
        for old_name in bone_names:
            eb = arm.data.edit_bones.get(temp_map[old_name])
            if eb:
                eb.name = desired_map[old_name]
        bpy.ops.object.mode_set(mode="OBJECT")
    finally:
        try:
            if getattr(bpy.context, "mode", "OBJECT") != "OBJECT":
                bpy.ops.object.mode_set(mode="OBJECT")
        except Exception:
            pass
        try:
            if old_active and old_active.name in bpy.data.objects:
                bpy.context.view_layer.objects.active = old_active
        except Exception:
            pass
        try:
            if old_mode != "OBJECT" and getattr(bpy.context, "mode", "OBJECT") == "OBJECT":
                bpy.ops.object.mode_set(mode=old_mode)
        except Exception:
            pass

    restore_bone_parent_links(child_links, desired_map)
    rename_pose_rest_keys(arm, desired_map)
    for new_name in desired_map.values():
        try:
            pb = arm.pose.bones.get(new_name)
            if pb:
                _store_rest_pose_bone(arm, pb, force=True)
        except Exception:
            pass
    return desired_map, desired_map.get(root_bone_name, "")


def pick_anchor_object(context, arm, si):
    active = getattr(context.view_layer.objects, "active", None)
    selected = [o for o in context.selected_objects if o and o.type != "ARMATURE"]

    if si and si.object_name:
        non_siren = [o for o in selected if o.name != si.object_name]
        if non_siren:
            selected = non_siren

    if active and active in selected:
        return active
    if selected:
        return selected[0]
    if active and active.type != "ARMATURE":
        if not si or active.name != si.object_name:
            return active

    if si and si.anchor_name and si.anchor_name in bpy.data.objects:
        anchor = bpy.data.objects[si.anchor_name]
        if anchor.type != "ARMATURE":
            return anchor
    return None


def pick_reference_object(context, si):
    active = getattr(context.view_layer.objects, "active", None)
    selected = [o for o in context.selected_objects if o and o.type != "ARMATURE"]

    if si and si.object_name:
        selected = [o for o in selected if o.name != si.object_name]

    if active and active in selected:
        return active
    if selected:
        return selected[0]
    if active and active.type != "ARMATURE":
        if not si or active.name != si.object_name:
            return active
    return None


def pick_any_reference_object(context):
    active = getattr(getattr(context, "view_layer", None), "objects", None)
    active = getattr(active, "active", None)
    selected = [o for o in getattr(context, "selected_objects", []) if o and getattr(o, "type", "") != "ARMATURE"]

    if active and active in selected:
        return active
    if selected:
        return selected[0]
    if active and getattr(active, "type", "") != "ARMATURE":
        return active
    return None


def set_object_origin_from_reference(obj, reference):
    if not obj or not reference:
        return False, "Missing source or reference object"
    if getattr(obj, "type", "") != "MESH":
        return False, "The linked siren object must be a mesh"
    if getattr(obj, "data", None) is None or not hasattr(obj.data, "transform"):
        return False, "The linked siren object has no editable mesh data"

    old_world = obj.matrix_world.copy()
    new_world = old_world.copy()
    new_world.translation = reference.matrix_world.translation.copy()

    try:
        transform = new_world.inverted() @ old_world
    except Exception:
        return False, "Could not calculate the new siren origin transform"

    try:
        if getattr(obj.data, "users", 1) > 1:
            obj.data = obj.data.copy()
        obj.data.transform(transform)
        if hasattr(obj.data, "update"):
            obj.data.update()
        obj.matrix_world = new_world
        _store_rest_loc(obj, force=True)
        return True, f"Set {obj.name} origin to {reference.name}"
    except Exception as ex:
        return False, f"Could not set siren origin: {ex}"

def set_object_origin_to_local_point(obj, local_point):
    if not obj:
        return False, "Missing object"
    if getattr(obj, "type", "") != "MESH":
        return False, "The active object must be a mesh"
    if getattr(obj, "data", None) is None or not hasattr(obj.data, "transform"):
        return False, "The active mesh has no editable geometry data"

    try:
        point = Vector(local_point)
    except Exception:
        return False, "Could not read the selected midpoint"

    old_world = obj.matrix_world.copy()
    new_world = old_world @ Matrix.Translation(point)

    try:
        if getattr(obj.data, "users", 1) > 1:
            obj.data = obj.data.copy()
        obj.data.transform(Matrix.Translation(-point))
        if hasattr(obj.data, "update"):
            obj.data.update()
        obj.matrix_world = new_world
        _store_rest_loc(obj, force=True)
        return True, f"Set {obj.name} origin to the current selection"
    except Exception as ex:
        return False, f"Could not set the object origin: {ex}"


def set_object_origin_to_world_point(obj, world_point):
    if not obj:
        return False, "Missing object"
    if getattr(obj, "type", "") != "MESH":
        return False, "The selected object must be a mesh"
    if getattr(obj, "data", None) is None or not hasattr(obj.data, "transform"):
        return False, "The selected mesh has no editable geometry data"

    try:
        point = Vector(world_point)
    except Exception:
        return False, "Could not read the target bone location"

    old_world = obj.matrix_world.copy()
    new_world = old_world.copy()
    new_world.translation = point

    try:
        transform = new_world.inverted() @ old_world
    except Exception:
        return False, "Could not calculate the new origin transform"

    try:
        if getattr(obj.data, "users", 1) > 1:
            obj.data = obj.data.copy()
        obj.data.transform(transform)
        if hasattr(obj.data, "update"):
            obj.data.update()
        obj.matrix_world = new_world
        _store_rest_loc(obj, force=True)
        return True, f"Set {obj.name} origin to its linked bone"
    except Exception as ex:
        return False, f"Could not set the object origin: {ex}"


def edit_selection_local_center(obj, context):
    if not obj or getattr(obj, "type", "") != "MESH":
        return None, "The active object must be a mesh"
    if getattr(obj, "mode", "") != "EDIT":
        return None, "Switch the active mesh to Edit Mode first"

    try:
        bm = bmesh.from_edit_mesh(obj.data)
    except Exception as ex:
        return None, f"Could not read the edit selection: {ex}"

    mesh_mode = tuple(getattr(getattr(context, "tool_settings", None), "mesh_select_mode", (True, False, False)) or (True, False, False))
    face_points = [f.calc_center_median().copy() for f in bm.faces if getattr(f, "select", False)]
    edge_points = [((e.verts[0].co.copy() + e.verts[1].co.copy()) * 0.5) for e in bm.edges if getattr(e, "select", False)]
    vert_points = [v.co.copy() for v in bm.verts if getattr(v, "select", False)]

    points = []
    if len(mesh_mode) > 2 and mesh_mode[2] and face_points:
        points = face_points
    elif len(mesh_mode) > 1 and mesh_mode[1] and edge_points:
        points = edge_points
    elif len(mesh_mode) > 0 and mesh_mode[0] and vert_points:
        points = vert_points
    elif face_points:
        points = face_points
    elif edge_points:
        points = edge_points
    else:
        points = vert_points

    if not points:
        return None, "Select at least one vertex, edge, or face first"

    center = Vector((0.0, 0.0, 0.0))
    for point in points:
        center += point
    center /= float(len(points))
    return center, ""


def move_siren_bone_to_world_point(scene, si, world_point, preserve_direction=True):
    if not scene or not si:
        return False, "No siren was resolved"

    arm, pb = siren_pose_bone(scene, si)
    if not arm or not pb:
        return False, f"No linked bone was found for siren {getattr(si, 'index', '?')}"

    try:
        point_world = Vector(world_point)
    except Exception:
        return False, "Could not read the selected object origin"

    old_active = getattr(bpy.context.view_layer.objects, "active", None)
    old_mode = getattr(bpy.context, "mode", "OBJECT")

    try:
        if old_mode != "OBJECT":
            bpy.ops.object.mode_set(mode="OBJECT")
        bpy.ops.object.select_all(action="DESELECT")
        arm.select_set(True)
        bpy.context.view_layer.objects.active = arm
        bpy.ops.object.mode_set(mode="EDIT")

        eb = arm.data.edit_bones.get(pb.name) or arm.data.edit_bones.get(getattr(si, "bone_name", ""))
        if not eb:
            bpy.ops.object.mode_set(mode="OBJECT")
            return False, f"Could not find linked bone for siren {getattr(si, 'index', '?')}"

        current_vec = (eb.tail - eb.head)
        length = current_vec.length
        if length < 0.000001:
            length = 0.05
        if preserve_direction and current_vec.length >= 0.000001:
            direction_vec = current_vec.normalized()
        else:
            ang = dir_val(si)
            direction_vec = Vector((math.sin(ang), math.cos(ang), 0.0))
            if direction_vec.length < 0.000001:
                direction_vec = Vector((0.0, 1.0, 0.0))
            direction_vec.normalize()

        head = arm.matrix_world.inverted() @ point_world
        eb.head = head
        eb.tail = head + (direction_vec * length)

        bpy.ops.object.mode_set(mode="OBJECT")
        pose_bone = arm.pose.bones.get(eb.name)
        if pose_bone:
            _store_rest_pose_bone(arm, pose_bone, force=True)
        try:
            bpy.context.view_layer.update()
        except Exception:
            pass
        return True, f"Moved bone {eb.name} to the selected object origin"
    except Exception as ex:
        return False, f"Could not move the linked bone: {ex}"
    finally:
        try:
            if old_active and old_active.name in bpy.data.objects:
                bpy.context.view_layer.objects.active = old_active
        except Exception:
            pass
        try:
            if old_mode != "OBJECT" and getattr(bpy.context, "mode", "OBJECT") == "OBJECT":
                bpy.ops.object.mode_set(mode=old_mode)
        except Exception:
            pass


def linked_bone_world_location(scene, obj, s=None):
    if not obj:
        return None, ""

    try:
        if obj.parent and obj.parent.type == "ARMATURE" and obj.parent_type == "BONE" and obj.parent_bone:
            arm = obj.parent
            pb = getattr(getattr(arm, "pose", None), "bones", {}).get(obj.parent_bone) if hasattr(getattr(arm, "pose", None), "bones") else None
            if pb:
                return arm.matrix_world @ Vector(pb.head), ""
    except Exception:
        pass

    si_index = infer_siren_index_from_hierarchy(obj, fallback=infer_siren_index_from_object(obj, s=s))
    if si_index and scene:
        try:
            arm, pb = siren_pose_bone(scene, int(si_index))
            if arm and pb:
                return arm.matrix_world @ Vector(pb.head), ""
        except Exception:
            pass

    try:
        if scene and s and getattr(s, "body_openings", None):
            obj_name = str(getattr(obj, "name", "") or "")
            for opening in s.body_openings:
                linked_name = str(getattr(opening, "object_name", "") or "")
                key_name = str(getattr(opening, "key", "") or "")
                if linked_name and linked_name == obj_name:
                    arm, pb = body_opening_pose_bone(scene, opening)
                    if arm and pb:
                        return arm.matrix_world @ Vector(pb.head), ""
                elif key_name and _body_opening_name_matches(obj_name, key_name):
                    arm, pb = body_opening_pose_bone(scene, opening)
                    if arm and pb:
                        if not linked_name:
                            opening.object_name = obj_name
                        return arm.matrix_world @ Vector(pb.head), ""
    except Exception:
        pass

    return None, f"No linked bone was found for {getattr(obj, 'name', 'the selected object')}"

def body_opening_display_name(key):
    lookup = {k: label for k, label, _opening_type in DEFAULT_BODY_OPENINGS}
    text = str(key or "").strip()
    if text in lookup:
        return lookup[text]
    if not text:
        return "Body Opening"
    return text.replace("_", " ").title()


def body_opening_supports_rotation(opening):
    return str(getattr(opening, "opening_type", "HINGED") or "HINGED") in {"HINGED", "HINGED_SLIDING"}


def body_opening_supports_translation(opening):
    return str(getattr(opening, "opening_type", "HINGED") or "HINGED") in {"SLIDING", "HINGED_SLIDING"}


def update_body_opening_type(self, context):
    opening_type = str(getattr(self, "opening_type", "HINGED") or "HINGED")
    if opening_type in {"SLIDING", "HINGED_SLIDING"}:
        if not any(bool(getattr(self, attr, False)) for attr in ("slide_x", "slide_y", "slide_z")):
            self.slide_y = True
        self.limit_translation = True
    if opening_type in {"HINGED", "HINGED_SLIDING"}:
        if not any(bool(getattr(self, attr, False)) for attr in ("rot_x", "rot_y", "rot_z")):
            self.rot_z = True
        self.limit_rotation = True


def ensure_body_opening_defaults(s):
    if not s or not hasattr(s, "body_openings"):
        return
    existing = {str(getattr(op, "key", "") or "") for op in getattr(s, "body_openings", [])}
    for key, label, opening_type in DEFAULT_BODY_OPENINGS:
        if key in existing:
            continue
        op = s.body_openings.add()
        op.key = key
        op.name = label
        op.opening_type = opening_type
        op.rot_x = True
        op.rot_y = True
        op.rot_z = True
        op.slide_x = False
        op.slide_y = opening_type == "SLIDING"
        op.slide_z = False
        op.limit_rotation = True
        op.limit_translation = opening_type == "SLIDING"
        existing.add(key)
    if getattr(s, "body_openings", None):
        s.active_body_opening = min(max(0, int(getattr(s, "active_body_opening", 0) or 0)), len(s.body_openings) - 1)


def body_opening_by_key(s, key=""):
    if not s or not getattr(s, "body_openings", None):
        return None
    wanted = str(key or "").strip()
    if wanted:
        for op in s.body_openings:
            if str(getattr(op, "key", "") or "") == wanted:
                return op
    idx = min(max(0, int(getattr(s, "active_body_opening", 0) or 0)), len(s.body_openings) - 1)
    return s.body_openings[idx]


def active_body_opening(s):
    return body_opening_by_key(s, "")


def _body_opening_name_matches(name, key):
    lhs = str(name or "").strip().lower()
    rhs = str(key or "").strip().lower()
    if not lhs or not rhs:
        return False
    return lhs == rhs or lhs.startswith(rhs + "_") or lhs.startswith(rhs + ".")


def find_body_opening_scene_object(scene, key):
    if not scene:
        return None
    exact = None
    fallback = None
    for obj in scene.objects:
        if getattr(obj, "type", "") != "MESH":
            continue
        name = str(getattr(obj, "name", "") or "")
        if name.lower() == str(key or "").lower():
            exact = obj
            break
        if fallback is None and _body_opening_name_matches(name, key):
            fallback = obj
    return exact or fallback


def find_body_opening_scene_bone(scene, settings, key):
    if not scene:
        return None, None
    candidates = []
    arm_name = str(getattr(settings, "armature_name", "") or "") if settings else ""
    if arm_name:
        arm = bpy.data.objects.get(arm_name)
        if arm and getattr(arm, "type", "") == "ARMATURE" and arm.name in scene.objects:
            candidates.append(arm)
    for obj in scene.objects:
        if getattr(obj, "type", "") == "ARMATURE" and obj not in candidates:
            candidates.append(obj)
    for arm in candidates:
        exact = arm.data.bones.get(str(key or ""))
        if exact:
            return arm, exact
        for bone in arm.data.bones:
            if _body_opening_name_matches(getattr(bone, "name", ""), key):
                return arm, bone
    return None, None


def _vector_has_motion(vec, eps=0.00001):
    try:
        return any(abs(float(v)) > eps for v in vec)
    except Exception:
        return False


def body_opening_state_configured(opening):
    if not opening:
        return False
    return any(
        _vector_has_motion(getattr(opening, attr, (0.0, 0.0, 0.0)))
        for attr in ("closed_location", "closed_rotation", "open_location", "open_rotation")
    )


def read_body_opening_current_transform(scene, opening):
    arm, pb = body_opening_pose_bone(scene, opening)
    if pb:
        pb.rotation_mode = "XYZ"
        return Vector(pb.location), Vector(pb.rotation_euler), "BONE"
    obj = body_opening_obj(opening)
    if obj:
        obj.rotation_mode = "XYZ"
        return Vector(obj.location), Vector(obj.rotation_euler), "MESH"
    return None, None, ""


def auto_detect_body_opening_links(scene, settings):
    if not scene or not settings or not getattr(settings, "body_openings", None):
        return False

    changed = False
    scene_names = {obj.name for obj in scene.objects}
    armatures = [obj for obj in scene.objects if getattr(obj, "type", "") == "ARMATURE"]
    arm_name = str(getattr(settings, "armature_name", "") or "")
    if (not arm_name or arm_name not in scene_names) and len(armatures) == 1:
        settings.armature_name = armatures[0].name
        changed = True

    for opening in settings.body_openings:
        mesh_name = str(getattr(opening, "object_name", "") or "")
        mesh_obj = bpy.data.objects.get(mesh_name) if mesh_name else None
        if mesh_obj is None or mesh_obj.name not in scene_names:
            found_obj = find_body_opening_scene_object(scene, getattr(opening, "key", ""))
            if found_obj and mesh_name != found_obj.name:
                opening.object_name = found_obj.name
                changed = True

        arm, bone = body_opening_pose_bone(scene, opening)
        if bone is not None and not str(getattr(opening, "bone_name", "") or ""):
            opening.bone_name = bone.name
            changed = True
            if arm and (not getattr(settings, "armature_name", "") or getattr(settings, "armature_name", "") not in scene_names):
                settings.armature_name = arm.name
                changed = True
        elif bone is None:
            found_arm, found_bone = find_body_opening_scene_bone(scene, settings, getattr(opening, "key", ""))
            if found_bone is not None:
                if str(getattr(opening, "bone_name", "") or "") != found_bone.name:
                    opening.bone_name = found_bone.name
                    changed = True
                if found_arm and (not getattr(settings, "armature_name", "") or getattr(settings, "armature_name", "") not in scene_names):
                    settings.armature_name = found_arm.name
                    changed = True

        if not body_opening_state_configured(opening):
            loc, rot, _source = read_body_opening_current_transform(scene, opening)
            if loc is None or rot is None:
                continue
            if _vector_has_motion(loc) or _vector_has_motion(rot):
                opening.open_location = (float(loc[0]), float(loc[1]), float(loc[2]))
                opening.open_rotation = (float(rot[0]), float(rot[1]), float(rot[2]))
                changed = True
            else:
                opening.closed_location = (float(loc[0]), float(loc[1]), float(loc[2]))
                opening.closed_rotation = (float(rot[0]), float(rot[1]), float(rot[2]))
                changed = True
    return changed


def draw_body_opening_controls(layout, context, s, opening):
    if not opening:
        layout.label(text="No body opening available")
        return

    icon_name = "CON_ROTLIKE" if getattr(opening, "opening_type", "HINGED") == "HINGED" else "EMPTY_ARROWS"
    header = layout.row(align=True)
    header.prop(opening, "expanded", text="", emboss=False, icon="TRIA_DOWN" if opening.expanded else "TRIA_RIGHT")
    header.label(text=str(getattr(opening, "name", "Body Opening") or "Body Opening"), icon=icon_name)
    summary = []
    obj_name = str(getattr(opening, "object_name", "") or "")
    bone_name = str(getattr(opening, "bone_name", "") or "")
    if obj_name:
        summary.append(obj_name)
    elif bone_name:
        summary.append(bone_name)
    if summary:
        header.label(text=" | ".join(summary))
    if not getattr(opening, "expanded", False):
        return

    layout.prop(opening, "opening_type", text="Type")

    motion = layout.box()
    if body_opening_supports_rotation(opening):
        rot_box = motion.box() if body_opening_supports_translation(opening) else motion
        rot_box.label(text="Rotation Axes")
        rr = rot_box.row(align=True)
        rr.prop(opening, "rot_x", text="X", toggle=True)
        rr.prop(opening, "rot_y", text="Y", toggle=True)
        rr.prop(opening, "rot_z", text="Z", toggle=True)
        rot_box.prop(opening, "limit_rotation")
    if body_opening_supports_translation(opening):
        slide_box = motion.box() if body_opening_supports_rotation(opening) else motion
        slide_box.label(text="Movement Axes")
        sr = slide_box.row(align=True)
        sr.prop(opening, "slide_x", text="X", toggle=True)
        sr.prop(opening, "slide_y", text="Y", toggle=True)
        sr.prop(opening, "slide_z", text="Z", toggle=True)
        slide_box.prop(opening, "limit_translation")

    link_box = layout.box()
    link_box.label(text="Object/Bone Linking")
    link_box.prop_search(s, "armature_name", context.scene, "objects", text="Parent Skeleton")
    op = link_box.operator("nels.body_opening_link", text="Assign Selected Mesh", icon="OUTLINER_OB_MESH")
    if op is not None:
        op.action = "MARK"
        op.opening_key = opening.key
    op = link_box.operator("nels.body_opening_link", text="Match Origin to Selected", icon="OBJECT_ORIGIN")
    if op is not None:
        op.action = "ORIGIN"
        op.opening_key = opening.key
    op = link_box.operator("nels.body_opening_link", text="Place Bone at Selected Origin", icon="BONE_DATA")
    if op is not None:
        op.action = "BONE"
        op.opening_key = opening.key

    mesh_row = link_box.row(align=True)
    mesh_row.prop_search(opening, "object_name", context.scene, "objects", text="Mesh")
    op = mesh_row.operator("nels.pick_selected_link_target", text="", icon="EYEDROPPER")
    if op is not None:
        op.target = "BODY_MESH"
        op.opening_key = opening.key

    arm = bpy.data.objects.get(getattr(s, "armature_name", "")) if getattr(s, "armature_name", "") else None
    bone_row = link_box.row(align=True)
    if arm and getattr(arm, "type", "") == "ARMATURE":
        bone_row.prop_search(opening, "bone_name", arm.data, "bones", text="Bone")
    else:
        bone_field = bone_row.row(align=True)
        bone_field.enabled = False
        bone_field.prop(opening, "bone_name", text="Bone")
    op = bone_row.operator("nels.pick_selected_link_target", text="", icon="EYEDROPPER")
    if op is not None:
        op.target = "BODY_BONE"
        op.opening_key = opening.key

    link_box.label(text="Mesh and bone links auto-detect from the current scene", icon="INFO")
    if not arm or getattr(arm, "type", "") != "ARMATURE":
        link_box.label(text="Select a Parent Skeleton to search scene bones", icon="INFO")
    link_box.label(text="Placed bones always point to vehicle front (Y+)", icon="INFO")

    state_box = layout.box()
    state_box.label(text="Capture and Preview")
    state_box.label(text="Set values directly or move the linked pose bone manually, then capture Closed and Open positions.", icon="INFO")
    capture_row = state_box.row(align=True)
    op = capture_row.operator("nels.body_opening_state", text="Set Closed Position", icon="IMPORT")
    if op is not None:
        op.action = "CAPTURE_CLOSED"
        op.opening_key = opening.key
    op = capture_row.operator("nels.body_opening_state", text="Set Open Position", icon="EXPORT")
    if op is not None:
        op.action = "CAPTURE_OPEN"
        op.opening_key = opening.key
    apply_row = state_box.row(align=True)
    op = apply_row.operator("nels.body_opening_state", text="Preview Closed", icon="LOOP_BACK")
    if op is not None:
        op.action = "APPLY_CLOSED"
        op.opening_key = opening.key
    op = apply_row.operator("nels.body_opening_state", text="Preview Open", icon="PLAY")
    if op is not None:
        op.action = "APPLY_OPEN"
        op.opening_key = opening.key


    closed_loc = Vector(getattr(opening, "closed_location", (0.0, 0.0, 0.0)))
    open_loc = Vector(getattr(opening, "open_location", (0.0, 0.0, 0.0)))
    closed_rot = Vector(getattr(opening, "closed_rotation", (0.0, 0.0, 0.0)))
    open_rot = Vector(getattr(opening, "open_rotation", (0.0, 0.0, 0.0)))
    slide_delta = open_loc - closed_loc
    rot_delta = open_rot - closed_rot

    def draw_axis_group(box, title, prop_name):
        grp = state_box.box()
        grp.label(text=title)
        for axis, idx in (("X", 0), ("Y", 1), ("Z", 2)):
            grp.prop(opening, prop_name, index=idx, text=axis, slider=True)
        return grp

    if body_opening_supports_translation(opening):
        draw_axis_group(state_box, "Closed Position", "closed_location")
        draw_axis_group(state_box, "Open Position", "open_location")
        state_box.label(text=f"Position Delta: X {slide_delta[0]:.4f}  Y {slide_delta[1]:.4f}  Z {slide_delta[2]:.4f}")

    if body_opening_supports_rotation(opening):
        draw_axis_group(state_box, "Closed Rotation", "closed_rotation")
        draw_axis_group(state_box, "Open Rotation", "open_rotation")
        state_box.label(text=f"Rotation Delta: X {rot_delta[0]:.4f}  Y {rot_delta[1]:.4f}  Z {rot_delta[2]:.4f}")


def body_opening_obj(opening):
    if not opening:
        return None
    name = str(getattr(opening, "object_name", "") or "")
    return bpy.data.objects.get(name) if name else None


def body_opening_pose_bone(scene, opening):
    if not scene or not opening:
        return None, None
    s = getattr(scene, "nels", None)
    bone_name = str(getattr(opening, "bone_name", "") or getattr(opening, "key", "") or "")
    if not bone_name:
        return None, None

    candidates = []
    arm_name = str(getattr(s, "armature_name", "") or "") if s else ""
    if arm_name:
        arm = bpy.data.objects.get(arm_name)
        if arm and getattr(arm, "type", "") == "ARMATURE":
            candidates.append(arm)
    if scene:
        for obj in scene.objects:
            if getattr(obj, "type", "") == "ARMATURE" and obj not in candidates:
                candidates.append(obj)

    for arm in candidates:
        try:
            pb = getattr(getattr(arm, "pose", None), "bones", {}).get(bone_name) if hasattr(getattr(arm, "pose", None), "bones") else None
            if pb:
                return arm, pb
        except Exception:
            continue
    return None, None


def pick_body_opening_reference(context, opening):
    opening_obj = body_opening_obj(opening)
    selected = [obj for obj in getattr(context, "selected_objects", []) if obj and getattr(obj, "type", "") != "ARMATURE"]
    if opening_obj:
        selected = [obj for obj in selected if obj != opening_obj]
    active = getattr(getattr(context, "view_layer", None), "objects", None)
    active = getattr(active, "active", None)
    if active and active in selected:
        return active
    if selected:
        return selected[0]
    if active and getattr(active, "type", "") != "ARMATURE" and active != opening_obj:
        return active
    return None


def capture_body_opening_state(scene, opening, state):
    prefix = "closed" if str(state or "CLOSED").upper() == "CLOSED" else "open"
    arm, pb = body_opening_pose_bone(scene, opening)
    if pb:
        pb.rotation_mode = "XYZ"
        setattr(opening, f"{prefix}_location", (float(pb.location[0]), float(pb.location[1]), float(pb.location[2])))
        setattr(opening, f"{prefix}_rotation", (float(pb.rotation_euler[0]), float(pb.rotation_euler[1]), float(pb.rotation_euler[2])))
        return True, f"Captured {prefix} state from bone {pb.name}"

    obj = body_opening_obj(opening)
    if not obj:
        return False, f"Assign a mesh or place bone {getattr(opening, 'key', 'opening')} first"
    obj.rotation_mode = "XYZ"
    setattr(opening, f"{prefix}_location", (float(obj.location[0]), float(obj.location[1]), float(obj.location[2])))
    setattr(opening, f"{prefix}_rotation", (float(obj.rotation_euler[0]), float(obj.rotation_euler[1]), float(obj.rotation_euler[2])))
    return True, f"Captured {prefix} state from mesh {obj.name}"


def apply_body_opening_state(scene, opening, state):
    prefix = "closed" if str(state or "CLOSED").upper() == "CLOSED" else "open"
    loc = Vector(getattr(opening, f"{prefix}_location", (0.0, 0.0, 0.0)))
    rot = Vector(getattr(opening, f"{prefix}_rotation", (0.0, 0.0, 0.0)))

    arm, pb = body_opening_pose_bone(scene, opening)
    if pb:
        pb.rotation_mode = "XYZ"
        pb.location = loc
        pb.rotation_euler = rot
        try:
            bpy.context.view_layer.update()
        except Exception:
            pass
        return True, f"Applied {prefix} state to bone {pb.name}"

    obj = body_opening_obj(opening)
    if not obj:
        return False, f"Assign a mesh or place bone {getattr(opening, 'key', 'opening')} first"
    obj.rotation_mode = "XYZ"
    obj.location = loc
    obj.rotation_euler = rot
    try:
        bpy.context.view_layer.update()
    except Exception:
        pass
    return True, f"Applied {prefix} state to mesh {obj.name}"


def infer_siren_index_from_object(obj, s=None):
    seen = set()
    cur = obj
    while cur and cur not in seen:
        seen.add(cur)
        idx = siren_index_from_name(getattr(cur, "name", ""))
        if idx:
            return idx
        idx = siren_index_from_name(getattr(cur, "parent_bone", ""))
        if idx:
            return idx
        if s:
            for si in getattr(s, "sirens", []):
                if getattr(si, "object_name", "") == getattr(cur, "name", ""):
                    return int(getattr(si, "index", 0) or 0)
        cur = getattr(cur, "parent", None)
    return 0


def retarget_siren_name_token(value, old_index, new_index, extra_name_map=None):
    text = str(value or "")
    if extra_name_map:
        for old_name, new_name in sorted(extra_name_map.items(), key=lambda item: len(str(item[0])), reverse=True):
            old_name = str(old_name or "")
            new_name = str(new_name or "")
            if old_name:
                text = text.replace(old_name, new_name)

    patterns = (
        (r'(?i)siren\s*0*%d(?=[^0-9]|$)' % int(old_index), f"siren{int(new_index)}"),
        (r'(?i)misc_rotator_?\s*0*%d(?=[^0-9]|$)' % int(old_index), lambda m: ("misc_rotator_" if m.group(0).lower().startswith("misc_rotator_") else "misc_rotator") + str(int(new_index))),
    )
    for pattern, repl in patterns:
        text = re.sub(pattern, repl, text)
    return text


def _localize_object_data(obj):
    if not obj:
        return
    data = getattr(obj, "data", None)
    try:
        if data is not None and getattr(data, "users", 1) > 1:
            obj.data = data.copy()
    except Exception:
        pass
    try:
        obj.animation_data_clear()
    except Exception:
        pass


def _retarget_vertex_groups(obj, old_index, new_index, extra_name_map=None):
    for vg in getattr(obj, "vertex_groups", []):
        new_name = retarget_siren_name_token(vg.name, old_index, new_index, extra_name_map=extra_name_map)
        if new_name != vg.name:
            vg.name = new_name


def _retarget_modifier_settings(obj, old_index, new_index, extra_name_map=None):
    for mod in getattr(obj, "modifiers", []):
        try:
            if hasattr(mod, "vertex_group"):
                value = str(getattr(mod, "vertex_group", "") or "")
                new_value = retarget_siren_name_token(value, old_index, new_index, extra_name_map=extra_name_map)
                if new_value != value:
                    setattr(mod, "vertex_group", new_value)
        except Exception:
            pass


def _retarget_id_properties(container, old_index, new_index, extra_name_map=None):
    if not hasattr(container, "keys"):
        return
    try:
        for key in list(container.keys()):
            try:
                value = container[key]
            except Exception:
                continue
            if isinstance(value, str):
                new_value = retarget_siren_name_token(value, old_index, new_index, extra_name_map=extra_name_map)
                if new_value != value:
                    container[key] = new_value
    except Exception:
        pass


def _retarget_pointer_properties(container, old_index, new_index, object_map=None, extra_name_map=None, depth=0, seen=None):
    if container is None or depth > 4:
        return
    if seen is None:
        seen = set()
    marker = id(container)
    if marker in seen:
        return
    seen.add(marker)

    _retarget_id_properties(container, old_index, new_index, extra_name_map=extra_name_map)
    bl_rna = getattr(container, "bl_rna", None)
    if bl_rna is None:
        return

    skip = {
        "rna_type", "name", "data", "parent", "users_collection", "modifiers", "constraints",
        "material_slots", "particle_systems", "vertex_groups", "pose", "children", "matrix_world",
        "matrix_local", "matrix_parent_inverse",
    }
    for prop in bl_rna.properties:
        ident = getattr(prop, "identifier", "")
        if not ident or ident in skip or getattr(prop, "is_readonly", False):
            continue
        try:
            value = getattr(container, ident)
        except Exception:
            continue

        ptype = getattr(prop, "type", "")
        if ptype == 'STRING' and isinstance(value, str):
            new_value = retarget_siren_name_token(value, old_index, new_index, extra_name_map=extra_name_map)
            if new_value != value:
                try:
                    setattr(container, ident, new_value)
                except Exception:
                    pass
        elif ptype == 'POINTER':
            if object_map and isinstance(value, bpy.types.Object) and value in object_map:
                try:
                    setattr(container, ident, object_map[value])
                except Exception:
                    pass
            elif value is not None and hasattr(value, 'bl_rna') and not isinstance(value, bpy.types.ID):
                _retarget_pointer_properties(value, old_index, new_index, object_map=object_map, extra_name_map=extra_name_map, depth=depth + 1, seen=seen)
        elif ptype == 'COLLECTION':
            try:
                for item in value:
                    if item is not None and hasattr(item, 'bl_rna'):
                        _retarget_pointer_properties(item, old_index, new_index, object_map=object_map, extra_name_map=extra_name_map, depth=depth + 1, seen=seen)
            except Exception:
                pass


def retarget_siren_hierarchy(root, old_index, new_index, object_map=None, detach_root=False, force_root_name=True):
    if not root or old_index <= 0 or new_index <= 0:
        return []

    hierarchy = [root] + iter_siren_object_hierarchy(root)
    if object_map is None:
        object_map = {obj: obj for obj in hierarchy}

    name_map = {}
    desired_names = {}
    for obj in hierarchy:
        desired = retarget_siren_name_token(obj.name, old_index, new_index)
        desired = re.sub(r'\.\d{3}$', '', desired)
        if force_root_name and obj == root:
            desired = f"siren{int(new_index)}"
        desired_names[obj] = desired
        name_map[obj.name] = desired

    for obj in hierarchy:
        _localize_object_data(obj)

    for obj in hierarchy:
        desired = desired_names.get(obj, obj.name)
        if desired and obj.name != desired:
            obj.name = desired
        data = getattr(obj, 'data', None)
        if data is not None and hasattr(data, 'name'):
            try:
                data.name = retarget_siren_name_token(data.name, old_index, new_index, extra_name_map=name_map)
            except Exception:
                pass
        if getattr(obj, 'parent_type', '') == 'BONE':
            try:
                obj.parent_bone = retarget_siren_name_token(obj.parent_bone, old_index, new_index, extra_name_map=name_map)
            except Exception:
                pass
        _retarget_vertex_groups(obj, old_index, new_index, extra_name_map=name_map)
        _retarget_modifier_settings(obj, old_index, new_index, extra_name_map=name_map)
        _retarget_pointer_properties(obj, old_index, new_index, object_map=object_map, extra_name_map=name_map)
        data = getattr(obj, 'data', None)
        if data is not None and hasattr(data, 'bl_rna'):
            _retarget_pointer_properties(data, old_index, new_index, object_map=object_map, extra_name_map=name_map)
        _store_rest_loc(obj, force=True)

    if detach_root:
        try:
            world = root.matrix_world.copy()
            root.parent = None
            root.parent_type = 'OBJECT'
            root.parent_bone = ''
            root.matrix_parent_inverse = Matrix.Identity(4)
            root.matrix_world = world
            _store_rest_loc(root, force=True)
        except Exception:
            pass
    return hierarchy


def infer_siren_index_from_hierarchy(root, fallback=0):
    counts = {}
    for obj in [root] + iter_siren_object_hierarchy(root):
        for candidate in (
            infer_siren_index_from_object(obj),
            siren_index_from_name(getattr(obj, "name", "")),
            siren_index_from_name(getattr(obj, "parent_bone", "")),
        ):
            if candidate > 0:
                counts[candidate] = counts.get(candidate, 0) + 1
        for vg in getattr(obj, "vertex_groups", []):
            candidate = siren_index_from_name(getattr(vg, "name", ""))
            if candidate > 0:
                counts[candidate] = counts.get(candidate, 0) + 1
    if counts:
        return max(sorted(counts), key=lambda key: counts[key])
    return int(fallback or 0)


def suggest_duplicate_target_index(s, source_index):
    source_index = int(source_index or 0)
    used = {int(getattr(si, 'index', 0) or 0) for si in getattr(s, 'sirens', []) if getattr(si, 'object_name', '') or getattr(si, 'bone_name', '')}
    for idx in range(1, MAX_SIRENS + 1):
        if idx != source_index and idx not in used:
            return idx
    return max(1, min(MAX_SIRENS, source_index + 1 if source_index < MAX_SIRENS else MAX_SIRENS))


def duplicate_siren_hierarchy(scene, source_obj, old_index, new_index, extra_sources=None):
    if not scene or not source_obj:
        return None, []

    hierarchy_children = iter_siren_object_hierarchy(source_obj)
    extra_sources = [obj for obj in (extra_sources or []) if obj and obj not in {source_obj} and obj not in hierarchy_children]
    extra_source_set = set(extra_sources)
    sources = [source_obj] + hierarchy_children + extra_sources
    object_map = {}
    for src in sources:
        dup = src.copy()
        data = getattr(src, 'data', None)
        if data is not None:
            try:
                dup.data = data.copy()
            except Exception:
                dup.data = data
        try:
            dup.animation_data_clear()
        except Exception:
            pass

        linked = False
        for col in getattr(src, 'users_collection', []) or []:
            try:
                col.objects.link(dup)
                linked = True
            except Exception:
                pass
        if (not linked) and getattr(scene, 'collection', None):
            scene.collection.objects.link(dup)
        object_map[src] = dup

    for src, dup in object_map.items():
        if src == source_obj:
            dup.parent = None
            dup.parent_type = 'OBJECT'
            dup.parent_bone = ''
            dup.matrix_parent_inverse = Matrix.Identity(4)
        elif src in extra_source_set:
            dup.parent = object_map[source_obj]
            dup.parent_type = 'OBJECT'
            dup.parent_bone = ''
            try:
                dup.matrix_parent_inverse = object_map[source_obj].matrix_world.inverted()
            except Exception:
                dup.matrix_parent_inverse = Matrix.Identity(4)
        elif src.parent in object_map:
            dup.parent = object_map[src.parent]
            dup.parent_type = src.parent_type
            dup.parent_bone = src.parent_bone
            try:
                dup.matrix_parent_inverse = src.matrix_parent_inverse.copy()
            except Exception:
                pass
        else:
            dup.parent = src.parent
            dup.parent_type = src.parent_type
            dup.parent_bone = src.parent_bone
            try:
                dup.matrix_parent_inverse = src.matrix_parent_inverse.copy()
            except Exception:
                pass
        dup.matrix_world = src.matrix_world.copy()
        _copy_obj_rotation(dup, src)
        dup.scale = src.scale.copy()

    dup_root = object_map.get(source_obj)
    retarget_siren_hierarchy(dup_root, old_index, new_index, object_map=object_map, detach_root=True)
    return dup_root, [object_map[src] for src in sources if src in object_map]


def resolve_context_siren(scene, s, require_linked=False, update_active=True):
    if not s or not getattr(s, "sirens", None):
        return None

    active_obj = getattr(bpy.context, "active_object", None)
    idx = infer_siren_index_from_object(active_obj, s=s) if active_obj else 0
    if 1 <= idx <= len(s.sirens):
        if update_active:
            s.active_siren = idx - 1
        return s.sirens[idx - 1]

    cur_idx = max(0, min(int(getattr(s, "active_siren", 0) or 0), len(s.sirens) - 1))
    cur_si = s.sirens[cur_idx]
    if not require_linked:
        return cur_si
    if siren_obj(cur_si) or siren_pose_bone(scene, cur_si)[1]:
        return cur_si

    for si in s.sirens:
        if siren_obj(si) or siren_pose_bone(scene, si)[1]:
            if update_active:
                s.active_siren = max(0, int(getattr(si, "index", 1)) - 1)
            return si
    return cur_si


def scene_armature_items(self, context):
    scene = getattr(context, "scene", None) if context else getattr(bpy.context, "scene", None)
    items = []
    if scene:
        arm_names = sorted({obj.name for obj in scene.objects if obj.type == "ARMATURE"}, key=str.lower)
        items = [(name, name, "") for name in arm_names]
    if not items:
        items = [("__NONE__", "(No armatures found)", "")]
    return items


def scene_siren_items(self, context):
    scene = getattr(context, "scene", None) if context else getattr(bpy.context, "scene", None)
    s = getattr(scene, "nels", None) if scene else None
    items = []
    if s and getattr(s, "sirens", None):
        for si in s.sirens:
            obj = siren_obj(si)
            arm, pb = siren_pose_bone(scene, si) if scene else (None, None)
            if obj or pb:
                idx = int(getattr(si, "index", 0) or 0)
                label = f"siren{idx}"
                desc = str(getattr(obj, "name", "") or getattr(pb, "name", "") or label)
                items.append((label, label, desc))
    if not items and s and getattr(s, "sirens", None):
        for si in s.sirens:
            idx = int(getattr(si, "index", 0) or 0)
            label = f"siren{idx}"
            items.append((label, label, ""))
    if not items:
        items = [("__NONE__", "(No sirens found)", "")]
    return items


def update_tool_working_siren(self, context):
    s = getattr(getattr(context, "scene", None), "nels", None) if context else None
    if not s or not getattr(s, "sirens", None):
        return
    val = str(getattr(s, "tool_working_siren", "") or "")
    if not val or val == "__NONE__":
        return
    idx = siren_index_from_name(val)
    if 1 <= idx <= len(s.sirens):
        s.active_siren = idx - 1


def sync_tool_working_siren(scene, s):
    if not scene or not s or not getattr(s, "sirens", None):
        return False
    si = resolve_context_siren(scene, s, require_linked=False, update_active=True)
    if not si:
        return False
    idx = int(getattr(si, "index", 0) or 0)
    target = f"siren{idx}"
    if str(getattr(s, "tool_working_siren", "") or "") != target:
        s.tool_working_siren = target
        return True
    return False


def _norm_angle(v):
    try:
        a = float(v)
    except Exception:
        a = 0.0
    return (a + math.pi) % (2.0 * math.pi) - math.pi


def direction_preset_from_value(v, tol=0.0002):
    vn = _norm_angle(v)
    best_key = None
    best_delta = 1e9
    for key, ang in DIRECTIONS.items():
        d = abs(_norm_angle(vn - ang))
        if d < best_delta:
            best_delta = d
            best_key = key
    if best_key is not None and best_delta <= tol:
        return best_key
    return None


def dir_val(si):
    return float(si.custom_direction) if si.direction_mode == "CUSTOM" else DIRECTIONS.get(si.direction_preset, 0.0)


def sync_scale_factor_controls(s):
    global _SCALE_FACTOR_SYNC_GUARD
    if not s or _SCALE_FACTOR_SYNC_GUARD:
        return

    _SCALE_FACTOR_SYNC_GUARD = True
    try:
        sf = max(0.0, float(getattr(s, "scale_factor", 0.5)))
        s.scale_factor_choice = scale_factor_choice_from_value(sf)
        s.scale_factor_custom = sf
    except Exception:
        pass
    finally:
        _SCALE_FACTOR_SYNC_GUARD = False


def update_scale_factor_choice(self, context):
    global _SCALE_FACTOR_SYNC_GUARD
    if _SCALE_FACTOR_SYNC_GUARD:
        return

    _SCALE_FACTOR_SYNC_GUARD = True
    try:
        ch = getattr(self, "scale_factor_choice", "SF_2")
        if ch == "CUSTOM":
            self.scale_factor = max(0.0, float(getattr(self, "scale_factor_custom", 0.5)))
        else:
            self.scale_factor = float(SCALE_FACTOR_PRESET_VALUES.get(ch, 0.5))
            self.scale_factor_custom = self.scale_factor
    except Exception:
        pass
    finally:
        _SCALE_FACTOR_SYNC_GUARD = False
    mark_preview_dirty(context)


def update_scale_factor_custom(self, context):
    if getattr(self, "scale_factor_choice", "SF_2") != "CUSTOM":
        return
    update_scale_factor_choice(self, context)


def update_scale_factor_value(self, context):
    sync_scale_factor_controls(self)
    mark_preview_dirty(context)


def sync_siren_selector_controls(si):
    if not si:
        return
    try:
        si.pattern_select = UNSAVED_PATTERN_KEY if getattr(si, "pattern_source", "LIBRARY") == "CUSTOM" else normalize_pattern_key(getattr(si, "pattern_choice", "PAT_0"))
    except Exception:
        pass
    try:
        si.color_select = "__CUSTOM__" if getattr(si, "color_mode", "PRESET") == "CUSTOM" else normalize_color_key(getattr(si, "color_preset", "COL_0"))
    except Exception:
        pass
    try:
        si.direction_select = "__CUSTOM__" if getattr(si, "direction_mode", "PRESET") == "CUSTOM" else str(getattr(si, "direction_preset", "FRONT") or "FRONT")
    except Exception:
        pass


def update_pattern_select(self, context):
    scene = getattr(context, "scene", None) if context else None
    s = getattr(scene, "nels", None) if scene else None
    current_select = getattr(self, "pattern_select", "PAT_0")
    if current_select in {UNSAVED_PATTERN_KEY, "__CUSTOM__"}:
        if getattr(self, "pattern_source", "LIBRARY") != "CUSTOM" and s:
            p = get_pattern(s, getattr(self, "pattern_choice", "PAT_0"))
            if p:
                self.custom_visibility = getattr(p, "visibility", "BOTH") or "BOTH"
                bits = clean_bits(getattr(p, "bits", "0"))
                self.custom_bits = bits
                self.custom_value = str(parse_u32(getattr(p, "value", bits_to_int(bits))))
        self.pattern_source = "CUSTOM"
        if current_select == "__CUSTOM__":
            self.pattern_select = UNSAVED_PATTERN_KEY
    else:
        self.pattern_source = "LIBRARY"
        self.pattern_choice = normalize_pattern_key(current_select)
    queue_preview_refresh_feedback(scene)
    mark_preview_dirty(context, scene=scene, immediate=False)


def update_color_select(self, context):
    scene = getattr(context, "scene", None) if context else None
    s = getattr(scene, "nels", None) if scene else None
    if getattr(self, "color_select", "COL_0") == "__CUSTOM__":
        if getattr(self, "color_mode", "PRESET") != "CUSTOM" and s:
            c = get_color(s, getattr(self, "color_preset", "COL_0"))
            if c:
                self.custom_color = color_to_rgb(getattr(c, "value", COLORS["GENERAL_WHITE"]))
        self.color_mode = "CUSTOM"
    else:
        self.color_mode = "PRESET"
        self.color_preset = normalize_color_key(self.color_select)
    mark_preview_dirty(context)


def update_direction_select(self, context):
    if getattr(self, "direction_select", "FRONT") == "__CUSTOM__":
        if getattr(self, "direction_mode", "PRESET") != "CUSTOM":
            self.custom_direction = float(DIRECTIONS.get(getattr(self, "direction_preset", "FRONT"), 0.0))
        self.direction_mode = "CUSTOM"
    else:
        self.direction_mode = "PRESET"
        self.direction_preset = self.direction_select
        self.custom_direction = float(DIRECTIONS.get(self.direction_preset, 0.0))
    update_siren_direction(self, context)

def scale_val(si, scene=None):
    scn = scene if scene is not None else getattr(bpy.context, "scene", None)
    settings = getattr(scn, "nels", None) if scn else None
    if settings and hasattr(settings, "scale_factor"):
        try:
            return max(0.0, float(settings.scale_factor))
        except Exception:
            pass

    # Backward compatibility fallback.
    try:
        if getattr(si, "scale_mode", "PRESET") == "CUSTOM":
            return max(0.0, float(getattr(si, "custom_scale", 0.5)))
        return SCALES.get(getattr(si, "scale_preset", "SCALE_50"), 0.5)
    except Exception:
        return 0.5


def scale_factor_from_siren(si, scene=None):
    sc = max(0.0, scale_val(si, scene=scene))
    if sc <= 0.0:
        return 0.0
    return 1.0 / sc


def format_scale_factor(v):
    try:
        fv = float(v)
    except Exception:
        fv = 0.0
    if abs(fv - round(fv)) < 0.000001:
        return str(int(round(fv)))
    return f8(fv)


def shown_sim_scale(s, si):
    return 1.0


def hidden_sim_scale(s, si):
    return max(0.0, scale_val(si))


def _store_rest_loc(obj, force=False):
    if (not force) and ("_nels_rest_loc" in obj):
        return
    obj["_nels_rest_loc"] = [float(obj.location[0]), float(obj.location[1]), float(obj.location[2])]
    obj["_nels_rest_rot"] = [float(obj.rotation_euler[0]), float(obj.rotation_euler[1]), float(obj.rotation_euler[2])]
    obj["_nels_rest_scale"] = [float(obj.scale[0]), float(obj.scale[1]), float(obj.scale[2])]
    try:
        obj["_nels_rest_world"] = [float(v) for row in obj.matrix_world for v in row]
    except Exception:
        pass


def _rest_loc(obj):
    data = obj.get("_nels_rest_loc")
    if isinstance(data, (list, tuple)) and len(data) == 3:
        return Vector((float(data[0]), float(data[1]), float(data[2])))
    _store_rest_loc(obj)
    data = obj.get("_nels_rest_loc")
    return Vector((float(data[0]), float(data[1]), float(data[2])))


def _rest_rot(obj):
    data = obj.get("_nels_rest_rot")
    if isinstance(data, (list, tuple)) and len(data) == 3:
        return Vector((float(data[0]), float(data[1]), float(data[2])))
    _store_rest_loc(obj)
    data = obj.get("_nels_rest_rot", [0.0, 0.0, 0.0])
    return Vector((float(data[0]), float(data[1]), float(data[2])))


def _rest_scale(obj):
    data = obj.get("_nels_rest_scale")
    if isinstance(data, (list, tuple)) and len(data) == 3:
        return Vector((float(data[0]), float(data[1]), float(data[2])))
    _store_rest_loc(obj)
    data = obj.get("_nels_rest_scale", [1.0, 1.0, 1.0])
    return Vector((float(data[0]), float(data[1]), float(data[2])))


def _rest_world_matrix(obj):
    data = obj.get("_nels_rest_world")
    if isinstance(data, (list, tuple)) and len(data) == 16:
        return Matrix((
            (float(data[0]), float(data[1]), float(data[2]), float(data[3])),
            (float(data[4]), float(data[5]), float(data[6]), float(data[7])),
            (float(data[8]), float(data[9]), float(data[10]), float(data[11])),
            (float(data[12]), float(data[13]), float(data[14]), float(data[15])),
        ))
    _store_rest_loc(obj)
    data = obj.get("_nels_rest_world", [1.0, 0.0, 0.0, 0.0, 0.0, 1.0, 0.0, 0.0, 0.0, 0.0, 1.0, 0.0, 0.0, 0.0, 0.0, 1.0])
    return Matrix((
        (float(data[0]), float(data[1]), float(data[2]), float(data[3])),
        (float(data[4]), float(data[5]), float(data[6]), float(data[7])),
        (float(data[8]), float(data[9]), float(data[10]), float(data[11])),
        (float(data[12]), float(data[13]), float(data[14]), float(data[15])),
    ))


def rotator_preview_targets(si):
    o = siren_obj(si)
    if not o:
        return []
    direct_children = [child for child in o.children if getattr(child, "type", "") != "ARMATURE"]
    return direct_children if direct_children else [o]


def rotator_preview_pose_bones(scene, si):
    arm, pb = siren_pose_bone(scene, si)
    if not arm or not pb:
        return []
    return [child for child in getattr(pb, "children", []) if child]


def iter_pose_bone_descendants(pb):
    found = []
    stack = list(getattr(pb, "children", []))
    while stack:
        cur = stack.pop(0)
        if not cur or cur in found:
            continue
        found.append(cur)
        stack.extend(list(getattr(cur, "children", [])))
    return found


def siren_descendant_bone_names(scene, si):
    arm, pb = siren_pose_bone(scene, si)
    if not arm or not pb:
        return set()
    return {child.name for child in iter_pose_bone_descendants(pb)}


def siren_descendant_bone_objects(scene, si):
    arm, pb = siren_pose_bone(scene, si)
    if not arm or not pb or not scene:
        return []
    names = siren_descendant_bone_names(scene, si)
    if not names:
        return []
    found = []
    for obj in scene.objects:
        try:
            if obj.parent == arm and obj.parent_type == "BONE" and obj.parent_bone in names:
                found.append(obj)
        except Exception:
            continue
    return found


def apply_rotator_preview_targets(si, turns=0.0, keyframe_frame=None):
    if not si or getattr(si, "siren_type", "FLASHER") != "ROTATOR":
        return 0

    rot_sign = 1.0 if getattr(si, "rotator_clockwise", True) else -1.0
    updated = 0
    for obj in rotator_preview_targets(si):
        _store_rest_loc(obj)
        rest_loc = _rest_loc(obj)
        rest_rot = _rest_rot(obj)
        rest_scale = _rest_scale(obj)
        obj.rotation_mode = "XYZ"
        obj.location = rest_loc
        obj.scale = rest_scale
        obj.rotation_euler = rest_rot
        obj.rotation_euler[2] = rest_rot[2] + rot_sign * turns * math.tau
        if keyframe_frame is not None:
            obj.keyframe_insert(data_path="rotation_euler", index=2, frame=keyframe_frame)
        updated += 1
    return updated


def apply_rotator_preview_pose_targets(scene, si, turns=0.0, keyframe_frame=None):
    if not si or getattr(si, "siren_type", "FLASHER") != "ROTATOR":
        return 0

    arm, _pb = siren_pose_bone(scene, si)
    if not arm:
        return 0

    rot_sign = 1.0 if getattr(si, "rotator_clockwise", True) else -1.0
    updated = 0
    for target in rotator_preview_pose_bones(scene, si):
        _store_rest_pose_bone(arm, target)
        rest_loc, rest_rot, rest_sc = _rest_pose_bone(arm, target)
        target.rotation_mode = "XYZ"
        target.location = rest_loc
        target.scale = rest_sc
        target.rotation_euler = rest_rot
        target.rotation_euler[2] = rest_rot[2] + rot_sign * turns * math.tau
        if keyframe_frame is not None:
            target.keyframe_insert(data_path="rotation_euler", index=2, frame=keyframe_frame)
        updated += 1
    return updated


def target_sim_loc(obj, mode):
    rest = _rest_loc(obj)
    if mode == "ON":
        return rest
    if obj.parent_type == "BONE":
        return Vector((0.0, 0.0, 0.0))
    return rest


def _vector_mul(a, b):
    return Vector((float(a[0]) * float(b[0]), float(a[1]) * float(b[1]), float(a[2]) * float(b[2])))


def _vector_div_scalar(v, scalar):
    val = float(scalar)
    return Vector((float(v[0]) / val, float(v[1]) / val, float(v[2]) / val))


def siren_object_driven_by_bone(scene, si):
    o = siren_obj(si)
    arm, pb = siren_pose_bone(scene, si)
    return bool(o and arm and pb and o.parent == arm and o.parent_type == "BONE" and o.parent_bone == pb.name)


def iter_siren_object_hierarchy(root):
    if not root:
        return []
    found = []
    stack = list(getattr(root, "children", []))
    while stack:
        obj = stack.pop(0)
        if not obj or obj in found:
            continue
        if getattr(obj, "type", "") != "ARMATURE":
            found.append(obj)
        stack.extend(list(getattr(obj, "children", [])))
    return found


def scale_object_data(obj, factor_vec):
    if not obj:
        return False
    data = getattr(obj, "data", None)
    if data is None or not hasattr(data, "transform"):
        return False
    try:
        if getattr(data, "users", 1) > 1:
            obj.data = data.copy()
            data = obj.data
        data.transform(Matrix.Diagonal((float(factor_vec[0]), float(factor_vec[1]), float(factor_vec[2]), 1.0)))
        if hasattr(data, "update"):
            data.update()
        return True
    except Exception:
        return False


def siren_child_objects(si):
    o = siren_obj(si)
    if not o:
        return []
    return [child for child in getattr(o, "children", []) if child and getattr(child, "type", "") != "ARMATURE"]


def apply_siren_child_object_compensation(si, scalar):
    root = siren_obj(si)
    if not root:
        return
    root.rotation_mode = "XYZ"
    parent_loc = root.matrix_world.translation.copy()
    parent_rot = root.matrix_world.to_quaternion()
    parent_noscale = Matrix.LocRotScale(parent_loc, parent_rot, Vector((1.0, 1.0, 1.0)))
    for child in siren_child_objects(si):
        _store_rest_loc(child)
        rest_loc = _rest_loc(child)
        rest_rot = Euler(_rest_rot(child), "XYZ")
        rest_scale = _rest_scale(child)
        child_local = Matrix.LocRotScale(rest_loc, rest_rot.to_quaternion(), rest_scale)
        child.matrix_world = parent_noscale @ child_local


def apply_siren_child_pose_compensation(scene, si, scalar):
    val = max(0.000001, float(scalar))
    arm, _pb = siren_pose_bone(scene, si)
    if not arm:
        return
    for child in rotator_preview_pose_bones(scene, si):
        _store_rest_pose_bone(arm, child)
        rest_loc, rest_rot, rest_sc = _rest_pose_bone(arm, child)
        child.rotation_mode = "XYZ"
        child.location = _vector_div_scalar(rest_loc, val)
        child.rotation_euler = rest_rot
        child.scale = (rest_sc[0] / val, rest_sc[1] / val, rest_sc[2] / val)


def apply_siren_descendant_bone_object_compensation(scene, si, mode, keyframe_frame=None, preserved_world=None):
    preserved_world = dict(preserved_world or {})
    for obj in siren_descendant_bone_objects(scene, si):
        _store_rest_loc(obj)
        obj.rotation_mode = "XYZ"
        rest_loc = _rest_loc(obj)
        rest_rot = Euler(_rest_rot(obj), "XYZ")
        rest_scale = _rest_scale(obj)

        preserved = preserved_world.get(obj)
        if preserved is not None:
            obj.matrix_world = preserved
        else:
            arm = getattr(obj, "parent", None)
            bone_name = str(getattr(obj, "parent_bone", "") or "")
            pose_bone = None
            try:
                if arm and getattr(arm, "type", "") == "ARMATURE" and bone_name:
                    pose_bone = getattr(getattr(arm, "pose", None), "bones", {}).get(bone_name)
            except Exception:
                pose_bone = None

            if pose_bone:
                parent_world = (arm.matrix_world @ pose_bone.matrix).copy()
                parent_noscale = Matrix.LocRotScale(parent_world.translation.copy(), parent_world.to_quaternion(), Vector((1.0, 1.0, 1.0)))
                child_local = Matrix.LocRotScale(rest_loc, rest_rot.to_quaternion(), rest_scale)
                obj.matrix_world = parent_noscale @ child_local
            elif mode == "OFF":
                obj.matrix_world = _rest_world_matrix(obj)
            else:
                obj.location = rest_loc
                obj.rotation_euler = rest_rot
                obj.scale = rest_scale

        if keyframe_frame is not None:
            obj.keyframe_insert(data_path="location", frame=keyframe_frame)
            obj.keyframe_insert(data_path="scale", frame=keyframe_frame)


def restore_siren_default_state(scene, si):
    restored = 0
    o = siren_obj(si)
    if o:
        _store_rest_loc(o)
        o.rotation_mode = "XYZ"
        o.location = _rest_loc(o)
        o.rotation_euler = _rest_rot(o)
        o.scale = _rest_scale(o)
        restored += 1
        for child in iter_siren_object_hierarchy(o):
            if any(k in child for k in ("_nels_rest_loc", "_nels_rest_rot", "_nels_rest_scale")):
                child.rotation_mode = "XYZ"
                child.location = _rest_loc(child)
                child.rotation_euler = _rest_rot(child)
                child.scale = _rest_scale(child)
                restored += 1

    arm, pb = siren_pose_bone(scene, si)
    if arm and pb:
        _store_rest_pose_bone(arm, pb)
        rest_loc, rest_rot, rest_sc = _rest_pose_bone(arm, pb)
        pb.rotation_mode = "XYZ"
        pb.location = rest_loc
        pb.rotation_euler = rest_rot
        pb.scale = rest_sc
        restored += 1
        for child in rotator_preview_pose_bones(scene, si):
            key = _pose_rest_key(child.name)
            if key in arm:
                rest_loc, rest_rot, rest_sc = _rest_pose_bone(arm, child)
                child.rotation_mode = "XYZ"
                child.location = rest_loc
                child.rotation_euler = rest_rot
                child.scale = rest_sc
                restored += 1
    for obj in siren_descendant_bone_objects(scene, si):
        if any(k in obj for k in ("_nels_rest_loc", "_nels_rest_rot", "_nels_rest_scale")):
            obj.rotation_mode = "XYZ"
            obj.location = _rest_loc(obj)
            obj.rotation_euler = _rest_rot(obj)
            obj.scale = _rest_scale(obj)
            restored += 1

    return restored


def bake_siren_scale_state(scene, s, si, mode):
    o = siren_obj(si)
    if not o:
        return False, "No linked siren mesh found for the selected siren"

    target_scalar = shown_sim_scale(s, si) if mode == "ON" else hidden_sim_scale(s, si)
    if target_scalar <= 0.0:
        return False, "Scale Factor must be above 0 before baking the hidden siren scale"

    arm, pb = siren_pose_bone(scene, si)
    bone_driven = siren_object_driven_by_bone(scene, si)

    current_effective = Vector((float(o.scale[0]), float(o.scale[1]), float(o.scale[2])))
    if bone_driven and pb:
        current_effective = _vector_mul(current_effective, Vector((float(pb.scale[0]), float(pb.scale[1]), float(pb.scale[2]))))

    factor_vec = _vector_div_scalar(current_effective, target_scalar)
    baked = 1 if scale_object_data(o, factor_vec) else 0

    o.rotation_mode = "XYZ"
    o.scale = (1.0, 1.0, 1.0)
    _store_rest_loc(o, force=True)

    if arm and pb:
        pb.rotation_mode = "XYZ"
        pb.scale = (1.0, 1.0, 1.0)
        _store_rest_pose_bone(arm, pb, force=True)

    apply_sim_state(scene, s, si, mode)

    if hasattr(scene, "view_layers"):
        try:
            bpy.context.view_layer.update()
        except Exception:
            pass

    queue_preview_refresh_feedback(scene)
    mark_preview_dirty(scene=scene, immediate=False)
    return True, f"Baked {mode.lower()} scale for siren{si.index} on {max(1, baked)} object(s)"



def _pose_rest_key(bone_name):
    return f"_nels_rest_pose_{bone_name}"


def _store_rest_pose_bone(arm, pb, force=False):
    key = _pose_rest_key(pb.name)
    if (not force) and (key in arm):
        return
    old_mode = pb.rotation_mode
    try:
        pb.rotation_mode = "XYZ"
        arm[key] = [
            float(pb.location[0]),
            float(pb.location[1]),
            float(pb.location[2]),
            float(pb.rotation_euler[0]),
            float(pb.rotation_euler[1]),
            float(pb.rotation_euler[2]),
            float(pb.scale[0]),
            float(pb.scale[1]),
            float(pb.scale[2]),
        ]
    finally:
        pb.rotation_mode = old_mode


def _rest_pose_bone(arm, pb):
    key = _pose_rest_key(pb.name)
    data = arm.get(key)
    if isinstance(data, (list, tuple)) and len(data) == 9:
        loc = Vector((float(data[0]), float(data[1]), float(data[2])))
        rot = Vector((float(data[3]), float(data[4]), float(data[5])))
        sc = Vector((float(data[6]), float(data[7]), float(data[8])))
        return loc, rot, sc
    _store_rest_pose_bone(arm, pb)
    data = arm.get(key, [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 1.0, 1.0, 1.0])
    loc = Vector((float(data[0]), float(data[1]), float(data[2])))
    rot = Vector((float(data[3]), float(data[4]), float(data[5])))
    sc = Vector((float(data[6]), float(data[7]), float(data[8])))
    return loc, rot, sc


def apply_sim_state(scene, s, si, mode, turns=0.0, keyframe_frame=None):
    o = siren_obj(si)
    arm, pb = siren_pose_bone(scene, si)
    sc = shown_sim_scale(s, si) if mode == "ON" else hidden_sim_scale(s, si)
    applied = False

    preserved_desc_world = {}
    if keyframe_frame is None and mode == "OFF":
        try:
            for child_obj in siren_descendant_bone_objects(scene, si):
                preserved_desc_world[child_obj] = child_obj.matrix_world.copy()
        except Exception:
            preserved_desc_world = {}

    is_rotator = getattr(si, "siren_type", "FLASHER") == "ROTATOR"
    rotation_only_key = bool(keyframe_frame is not None and is_rotator and mode == "ON" and abs(float(turns)) > 0.000001)
    object_driven_by_bone = bool(o and arm and pb and o.parent == arm and o.parent_type == "BONE" and o.parent_bone == pb.name)

    if o:
        _store_rest_loc(o)
        rest_loc = _rest_loc(o)
        rest_rot = _rest_rot(o)
        rest_scale = _rest_scale(o)

        o.rotation_mode = "XYZ"
        o.rotation_euler = rest_rot
        if is_rotator and not (arm and pb):
            rot_sign = 1.0 if getattr(si, "rotator_clockwise", True) else -1.0
            o.rotation_euler[2] = rest_rot[2] + rot_sign * turns * math.tau

        o.location = rest_loc
        if object_driven_by_bone or (arm and pb and is_rotator):
            o.scale = rest_scale
        else:
            o.scale = (rest_scale[0] * sc, rest_scale[1] * sc, rest_scale[2] * sc)

        if keyframe_frame is not None:
            if (not rotation_only_key) and not (object_driven_by_bone or (arm and pb and is_rotator)):
                o.keyframe_insert(data_path="scale", frame=keyframe_frame)
            if is_rotator and not (arm and pb):
                o.keyframe_insert(data_path="rotation_euler", index=2, frame=keyframe_frame)
        applied = True

    if arm and pb:
        _store_rest_pose_bone(arm, pb)
        rest_loc, rest_rot, rest_sc = _rest_pose_bone(arm, pb)
        pb.rotation_mode = "XYZ"
        pb.location = rest_loc
        pb.rotation_euler = rest_rot
        if is_rotator:
            rot_sign = 1.0 if getattr(si, "rotator_clockwise", True) else -1.0
            pb.rotation_euler = (rest_rot[0], rest_rot[1], rest_rot[2] + rot_sign * turns * math.tau)
        pb.scale = (rest_sc[0] * sc, rest_sc[1] * sc, rest_sc[2] * sc)

        if keyframe_frame is not None:
            if not rotation_only_key:
                pb.keyframe_insert(data_path="scale", frame=keyframe_frame)
            if is_rotator:
                pb.keyframe_insert(data_path="rotation_euler", index=2, frame=keyframe_frame)
        applied = True

    if applied:
        try:
            bpy.context.view_layer.update()
        except Exception:
            pass

    if o:
        apply_siren_child_object_compensation(si, sc)
    if arm and pb:
        apply_siren_child_pose_compensation(scene, si, sc)
        apply_siren_descendant_bone_object_compensation(scene, si, mode, keyframe_frame=keyframe_frame, preserved_world=preserved_desc_world)

    return applied


def _ensure_cycles_fcurve(fc):
    if not fc:
        return
    for m in fc.modifiers:
        if m.type == "CYCLES":
            return
    mod = fc.modifiers.new(type="CYCLES")
    mod.mode_before = "REPEAT"
    mod.mode_after = "REPEAT"


def _iter_action_fcurves(action):
    if not action:
        return

    # Blender <= 4.x API.
    legacy = getattr(action, "fcurves", None)
    if legacy is not None:
        for fc in legacy:
            yield fc
        return

    # Blender 5.x layered Action API.
    for layer in getattr(action, "layers", []):
        for strip in getattr(layer, "strips", []):
            for bag in getattr(strip, "channelbags", []):
                for fc in getattr(bag, "fcurves", []):
                    yield fc

def _clear_cycles_modifiers(action, path_predicate):
    for fc in _iter_action_fcurves(action):
        data_path = str(getattr(fc, "data_path", ""))
        if not path_predicate(data_path):
            continue
        try:
            for m in list(fc.modifiers):
                if m.type == "CYCLES":
                    fc.modifiers.remove(m)
        except Exception:
            pass


def _set_preview_key_interpolation(scene, si):
    def _set_interp(fc, mode):
        try:
            for kp in fc.keyframe_points:
                kp.interpolation = mode
        except Exception:
            pass

    o = siren_obj(si)
    if o and o.animation_data and o.animation_data.action:
        for fc in _iter_action_fcurves(o.animation_data.action):
            if fc.data_path in {"location", "scale"}:
                _set_interp(fc, "CONSTANT")
            elif si.siren_type == "ROTATOR" and fc.data_path == "rotation_euler" and int(getattr(fc, "array_index", -1)) == 2:
                _set_interp(fc, "LINEAR")

    if getattr(si, "siren_type", "FLASHER") == "ROTATOR":
        for target in rotator_preview_targets(si):
            if not target or target == o:
                continue
            act = getattr(getattr(target, "animation_data", None), "action", None)
            if not act:
                continue
            for fc in _iter_action_fcurves(act):
                if fc.data_path == "rotation_euler" and int(getattr(fc, "array_index", -1)) == 2:
                    _set_interp(fc, "LINEAR")

    arm, pb = siren_pose_bone(scene, si)
    if arm and pb and arm.animation_data and arm.animation_data.action:
        target_bones = {pb.name}
        if getattr(si, "siren_type", "FLASHER") == "ROTATOR":
            target_bones.update(child.name for child in rotator_preview_pose_bones(scene, si))

        for fc in _iter_action_fcurves(arm.animation_data.action):
            path = str(getattr(fc, "data_path", ""))
            prefix = 'pose.bones["'
            if not path.startswith(prefix):
                continue
            bone_name = path[len(prefix):].split('"]', 1)[0]
            if bone_name not in target_bones:
                continue
            if path.endswith(".location") or path.endswith(".scale"):
                _set_interp(fc, "CONSTANT")
            elif si.siren_type == "ROTATOR" and path.endswith(".rotation_euler") and int(getattr(fc, "array_index", -1)) == 2:
                _set_interp(fc, "LINEAR")


def preview_step_frames(bpm, fps):
    bpm_val = max(1.0, float(bpm))
    fps_val = max(1.0, float(fps))
    return max(0.01, (60.0 / bpm_val) * fps_val)


def preview_cycle_frames(bpm, fps, bit_count=32):
    return preview_step_frames(bpm, fps) * max(1, int(bit_count))


def start_delay_frames(bpm, fps, si):
    try:
        delay = max(0.0, float(getattr(si, "start_delay", 0.0) or 0.0))
    except Exception:
        delay = 0.0
    return delay * preview_step_frames(bpm, fps)

def ensure_siren_preview_cycles(scene, si):
    o = siren_obj(si)
    if o and o.animation_data and o.animation_data.action:
        act = o.animation_data.action
        for fc in _iter_action_fcurves(act):
            if fc.data_path in {"location", "scale", "rotation_euler"}:
                _ensure_cycles_fcurve(fc)

    if getattr(si, "siren_type", "FLASHER") == "ROTATOR":
        for target in rotator_preview_targets(si):
            if not target or target == o:
                continue
            act = getattr(getattr(target, "animation_data", None), "action", None)
            if not act:
                continue
            for fc in _iter_action_fcurves(act):
                if fc.data_path == "rotation_euler" and int(getattr(fc, "array_index", -1)) == 2:
                    _ensure_cycles_fcurve(fc)

    arm, pb = siren_pose_bone(scene, si)
    if arm and pb and arm.animation_data and arm.animation_data.action:
        target_bones = {pb.name}
        if getattr(si, "siren_type", "FLASHER") == "ROTATOR":
            target_bones.update(child.name for child in rotator_preview_pose_bones(scene, si))
        act = arm.animation_data.action
        for fc in _iter_action_fcurves(act):
            path = str(getattr(fc, "data_path", ""))
            prefix = 'pose.bones["'
            if not path.startswith(prefix):
                continue
            bone_name = path[len(prefix):].split('"]', 1)[0]
            if bone_name not in target_bones:
                continue
            if path.endswith(".location") or path.endswith(".scale") or path.endswith(".rotation_euler"):
                _ensure_cycles_fcurve(fc)
def rot_speed(bpm, si):
    if si.rotator_speed_mode == "CUSTOM":
        return float(bpm) / 100.0 * (max(0.0, si.rotator_custom_percent) / 6.25)
    return float(bpm) / 100.0 * ROT_SPEED.get(si.rotator_speed_mode, 1.0)


def rotator_cycle_frames(bpm, fps, si):
    rpm = max(0.000001, float(rot_speed(bpm, si)))
    fps_val = max(1.0, float(fps))
    return max(1.0, (60.0 / rpm) * fps_val)


def siren_base_color_rgb(s, si):
    if si.color_mode == "PRESET":
        c = get_color(s, si.color_preset)
        return color_to_rgb(c.value) if c else (1.0, 0.0, 0.0)
    return tuple(si.custom_color)


def color_hex(s, si):
    if si.color_mode == "PRESET":
        c = get_color(s, si.color_preset)
        return clean_color_value(c.value) if c else "0xFFFF0000"
    return rgb_to_color(si.custom_color)

def pattern_triplet(s, si):
    if si.pattern_source == "CUSTOM":
        bits = repeat_32(si.custom_bits)
        return bits, bits_to_int(bits), si.custom_visibility
    p = get_pattern(s, si.pattern_choice)
    if not p:
        return "0" * 32, 0, "BOTH"
    bits = repeat_32(p.bits)
    return bits, bits_to_int(bits), p.visibility


def siren_is_active(si):
    if not si:
        return False

    has_object = bool(si.object_name and si.object_name in bpy.data.objects)
    has_bone = False
    try:
        scene = getattr(bpy.context, "scene", None)
        arm, pb = siren_pose_bone(scene, si)
        has_bone = bool(arm and pb)
    except Exception:
        has_bone = False
    return has_object or has_bone

def siren_has_output(s, si):
    if not s or not si:
        return False
    _, seq, vis = pattern_triplet(s, si)
    if seq == 0:
        return False
    if si.siren_type == "ROTATOR":
        return vis in {"BOTH", "ROTATOR"}
    return vis in {"BOTH", "FLASHER"}


def ensure_defaults(s):
    if not s.patterns:
        data = load_global_library_data()
        loaded = False
        pats = data.get("patterns", []) if isinstance(data, dict) else []
        if isinstance(pats, list) and pats:
            for pd in pats:
                if not isinstance(pd, dict):
                    continue
                p = s.patterns.add()
                p.name = str(pd.get("name", "Pattern") or "Pattern")
                p.visibility = "FLASHER" if pd.get("visibility", "BOTH") == "FLASHER" else "BOTH"
                p.bits = clean_bits(pd.get("bits", int_to_bits(pd.get("value", 0)))) or "0"
                p.value = str(parse_u32(pd.get("value", bits_to_int(p.bits))))
                p.allow_duplicate = bool(pd.get("allow_duplicate", False))
            loaded = bool(s.patterns)

        if not loaded:
            populate_default_patterns(s)

    migrate_legacy_default_patterns(s)

    ensure_off_pattern(s)
    if s.patterns:
        s.active_pattern = min(max(0, s.active_pattern), len(s.patterns) - 1)
    save_global_library(s)


def ensure_off_pattern(s):
    for p in s.patterns:
        if (p.name or "").strip().lower() == "off":
            if not hasattr(p, "allow_duplicate"):
                continue
            return
    p = s.patterns.add()
    p.name = "Off"
    p.visibility = "BOTH"
    p.bits = "0"
    p.value = "0"
    p.allow_duplicate = False


def ensure_default_color_entries(s):
    if not s:
        return False
    changed = False
    existing = {(str(getattr(c, "name", "") or "").strip().lower(), clean_color_value(getattr(c, "value", "0xFFFF0000"))) for c in getattr(s, "colors", [])}
    existing_values = {clean_color_value(getattr(c, "value", "0xFFFF0000")) for c in getattr(s, "colors", [])}
    for _key, label, value in COLOR_ITEMS:
        sig = (label.strip().lower(), clean_color_value(value))
        if sig in existing or sig[1] in existing_values:
            continue
        c = s.colors.add()
        c.name = label
        c.value = clean_color_value(value)
        c.rgb = color_to_rgb(c.value)
        existing.add(sig)
        existing_values.add(sig[1])
        changed = True
    return changed


def ensure_color_defaults(s):
    loaded = bool(getattr(s, "colors", None))
    if not loaded:
        data = load_global_library_data()
        cols = data.get("colors", []) if isinstance(data, dict) else []
        if isinstance(cols, list) and cols:
            for cd in cols:
                if not isinstance(cd, dict):
                    continue
                c = s.colors.add()
                c.name = str(cd.get("name", "Colour") or "Colour")
                c.value = clean_color_value(cd.get("value", "0xFFFF0000"))
                c.rgb = color_to_rgb(c.value)
            loaded = bool(s.colors)

    if not loaded:
        for name, value in DEFAULT_COLOR_LIBRARY:
            c = s.colors.add()
            c.name = name
            c.value = clean_color_value(value)
            c.rgb = color_to_rgb(c.value)

    changed = ensure_default_color_entries(s)
    s.active_color = min(max(0, s.active_color), max(0, len(s.colors) - 1)) if s.colors else 0
    if changed or not loaded:
        save_global_library(s)


def ensure_other_attributes_defaults(s):
    if not s or s.other_attributes:
        return

    defaults = [
        ("Scale Factor 2", "0.5"),
        ("Scale Factor 10", "0.1"),
        ("Scale Factor 100", "0.01"),
    ]
    for disp, ret in defaults:
        a = s.other_attributes.add()
        a.display_value = disp
        a.return_value = ret
    s.active_other_attribute = 0


def add_siren(s, si, idx):
    si.index = idx
    si.name = f"siren{idx}"
    si.enabled = False
    si.siren_type = "FLASHER"
    si.rotator_speed_mode = "P50"
    si.rotator_custom_percent = 50.0
    si.rotator_clockwise = True
    si.pattern_source = "LIBRARY"
    si.pattern_choice = off_pattern_key(s)
    si.custom_visibility = "BOTH"
    si.custom_bits = "0"
    si.custom_value = "0"
    si.color_mode = "PRESET"
    si.color_preset = white_color_key(s)
    si.custom_color = (1.0, 1.0, 1.0)
    si.flash_preview = True
    si.direction_mode = "PRESET"
    si.direction_preset = "FRONT"
    si.scale_mode = "PRESET"
    si.scale_preset = "SCALE_50"
    si.custom_scale = 0.5
    si.sync_to_bpm = True
    si.flash = True
    si.light = False
    si.spot_light = False
    si.cast_shadows = False
    si.light_group = 1
    si.start_delay = 0.0
    si.light_speed = 0.0
    si.light_multiples = 2
    si.corona_intensity = 0.5
    si.corona_size = 0.0
    si.corona_pull = 0.00000001
    si.light_intensity = 0.5
    si.corona_face_camera = False
    si.object_name = ""
    si.anchor_name = ""
    si.bone_name = ""
    sync_siren_selector_controls(si)


def ensure_sirens(s, count):
    count = max(0, min(MAX_SIRENS, int(count)))
    while len(s.sirens) < count:
        i = len(s.sirens) + 1
        si = s.sirens.add()
        add_siren(s, si, i)
    while len(s.sirens) > count:
        s.sirens.remove(len(s.sirens) - 1)
    s.siren_count = count
    s.active_siren = min(s.active_siren, max(0, count - 1))
    for i, si in enumerate(s.sirens, start=1):
        si.index = i
        si.name = f"siren{i}"
    if hasattr(s, "preview_dirty"):
        s.preview_dirty = True



def _sync_pattern_bits(pg):
    bits = repeat_32(pg.bits)
    val = str(bits_to_int(bits))
    if pg.bits != bits:
        pg.bits = bits
    if pg.value != val:
        pg.value = val


def _sync_pattern_value(pg):
    val = str(parse_u32(pg.value))
    bits = int_to_bits(val)
    if pg.value != val:
        pg.value = val
    if pg.bits != bits:
        pg.bits = bits


def update_pattern_bits(self, context):
    scene = getattr(context, "scene", None) if context else getattr(bpy.context, "scene", None)
    _sync_pattern_bits(self)
    save_library_from_context(context)
    queue_preview_refresh_feedback(scene)
    mark_preview_dirty(context, scene=scene, immediate=False)


def update_pattern_value(self, context):
    scene = getattr(context, "scene", None) if context else getattr(bpy.context, "scene", None)
    _sync_pattern_value(self)
    save_library_from_context(context)
    queue_preview_refresh_feedback(scene)
    mark_preview_dirty(context, scene=scene, immediate=False)


def update_pattern_meta(self, context):
    scene = getattr(context, "scene", None) if context else getattr(bpy.context, "scene", None)
    save_library_from_context(context)
    queue_preview_refresh_feedback(scene)
    mark_preview_dirty(context, scene=scene, immediate=False)


def update_color_name(self, context):
    save_library_from_context(context)


def _sync_siren_bits(si):
    bits = repeat_32(si.custom_bits)
    val = str(bits_to_int(bits))
    if si.custom_bits != bits:
        si.custom_bits = bits
    if si.custom_value != val:
        si.custom_value = val


def _sync_siren_value(si):
    val = str(parse_u32(si.custom_value))
    bits = int_to_bits(val)
    if si.custom_value != val:
        si.custom_value = val
    if si.custom_bits != bits:
        si.custom_bits = bits


def update_siren_bits(self, context):
    scene = getattr(context, "scene", None) if context else getattr(bpy.context, "scene", None)
    _sync_siren_bits(self)
    queue_preview_refresh_feedback(scene)
    mark_preview_dirty(context, scene=scene, immediate=False)


def update_siren_value(self, context):
    scene = getattr(context, "scene", None) if context else getattr(bpy.context, "scene", None)
    _sync_siren_value(self)
    queue_preview_refresh_feedback(scene)
    mark_preview_dirty(context, scene=scene, immediate=False)

PREVIEW_OFF_RGB = (0.18, 0.18, 0.18)


def _emissive_level(rgb, gain):
    g = max(0.0, float(gain))
    return tuple(max(0.0, min(1.0, float(c) * g)) for c in rgb)


def _preview_lit_color(rgb, intensity=1.0):
    base = tuple(max(0.0, min(1.0, float(c))) for c in rgb)
    peak = max(base) if base else 0.0
    if peak > 0.000001:
        vivid = tuple(min(1.0, c / peak) for c in base)
    else:
        vivid = (1.0, 1.0, 1.0)
    t = max(0.0, min(1.0, float(intensity)))
    return tuple((PREVIEW_OFF_RGB[i] * (1.0 - t)) + (vivid[i] * t) for i in range(3))


def _emissive_color(rgb, lit):
    if lit:
        return _preview_lit_color(rgb, 1.0)
    return PREVIEW_OFF_RGB


def apply_sollumz_emissive_multiplier(obj, value=10.0):
    if not obj or getattr(obj, "type", "") != "MESH":
        return
    mats = getattr(getattr(obj, "data", None), "materials", None)
    if not mats:
        return
    try:
        target = float(value)
    except Exception:
        target = 10.0

    for mat in mats:
        if mat is None:
            continue
        try:
            sp = getattr(mat, "shader_properties", None)
            if sp is not None:
                if hasattr(sp, "emissive_multiplier"):
                    setattr(sp, "emissive_multiplier", target)
                elif hasattr(sp, "emissiveMultiplier"):
                    setattr(sp, "emissiveMultiplier", target)

            if hasattr(mat, "emissive_multiplier"):
                setattr(mat, "emissive_multiplier", target)
            if hasattr(mat, "emissiveMultiplier"):
                setattr(mat, "emissiveMultiplier", target)

            if "emissiveMultiplier" in mat:
                mat["emissiveMultiplier"] = target
        except Exception:
            pass


def _head_tail_preview(s, key, base_rgb, preview_on=True):
    if not s:
        return tuple(base_rgb)
    if not preview_on:
        return tuple(base_rgb)
    scn = getattr(bpy.context, "scene", None)
    p = get_pattern(s, key)
    bits = repeat_32(p.bits) if p else ("0" * 32)
    return _emissive_color(base_rgb, preview_pattern_is_on(bits, s.bpm, scene=scn))


def get_left_head_preview(self):
    try:
        return tuple(self.left_head_preview_cache)
    except Exception:
        return _head_tail_preview(self, self.left_head, (1.0, 1.0, 1.0), getattr(self, "head_tail_preview", True))


def get_right_head_preview(self):
    try:
        return tuple(self.right_head_preview_cache)
    except Exception:
        return _head_tail_preview(self, self.right_head, (1.0, 1.0, 1.0), getattr(self, "head_tail_preview", True))


def get_left_tail_preview(self):
    try:
        return tuple(self.left_tail_preview_cache)
    except Exception:
        return _head_tail_preview(self, self.left_tail, (1.0, 0.0, 0.0), getattr(self, "head_tail_preview", True))


def get_right_tail_preview(self):
    try:
        return tuple(self.right_tail_preview_cache)
    except Exception:
        return _head_tail_preview(self, self.right_tail, (1.0, 0.0, 0.0), getattr(self, "head_tail_preview", True))


def update_rotator_settings(self, context):
    scene = getattr(context, "scene", None) if context else None
    s = getattr(scene, "nels", None) if scene else None
    if self.siren_type == "ROTATOR":
        if s:
            off_key = off_pattern_key(s)
            if normalize_pattern_key(self.pattern_choice) == off_key:
                self.pattern_choice = find_pattern_key_by_name(s, "Single Sweep")
        bpm = getattr(s, "bpm", 800) if s else 800
        self.light_speed = rot_speed(bpm, self)
    mark_preview_dirty(context, scene=scene)


def update_siren_type(self, context):
    if self.siren_type == "ROTATOR":
        self.pattern_source = "LIBRARY"
    update_rotator_settings(self, context)
    sync_siren_selector_controls(self)
    mark_preview_dirty(context)


def update_bpm(self, context):
    for si in self.sirens:
        if si.siren_type == "ROTATOR":
            try:
                si.light_speed = rot_speed(self.bpm, si)
            except Exception:
                pass
    mark_preview_dirty(context)



def preview_updates_suspended():
    return _PREVIEW_UPDATE_SUSPEND > 0


def suspend_preview_updates():
    global _PREVIEW_UPDATE_SUSPEND
    _PREVIEW_UPDATE_SUSPEND += 1


def resume_preview_updates():
    global _PREVIEW_UPDATE_SUSPEND
    _PREVIEW_UPDATE_SUSPEND = max(0, _PREVIEW_UPDATE_SUSPEND - 1)


def tag_all_ui_redraw():
    wm = getattr(bpy.context, "window_manager", None)
    if not wm:
        return
    try:
        for win in wm.windows:
            screen = getattr(win, "screen", None)
            if not screen:
                continue
            for area in screen.areas:
                try:
                    area.tag_redraw()
                except Exception:
                    pass
                for region in getattr(area, "regions", []):
                    try:
                        region.tag_redraw()
                    except Exception:
                        pass
    except Exception:
        pass


def custom_preview_overlay_enabled():
    return False
def tag_preview_ui_redraw():
    wm = getattr(bpy.context, "window_manager", None)
    if not wm:
        return
    try:
        for win in wm.windows:
            screen = getattr(win, "screen", None)
            if not screen:
                continue
            for area in screen.areas:
                if getattr(area, "type", "") != "VIEW_3D":
                    continue
                for region in getattr(area, "regions", []):
                    if getattr(region, "type", "") != "UI":
                        continue
                    try:
                        region.tag_redraw()
                    except Exception:
                        pass
    except Exception:
        pass

def ui_wrap_width_chars(context, fallback=34):
    try:
        region = getattr(context, "region", None)
        width = int(getattr(region, "width", 0) or 0)
        if width <= 0:
            return fallback
        return max(18, min(56, int((width - 42) / 6.8)))
    except Exception:
        return fallback


def draw_wrapped_text(layout, context, text, icon="NONE"):
    msg = str(text or "").strip()
    if not msg:
        return
    width = ui_wrap_width_chars(context)
    lines = textwrap.wrap(msg, width=width, break_long_words=False, break_on_hyphens=False) or [msg]
    for i, line in enumerate(lines):
        if i == 0 and icon and icon != "NONE":
            layout.label(text=line, icon=icon)
        else:
            layout.label(text=line)


def preview_cache_signature(scene):
    s = getattr(scene, "nels", None) if scene else None
    if not s:
        return ""

    values = []
    for prop in ("left_head_preview_cache", "right_head_preview_cache", "left_tail_preview_cache", "right_tail_preview_cache"):
        try:
            values.extend(round(float(c), 4) for c in getattr(s, prop))
        except Exception:
            values.extend((0.0, 0.0, 0.0))

    for si in s.sirens:
        try:
            values.extend(round(float(c), 4) for c in si.preview_color_cache)
        except Exception:
            values.extend((0.0, 0.0, 0.0))
    return "|".join(f"{v:.4f}" for v in values)


def preview_targets_animated(scene):
    s = getattr(scene, "nels", None) if scene else None
    if not s:
        return False

    if getattr(s, "head_tail_preview", True):
        for key in (getattr(s, "left_head", ""), getattr(s, "right_head", ""), getattr(s, "left_tail", ""), getattr(s, "right_tail", "")):
            p = get_pattern(s, key)
            bits = repeat_32(p.bits) if p else ("0" * 32)
            if "1" in bits:
                return True

    for si in s.sirens:
        if not getattr(si, "flash_preview", True):
            continue
        if getattr(si, "siren_type", "FLASHER") == "ROTATOR":
            return True
        bits, seq, vis = pattern_triplet(s, si)
        if seq and vis in {"BOTH", "FLASHER"} and "1" in bits:
            return True
    return False


def queue_preview_refresh_feedback(scene, message="Preview refresh in progress..."):
    s = getattr(scene, "nels", None) if scene else None
    if not s:
        return
    s.preview_refresh_pending = True
    s.preview_refresh_started_at = _time.time()
    s.preview_refresh_done_at = 0.0
    s.preview_refresh_signature = preview_cache_signature(scene)
    s.preview_refresh_has_motion = preview_targets_animated(scene)
    s.status_message = message
    tag_preview_ui_redraw()


def update_preview_refresh_feedback(scene):
    s = getattr(scene, "nels", None) if scene else None
    if not s:
        return False

    changed = False
    now = _time.time()
    status = str(getattr(s, "status_message", "") or "")

    if getattr(s, "preview_refresh_pending", False):
        started = float(getattr(s, "preview_refresh_started_at", now) or now)
        has_motion = bool(getattr(s, "preview_refresh_has_motion", False))
        current_signature = preview_cache_signature(scene)
        previous_signature = str(getattr(s, "preview_refresh_signature", "") or "")
        if current_signature != previous_signature or ((not has_motion) and (now - started) >= 0.25):
            s.preview_refresh_pending = False
            s.preview_refresh_signature = current_signature
            s.preview_refresh_done_at = now
            if status.startswith("Preview refresh"):
                s.status_message = "Preview refresh complete"
            changed = True
        return changed

    done_at = float(getattr(s, "preview_refresh_done_at", 0.0) or 0.0)
    if done_at > 0.0 and status == "Preview refresh complete" and (now - done_at) >= 1.0:
        s.preview_refresh_done_at = 0.0
        s.status_message = ""
        changed = True
    return changed


def mark_preview_dirty(context=None, scene=None, immediate=True):
    sc = scene
    if sc is None and context is not None:
        sc = getattr(context, "scene", None)
    if sc is None:
        sc = getattr(bpy.context, "scene", None)
    s = getattr(sc, "nels", None) if sc else None
    if not s:
        return
    s.preview_dirty = True
    s.preview_last_step = -1
    if not timeline_playing():
        try:
            s.preview_time_origin = _time.time()
        except Exception:
            pass
    if getattr(s, "auto_timeline_preview", False) and (not preview_updates_suspended()):
        s.auto_timeline_pending = True
        s.auto_timeline_requested_at = _time.time()
        try:
            rebuild_auto_timeline_preview(sc)
        except Exception:
            pass
    if preview_updates_suspended() or (not immediate):
        tag_preview_ui_redraw()
        return
    try:
        refresh_siren_preview_cache(sc)
    except Exception:
        pass
    tag_preview_ui_redraw()


def update_preview_only(self, context):
    mark_preview_dirty(context)


def update_pattern_preview_only(self, context):
    scene = getattr(context, "scene", None) if context else getattr(bpy.context, "scene", None)
    queue_preview_refresh_feedback(scene)
    mark_preview_dirty(context, scene=scene, immediate=False)



def env_light_name_for_siren(index):
    return f"nels_env_siren{int(index)}"


def siren_env_transform(scene, si):
    obj = siren_obj(si)
    arm, pb = siren_pose_bone(scene, si)

    if arm and pb:
        base_matrix = arm.matrix_world @ pb.matrix
        pos = base_matrix.translation.copy()
        direction = (base_matrix.to_quaternion() @ Vector((0.0, 1.0, 0.0))).normalized()
        return pos, direction

    if obj:
        base_matrix = obj.matrix_world.copy()
        pos = base_matrix.translation.copy()
        direction = (base_matrix.to_quaternion() @ Vector((0.0, 1.0, 0.0))).normalized()
        return pos, direction

    return None, None


def env_light_world_matrix(position, direction):
    try:
        direction = Vector(direction)
    except Exception:
        direction = Vector((0.0, 1.0, 0.0))
    if direction.length <= 0.000001:
        direction = Vector((0.0, 1.0, 0.0))
    direction.normalize()
    quat = Vector((0.0, 0.0, -1.0)).rotation_difference(direction)
    return Matrix.LocRotScale(Vector(position), quat, Vector((1.0, 1.0, 1.0)))


def clear_environment_lights(scene):
    removed = 0
    scene_objects = set(getattr(scene, "objects", [])) if scene else set()
    for obj in list(bpy.data.objects):
        if not obj or not obj.get("_nels_env_light"):
            continue
        if scene and scene_objects and obj not in scene_objects:
            continue
        try:
            data = getattr(obj, "data", None)
            bpy.data.objects.remove(obj, do_unlink=True)
            if data and getattr(data, "users", 0) == 0:
                bpy.data.lights.remove(data)
            removed += 1
        except Exception:
            pass
    return removed


def enable_viewport_scene_lights():
    wm = getattr(bpy.context, "window_manager", None)
    if not wm:
        return
    try:
        for win in wm.windows:
            screen = getattr(win, "screen", None)
            if not screen:
                continue
            for area in screen.areas:
                if getattr(area, "type", "") != "VIEW_3D":
                    continue
                for space in getattr(area, "spaces", []):
                    if getattr(space, "type", "") != "VIEW_3D":
                        continue
                    shading = getattr(space, "shading", None)
                    if not shading:
                        continue
                    for attr in ("use_scene_lights", "use_scene_lights_render"):
                        if hasattr(shading, attr):
                            try:
                                setattr(shading, attr, True)
                            except Exception:
                                pass
    except Exception:
        pass


def generate_environment_lights(scene, s):
    if not scene or not s:
        return 0, 0

    enable_viewport_scene_lights()
    collection = getattr(scene, "collection", None)
    created = 0
    updated = 0
    outer_angle = max(1.0, min(179.0, float(getattr(s, "light_outer_angle", 70.0) or 70.0)))
    inner_angle = max(0.0, min(outer_angle, float(getattr(s, "light_inner_angle", 2.29061) or 2.29061)))
    falloff = max(1.0, float(getattr(s, "light_falloff_max", 100.0) or 100.0))
    offset = max(0.05, float(getattr(s, "light_offset", 0.0) or 0.0) + 0.05)
    blend = 0.15
    if outer_angle > 0.0001:
        blend = max(0.0, min(1.0, 1.0 - (inner_angle / outer_angle)))

    for si in s.sirens:
        if not siren_is_active(si):
            continue
        position, direction = siren_env_transform(scene, si)
        if position is None or direction is None:
            continue
        try:
            direction = Vector(direction)
        except Exception:
            direction = Vector((0.0, 1.0, 0.0))
        if direction.length <= 0.000001:
            direction = Vector((0.0, 1.0, 0.0))
        direction.normalize()
        base_rgb = tuple(max(0.0, min(1.0, float(c))) for c in siren_base_color_rgb(s, si))
        peak = max(base_rgb) if base_rgb else 0.0
        vivid_rgb = tuple(min(1.0, c / peak) for c in base_rgb) if peak > 0.000001 else (1.0, 1.0, 1.0)

        name = env_light_name_for_siren(si.index)
        light_obj = bpy.data.objects.get(name)
        if not light_obj or getattr(light_obj, "type", "") != "LIGHT":
            light_data = bpy.data.lights.new(name=name, type="SPOT")
            light_obj = bpy.data.objects.new(name, light_data)
            light_obj["_nels_env_light"] = True
            if collection:
                collection.objects.link(light_obj)
            created += 1
        else:
            updated += 1

        light_obj["_nels_env_light"] = True
        light_data = light_obj.data
        light_data.type = "SPOT"
        light_data.color = vivid_rgb
        light_data.energy = max(2500.0, float(getattr(si, "light_intensity", 0.5) or 0.5) * 20000.0)
        light_data.shadow_soft_size = max(0.001, float(getattr(si, "corona_size", 0.0) or 0.0) + 0.05)
        light_data.spot_size = math.radians(outer_angle)
        light_data.spot_blend = blend
        if hasattr(light_data, "use_custom_distance"):
            light_data.use_custom_distance = True
        if hasattr(light_data, "cutoff_distance"):
            light_data.cutoff_distance = falloff
        if hasattr(light_data, "use_shadow"):
            light_data.use_shadow = bool(getattr(si, "cast_shadows", False))
        if hasattr(light_data, "diffuse_factor"):
            light_data.diffuse_factor = 1.0
        if hasattr(light_data, "specular_factor"):
            light_data.specular_factor = 1.0
        light_obj.hide_select = False
        light_obj.hide_viewport = False
        light_obj.hide_render = False
        light_obj.location = Vector(position) + (direction * offset)
        light_obj.rotation_mode = "QUATERNION"
        light_obj.rotation_quaternion = Vector((0.0, 0.0, -1.0)).rotation_difference(direction)

    return created, updated

def apply_car_light_simulation(scene, s, blink_indicators=False, now=None):
    if not scene or not s:
        return 0

    sim_now = playback_seconds(scene=scene, now=now)

    blink_on = True
    if blink_indicators and (s.car_left_indicator_on or s.car_right_indicator_on):
        ts = sim_now
        blink_on = ((ts * 1.5) % 1.0) < 0.5  # Standard-like turn signal cadence.

    head_l_on = bool(s.car_headlights_on) and pattern_is_on(s, s.left_head, s.bpm, now=sim_now, scene=scene)
    head_r_on = bool(s.car_headlights_on) and pattern_is_on(s, s.right_head, s.bpm, now=sim_now, scene=scene)
    tail_l_on = bool(s.car_taillights_on) and pattern_is_on(s, s.left_tail, s.bpm, now=sim_now, scene=scene)
    tail_r_on = bool(s.car_taillights_on) and pattern_is_on(s, s.right_tail, s.bpm, now=sim_now, scene=scene)

    left_on = bool(s.car_left_indicator_on) and blink_on
    right_on = bool(s.car_right_indicator_on) and blink_on
    extra_on = bool(s.car_extra_lights_on)

    touched = set()

    def _apply(objs, show):
        for obj in objs:
            if is_object_visible(obj) != bool(show):
                set_object_visible(obj, show)
                touched.add(obj.name)

    heads = scene_objects_by_keywords(scene, HEADLIGHT_KEYS)
    tails = scene_objects_by_keywords(scene, TAILLIGHT_KEYS)
    hl, hr, hc = split_side_objects(heads)
    tl, tr, tc = split_side_objects(tails)

    _apply(hl, head_l_on)
    _apply(hr, head_r_on)
    _apply(hc, bool(head_l_on or head_r_on))

    _apply(tl, tail_l_on)
    _apply(tr, tail_r_on)
    _apply(tc, bool(tail_l_on or tail_r_on))

    _apply(scene_objects_by_keywords(scene, LEFT_INDICATOR_KEYS), left_on)
    _apply(scene_objects_by_keywords(scene, RIGHT_INDICATOR_KEYS), right_on)
    _apply(scene_objects_by_keywords(scene, EXTRA_LIGHT_KEYS), extra_on)

    preview_states = {
        "always_on": True,
        "headlight_l": head_l_on,
        "headlight_r": head_r_on,
        "taillight_l": tail_l_on,
        "taillight_r": tail_r_on,
        "brakelight_l": tail_l_on,
        "brakelight_r": tail_r_on,
        "brakelight_m": bool(tail_l_on or tail_r_on),
        "reversinglight_l": False,
        "reversinglight_r": False,
        "indicator_lf": left_on,
        "indicator_lr": left_on,
        "indicator_rf": right_on,
        "indicator_rr": right_on,
        "extralight_1": extra_on,
        "extralight_2": extra_on,
        "extralight_3": extra_on,
        "extralight_4": extra_on,
    }
    touched_count = apply_light_id_preview(scene, s, preview_states)
    return len(touched) + int(touched_count)

def update_car_light_toggle(self, context):
    scene = getattr(context, "scene", None) if context else getattr(bpy.context, "scene", None)
    s = getattr(scene, "nels", None) if scene else None
    if not s:
        return
    apply_car_light_simulation(scene, s, blink_indicators=True, now=playback_seconds(scene=scene))


def timeline_playing():
    wm = getattr(bpy.context, "window_manager", None)
    if not wm:
        return False
    try:
        for win in wm.windows:
            screen = getattr(win, "screen", None)
            if screen and getattr(screen, "is_animation_playing", False):
                return True
    except Exception:
        return False
    return False



def stop_timeline_playback():
    wm = getattr(bpy.context, "window_manager", None)
    if not wm:
        return False
    stopped = False
    try:
        for win in wm.windows:
            screen = getattr(win, "screen", None)
            if not screen or not getattr(screen, "is_animation_playing", False):
                continue
            area = next((a for a in screen.areas if getattr(a, "type", "") == "VIEW_3D"), None)
            if area is None and getattr(screen, "areas", None):
                area = screen.areas[0]
            region = next((r for r in getattr(area, "regions", []) if getattr(r, "type", "") == "WINDOW"), None) if area else None
            try:
                with bpy.context.temp_override(window=win, screen=screen, area=area, region=region):
                    bpy.ops.screen.animation_cancel(restore_frame=False)
                stopped = True
            except Exception:
                try:
                    with bpy.context.temp_override(window=win, screen=screen, area=area, region=region):
                        bpy.ops.screen.animation_play()
                    stopped = True
                except Exception:
                    pass
    except Exception:
        return False
    return stopped

def set_scene_warning(scene, msg):
    s = getattr(scene, "nels", None) if scene else None
    if s and hasattr(s, "status_message"):
        s.status_message = str(msg or "")


def active_siren_direction_warning(scene):
    s = getattr(scene, "nels", None) if scene else None
    if not s or not s.sirens:
        return ""

    idx = max(0, min(int(s.active_siren), len(s.sirens) - 1))
    si = s.sirens[idx]
    if not siren_obj(si):
        return ""

    arm, pb = siren_pose_bone(scene, si)
    has_bone = bool(arm and pb and getattr(si, "bone_name", ""))
    if has_bone:
        return ""
    return f"Warning: Siren {si.index} has no linked bone for direction sync"


def refresh_direction_warning(scene):
    s = getattr(scene, "nels", None) if scene else None
    if not s:
        return
    msg = str(getattr(s, "status_message", "") or "")
    if msg.startswith("Warning: Siren ") and msg.endswith(" has no linked bone for direction sync"):
        s.status_message = ""


def apply_siren_direction_to_bone(scene, si, set_warning=True):
    if not scene or not si:
        return False

    arm, pb = siren_pose_bone(scene, si)
    if not arm or not pb:
        if set_warning:
            set_scene_warning(scene, f"Warning: Siren {si.index} has no linked bone for direction sync")
        return False

    ang = dir_val(si)
    vec = Vector((math.sin(ang), math.cos(ang), 0.0))
    if vec.length < 0.000001:
        vec = Vector((0.0, 1.0, 0.0))

    old_active = getattr(bpy.context.view_layer.objects, "active", None)
    old_mode = getattr(bpy.context, "mode", "OBJECT")

    try:
        if old_mode != "OBJECT":
            bpy.ops.object.mode_set(mode="OBJECT")
        bpy.ops.object.select_all(action="DESELECT")
        arm.select_set(True)
        bpy.context.view_layer.objects.active = arm
        bpy.ops.object.mode_set(mode="EDIT")

        eb = arm.data.edit_bones.get(pb.name) or arm.data.edit_bones.get(si.bone_name)
        if not eb:
            bpy.ops.object.mode_set(mode="OBJECT")
            if set_warning:
                set_scene_warning(scene, f"Warning: Could not find linked bone for siren {si.index}")
            return False

        head = eb.head.copy()
        length = (eb.tail - eb.head).length
        if length < 0.000001:
            length = 0.05
        eb.tail = head + vec.normalized() * length

        bpy.ops.object.mode_set(mode="OBJECT")
        pose_bone = arm.pose.bones.get(eb.name)
        if pose_bone:
            _store_rest_pose_bone(arm, pose_bone, force=True)

        if set_warning:
            set_scene_warning(scene, "")
        return True
    except Exception:
        if set_warning:
            set_scene_warning(scene, f"Warning: Failed to apply direction to siren {si.index} bone")
        return False
    finally:
        try:
            if old_active and old_active.name in bpy.data.objects:
                bpy.context.view_layer.objects.active = old_active
        except Exception:
            pass
        try:
            if old_mode != "OBJECT" and getattr(bpy.context, "mode", "OBJECT") == "OBJECT":
                bpy.ops.object.mode_set(mode=old_mode)
        except Exception:
            pass



def apply_all_siren_directions(scene):
    s = getattr(scene, "nels", None) if scene else None
    if not s or not s.sirens:
        return 0

    groups = {}
    for si in s.sirens:
        arm, pb = siren_pose_bone(scene, si)
        if arm and pb:
            groups.setdefault(arm.name, []).append((si, pb.name))

    if not groups:
        return 0

    updated = 0
    old_active = getattr(bpy.context.view_layer.objects, "active", None)
    old_mode = getattr(bpy.context, "mode", "OBJECT")

    try:
        if old_mode != "OBJECT":
            bpy.ops.object.mode_set(mode="OBJECT")
        bpy.ops.object.select_all(action="DESELECT")

        for arm_name, entries in groups.items():
            arm = bpy.data.objects.get(arm_name)
            if not arm or arm.type != "ARMATURE":
                continue

            bpy.ops.object.select_all(action="DESELECT")
            arm.select_set(True)
            bpy.context.view_layer.objects.active = arm
            bpy.ops.object.mode_set(mode="EDIT")

            updated_names = []
            for si, bone_name in entries:
                eb = arm.data.edit_bones.get(bone_name)
                if not eb:
                    continue
                ang = dir_val(si)
                vec = Vector((math.sin(ang), math.cos(ang), 0.0))
                if vec.length < 0.000001:
                    vec = Vector((0.0, 1.0, 0.0))
                head = eb.head.copy()
                length = (eb.tail - eb.head).length
                if length < 0.000001:
                    length = 0.05
                eb.tail = head + vec.normalized() * length
                updated_names.append(eb.name)
                updated += 1

            bpy.ops.object.mode_set(mode="OBJECT")
            for bone_name in updated_names:
                pb = arm.pose.bones.get(bone_name)
                if pb:
                    _store_rest_pose_bone(arm, pb, force=True)
    except Exception:
        return updated
    finally:
        try:
            if getattr(bpy.context, "mode", "OBJECT") != "OBJECT":
                bpy.ops.object.mode_set(mode="OBJECT")
        except Exception:
            pass
        try:
            if old_active and old_active.name in bpy.data.objects:
                bpy.context.view_layer.objects.active = old_active
        except Exception:
            pass
        try:
            if old_mode != "OBJECT" and getattr(bpy.context, "mode", "OBJECT") == "OBJECT":
                bpy.ops.object.mode_set(mode=old_mode)
        except Exception:
            pass

    return updated

def update_siren_direction(self, context):
    scene = getattr(context, "scene", None) if context else getattr(bpy.context, "scene", None)
    apply_siren_direction_to_bone(scene, self, set_warning=False)
    mark_preview_dirty(context, scene=scene)


def update_siren_bone_link(self, context):
    scene = getattr(context, "scene", None) if context else getattr(bpy.context, "scene", None)
    if self.bone_name:
        apply_siren_direction_to_bone(scene, self, set_warning=True)
    mark_preview_dirty(context, scene=scene)


def selected_mesh_name_from_context(context):
    active = getattr(context, "active_object", None)
    if active and getattr(active, "type", "") == "MESH":
        return active.name
    for obj in getattr(context, "selected_objects", []) or []:
        if obj and getattr(obj, "type", "") == "MESH":
            return obj.name
    return ""


def selected_armature_from_context(context, scene=None, s=None):
    active = getattr(context, "active_object", None)
    if active and getattr(active, "type", "") == "ARMATURE":
        return active
    if active and getattr(active, "parent", None) and getattr(active.parent, "type", "") == "ARMATURE":
        return active.parent
    for obj in getattr(context, "selected_objects", []) or []:
        if obj and getattr(obj, "type", "") == "ARMATURE":
            return obj
        if obj and getattr(obj, "parent", None) and getattr(obj.parent, "type", "") == "ARMATURE":
            return obj.parent
    arm_name = str(getattr(s, "armature_name", "") or "")
    if arm_name:
        arm = bpy.data.objects.get(arm_name)
        if arm and getattr(arm, "type", "") == "ARMATURE":
            if not scene or arm.name in getattr(scene, "objects", {}):
                return arm
    return None


def selected_bone_name_from_context(context, arm=None):
    active = getattr(context, "active_object", None)
    if arm and active and getattr(active, "parent", None) == arm and getattr(active, "parent_type", "") == "BONE" and getattr(active, "parent_bone", ""):
        return str(active.parent_bone)

    active_pose_bone = getattr(context, "active_pose_bone", None)
    if active_pose_bone and ((not arm) or active == arm):
        return str(active_pose_bone.name)

    active_bone = getattr(context, "active_bone", None)
    if active_bone and ((not arm) or active == arm):
        return str(active_bone.name)

    if active and getattr(active, "parent_type", "") == "BONE" and getattr(active, "parent_bone", ""):
        if (not arm) or getattr(active, "parent", None) == arm:
            return str(active.parent_bone)
    return ""

def compute_siren_preview_color(scene, s, si, now=None):
    try:
        base = siren_base_color_rgb(s, si) if s else tuple(si.custom_color)
        if not getattr(si, "flash_preview", True) or not s:
            return tuple(base)

        bits, _, vis = pattern_triplet(s, si)
        ts = preview_seconds(scene=scene, now=now)

        if si.siren_type == "ROTATOR":
            if vis not in {"BOTH", "ROTATOR"}:
                return _emissive_color(base, False)
            return _preview_lit_color(base, 1.0)

        vis_ok = vis in {"BOTH", "FLASHER"}
        bpm = max(1.0, float(getattr(s, "bpm", 800)))
        steps_per_second = bpm / 60.0
        idx = int(ts * steps_per_second) % 32
        on = bits[idx] == "1"
        return _emissive_color(base, bool(vis_ok and on))
    except Exception:
        return (1.0, 0.0, 0.0)


def get_siren_preview_color(self):
    scene = getattr(bpy.context, "scene", None)
    s = getattr(scene, "nels", None) if scene else None
    return compute_siren_preview_color(scene, s, self)


def refresh_siren_preview_cache(scene):
    s = getattr(scene, "nels", None) if scene else None
    if not s:
        return False
    if scene and getattr(s, "preview_generated", False) and timeline_playing() and (not getattr(s, "preview_refresh_pending", False)):
        return False

    ts = playback_seconds(scene=scene)
    bpm = max(1.0, float(getattr(s, "bpm", 800) or 800))
    step_idx = int(ts * (bpm / 60.0)) % 32
    if (not getattr(s, "preview_refresh_pending", False)) and int(getattr(s, "preview_last_step", -1) or -1) == step_idx:
        return False

    changed = False

    head_tail = (
        ("left_head_preview_cache", _head_tail_preview(s, s.left_head, (1.0, 1.0, 1.0), getattr(s, "head_tail_preview", True))),
        ("right_head_preview_cache", _head_tail_preview(s, s.right_head, (1.0, 1.0, 1.0), getattr(s, "head_tail_preview", True))),
        ("left_tail_preview_cache", _head_tail_preview(s, s.left_tail, (1.0, 0.0, 0.0), getattr(s, "head_tail_preview", True))),
        ("right_tail_preview_cache", _head_tail_preview(s, s.right_tail, (1.0, 0.0, 0.0), getattr(s, "head_tail_preview", True))),
    )
    for prop, col in head_tail:
        try:
            if tuple(getattr(s, prop)) != tuple(col):
                setattr(s, prop, col)
                changed = True
        except Exception:
            pass

    for si in s.sirens:
        col = compute_siren_preview_color(scene, s, si, now=ts)
        try:
            if tuple(si.preview_color_cache) != tuple(col):
                si.preview_color_cache = col
                changed = True
        except Exception:
            pass

    s.preview_last_step = step_idx
    return changed


def update_lib_color_rgb(self, context):
    v = rgb_to_color(self.rgb)
    if self.value != v:
        self.value = v
    save_library_from_context(context)


def update_lib_color_value(self, context):
    v = clean_color_value(self.value)
    if self.value != v:
        self.value = v
    rgb = color_to_rgb(v)
    if tuple(self.rgb) != rgb:
        self.rgb = rgb
    save_library_from_context(context)


def _draw_preview_rect(shader, x0, y0, x1, y1, color):
    if not shader or not batch_for_shader:
        return
    verts = ((x0, y0), (x1, y0), (x1, y1), (x0, y1))
    batch = batch_for_shader(shader, "TRI_FAN", {"pos": verts})
    shader.uniform_float("color", color)
    batch.draw(shader)


def _clip_range(start, end, lower, upper):
    return max(lower, start), min(upper, end)


def draw_custom_preview_overlay():
    return


def ensure_custom_preview_draw_handler():
    remove_custom_preview_draw_handler()
    return

def remove_custom_preview_draw_handler():
    global _CUSTOM_PREVIEW_DRAW_HANDLE
    if not _CUSTOM_PREVIEW_DRAW_HANDLE:
        return
    try:
        bpy.types.SpaceView3D.draw_handler_remove(_CUSTOM_PREVIEW_DRAW_HANDLE, "WINDOW")
    except Exception:
        pass
    _CUSTOM_PREVIEW_DRAW_HANDLE = None


class NELSPattern(PropertyGroup):
    name: StringProperty(default="Pattern", update=update_pattern_meta)
    allow_duplicate: BoolProperty(default=False, update=update_pattern_meta)
    visibility: EnumProperty(items=VISIBILITY_ITEMS, default="BOTH", update=update_pattern_meta)
    bits: StringProperty(default="00001111000011110000111100001111", maxlen=32, update=update_pattern_bits)
    value: StringProperty(default="252645135", update=update_pattern_value)


class NELSColor(PropertyGroup):
    name: StringProperty(default="Colour", update=update_color_name)
    value: StringProperty(default="0xFFFF0000", update=update_lib_color_value)
    rgb: FloatVectorProperty(subtype="COLOR", size=3, min=0.0, max=1.0, default=(1.0, 0.0, 0.0), update=update_lib_color_rgb)


class NELSOtherAttribute(PropertyGroup):
    display_value: StringProperty(default="Attribute")
    return_value: StringProperty(default="")


class NELSBodyOpening(PropertyGroup):
    key: StringProperty(default="door_dside_f")
    name: StringProperty(default="Body Opening")
    expanded: BoolProperty(default=False)
    opening_type: EnumProperty(items=BODY_OPENING_TYPES, default="HINGED", update=update_body_opening_type)
    rot_x: BoolProperty(default=True)
    rot_y: BoolProperty(default=True)
    rot_z: BoolProperty(default=True)
    slide_x: BoolProperty(default=False)
    slide_y: BoolProperty(default=False)
    slide_z: BoolProperty(default=False)
    limit_rotation: BoolProperty(default=True)
    limit_translation: BoolProperty(default=False)
    object_name: StringProperty(default="")
    anchor_name: StringProperty(default="")
    bone_name: StringProperty(default="")
    closed_location: FloatVectorProperty(size=3, default=(0.0, 0.0, 0.0), subtype="TRANSLATION")
    closed_rotation: FloatVectorProperty(size=3, default=(0.0, 0.0, 0.0), subtype="EULER")
    open_location: FloatVectorProperty(size=3, default=(0.0, 0.0, 0.0), subtype="TRANSLATION")
    open_rotation: FloatVectorProperty(size=3, default=(0.0, 0.0, 0.0), subtype="EULER")


class NELSSiren(PropertyGroup):
    index: IntProperty(default=1, min=1, max=MAX_SIRENS)
    name: StringProperty(default="Siren 1")
    enabled: BoolProperty(default=False)

    siren_type: EnumProperty(items=SIREN_TYPES, default="FLASHER", update=update_siren_type)
    rotator_speed_mode: EnumProperty(items=ROT_SPEED_ITEMS, default="P50", update=update_rotator_settings)
    rotator_custom_percent: FloatProperty(default=50.0, min=0.0, update=update_rotator_settings)
    rotator_clockwise: BoolProperty(default=True, update=update_preview_only)

    pattern_source: EnumProperty(items=[("LIBRARY", "Saved Pattern", ""), ("CUSTOM", "Custom Pattern", "")], default="LIBRARY", update=update_pattern_preview_only)
    pattern_choice: EnumProperty(items=pattern_items, update=update_pattern_preview_only)
    pattern_select: EnumProperty(items=pattern_select_items, update=update_pattern_select)
    custom_visibility: EnumProperty(items=VISIBILITY_ITEMS, default="BOTH", update=update_pattern_preview_only)
    custom_bits: StringProperty(default="00001111000011110000111100001111", maxlen=32, update=update_siren_bits)
    custom_value: StringProperty(default="252645135", update=update_siren_value)

    color_mode: EnumProperty(items=[("PRESET", "Preset", ""), ("CUSTOM", "Custom", "")], default="PRESET")
    color_preset: EnumProperty(items=color_items)
    color_select: EnumProperty(items=color_select_items, update=update_color_select)
    custom_color: FloatVectorProperty(subtype="COLOR", size=3, min=0.0, max=1.0, default=(1.0, 1.0, 1.0))
    flash_preview: BoolProperty(default=True)
    preview_color_cache: FloatVectorProperty(subtype="COLOR", size=3, min=0.0, max=1.0, default=(0.07, 0.07, 0.07))
    preview_color: FloatVectorProperty(subtype="COLOR", size=3, min=0.0, max=1.0, get=get_siren_preview_color)

    direction_mode: EnumProperty(items=[("PRESET", "Preset", ""), ("CUSTOM", "Custom", "")], default="PRESET", update=update_siren_direction)
    direction_preset: EnumProperty(items=DIRECTION_ITEMS, default="FRONT", update=update_siren_direction)
    direction_select: EnumProperty(items=direction_select_items, update=update_direction_select)
    custom_direction: FloatProperty(default=0.0, precision=8, update=update_siren_direction)
    scale_mode: EnumProperty(items=[("PRESET", "Preset", ""), ("CUSTOM", "Custom", "")], default="PRESET", update=update_preview_only)
    scale_preset: EnumProperty(items=SCALE_ITEMS, default="SCALE_50", update=update_preview_only)
    custom_scale: FloatProperty(default=0.5, min=0.0, precision=8, update=update_preview_only)

    sync_to_bpm: BoolProperty(default=True, update=update_preview_only)

    show_advanced: BoolProperty(default=False)
    flash: BoolProperty(default=True)
    light: BoolProperty(default=False)
    spot_light: BoolProperty(default=False)
    cast_shadows: BoolProperty(default=False)
    light_group: IntProperty(default=1, min=0)
    start_delay: FloatProperty(default=0.0, precision=8)
    light_speed: FloatProperty(default=0.0, precision=8)
    light_multiples: IntProperty(default=2, min=0)
    corona_intensity: FloatProperty(default=0.5, precision=8)
    corona_size: FloatProperty(default=0.0, precision=8)
    corona_pull: FloatProperty(default=0.00000001, precision=8)
    light_intensity: FloatProperty(default=0.5, precision=8)
    corona_face_camera: BoolProperty(default=False)

    object_name: StringProperty(default="")
    anchor_name: StringProperty(default="")
    bone_name: StringProperty(default="", update=update_siren_bone_link)


class NELSSettings(PropertyGroup):
    config_name: StringProperty(default="new_lightbar")
    vehicle_name: StringProperty(name="vehicle_name", default="police")
    vehicle_id: IntProperty(name="siren_id", default=25000, min=1, soft_min=25000)
    saved_config: EnumProperty(items=saved_cfg_items)

    bpm: IntProperty(default=800, min=1, update=update_bpm)
    scale_factor_choice: EnumProperty(items=SCALE_FACTOR_PRESET_ITEMS, default="SF_2", update=update_scale_factor_choice)
    scale_factor_custom: FloatProperty(default=0.5, min=0.0, precision=8, update=update_scale_factor_custom)
    scale_factor: FloatProperty(default=0.5, min=0.0, precision=8, update=update_scale_factor_value)
    left_head: EnumProperty(items=pattern_items, update=update_pattern_preview_only)
    right_head: EnumProperty(items=pattern_items, update=update_pattern_preview_only)
    left_tail: EnumProperty(items=pattern_items, update=update_pattern_preview_only)
    right_tail: EnumProperty(items=pattern_items, update=update_pattern_preview_only)

    all_flash_previews: BoolProperty(default=True)
    list_flash_preview: BoolProperty(default=True)
    head_tail_preview: BoolProperty(default=True)
    left_head_preview_cache: FloatVectorProperty(subtype="COLOR", size=3, min=0.0, max=1.0, default=(0.07, 0.07, 0.07))
    right_head_preview_cache: FloatVectorProperty(subtype="COLOR", size=3, min=0.0, max=1.0, default=(0.07, 0.07, 0.07))
    left_tail_preview_cache: FloatVectorProperty(subtype="COLOR", size=3, min=0.0, max=1.0, default=(0.07, 0.0, 0.0))
    right_tail_preview_cache: FloatVectorProperty(subtype="COLOR", size=3, min=0.0, max=1.0, default=(0.07, 0.0, 0.0))
    left_head_preview: FloatVectorProperty(subtype="COLOR", size=3, min=0.0, max=1.0, get=get_left_head_preview)
    right_head_preview: FloatVectorProperty(subtype="COLOR", size=3, min=0.0, max=1.0, get=get_right_head_preview)
    left_tail_preview: FloatVectorProperty(subtype="COLOR", size=3, min=0.0, max=1.0, get=get_left_tail_preview)
    right_tail_preview: FloatVectorProperty(subtype="COLOR", size=3, min=0.0, max=1.0, get=get_right_tail_preview)

    show_adv_main: BoolProperty(default=False)
    show_sirens_section: BoolProperty(default=True)
    show_other_attributes: BoolProperty(default=False)
    use_real_lights: BoolProperty(default=True)
    time_multiplier: FloatProperty(default=1.0, precision=8)
    light_falloff_max: FloatProperty(default=100.0, precision=8)
    light_falloff_exp: FloatProperty(default=100.0, precision=8)
    light_inner_angle: FloatProperty(default=2.29061, precision=8)
    light_outer_angle: FloatProperty(default=70.0, precision=8)
    light_offset: FloatProperty(default=0.0, precision=8)
    texture_name: StringProperty(default="VehicleLight_sirenlight")
    left_head_mult: IntProperty(default=1, min=0)
    right_head_mult: IntProperty(default=1, min=0)
    left_tail_mult: IntProperty(default=1, min=0)
    right_tail_mult: IntProperty(default=1, min=0)

    patterns: CollectionProperty(type=NELSPattern)
    active_pattern: IntProperty(default=0)

    colors: CollectionProperty(type=NELSColor)
    active_color: IntProperty(default=0)

    other_attributes: CollectionProperty(type=NELSOtherAttribute)
    active_other_attribute: IntProperty(default=0)

    body_openings: CollectionProperty(type=NELSBodyOpening)
    active_body_opening: IntProperty(default=0)
    body_opening_autodetect_at: FloatProperty(default=0.0, options={"HIDDEN"})

    sirens: CollectionProperty(type=NELSSiren)
    active_siren: IntProperty(default=0)
    tool_working_siren: EnumProperty(items=scene_siren_items, update=update_tool_working_siren)
    tool_origin_object: StringProperty(default="")
    siren_count: IntProperty(default=0, min=0, max=MAX_SIRENS)

    armature_name: StringProperty(default="")

    pattern_library_path: StringProperty(default=os.path.join(os.path.expanduser("~"), "Downloads", "flash_patterns.json"), subtype="FILE_PATH")

    wheel_all_axes_degrees: FloatProperty(default=25.0, precision=3)
    car_headlights_on: BoolProperty(default=False, update=update_car_light_toggle)
    car_taillights_on: BoolProperty(default=False, update=update_car_light_toggle)
    car_left_indicator_on: BoolProperty(default=False, update=update_car_light_toggle)
    car_right_indicator_on: BoolProperty(default=False, update=update_car_light_toggle)
    car_extra_lights_on: BoolProperty(default=False, update=update_car_light_toggle)
    car_light_id_target: EnumProperty(items=SOLLUMZ_LIGHT_ID_UI_ITEMS, default="always_on")
    car_light_id_custom_value: IntProperty(default=0, min=0)
    car_light_id_preview: BoolProperty(default=True, options={"HIDDEN"})
    car_light_id_signature: StringProperty(default="", options={"HIDDEN"})
    car_light_id_checked_at: FloatProperty(default=0.0, options={"HIDDEN"})
    export_path: StringProperty(default=os.path.join(os.path.expanduser("~"), "Downloads", "carcols.meta"), subtype="FILE_PATH")
    status_message: StringProperty(default="")
    preview_generated: BoolProperty(default=False, options={"HIDDEN"})
    preview_dirty: BoolProperty(default=False, options={"HIDDEN"})
    preview_refresh_pending: BoolProperty(default=False, options={"HIDDEN"})
    preview_refresh_has_motion: BoolProperty(default=False, options={"HIDDEN"})
    preview_refresh_started_at: FloatProperty(default=0.0, options={"HIDDEN"})
    preview_refresh_done_at: FloatProperty(default=0.0, options={"HIDDEN"})
    preview_refresh_signature: StringProperty(default="", options={"HIDDEN"})
    head_tail_initialized: BoolProperty(default=False, options={"HIDDEN"})
    preview_time_origin: FloatProperty(default=0.0, options={"HIDDEN"})
    preview_last_step: IntProperty(default=-1, options={"HIDDEN"})
    auto_timeline_preview: BoolProperty(default=False, update=lambda self, context: update_auto_timeline_preview(self, context))
    custom_preview_overlay: BoolProperty(default=False, update=update_preview_only)
    auto_timeline_pending: BoolProperty(default=False, options={"HIDDEN"})
    auto_timeline_requested_at: FloatProperty(default=0.0, options={"HIDDEN"})
    update_check_on_startup: BoolProperty(default=True)
    update_remote_version: StringProperty(default="")
    update_last_checked: StringProperty(default="")
    update_status: StringProperty(default="Not checked yet")
    update_available: BoolProperty(default=False)
    update_check_in_progress: BoolProperty(default=False, options={"HIDDEN"})
    update_install_in_progress: BoolProperty(default=False, options={"HIDDEN"})
    update_restart_required: BoolProperty(default=False)


def settings_to_dict(s):
    return {
        "config_name": s.config_name,
        "vehicle_name": s.vehicle_name,
        "vehicle_id": s.vehicle_id,
        "bpm": s.bpm,
        "scale_factor": s.scale_factor,
        "left_head": s.left_head,
        "right_head": s.right_head,
        "left_tail": s.left_tail,
        "right_tail": s.right_tail,
        "scale_factor_choice": s.scale_factor_choice,
        "scale_factor_custom": s.scale_factor_custom,
        "main": {k: getattr(s, k) for k in ["use_real_lights", "time_multiplier", "light_falloff_max", "light_falloff_exp", "light_inner_angle", "light_outer_angle", "light_offset", "texture_name", "left_head_mult", "right_head_mult", "left_tail_mult", "right_tail_mult", "armature_name", "siren_count"]},
        "patterns": [{"name": p.name, "visibility": p.visibility, "bits": clean_bits(p.bits), "value": parse_u32(p.value), "allow_duplicate": bool(getattr(p, "allow_duplicate", False))} for p in s.patterns],
        "colors": [{"name": c.name, "value": clean_color_value(c.value)} for c in s.colors],
        "other_attributes": [{"display_value": a.display_value, "return_value": a.return_value} for a in s.other_attributes],
        "body_openings": [{k: getattr(op, k) for k in ["key", "name", "opening_type", "rot_x", "rot_y", "rot_z", "slide_x", "slide_y", "slide_z", "limit_rotation", "limit_translation", "object_name", "anchor_name", "bone_name"]} | {"closed_location": list(op.closed_location), "closed_rotation": list(op.closed_rotation), "open_location": list(op.open_location), "open_rotation": list(op.open_rotation)} for op in s.body_openings],
        "sirens": [{k: getattr(si, k) for k in ["index", "name", "enabled", "siren_type", "rotator_speed_mode", "rotator_custom_percent", "rotator_clockwise", "pattern_source", "pattern_choice", "custom_visibility", "custom_bits", "custom_value", "color_mode", "color_preset", "direction_mode", "direction_preset", "custom_direction", "scale_mode", "scale_preset", "custom_scale", "sync_to_bpm", "flash_preview", "flash", "light", "spot_light", "cast_shadows", "light_group", "start_delay", "light_speed", "light_multiples", "corona_intensity", "corona_size", "corona_pull", "light_intensity", "corona_face_camera", "object_name", "anchor_name", "bone_name"]} | {"custom_color": list(si.custom_color)} for si in s.sirens],
    }


def apply_settings_dict(s, data):
    if not isinstance(data, dict):
        return

    for k in ["config_name", "vehicle_name", "vehicle_id", "bpm", "scale_factor", "scale_factor_choice", "scale_factor_custom", "left_head", "right_head", "left_tail", "right_tail", "all_flash_previews"]:
        if k in data:
            if k in {"left_head", "right_head", "left_tail", "right_tail"}:
                setattr(s, k, normalize_pattern_key(data[k]))
            elif k == "scale_factor_choice":
                setattr(s, k, data[k] if data[k] in {it[0] for it in SCALE_FACTOR_PRESET_ITEMS} else "CUSTOM")
            else:
                setattr(s, k, data[k])

    main = data.get("main", {})
    if not isinstance(main, dict):
        main = {}
    for k, v in main.items():
        if hasattr(s, k):
            setattr(s, k, v)

    s.patterns.clear()
    patterns_data = data.get("patterns", [])
    if not isinstance(patterns_data, list):
        patterns_data = []
    for pd in patterns_data:
        if not isinstance(pd, dict):
            continue
        p = s.patterns.add()
        p.name = pd.get("name", "Pattern")
        p.allow_duplicate = bool(pd.get("allow_duplicate", False))
        p.visibility = "FLASHER" if pd.get("visibility", "BOTH") == "FLASHER" else "BOTH"
        p.bits = clean_bits(pd.get("bits", int_to_bits(pd.get("value", 0))))
        p.value = str(parse_u32(pd.get("value", bits_to_int(p.bits))))
    ensure_off_pattern(s)
    if not s.patterns:
        ensure_defaults(s)

    s.colors.clear()
    colors_data = data.get("colors", [])
    if not isinstance(colors_data, list):
        colors_data = []
    for cd in colors_data:
        if not isinstance(cd, dict):
            continue
        c = s.colors.add()
        c.name = cd.get("name", "Colour")
        c.value = clean_color_value(cd.get("value", "0xFFFF0000"))
        c.rgb = color_to_rgb(c.value)
    ensure_color_defaults(s)

    s.other_attributes.clear()
    attrs_data = data.get("other_attributes", [])
    if not isinstance(attrs_data, list):
        attrs_data = []
    for ad in attrs_data:
        if not isinstance(ad, dict):
            continue
        a = s.other_attributes.add()
        a.display_value = str(ad.get("display_value", "Attribute") or "Attribute")
        a.return_value = str(ad.get("return_value", "") or "")
    if not s.other_attributes:
        ensure_other_attributes_defaults(s)

    s.body_openings.clear()
    openings_data = data.get("body_openings", [])
    if not isinstance(openings_data, list):
        openings_data = []
    for od in openings_data:
        if not isinstance(od, dict):
            continue
        op = s.body_openings.add()
        for key in ["key", "name", "opening_type", "rot_x", "rot_y", "rot_z", "slide_x", "slide_y", "slide_z", "limit_rotation", "limit_translation", "object_name", "anchor_name", "bone_name"]:
            if hasattr(op, key) and key in od:
                setattr(op, key, od[key])
        for key in ["closed_location", "closed_rotation", "open_location", "open_rotation"]:
            value = od.get(key, None)
            if isinstance(value, list) and len(value) >= 3:
                setattr(op, key, (float(value[0]), float(value[1]), float(value[2])))
    ensure_body_opening_defaults(s)

    loaded_sirens = data.get("sirens", [])
    if not isinstance(loaded_sirens, list):
        loaded_sirens = []

    try:
        requested_count = int(main.get("siren_count", data.get("siren_count", 0)))
    except Exception:
        requested_count = 0
    requested_count = max(requested_count, len(loaded_sirens))
    ensure_sirens(s, requested_count)

    for i, sd in enumerate(loaded_sirens):
        if i >= len(s.sirens):
            break
        if not isinstance(sd, dict):
            continue
        si = s.sirens[i]
        for k, v in sd.items():
            if k == "custom_color" and isinstance(v, list) and len(v) >= 3:
                si.custom_color = (float(v[0]), float(v[1]), float(v[2]))
            elif k == "custom_value":
                si.custom_value = str(parse_u32(v))
            elif k == "pattern_choice":
                si.pattern_choice = normalize_pattern_key(v)
            elif k == "color_preset":
                legacy = COLORS.get(str(v), None)
                if legacy:
                    target = clean_color_value(legacy)
                    idx = 0
                    for ci, col in enumerate(s.colors):
                        if clean_color_value(col.value) == target:
                            idx = ci
                            break
                    si.color_preset = f"COL_{idx}"
                else:
                    si.color_preset = normalize_color_key(v)
            elif hasattr(si, k):
                setattr(si, k, v)

    for i, si in enumerate(s.sirens, start=1):
        si.index = i
        si.name = f"siren{i}"
        si.color_preset = normalize_color_key(si.color_preset)
        si.pattern_choice = normalize_pattern_key(si.pattern_choice)
        sync_siren_selector_controls(si)

    try:
        current_id = int(s.vehicle_id)
    except Exception:
        current_id = 0
    if current_id <= 0:
        s.vehicle_id = generate_siren_id(s.vehicle_name)

    sync_scale_factor_controls(s)
    s.head_tail_initialized = True
    save_global_library(s)


def clear_missing_associations(scene):
    s = getattr(scene, "nels", None)
    if not s:
        return

    arm = None
    if s.armature_name:
        arm_obj = bpy.data.objects.get(s.armature_name)
        if arm_obj and arm_obj.type == "ARMATURE":
            arm = arm_obj
        else:
            s.armature_name = ""

    for si in s.sirens:
        if si.object_name and si.object_name not in bpy.data.objects:
            si.object_name = ""
        if si.anchor_name and si.anchor_name not in bpy.data.objects:
            si.anchor_name = ""
        if si.bone_name:
            has_bone = bool(arm and si.bone_name in arm.data.bones)
            if not has_bone:
                for obj in bpy.data.objects:
                    if obj.type != "ARMATURE":
                        continue
                    if si.bone_name in obj.data.bones:
                        has_bone = True
                        if not arm:
                            arm = obj
                            s.armature_name = obj.name
                        break
            if not has_bone:
                si.bone_name = ""
        si.enabled = bool(si.object_name or si.bone_name)

def ensure_scene_defaults(scene):
    s = getattr(scene, "nels", None)
    if not s:
        return None

    if not s.patterns:
        ensure_defaults(s)
    migrate_legacy_default_patterns(s)
    ensure_off_pattern(s)
    ensure_color_defaults(s)
    ensure_other_attributes_defaults(s)
    ensure_body_opening_defaults(s)
    sync_scale_factor_controls(s)

    off_key = off_pattern_key(s)
    if not getattr(s, "head_tail_initialized", False):
        s.left_head = off_key
        s.right_head = off_key
        s.left_tail = off_key
        s.right_tail = off_key
        s.head_tail_initialized = True
    else:
        if not s.left_head:
            s.left_head = off_key
        if not s.right_head:
            s.right_head = off_key
        if not s.left_tail:
            s.left_tail = off_key
        if not s.right_tail:
            s.right_tail = off_key

    if not s.saved_config:
        s.saved_config = NO_SAVED_CFG
    for si in s.sirens:
        si.color_preset = normalize_color_key(si.color_preset)
        si.pattern_choice = normalize_pattern_key(si.pattern_choice)
        if si.siren_type == "ROTATOR":
            update_rotator_settings(si, bpy.context)
        sync_siren_selector_controls(si)
    clear_missing_associations(scene)
    auto_detect_scene_sirens(scene, create_missing=(len(s.sirens) == 0), sync_direction=False)
    auto_detect_body_opening_links(scene, s)

    try:
        current_id = int(s.vehicle_id)
    except Exception:
        current_id = 0
    if current_id <= 0:
        s.vehicle_id = generate_siren_id(s.vehicle_name)
    normalize_update_state(s)
    refresh_siren_preview_cache(scene)
    schedule_startup_update_check(scene)
    return s


class NELS_OT_initialize_defaults(Operator):
    bl_idname = "nels.initialize_defaults"
    bl_label = "Initialize Defaults"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        ensure_scene_defaults(context.scene)
        return {"FINISHED"}

class NELS_OT_pattern_tools(Operator):
    bl_idname = "nels.pattern_tools"
    bl_label = "Pattern Tools"
    bl_options = {"REGISTER", "UNDO"}

    action: EnumProperty(items=[("ADD", "ADD", ""), ("DUPLICATE", "DUPLICATE", ""), ("REMOVE", "REMOVE", ""), ("REPEAT", "REPEAT", ""), ("INVERT", "INVERT", "")])
    scope: EnumProperty(items=[("LIB", "LIB", ""), ("SIREN", "SIREN", "")], default="LIB")

    def execute(self, context):
        s = context.scene.nels
        if self.action == "ADD":
            p = s.patterns.add()
            p.name = f"Pattern {len(s.patterns)}"
            p.allow_duplicate = False
            p.visibility = "BOTH"
            p.bits = "00001111000011110000111100001111"
            p.value = str(bits_to_int(p.bits))
            s.active_pattern = len(s.patterns) - 1
            save_global_library(s)
            return {"FINISHED"}
        if self.action == "DUPLICATE":
            if not s.patterns:
                return {"CANCELLED"}
            i = max(0, min(s.active_pattern, len(s.patterns) - 1))
            src = s.patterns[i]
            p = s.patterns.add()
            p.name = f"{(src.name or f'Pattern {i + 1}')} Copy"
            p.allow_duplicate = False
            p.visibility = src.visibility
            p.bits = src.bits
            p.value = src.value
            s.active_pattern = len(s.patterns) - 1
            save_global_library(s)
            return {"FINISHED"}
        if self.action == "REMOVE":
            if s.patterns:
                i = max(0, min(s.active_pattern, len(s.patterns) - 1))
                s.patterns.remove(i)
                s.active_pattern = min(i, max(0, len(s.patterns) - 1))
            save_global_library(s)
            return {"FINISHED"}

        si = s.sirens[s.active_siren] if s.sirens and 0 <= s.active_siren < len(s.sirens) else None
        if self.scope == "LIB":
            p = s.patterns[s.active_pattern] if s.patterns and 0 <= s.active_pattern < len(s.patterns) else None
            if not p:
                return {"CANCELLED"}
            if self.action == "REPEAT":
                p.bits = repeat_32(p.bits)
            elif self.action == "INVERT":
                p.bits = invert_bits(p.bits)
            save_global_library(s)
            return {"FINISHED"}

        if not si:
            return {"CANCELLED"}
        if self.action == "REPEAT":
            si.custom_bits = repeat_32(si.custom_bits)
        elif self.action == "INVERT":
            si.custom_bits = invert_bits(si.custom_bits)
        return {"FINISHED"}


class NELS_OT_save_siren_pattern(Operator):
    bl_idname = "nels.save_siren_pattern"
    bl_label = "Save Pattern to Library"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        scene = getattr(context, "scene", None)
        s = getattr(scene, "nels", None) if scene else None
        if not s or not s.sirens:
            self.report({"ERROR"}, "No siren selected")
            return {"CANCELLED"}

        idx = max(0, min(getattr(s, "active_siren", 0), len(s.sirens) - 1))
        si = s.sirens[idx]
        bits = repeat_32(getattr(si, "custom_bits", "0"))
        value = str(bits_to_int(bits))
        visibility = getattr(si, "custom_visibility", "BOTH")

        existing_key = find_pattern_key_by_bits(s, bits, visibility)
        if existing_key:
            si.pattern_source = "LIBRARY"
            si.pattern_choice = existing_key
            sync_siren_selector_controls(si)
            mark_preview_dirty(context)
            self.report({"INFO"}, "Matched existing library pattern")
            return {"FINISHED"}

        p = s.patterns.add()
        p.name = next_pattern_name(s, "Unsaved Pattern")
        p.allow_duplicate = False
        p.visibility = normalize_pattern_visibility(visibility)
        p.bits = bits
        p.value = value
        s.active_pattern = len(s.patterns) - 1

        save_global_library(s)

        si.pattern_source = "LIBRARY"
        si.pattern_choice = f"PAT_{s.active_pattern}"
        si.custom_bits = bits
        si.custom_value = value
        sync_siren_selector_controls(si)
        mark_preview_dirty(context)
        self.report({"INFO"}, f"Saved pattern as {p.name}")
        return {"FINISHED"}


class NELS_OT_pattern_duplicate_resolution(Operator):
    bl_idname = "nels.pattern_duplicate_resolution"
    bl_label = "Resolve Pattern Duplicate"
    bl_options = {"REGISTER", "UNDO"}

    action: EnumProperty(items=[("ALLOW", "Allow Duplicate", ""), ("KEEP_SELECTED", "Keep Selected Only", ""), ("WARN", "Warn Again", "")], default="ALLOW")
    index: IntProperty(default=-1)

    def execute(self, context):
        s = context.scene.nels
        idx = max(0, min(self.index, len(s.patterns) - 1)) if s.patterns else -1
        matches = pattern_duplicate_indices(s, idx)
        if idx < 0 or not matches:
            self.report({"INFO"}, "No duplicate pattern name detected")
            return {"CANCELLED"}

        if self.action == "ALLOW":
            count = set_pattern_duplicate_allowed(s, idx, True)
            save_global_library(s)
            self.report({"INFO"}, f"Duplicate allowed for {count} patterns")
            return {"FINISHED"}

        if self.action == "WARN":
            count = set_pattern_duplicate_allowed(s, idx, False)
            save_global_library(s)
            self.report({"INFO"}, f"Duplicate warning restored for {count} patterns")
            return {"FINISHED"}

        removed, keep_idx = remove_pattern_duplicates_keep_selected(s, idx)
        s.active_pattern = min(max(0, keep_idx), max(0, len(s.patterns) - 1))
        save_global_library(s)
        self.report({"INFO"}, f"Removed {removed} duplicate patterns")
        return {"FINISHED"}


class NELS_OT_pattern_library_io(Operator):
    bl_idname = "nels.pattern_library_io"
    bl_label = "Pattern Library Import/Export"
    bl_options = {"REGISTER", "UNDO"}

    action: EnumProperty(items=[("EXPORT", "EXPORT", ""), ("IMPORT", "IMPORT", "")], default="EXPORT")

    def execute(self, context):
        s = context.scene.nels
        fp = bpy.path.abspath(getattr(s, "pattern_library_path", "") or "").strip()
        if not fp:
            self.report({"ERROR"}, "Pattern library path is empty")
            return {"CANCELLED"}
        if not fp.lower().endswith(".json"):
            fp += ".json"

        try:
            if self.action == "EXPORT":
                out_dir = os.path.dirname(fp)
                if out_dir:
                    os.makedirs(out_dir, exist_ok=True)

                data = {
                    "patterns": [
                        {
                            "name": p.name,
                            "visibility": "FLASHER" if p.visibility == "FLASHER" else "BOTH",
                            "bits": repeat_32(p.bits),
                            "value": parse_u32(p.value),
                            "allow_duplicate": bool(getattr(p, "allow_duplicate", False)),
                        }
                        for p in s.patterns
                    ]
                }
                with open(fp, "w", encoding="utf-8") as h:
                    json.dump(data, h, indent=2)
                s.pattern_library_path = fp
                s.status_message = f"Pattern library exported: {fp}"
                self.report({"INFO"}, s.status_message)
                return {"FINISHED"}

            if not os.path.exists(fp):
                self.report({"ERROR"}, f"Pattern library not found: {fp}")
                return {"CANCELLED"}

            with open(fp, "r", encoding="utf-8") as h:
                data = json.load(h)

            if isinstance(data, dict):
                pats = data.get("patterns", [])
            elif isinstance(data, list):
                pats = data
            else:
                self.report({"ERROR"}, "Invalid pattern library format")
                return {"CANCELLED"}

            if not isinstance(pats, list):
                self.report({"ERROR"}, "Pattern library must contain a list of patterns")
                return {"CANCELLED"}

            s.patterns.clear()
            for pd in pats:
                if not isinstance(pd, dict):
                    continue
                p = s.patterns.add()
                p.name = str(pd.get("name", "Pattern") or "Pattern")
                p.allow_duplicate = bool(pd.get("allow_duplicate", False))
                p.visibility = "FLASHER" if pd.get("visibility", "BOTH") == "FLASHER" else "BOTH"
                bits = clean_bits(pd.get("bits", int_to_bits(pd.get("value", 0)))) or "0"
                p.bits = bits
                p.value = str(parse_u32(pd.get("value", bits_to_int(bits))))

            ensure_off_pattern(s)
            s.active_pattern = min(max(0, s.active_pattern), max(0, len(s.patterns) - 1))
            save_global_library(s)
            s.pattern_library_path = fp
            s.status_message = f"Pattern library imported: {fp}"
            self.report({"INFO"}, s.status_message)
            return {"FINISHED"}
        except Exception as ex:
            self.report({"ERROR"}, f"Pattern library {self.action.lower()} failed: {ex}")
            return {"CANCELLED"}
class NELS_OT_color_tools(Operator):
    bl_idname = "nels.color_tools"
    bl_label = "Color Tools"
    bl_options = {"REGISTER", "UNDO"}

    action: EnumProperty(items=[("ADD", "ADD", ""), ("REMOVE", "REMOVE", "")])

    def execute(self, context):
        s = context.scene.nels
        ensure_color_defaults(s)

        if self.action == "ADD":
            c = s.colors.add()
            c.name = f"Custom Colour {len(s.colors)}"
            c.rgb = (1.0, 0.0, 0.0)
            c.value = rgb_to_color(c.rgb)
            s.active_color = len(s.colors) - 1
            save_global_library(s)
            return {"FINISHED"}

        if not s.colors:
            return {"CANCELLED"}
        i = max(0, min(s.active_color, len(s.colors) - 1))
        s.colors.remove(i)
        if not s.colors:
            ensure_color_defaults(s)
        s.active_color = min(i, max(0, len(s.colors) - 1))
        for si in s.sirens:
            si.color_preset = normalize_color_key(si.color_preset)
        save_global_library(s)
        return {"FINISHED"}


class NELS_OT_other_attr_tools(Operator):
    bl_idname = "nels.other_attr_tools"
    bl_label = "Other Attribute Tools"
    bl_options = {"REGISTER", "UNDO"}

    action: EnumProperty(items=[("ADD", "ADD", ""), ("REMOVE", "REMOVE", "")], default="ADD")

    def execute(self, context):
        s = context.scene.nels
        ensure_other_attributes_defaults(s)

        if self.action == "ADD":
            a = s.other_attributes.add()
            a.display_value = f"Attribute {len(s.other_attributes)}"
            a.return_value = ""
            s.active_other_attribute = len(s.other_attributes) - 1
            return {"FINISHED"}

        if not s.other_attributes:
            return {"CANCELLED"}
        i = max(0, min(s.active_other_attribute, len(s.other_attributes) - 1))
        s.other_attributes.remove(i)
        if not s.other_attributes:
            ensure_other_attributes_defaults(s)
        s.active_other_attribute = min(i, max(0, len(s.other_attributes) - 1))
        return {"FINISHED"}


class NELS_OT_light_id_faces(Operator):
    bl_idname = "nels.light_id_faces"
    bl_label = "Light IDs"
    bl_options = {"REGISTER", "UNDO"}

    action: EnumProperty(items=[("SET", "Set", "Assign the selected Light ID to the selected faces"), ("SELECT", "Select", "Select faces that already use the chosen Light ID")], default="SET")

    def execute(self, context):
        scene = getattr(context, "scene", None)
        s = getattr(scene, "nels", None) if scene else None
        if not s:
            self.report({"WARNING"}, "No scene settings available")
            return {"CANCELLED"}
        if not light_id_face_select_ready(context):
            self.report({"WARNING"}, "Must be in Edit Mode > Face Select")
            return {"CANCELLED"}

        obj = getattr(context, "active_object", None)
        if not obj or getattr(obj, "type", "") != "MESH":
            self.report({"WARNING"}, "Select a mesh in Edit Mode")
            return {"CANCELLED"}

        bm = bmesh.from_edit_mesh(obj.data)
        bm.faces.ensure_lookup_table()
        value = current_light_id_value(s)
        label = next((item[1] for item in SOLLUMZ_LIGHT_ID_UI_ITEMS if item[0] == getattr(s, "car_light_id_target", "always_on")), "Custom")

        if self.action == "SET":
            faces = [face for face in bm.faces if face.select]
            if not faces:
                self.report({"WARNING"}, "Select one or more faces first")
                return {"CANCELLED"}
            layer = editable_light_id_face_layer(bm, create=True)
            if layer is None:
                self.report({"ERROR"}, "Could not access a face integer layer for Light IDs")
                return {"CANCELLED"}
            for face in faces:
                face[layer] = int(value)
            bmesh.update_edit_mesh(obj.data, loop_triangles=False, destructive=False)
            s.car_light_id_signature = ""
            s.car_light_id_checked_at = 0.0
            apply_car_light_simulation(scene, s, blink_indicators=True, now=playback_seconds(scene=scene))
            self.report({"INFO"}, f"Assigned {label} to {len(faces)} face(s)")
            return {"FINISHED"}

        layer = editable_light_id_face_layer(bm, create=False)
        if layer is None:
            self.report({"WARNING"}, "No editable Light ID layer was found on this mesh")
            return {"CANCELLED"}

        match_count = 0
        for face in bm.faces:
            is_match = int(face[layer]) == int(value)
            face.select_set(is_match)
            if is_match:
                match_count += 1
        bmesh.update_edit_mesh(obj.data, loop_triangles=False, destructive=False)
        if match_count <= 0:
            self.report({"WARNING"}, f"No faces use {label}")
            return {"CANCELLED"}
        self.report({"INFO"}, f"Selected {match_count} face(s) using {label}")
        return {"FINISHED"}

class NELS_OT_car_lights_sim(Operator):
    bl_idname = "nels.car_lights_sim"
    bl_label = "Apply Car Light Simulation"
    bl_options = {"REGISTER", "UNDO"}

    action: EnumProperty(items=[("APPLY", "APPLY", ""), ("RESET", "RESET", "")], default="APPLY")

    def execute(self, context):
        s = context.scene.nels
        scene = context.scene

        if self.action == "RESET":
            s.car_headlights_on = False
            s.car_taillights_on = False
            s.car_left_indicator_on = False
            s.car_right_indicator_on = False
            s.car_extra_lights_on = False

        touched = apply_car_light_simulation(scene, s, blink_indicators=True, now=playback_seconds(scene=scene))
        msg = f"Applied car light simulation to {touched} objects"
        s.status_message = msg
        self.report({"INFO"}, msg)
        return {"FINISHED"}


class NELS_OT_wheel_simulation(Operator):
    bl_idname = "nels.wheel_simulation"
    bl_label = "Wheel Preview"
    bl_options = {"REGISTER", "UNDO"}

    action: EnumProperty(items=[("APPLY", "APPLY", ""), ("RESET", "RESET", "")], default="APPLY")

    def execute(self, context):
        s = context.scene.nels
        scene = context.scene

        if self.action == "RESET":
            removed = clear_wheel_preview_objects(scene)
            msg = f"Cleared {removed} tyre preview objects"
            s.status_message = msg
            self.report({"INFO"}, msg)
            return {"FINISHED"}

        arm, bones = wheel_pose_bones(scene)
        if not arm or not bones:
            msg = "Warning: No wheel bones found (set Parent Skeleton and ensure wheel bone names contain 'wheel')"
            s.status_message = msg
            self.report({"WARNING"}, msg)
            return {"CANCELLED"}

        linked, skipped, msg = simulate_tyres_on_wheel_bones(context, arm, bones)
        s.status_message = msg
        if linked <= 0:
            self.report({"WARNING"}, msg)
            return {"CANCELLED"}

        self.report({"INFO"}, f"{msg} (source wheel kept: {skipped})")
        return {"FINISHED"}


class NELS_OT_environment_lights(Operator):
    bl_idname = "nels.environment_lights"
    bl_label = "Environmental Lights"
    bl_options = {"REGISTER", "UNDO"}

    action: EnumProperty(
        items=[
            ("GENERATE", "Generate", "Create or update environment preview lights for active sirens"),
            ("CLEAR", "Clear", "Remove previously generated environment preview lights"),
        ],
        default="GENERATE",
    )

    def execute(self, context):
        scene = getattr(context, "scene", None)
        s = getattr(scene, "nels", None) if scene else None
        if not scene or not s:
            self.report({"WARNING"}, "No scene settings available")
            return {"CANCELLED"}

        if self.action == "CLEAR":
            removed = clear_environment_lights(scene)
            self.report({"INFO"}, f"Removed {removed} generated environment light(s)")
            return {"FINISHED"}

        created, updated = generate_environment_lights(scene, s)
        self.report({"INFO"}, f"Environment lights updated: {created} created, {updated} updated")
        return {"FINISHED"}


class NELS_OT_extra_visibility(Operator):
    bl_idname = "nels.extra_visibility"
    bl_label = "Set Extra Visibility"
    bl_options = {"REGISTER", "UNDO"}

    object_name: StringProperty(default="")
    show: BoolProperty(default=True)

    def execute(self, context):
        obj = bpy.data.objects.get(self.object_name)
        if not obj:
            return {"CANCELLED"}
        set_object_visible(obj, self.show)
        return {"FINISHED"}


class NELS_OT_extras_visibility_all(Operator):
    bl_idname = "nels.extras_visibility_all"
    bl_label = "Set All Extras Visibility"
    bl_options = {"REGISTER", "UNDO"}

    show: BoolProperty(default=True)

    def execute(self, context):
        objs = scene_extra_objects(context.scene)
        for obj in objs:
            set_object_visible(obj, self.show)
        self.report({"INFO"}, f"Updated {len(objs)} extras")
        return {"FINISHED"}
class NELS_OT_set_siren_count(Operator):
    bl_idname = "nels.set_siren_count"
    bl_label = "Set Siren Count"
    bl_options = {"REGISTER", "UNDO"}
    count: IntProperty(default=20)

    def execute(self, context):
        ensure_sirens(context.scene.nels, self.count)
        return {"FINISHED"}



class NELS_OT_swap_sirens(Operator):
    bl_idname = "nels.swap_sirens"
    bl_label = "Swap Sirens"
    bl_options = {"REGISTER", "UNDO"}

    siren_a: EnumProperty(name="First Siren", items=swappable_siren_items)
    siren_b: EnumProperty(name="Second Siren", items=swappable_siren_items)

    def invoke(self, context, event):
        items = [item[0] for item in swappable_siren_items(self, context) if item[0] != "__NONE__"]
        if len(items) < 2:
            msg = "Warning: Link mesh and bone for at least two sirens before swapping"
            context.scene.nels.status_message = msg
            self.report({"WARNING"}, msg)
            return {"CANCELLED"}
        if self.siren_a not in items:
            self.siren_a = items[0]
        if self.siren_b not in items or self.siren_b == self.siren_a:
            self.siren_b = next((item for item in items if item != self.siren_a), items[0])
        return context.window_manager.invoke_props_dialog(self, width=360)

    def draw(self, context):
        l = self.layout
        l.label(text="Swap the scene mesh and bone names for two configured sirens.")
        l.prop(self, "siren_a", text="First Siren")
        l.prop(self, "siren_b", text="Second Siren")

    def execute(self, context):
        scene = context.scene
        s = scene.nels
        if self.siren_a == "__NONE__" or self.siren_b == "__NONE__":
            msg = "Warning: Link mesh and bone for at least two sirens before swapping"
            s.status_message = msg
            self.report({"WARNING"}, msg)
            return {"CANCELLED"}
        if self.siren_a == self.siren_b:
            msg = "Warning: Choose two different sirens to swap"
            s.status_message = msg
            self.report({"WARNING"}, msg)
            return {"CANCELLED"}

        si_a = siren_slot_by_index(s, self.siren_a)
        si_b = siren_slot_by_index(s, self.siren_b)
        if not si_a or not si_b:
            msg = "Warning: Could not resolve the selected sirens"
            s.status_message = msg
            self.report({"WARNING"}, msg)
            return {"CANCELLED"}

        obj_a = siren_obj(si_a)
        obj_b = siren_obj(si_b)
        arm_a, pb_a = siren_pose_bone(scene, si_a)
        arm_b, pb_b = siren_pose_bone(scene, si_b)
        if not obj_a or obj_a.type != "MESH" or not obj_b or obj_b.type != "MESH":
            msg = "Warning: Both selected sirens must have linked mesh objects before swapping"
            s.status_message = msg
            self.report({"WARNING"}, msg)
            return {"CANCELLED"}
        if not arm_a or not pb_a or not arm_b or not pb_b:
            msg = "Warning: Both selected sirens must have linked bones before swapping"
            s.status_message = msg
            self.report({"WARNING"}, msg)
            return {"CANCELLED"}

        old_obj_a_name = obj_a.name
        old_obj_b_name = obj_b.name
        old_bone_a_name = pb_a.name
        old_bone_b_name = pb_b.name
        new_obj_a_name = f"siren{si_b.index}"
        new_obj_b_name = f"siren{si_a.index}"
        new_bone_a_name = f"siren{si_b.index}"
        new_bone_b_name = f"siren{si_a.index}"

        def object_name_conflict(target_name):
            other = bpy.data.objects.get(target_name)
            return other is not None and other not in (obj_a, obj_b)

        def bone_name_conflict(arm, target_name, allowed_names):
            bone = arm.data.bones.get(target_name) if arm and getattr(arm, "data", None) else None
            return bone is not None and bone.name not in allowed_names

        if object_name_conflict(new_obj_a_name) or object_name_conflict(new_obj_b_name):
            msg = "Warning: A different scene object is already using one of the target siren names"
            s.status_message = msg
            self.report({"WARNING"}, msg)
            return {"CANCELLED"}

        allowed_a = {old_bone_a_name}
        allowed_b = {old_bone_b_name}
        if arm_a == arm_b:
            allowed_a.add(old_bone_b_name)
            allowed_b.add(old_bone_a_name)
        if bone_name_conflict(arm_a, new_bone_a_name, allowed_a) or bone_name_conflict(arm_b, new_bone_b_name, allowed_b):
            msg = "Warning: A different siren bone is already using one of the target siren names"
            s.status_message = msg
            self.report({"WARNING"}, msg)
            return {"CANCELLED"}

        def capture_children(arm, bone_name):
            links = []
            for child in scene.objects:
                try:
                    if child.parent == arm and child.parent_type == "BONE" and child.parent_bone == bone_name:
                        links.append((child, child.matrix_world.copy()))
                except Exception:
                    continue
            return links

        def restore_children(links, arm, bone_name):
            for child, matrix_world in links:
                try:
                    child.parent = arm
                    child.parent_type = "BONE"
                    child.parent_bone = bone_name
                    child.matrix_world = matrix_world
                except Exception:
                    continue

        child_links_a = capture_children(arm_a, old_bone_a_name)
        child_links_b = capture_children(arm_b, old_bone_b_name)
        temp_tag = _time.time_ns()
        temp_obj_a_name = f"__nels_swap_obj_{si_a.index}_{temp_tag}_a"
        temp_obj_b_name = f"__nels_swap_obj_{si_b.index}_{temp_tag}_b"
        temp_bone_a_name = f"__nels_swap_bone_{si_a.index}_{temp_tag}_a"
        temp_bone_b_name = f"__nels_swap_bone_{si_b.index}_{temp_tag}_b"

        old_active = getattr(context.view_layer.objects, "active", None)
        old_mode = getattr(context, "mode", "OBJECT")
        try:
            obj_a.name = temp_obj_a_name
            obj_b.name = temp_obj_b_name
            obj_a.name = new_obj_a_name
            obj_b.name = new_obj_b_name

            plans = []
            if arm_a == arm_b:
                plans.append((arm_a, [(old_bone_a_name, temp_bone_a_name), (old_bone_b_name, temp_bone_b_name)], [(temp_bone_a_name, new_bone_a_name), (temp_bone_b_name, new_bone_b_name)]))
            else:
                plans.append((arm_a, [(old_bone_a_name, temp_bone_a_name)], [(temp_bone_a_name, new_bone_a_name)]))
                plans.append((arm_b, [(old_bone_b_name, temp_bone_b_name)], [(temp_bone_b_name, new_bone_b_name)]))

            if old_mode != "OBJECT":
                bpy.ops.object.mode_set(mode="OBJECT")
            for arm, temp_pairs, final_pairs in plans:
                bpy.ops.object.select_all(action="DESELECT")
                arm.select_set(True)
                context.view_layer.objects.active = arm
                bpy.ops.object.mode_set(mode="EDIT")
                for old_name, temp_name in temp_pairs:
                    eb = arm.data.edit_bones.get(old_name)
                    if not eb:
                        raise RuntimeError(f"Missing editable bone {old_name}")
                    eb.name = temp_name
                for temp_name, final_name in final_pairs:
                    eb = arm.data.edit_bones.get(temp_name)
                    if not eb:
                        raise RuntimeError(f"Missing temporary bone {temp_name}")
                    eb.name = final_name
                bpy.ops.object.mode_set(mode="OBJECT")
        except Exception as exc:
            msg = f"Warning: Failed to swap sirens: {exc}"
            s.status_message = msg
            self.report({"WARNING"}, msg)
            return {"CANCELLED"}
        finally:
            try:
                if getattr(context, "mode", "OBJECT") != "OBJECT":
                    bpy.ops.object.mode_set(mode="OBJECT")
            except Exception:
                pass
            try:
                if old_active and old_active.name in bpy.data.objects:
                    context.view_layer.objects.active = old_active
            except Exception:
                pass
            try:
                if old_mode != "OBJECT" and getattr(context, "mode", "OBJECT") == "OBJECT":
                    bpy.ops.object.mode_set(mode=old_mode)
            except Exception:
                pass

        restore_children(child_links_a, arm_a, new_bone_a_name)
        restore_children(child_links_b, arm_b, new_bone_b_name)

        object_map = {old_obj_a_name: new_obj_a_name, old_obj_b_name: new_obj_b_name}
        bone_map = {old_bone_a_name: new_bone_a_name, old_bone_b_name: new_bone_b_name}
        for si in s.sirens:
            if si.object_name in object_map:
                si.object_name = object_map[si.object_name]
            if si.bone_name in bone_map:
                si.bone_name = bone_map[si.bone_name]
            si.enabled = bool(si.object_name or si.bone_name)

        anchor_a = si_a.anchor_name
        anchor_b = si_b.anchor_name
        si_a.object_name = f"siren{si_a.index}"
        si_b.object_name = f"siren{si_b.index}"
        si_a.bone_name = f"siren{si_a.index}"
        si_b.bone_name = f"siren{si_b.index}"
        si_a.anchor_name = anchor_b
        si_b.anchor_name = anchor_a
        si_a.enabled = True
        si_b.enabled = True

        apply_all_siren_directions(scene)
        refresh_direction_warning(scene)
        mark_preview_dirty(context)
        tag_all_ui_redraw()

        msg = f"Swapped Siren {si_a.index} and Siren {si_b.index}"
        s.status_message = msg
        self.report({"INFO"}, msg)
        return {"FINISHED"}


class NELS_OT_renumber_siren(Operator):
    bl_idname = "nels.renumber_siren"
    bl_label = "Renumber Siren"
    bl_options = {"REGISTER", "UNDO"}

    target_index: EnumProperty(name="New Siren Number", items=renumber_target_items)

    def invoke(self, context, event):
        scene = context.scene
        s = getattr(scene, "nels", None)
        if not s or not s.sirens:
            self.report({"WARNING"}, "No sirens are configured")
            return {"CANCELLED"}
        clear_missing_associations(scene)
        items = [item[0] for item in renumber_target_items(self, context) if item[0] != "__NONE__"]
        if not items:
            self.report({"WARNING"}, "No available siren numbers exist in the current configuration")
            return {"CANCELLED"}
        if self.target_index not in items:
            self.target_index = items[0]
        return context.window_manager.invoke_props_dialog(self, width=340)

    def draw(self, context):
        self.layout.label(text="Rename the selected siren hierarchy to an unused configured siren number.")
        self.layout.prop(self, "target_index", text="Target")

    def execute(self, context):
        scene = context.scene
        s = getattr(scene, "nels", None)
        if not s or not s.sirens:
            self.report({"ERROR"}, "No sirens are configured")
            return {"CANCELLED"}

        clear_missing_associations(scene)
        if self.target_index == "__NONE__":
            self.report({"ERROR"}, "No target siren number is available")
            return {"CANCELLED"}

        try:
            target_index = int(self.target_index)
        except Exception:
            self.report({"ERROR"}, "Invalid target siren number")
            return {"CANCELLED"}

        limit = max(0, min(int(getattr(s, "siren_count", len(s.sirens)) or len(s.sirens)), len(s.sirens)))
        if target_index < 1 or target_index > limit:
            self.report({"ERROR"}, f"Target siren must be between 1 and {limit}")
            return {"CANCELLED"}

        target_slot = siren_slot_by_index(s, target_index)
        if not target_slot:
            self.report({"ERROR"}, f"Could not resolve Siren {target_index}")
            return {"CANCELLED"}
        if (siren_obj(target_slot) or siren_pose_bone(scene, target_slot)[1]):
            self.report({"ERROR"}, f"Siren {target_index} already exists in the scene")
            return {"CANCELLED"}

        source_slot = resolve_context_siren(scene, s, require_linked=False)
        active = selected_siren_root_object(context, fallback=siren_obj(source_slot) if source_slot else None)
        if not active:
            self.report({"ERROR"}, "Select a siren mesh or sub-mesh first")
            return {"CANCELLED"}

        source_obj = active
        old_index = infer_siren_index_from_hierarchy(source_obj, fallback=int(getattr(source_slot, "index", 0) or 0))
        if old_index <= 0:
            self.report({"ERROR"}, "Could not determine the siren number from the selected hierarchy")
            return {"CANCELLED"}
        if old_index == target_index:
            self.report({"ERROR"}, "Choose a different siren number")
            return {"CANCELLED"}

        source_slot = siren_slot_by_index(s, old_index) or source_slot
        source_snapshot = capture_siren_slot_snapshot(source_slot) if source_slot else None
        old_object_name = getattr(source_obj, "name", "")
        old_anchor_name = getattr(source_slot, "anchor_name", "") if source_slot else ""
        old_bone_name = str(getattr(source_slot, "bone_name", "") or f"siren{old_index}")

        try:
            arm, pb = siren_pose_bone(scene, source_slot) if source_slot else (None, None)
            renamed_bones = {}
            new_root_bone_name = ""
            if arm and pb:
                renamed_bones, new_root_bone_name = rename_siren_bone_hierarchy(scene, arm, pb.name, old_index, target_index)
            hierarchy = retarget_siren_hierarchy(source_obj, old_index, target_index, detach_root=False)
            renamed_objects = set(hierarchy or [])
            if arm and renamed_bones:
                subtree_bones = set(renamed_bones.values())
                extra_roots = []
                for obj in scene.objects:
                    try:
                        if obj in renamed_objects:
                            continue
                        if obj.parent == arm and obj.parent_type == "BONE" and obj.parent_bone in subtree_bones:
                            extra_roots.append(obj)
                    except Exception:
                        continue
                for obj in extra_roots:
                    renamed_objects.update(retarget_siren_hierarchy(obj, old_index, target_index, detach_root=False, force_root_name=False) or [])
            new_object_name = getattr(source_obj, "name", f"siren{target_index}")
        except Exception as exc:
            self.report({"ERROR"}, f"Failed to renumber siren: {exc}")
            return {"CANCELLED"}

        if source_snapshot:
            apply_siren_slot_snapshot(s, target_slot, target_index, source_snapshot)
        else:
            add_siren(s, target_slot, target_index)

        target_slot.object_name = new_object_name
        if new_root_bone_name:
            target_slot.bone_name = new_root_bone_name
        elif renamed_bones:
            target_slot.bone_name = renamed_bones.get(old_bone_name, f"siren{target_index}")
        target_slot.anchor_name = old_anchor_name
        target_slot.enabled = True

        if source_slot:
            add_siren(s, source_slot, old_index)
        s.active_siren = max(0, target_index - 1)

        refresh_direction_warning(scene)
        apply_all_siren_directions(scene)
        clear_preview_keyframes(scene, list(s.sirens))
        s.preview_generated = False
        mark_preview_dirty(context)
        tag_all_ui_redraw()

        msg = f"Renumbered siren{old_index} to siren{target_index}"
        s.status_message = msg
        self.report({"INFO"}, msg)
        return {"FINISHED"}


class NELS_OT_duplicate_siren(Operator):
    bl_idname = "nels.duplicate_siren"
    bl_label = "Duplicate Siren"
    bl_options = {"REGISTER", "UNDO"}

    target_index: EnumProperty(name="Target Siren", items=renumber_target_items)

    def invoke(self, context, event):
        scene = context.scene
        s = getattr(scene, "nels", None)
        if not s or not s.sirens:
            return {"CANCELLED"}
        source = resolve_context_siren(scene, s, require_linked=True)
        if not source:
            return {"CANCELLED"}
        items = [item[0] for item in renumber_target_items(self, context) if item[0] != "__NONE__"]
        if not items:
            self.report({"WARNING"}, "No available siren numbers exist in the current configuration")
            return {"CANCELLED"}
        suggested = str(suggest_duplicate_target_index(s, source.index))
        self.target_index = suggested if suggested in items else items[0]
        return context.window_manager.invoke_props_dialog(self, width=340)

    def draw(self, context):
        self.layout.label(text="Duplicate the selected siren hierarchy to an unused configured siren number.")
        self.layout.prop(self, "target_index", text="Target")

    def execute(self, context):
        scene = context.scene
        s = getattr(scene, "nels", None)
        if not s or not s.sirens:
            self.report({"ERROR"}, "No sirens are available in the current configuration")
            return {"CANCELLED"}

        source = resolve_context_siren(scene, s, require_linked=True)
        if not source:
            self.report({"ERROR"}, "No linked siren could be resolved from the current selection")
            return {"CANCELLED"}

        if self.target_index == "__NONE__":
            self.report({"ERROR"}, "No target siren number is available")
            return {"CANCELLED"}
        target_index = int(self.target_index or 0)
        limit = max(0, min(int(getattr(s, "siren_count", len(s.sirens)) or len(s.sirens)), len(s.sirens)))
        if target_index < 1 or target_index > limit:
            self.report({"ERROR"}, f"Target siren must be between 1 and {limit}")
            return {"CANCELLED"}
        if target_index == int(source.index):
            self.report({"ERROR"}, "Choose a different siren number for the duplicate")
            return {"CANCELLED"}

        ensure_sirens(s, max(len(s.sirens), target_index))
        target = siren_slot_by_index(s, target_index)
        if not target:
            self.report({"ERROR"}, f"Could not resolve Siren {target_index}")
            return {"CANCELLED"}
        if target.object_name or target.bone_name:
            self.report({"ERROR"}, f"Siren {target_index} is already configured")
            return {"CANCELLED"}
        if bpy.data.objects.get(f"siren{target_index}") is not None:
            self.report({"ERROR"}, f"An object named siren{target_index} already exists")
            return {"CANCELLED"}

        source_obj = siren_obj(source)
        if not source_obj:
            self.report({"ERROR"}, "The active siren has no linked mesh to duplicate")
            return {"CANCELLED"}

        arm, pb = siren_pose_bone(scene, source)
        extra_sources = siren_bone_subtree_objects(scene, arm, pb.name, exclude={source_obj}) if arm and pb else []
        dup_root, duplicates = duplicate_siren_hierarchy(scene, source_obj, source.index, target_index, extra_sources=extra_sources)
        if not dup_root:
            self.report({"ERROR"}, "Could not duplicate the selected siren hierarchy")
            return {"CANCELLED"}

        source_snapshot = capture_siren_slot_snapshot(source)
        apply_siren_slot_snapshot(s, target, target_index, source_snapshot)
        target.object_name = dup_root.name
        target.bone_name = ""
        target.anchor_name = ""
        target.enabled = True
        s.active_siren = max(0, target_index - 1)
        clear_preview_keyframes(scene, [target])
        refresh_direction_warning(scene)
        mark_preview_dirty(context)

        try:
            bpy.ops.object.select_all(action='DESELECT')
            for obj in duplicates:
                obj.select_set(True)
            context.view_layer.objects.active = dup_root
        except Exception:
            pass

        msg = f"Duplicated Siren {source.index} to Siren {target_index}"
        s.status_message = msg
        self.report({"INFO"}, msg)
        return {"FINISHED"}


class NELS_OT_auto_detect(Operator):
    bl_idname = "nels.auto_detect"
    bl_label = "Auto-Detect Sirens/Bones"
    bl_options = {"REGISTER", "UNDO"}

    create_missing: BoolProperty(default=True)

    def execute(self, context):
        obj_count, bone_count, linked = auto_detect_scene_sirens(context.scene, create_missing=self.create_missing, sync_direction=True)
        self.report({"INFO"}, f"Detected objects: {obj_count}, bones: {bone_count}, linked: {linked}")
        return {"FINISHED"}


class NELS_OT_generate_siren_id(Operator):
    bl_idname = "nels.generate_siren_id"
    bl_label = "Generate Siren ID"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        s = context.scene.nels
        s.vehicle_id = generate_siren_id(s.vehicle_name)
        return {"FINISHED"}


def reset_scene_config_defaults(s, keep_name=False):
    cfg_name = s.config_name if keep_name and str(s.config_name).strip() else "new_lightbar"
    s.config_name = cfg_name
    s.vehicle_name = "police"
    s.vehicle_id = generate_siren_id(s.vehicle_name)
    s.bpm = 800
    s.scale_factor = 0.5
    s.scale_factor_choice = "SF_2"
    s.scale_factor_custom = 0.5
    s.patterns.clear()
    ensure_defaults(s)
    s.colors.clear()
    ensure_color_defaults(s)
    s.other_attributes.clear()
    ensure_other_attributes_defaults(s)
    s.sirens.clear()
    s.siren_count = 0
    off_key = off_pattern_key(s)
    s.left_head = off_key
    s.right_head = off_key
    s.left_tail = off_key
    s.right_tail = off_key
    s.saved_config = NO_SAVED_CFG
    s.car_headlights_on = False
    s.car_taillights_on = False
    s.car_left_indicator_on = False
    s.car_right_indicator_on = False
    s.car_extra_lights_on = False
    sync_scale_factor_controls(s)


class NELS_OT_new_save_load(Operator):
    bl_idname = "nels.new_save_load"
    bl_label = "Config IO"
    bl_options = {"REGISTER", "UNDO"}
    action: EnumProperty(items=[("NEW", "NEW", ""), ("SAVE", "SAVE", ""), ("LOAD", "LOAD", ""), ("DELETE", "DELETE", ""), ("RESET", "RESET", "")])

    def execute(self, context):
        s = context.scene.nels
        if self.action == "NEW":
            reset_scene_config_defaults(s, keep_name=False)
            auto_detect_scene_sirens(context.scene, create_missing=True, sync_direction=True)
            return {"FINISHED"}

        if self.action == "SAVE":
            fp = os.path.join(cfg_dir(), safe_name(s.config_name) + ".json")
            with open(fp, "w", encoding="utf-8") as h:
                json.dump(settings_to_dict(s), h, indent=2)
            s.saved_config = os.path.basename(fp)
            return {"FINISHED"}

        if self.action == "RESET":
            if s.saved_config and s.saved_config != NO_SAVED_CFG:
                fp = os.path.join(cfg_dir(), s.saved_config)
                if os.path.exists(fp):
                    with open(fp, "r", encoding="utf-8") as h:
                        data = json.load(h)
                    apply_settings_dict(s, data)
                    ensure_scene_defaults(context.scene)
                    return {"FINISHED"}
            reset_scene_config_defaults(s, keep_name=True)
            auto_detect_scene_sirens(context.scene, create_missing=True, sync_direction=True)
            return {"FINISHED"}

        if self.action == "DELETE":
            if not s.saved_config or s.saved_config == NO_SAVED_CFG:
                return {"CANCELLED"}
            fp = os.path.join(cfg_dir(), s.saved_config)
            if os.path.exists(fp):
                os.remove(fp)
            choices = config_json_files()
            s.saved_config = choices[0] if choices else NO_SAVED_CFG
            return {"FINISHED"}

        if not s.saved_config or s.saved_config == NO_SAVED_CFG:
            return {"CANCELLED"}
        fp = os.path.join(cfg_dir(), s.saved_config)
        if not os.path.exists(fp):
            return {"CANCELLED"}
        with open(fp, "r", encoding="utf-8") as h:
            data = json.load(h)
        apply_settings_dict(s, data)
        ensure_scene_defaults(context.scene)
        return {"FINISHED"}


class NELS_OT_export_config(Operator):
    bl_idname = "nels.export_config"
    bl_label = "Export Configuration"

    filepath: StringProperty(subtype="FILE_PATH")
    filter_glob: StringProperty(default="*.json", options={"HIDDEN"})

    def execute(self, context):
        s = context.scene.nels
        fp = self.filepath or bpy.path.abspath(f"//{safe_name(s.config_name)}.json")
        if not fp.lower().endswith(".json"):
            fp += ".json"
        out_dir = os.path.dirname(fp)
        if out_dir:
            os.makedirs(out_dir, exist_ok=True)
        with open(fp, "w", encoding="utf-8") as h:
            json.dump(settings_to_dict(s), h, indent=2)
        self.report({"INFO"}, f"Exported configuration: {fp}")
        return {"FINISHED"}

    def invoke(self, context, event):
        s = context.scene.nels
        if not self.filepath:
            self.filepath = bpy.path.abspath(f"//{safe_name(s.config_name)}.json")
        context.window_manager.fileselect_add(self)
        return {"RUNNING_MODAL"}


class NELS_OT_import_config(Operator):
    bl_idname = "nels.import_config"
    bl_label = "Import Configuration"

    filepath: StringProperty(subtype="FILE_PATH")
    filter_glob: StringProperty(default="*.json", options={"HIDDEN"})

    def execute(self, context):
        s = context.scene.nels
        fp = self.filepath
        if not fp or not os.path.exists(fp):
            self.report({"ERROR"}, "Configuration file not found")
            return {"CANCELLED"}

        with open(fp, "r", encoding="utf-8") as h:
            data = json.load(h)
        apply_settings_dict(s, data)
        ensure_scene_defaults(context.scene)
        self.report({"INFO"}, f"Imported configuration: {fp}")
        return {"FINISHED"}

    def invoke(self, context, event):
        self.filepath = bpy.path.abspath("//")
        context.window_manager.fileselect_add(self)
        return {"RUNNING_MODAL"}



def _read_xml_value(node, tag, default=None):
    if node is None:
        return default
    child = node.find(tag)
    if child is None:
        return default
    return child.attrib.get("value", default)


def _read_bool(value, default=False):
    txt = str(value).strip().lower()
    if txt in {"true", "1", "yes"}:
        return True
    if txt in {"false", "0", "no"}:
        return False
    return bool(default)


class NELS_OT_import_carcols(Operator):
    bl_idname = "nels.import_carcols"
    bl_label = "Import carcols.meta"

    filepath: StringProperty(subtype="FILE_PATH")
    filter_glob: StringProperty(default="*.meta;*.xml", options={"HIDDEN"})

    def execute(self, context):
        s = context.scene.nels
        fp = self.filepath
        if not fp or not os.path.exists(fp):
            self.report({"ERROR"}, "carcols.meta file not found")
            return {"CANCELLED"}

        suspend_preview_updates()
        try:
            try:
                tree = ET.parse(fp)
                root = tree.getroot()
            except Exception as ex:
                self.report({"ERROR"}, f"Invalid XML: {ex}")
                return {"CANCELLED"}

            top = root.find("./Sirens/Item")
            if top is None:
                self.report({"ERROR"}, "Invalid carcols format: missing Sirens/Item")
                return {"CANCELLED"}

            if not s.patterns:
                ensure_defaults(s)
            migrate_legacy_default_patterns(s)
            ensure_off_pattern(s)
            ensure_color_defaults(s)
            ensure_other_attributes_defaults(s)
            sync_scale_factor_controls(s)

            try:
                s.vehicle_id = int(_read_xml_value(top, "id", s.vehicle_id))
            except Exception:
                pass
            nm = top.find("name")
            if nm is not None and nm.text:
                s.vehicle_name = nm.text.strip() or s.vehicle_name

            try:
                s.bpm = int(_read_xml_value(top, "sequencerBpm", s.bpm))
            except Exception:
                pass

            off_key = off_pattern_key(s)
            s.left_head = off_key
            s.right_head = off_key
            s.left_tail = off_key
            s.right_tail = off_key
            s.head_tail_initialized = True

            for tag, prop in [("leftHeadLight", "left_head"), ("rightHeadLight", "right_head"), ("leftTailLight", "left_tail"), ("rightTailLight", "right_tail")]:
                sec = top.find(tag)
                if sec is None:
                    continue
                seq = parse_u32(_read_xml_value(sec, "sequencer", 0))
                bits = int_to_bits(seq)
                setattr(s, prop, off_key if seq == 0 else normalize_pattern_key(get_or_add_pattern(s, f"Imported {tag}", "BOTH", bits)))

            sirens_node = top.find("sirens")
            if sirens_node is None:
                self.report({"ERROR"}, "Invalid carcols format: missing sirens block")
                return {"CANCELLED"}

            items = [n for n in sirens_node.findall("Item")]
            ensure_sirens(s, len(items))
            imported_scale_factor = None

            for i, it in enumerate(items):
                if i >= len(s.sirens):
                    break
                si = s.sirens[i]
                rot = it.find("rotation")
                fl = it.find("flashiness")
                rotate_flag = _read_bool(_read_xml_value(it, "rotate", "false"), False)
                si.siren_type = "ROTATOR" if rotate_flag else "FLASHER"

                seq_val = 0
                vis = "BOTH"
                if si.siren_type == "ROTATOR" and rot is not None:
                    seq_val = parse_u32(_read_xml_value(rot, "sequencer", 0))
                    vis = "ROTATOR"
                elif fl is not None:
                    seq_val = parse_u32(_read_xml_value(fl, "sequencer", 0))
                    vis = "FLASHER"

                if seq_val == 0:
                    si.pattern_source = "LIBRARY"
                    si.pattern_choice = off_key
                else:
                    matched_pattern = find_pattern_key_by_bits(s, int_to_bits(seq_val), vis)
                    if matched_pattern:
                        si.pattern_source = "LIBRARY"
                        si.pattern_choice = matched_pattern
                    else:
                        si.pattern_source = "CUSTOM"
                        si.custom_visibility = normalize_pattern_visibility(vis)
                        si.custom_value = str(seq_val)
                        si.custom_bits = int_to_bits(seq_val)

                col_hex = clean_color_value(_read_xml_value(it, "color", COLORS["GENERAL_WHITE"]))
                preset = find_color_key_by_value(s, col_hex)
                if preset != "COL_0" or col_hex == clean_color_value(COLORS["GENERAL_WHITE"]):
                    si.color_mode = "PRESET"
                    si.color_preset = preset
                else:
                    si.color_mode = "CUSTOM"
                    si.custom_color = color_to_rgb(col_hex)

                scale_factor = _read_xml_value(it, "scaleFactor", None)
                if imported_scale_factor is None and scale_factor is not None:
                    imported_scale_factor = normalize_import_scale_factor(scale_factor)
                apply_scale_to_siren(si, scale_factor)

                dir_val_txt = _read_xml_value(rot if rotate_flag and rot is not None else fl, "delta", 0.0)
                try:
                    imported_dir = float(dir_val_txt)
                except Exception:
                    imported_dir = 0.0
                preset_dir = direction_preset_from_value(imported_dir)
                if preset_dir:
                    si.direction_mode = "PRESET"
                    si.direction_preset = preset_dir
                    si.custom_direction = float(DIRECTIONS.get(preset_dir, 0.0))
                else:
                    si.direction_mode = "CUSTOM"
                    si.custom_direction = imported_dir
                si.sync_to_bpm = _read_bool(_read_xml_value(rot if rotate_flag and rot is not None else fl, "syncToBpm", "true"), True)
                si.start_delay = float(_read_xml_value(fl if fl is not None else rot, "start", 0.0) or 0.0)
                si.light_speed = float(_read_xml_value(fl if fl is not None else rot, "speed", 0.0) or 0.0)
                si.light_multiples = int(float(_read_xml_value(fl if fl is not None else rot, "multiples", 0) or 0))
                si.rotator_clockwise = _read_bool(_read_xml_value(rot, "direction", "true"), True) if rot is not None else True

                si.flash = _read_bool(_read_xml_value(it, "flash", "true"), True)
                si.light = _read_bool(_read_xml_value(it, "light", "false"), False)
                si.spot_light = _read_bool(_read_xml_value(it, "spotLight", "false"), False)
                si.cast_shadows = _read_bool(_read_xml_value(it, "castShadows", "false"), False)
                si.light_group = int(float(_read_xml_value(it, "lightGroup", 1) or 1))

                cor = it.find("corona")
                if cor is not None:
                    si.corona_intensity = float(_read_xml_value(cor, "intensity", si.corona_intensity) or si.corona_intensity)
                    si.corona_size = float(_read_xml_value(cor, "size", si.corona_size) or si.corona_size)
                    si.corona_pull = float(_read_xml_value(cor, "pull", si.corona_pull) or si.corona_pull)
                    si.corona_face_camera = _read_bool(_read_xml_value(cor, "faceCamera", si.corona_face_camera), si.corona_face_camera)

                update_rotator_settings(si, context)

            if imported_scale_factor is not None:
                apply_scale_to_settings(s, imported_scale_factor)

            off_key = off_pattern_key(s)
            s.left_head = normalize_pattern_key(s.left_head) if s.left_head else off_key
            s.right_head = normalize_pattern_key(s.right_head) if s.right_head else off_key
            s.left_tail = normalize_pattern_key(s.left_tail) if s.left_tail else off_key
            s.right_tail = normalize_pattern_key(s.right_tail) if s.right_tail else off_key

            for i, si in enumerate(s.sirens, start=1):
                si.index = i
                si.name = f"siren{i}"
                si.color_preset = normalize_color_key(si.color_preset)
                if getattr(si, "pattern_source", "LIBRARY") != "CUSTOM":
                    si.pattern_choice = normalize_pattern_key(si.pattern_choice or off_key)
                if si.siren_type == "ROTATOR":
                    update_rotator_settings(si, context)
                sync_siren_selector_controls(si)

            if not s.saved_config:
                s.saved_config = NO_SAVED_CFG
            clear_missing_associations(context.scene)
            try:
                current_id = int(s.vehicle_id)
            except Exception:
                current_id = 0
            if current_id <= 0:
                s.vehicle_id = generate_siren_id(s.vehicle_name)
        finally:
            resume_preview_updates()

        auto_detect_scene_sirens(context.scene, create_missing=False, sync_direction=False)
        apply_all_siren_directions(context.scene)
        clear_preview_keyframes(context.scene, list(s.sirens))
        s.preview_generated = False
        s.auto_timeline_pending = False
        stop_timeline_playback()
        s.preview_time_origin = _time.time()
        s.preview_last_step = -1
        s.preview_dirty = True
        refresh_siren_preview_cache(context.scene)
        tag_all_ui_redraw()
        self.report({"INFO"}, f"Imported carcols: {fp}")
        return {"FINISHED"}

    def invoke(self, context, event):
        self.filepath = bpy.path.abspath("//")
        context.window_manager.fileselect_add(self)
        return {"RUNNING_MODAL"}


class NELS_MT_siren_actions(Menu):
    bl_label = "Siren Actions"
    bl_idname = "NELS_MT_siren_actions"

    def draw(self, context):
        l = self.layout
        s = getattr(context.scene, "nels", None)
        o = l.operator("nels.set_siren_count", text="Add 20 Sirens", icon="ADD")
        o.count = 20
        o = l.operator("nels.set_siren_count", text="Add 32 Sirens", icon="ADD")
        o.count = 32
        if s and len(s.sirens) == 20:
            o = l.operator("nels.set_siren_count", text="Add 12 Additional (21-32)", icon="ADD")
            o.count = 32
        if s and len(s.sirens) > 20:
            o = l.operator("nels.set_siren_count", text="Remove Sirens 21-32", icon="REMOVE")
            o.count = 20
        o = l.operator("nels.set_siren_count", text="Remove All Sirens", icon="TRASH")
        o.count = 0
        l.separator()
        l.operator("nels.duplicate_siren", text="Duplicate Siren", icon="DUPLICATE")
        l.operator("nels.swap_sirens", text="Swap Two Sirens", icon="FILE_REFRESH")

class NELS_MT_config_actions(Menu):
    bl_label = "Configuration Actions"
    bl_idname = "NELS_MT_config_actions"

    def draw(self, context):
        l = self.layout
        o = l.operator("nels.new_save_load", text="Save Configuration", icon="FILE_TICK")
        o.action = "SAVE"
        o = l.operator("nels.new_save_load", text="Reset Current to Default", icon="LOOP_BACK")
        o.action = "RESET"
        o = l.operator("nels.new_save_load", text="Delete Saved Configuration", icon="TRASH")
        o.action = "DELETE"
        l.operator("nels.export_config", text="Export Configuration", icon="EXPORT")
        l.operator("nels.import_config", text="Import Configuration", icon="IMPORT")
        l.operator("nels.import_carcols", text="Import carcols.meta", icon="FILEBROWSER")


class NELS_OT_choose_parent_skeleton(Operator):
    bl_idname = "nels.choose_parent_skeleton"
    bl_label = "Select Parent Skeleton"
    bl_options = {"REGISTER", "UNDO"}

    next_action: EnumProperty(items=[("BONE", "BONE", "")], default="BONE")
    skeleton_name: EnumProperty(items=scene_armature_items)

    def invoke(self, context, event):
        s = context.scene.nels
        arm = bpy.data.objects.get(s.armature_name) if s.armature_name else None
        if arm and arm.type == "ARMATURE":
            self.skeleton_name = arm.name
        else:
            arms = sorted({obj.name for obj in context.scene.objects if obj.type == "ARMATURE"}, key=str.lower)
            if not arms:
                msg = "Warning: Select or create a Parent Skeleton before placing a siren bone"
                s.status_message = msg
                self.report({"WARNING"}, msg)
                return {"CANCELLED"}
            self.skeleton_name = arms[0]
        return context.window_manager.invoke_props_dialog(self, width=360)

    def draw(self, context):
        l = self.layout
        l.label(text="Choose the armature that will receive the siren bone.")
        l.prop(self, "skeleton_name", text="Parent Skeleton")

    def execute(self, context):
        s = context.scene.nels
        if self.skeleton_name == "__NONE__":
            msg = "Warning: No armatures were found in the current scene"
            s.status_message = msg
            self.report({"WARNING"}, msg)
            return {"CANCELLED"}
        s.armature_name = self.skeleton_name
        s.status_message = f"Parent Skeleton set to {self.skeleton_name}"
        if self.next_action:
            return bpy.ops.nels.link_bone(action=self.next_action)
        return {"FINISHED"}


class NELS_OT_link_bone(Operator):
    bl_idname = "nels.link_bone"
    bl_label = "Link Object/Bone"
    bl_options = {"REGISTER", "UNDO"}
    action: EnumProperty(items=[("MARK", "MARK", ""), ("BONE", "BONE", ""), ("ORIGIN", "ORIGIN", "")])

    def execute(self, context):
        s = context.scene.nels
        if not s.sirens:
            return {"CANCELLED"}
        si = s.sirens[s.active_siren]
        obj = context.active_object

        if self.action == "MARK":
            if not obj:
                return {"CANCELLED"}
            old_index = infer_siren_index_from_hierarchy(obj, fallback=infer_siren_index_from_object(obj, s=s) or si.index) or si.index
            retarget_siren_hierarchy(obj, old_index, si.index, detach_root=True)
            nm = f"siren{si.index}"
            obj.name = nm
            si.object_name = nm
            si.bone_name = ""
            si.anchor_name = ""
            si.enabled = True
            _store_rest_loc(obj, force=True)
            s.status_message = f"Assigned {nm} and retargeted linked mesh data"
            return {"FINISHED"}

        if self.action == "ORIGIN":
            sobj = siren_obj(si)
            if not sobj:
                msg = f"Warning: Assign a siren object to siren{si.index} before copying its origin"
                s.status_message = msg
                self.report({"WARNING"}, msg)
                return {"CANCELLED"}

            reference = pick_reference_object(context, si)
            if not reference:
                msg = "Warning: Select a separate helper object to copy its origin to the active siren"
                s.status_message = msg
                self.report({"WARNING"}, msg)
                return {"CANCELLED"}

            ok, msg = set_object_origin_from_reference(sobj, reference)
            s.status_message = msg
            if ok:
                si.anchor_name = reference.name
                self.report({"INFO"}, msg)
                return {"FINISHED"}
            self.report({"ERROR"}, msg)
            return {"CANCELLED"}

        arm = bpy.data.objects.get(s.armature_name) if s.armature_name else None
        if not arm or arm.type != "ARMATURE":
            scene_arms = sorted({o.name for o in context.scene.objects if o.type == "ARMATURE"}, key=str.lower)
            if not scene_arms:
                msg = "Warning: Select or create a Parent Skeleton before placing a siren bone"
                s.status_message = msg
                self.report({"WARNING"}, msg)
                return {"CANCELLED"}
            if len(scene_arms) == 1:
                s.armature_name = scene_arms[0]
                arm = bpy.data.objects.get(s.armature_name)
                s.status_message = f"Parent Skeleton set to {s.armature_name}"
            else:
                bpy.ops.nels.choose_parent_skeleton('INVOKE_DEFAULT', next_action=self.action)
                return {"FINISHED"}

        sobj = siren_obj(si)
        if not sobj:
            msg = f"Warning: Assign a siren object to siren{si.index} before placing its bone"
            s.status_message = msg
            self.report({"WARNING"}, msg)
            return {"CANCELLED"}

        anchor = pick_anchor_object(context, arm, si)
        if not anchor:
            anchor = sobj

        active = context.view_layer.objects.active
        mode = context.mode
        try:
            if mode != "OBJECT":
                bpy.ops.object.mode_set(mode="OBJECT")
            bpy.ops.object.select_all(action="DESELECT")
            arm.select_set(True)
            context.view_layer.objects.active = arm
            bpy.ops.object.mode_set(mode="EDIT")
            bn = f"siren{si.index}"
            eb = arm.data.edit_bones.get(bn) or arm.data.edit_bones.new(bn)
            head = arm.matrix_world.inverted() @ anchor.matrix_world.translation
            eb.head = head
            eb.tail = head + Vector((0.0, 0.05, 0.0))
            bpy.ops.object.mode_set(mode="OBJECT")
            wm = sobj.matrix_world.copy()
            sobj.parent = arm
            sobj.parent_type = "BONE"
            sobj.parent_bone = bn
            sobj.matrix_world = wm
            si.bone_name = bn
            si.anchor_name = anchor.name
            _store_rest_loc(sobj, force=True)
            s.status_message = f"Placed bone {bn} on {arm.name}"
        finally:
            if active and active.name in bpy.data.objects:
                context.view_layer.objects.active = active
            if mode != "OBJECT" and context.mode == "OBJECT":
                try:
                    bpy.ops.object.mode_set(mode=mode)
                except Exception:
                    pass
        return {"FINISHED"}
        if not s.armature_name:
            return {"CANCELLED"}
        arm = bpy.data.objects.get(s.armature_name)
        sobj = siren_obj(si)
        anchor = pick_anchor_object(context, arm, si)
        if not arm or arm.type != "ARMATURE" or not sobj or not anchor:
            return {"CANCELLED"}

        active = context.view_layer.objects.active
        mode = context.mode
        try:
            if mode != "OBJECT":
                bpy.ops.object.mode_set(mode="OBJECT")
            bpy.ops.object.select_all(action="DESELECT")
            arm.select_set(True)
            context.view_layer.objects.active = arm
            bpy.ops.object.mode_set(mode="EDIT")
            bn = f"siren{si.index}"
            eb = arm.data.edit_bones.get(bn) or arm.data.edit_bones.new(bn)
            head = arm.matrix_world.inverted() @ anchor.matrix_world.translation
            eb.head = head
            eb.tail = head + Vector((0.0, 0.05, 0.0))
            bpy.ops.object.mode_set(mode="OBJECT")
            wm = sobj.matrix_world.copy()
            sobj.parent = arm
            sobj.parent_type = "BONE"
            sobj.parent_bone = bn
            sobj.matrix_world = wm
            si.bone_name = bn
            si.anchor_name = anchor.name
            _store_rest_loc(sobj, force=True)
        finally:
            if active and active.name in bpy.data.objects:
                context.view_layer.objects.active = active
            if mode != "OBJECT" and context.mode == "OBJECT":
                try:
                    bpy.ops.object.mode_set(mode=mode)
                except Exception:
                    pass
        return {"FINISHED"}


class NELS_OT_origin_to_selection(Operator):
    bl_idname = "nels.origin_to_selection"
    bl_label = "Set Origin to Selection"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        scene = getattr(context, "scene", None)
        s = getattr(scene, "nels", None) if scene else None
        obj = getattr(context, "active_object", None)
        if not obj or getattr(obj, "type", "") != "MESH":
            msg = "Select a mesh in Edit Mode first"
            if s:
                s.status_message = msg
            self.report({"WARNING"}, msg)
            return {"CANCELLED"}
        if getattr(context, "mode", "") != "EDIT_MESH" or getattr(obj, "mode", "") != "EDIT":
            msg = "Switch the active mesh to Edit Mode first"
            if s:
                s.status_message = msg
            self.report({"WARNING"}, msg)
            return {"CANCELLED"}

        center, msg = edit_selection_local_center(obj, context)
        if center is None:
            if s:
                s.status_message = msg
            self.report({"WARNING"}, msg)
            return {"CANCELLED"}

        active = getattr(context.view_layer, "objects", None).active if getattr(context, "view_layer", None) else obj
        try:
            bpy.ops.object.mode_set(mode="OBJECT")
            ok, msg = set_object_origin_to_local_point(obj, center)
        finally:
            try:
                if active and active.name in bpy.data.objects:
                    context.view_layer.objects.active = active
            except Exception:
                pass
            if getattr(context, "mode", "") == "OBJECT":
                try:
                    bpy.ops.object.mode_set(mode="EDIT")
                except Exception:
                    pass

        if s:
            s.status_message = msg
        if ok:
            self.report({"INFO"}, msg)
            return {"FINISHED"}
        self.report({"ERROR"}, msg)
        return {"CANCELLED"}


class NELS_OT_origins_to_bones(Operator):
    bl_idname = "nels.origins_to_bones"
    bl_label = "Set Selected Origins to Bones"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        scene = getattr(context, "scene", None)
        s = getattr(scene, "nels", None) if scene else None
        if getattr(context, "mode", "") != "OBJECT":
            msg = "Switch to Object Mode before moving selected origins to bones"
            if s:
                s.status_message = msg
            self.report({"WARNING"}, msg)
            return {"CANCELLED"}

        selected = [obj for obj in getattr(context, "selected_objects", []) if obj and getattr(obj, "type", "") == "MESH"]
        if not selected:
            msg = "Select one or more mesh objects first"
            if s:
                s.status_message = msg
            self.report({"WARNING"}, msg)
            return {"CANCELLED"}

        moved = 0
        skipped = []
        for obj in selected:
            world_point, msg = linked_bone_world_location(scene, obj, s=s)
            if world_point is None:
                skipped.append(msg or f"No linked bone was found for {obj.name}")
                continue
            ok, result = set_object_origin_to_world_point(obj, world_point)
            if ok:
                moved += 1
            else:
                skipped.append(result)

        if moved:
            msg = f"Set {moved} selected object origin{'s' if moved != 1 else ''} to linked bone locations"
            if skipped:
                msg += f" ({len(skipped)} skipped)"
            if s:
                s.status_message = msg
            self.report({"INFO"}, msg)
            return {"FINISHED"}

        msg = skipped[0] if skipped else "No selected mesh objects could be matched to linked bones"
        if s:
            s.status_message = msg
        self.report({"WARNING"}, msg)
        return {"CANCELLED"}


class NELS_OT_match_origin_to_object(Operator):
    bl_idname = "nels.match_origin_to_object"
    bl_label = "Match Origin to Object"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        scene = getattr(context, "scene", None)
        s = getattr(scene, "nels", None) if scene else None
        if not s or not getattr(s, "sirens", None):
            self.report({"ERROR"}, "No sirens are available in the current configuration")
            return {"CANCELLED"}

        idx = max(0, min(int(getattr(s, "active_siren", 0) or 0), len(s.sirens) - 1))
        si = s.sirens[idx] if getattr(s, "sirens", None) else None
        if not si:
            self.report({"WARNING"}, "No siren could be resolved")
            return {"CANCELLED"}
            return {"CANCELLED"}

        sobj = siren_obj(si)
        if not sobj:
            msg = f"Warning: Assign a siren object to siren{si.index} before matching its origin"
            s.status_message = msg
            self.report({"WARNING"}, msg)
            return {"CANCELLED"}

        ref_name = str(getattr(s, "tool_origin_object", "") or "")
        reference = bpy.data.objects.get(ref_name) if ref_name else None
        if reference is None:
            reference = pick_reference_object(context, si)
        if reference is None:
            msg = "Select or pick an object to match the siren origin"
            s.status_message = msg
            self.report({"WARNING"}, msg)
            return {"CANCELLED"}
        if reference == sobj:
            msg = "Choose a separate helper object"
            s.status_message = msg
            self.report({"WARNING"}, msg)
            return {"CANCELLED"}

        ok, msg = set_object_origin_from_reference(sobj, reference)
        s.tool_origin_object = ""
        s.status_message = msg
        if ok:
            si.anchor_name = reference.name
            self.report({"INFO"}, msg)
            return {"FINISHED"}
        self.report({"ERROR"}, msg)
        return {"CANCELLED"}

class NELS_OT_move_bone_to_selected(Operator):
    bl_idname = "nels.move_bone_to_selected"
    bl_label = "Move Bone to Selected"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        scene = getattr(context, "scene", None)
        s = getattr(scene, "nels", None) if scene else None
        if not s or not getattr(s, "sirens", None):
            self.report({"ERROR"}, "No sirens are available in the current configuration")
            return {"CANCELLED"}

        si = resolve_context_siren(scene, s, require_linked=True)
        if not si:
            msg = "No linked siren could be resolved from the current selection"
            if s:
                s.status_message = msg
            self.report({"WARNING"}, msg)
            return {"CANCELLED"}

        reference = pick_any_reference_object(context)
        if not reference:
            msg = "Select a helper object first"
            if s:
                s.status_message = msg
            self.report({"WARNING"}, msg)
            return {"CANCELLED"}

        ok, msg = move_siren_bone_to_world_point(scene, si, reference.matrix_world.translation, preserve_direction=True)
        if s:
            s.status_message = msg
        if ok:
            si.anchor_name = reference.name
            self.report({"INFO"}, msg)
            return {"FINISHED"}
        self.report({"WARNING"}, msg)
        return {"CANCELLED"}


class NELS_OT_pick_selected_link_target(Operator):
    bl_idname = "nels.pick_selected_link_target"
    bl_label = "Use Selected Link Target"
    bl_options = {"REGISTER", "UNDO"}

    target: EnumProperty(items=[
        ("SIREN_MESH", "SIREN_MESH", ""),
        ("SIREN_BONE", "SIREN_BONE", ""),
        ("BODY_MESH", "BODY_MESH", ""),
        ("BODY_BONE", "BODY_BONE", ""),
        ("TOOL_ORIGIN_OBJECT", "TOOL_ORIGIN_OBJECT", ""),
    ])
    opening_key: StringProperty(default="")

    def execute(self, context):
        scene = getattr(context, "scene", None)
        s = getattr(scene, "nels", None) if scene else None
        if not s:
            self.report({"ERROR"}, "No scene settings available")
            return {"CANCELLED"}

        if self.target == "TOOL_ORIGIN_OBJECT":
            ref = pick_any_reference_object(context)
            if not ref:
                msg = "Select an object first"
                s.status_message = msg
                self.report({"WARNING"}, msg)
                return {"CANCELLED"}
            s.tool_origin_object = ref.name
            msg = f"Picked {ref.name} as the origin helper"
            s.status_message = msg
            self.report({"INFO"}, msg)
            return {"FINISHED"}

        is_siren = self.target.startswith("SIREN")
        wants_bone = self.target.endswith("BONE")

        if is_siren:
            if not getattr(s, "sirens", None):
                self.report({"ERROR"}, "No sirens are available in the current configuration")
                return {"CANCELLED"}
            target = resolve_context_siren(scene, s, require_linked=False)
            if not target:
                idx = max(0, min(int(getattr(s, "active_siren", 0) or 0), len(s.sirens) - 1))
                target = s.sirens[idx]
        else:
            target = body_opening_by_key(s, self.opening_key) if self.opening_key else active_body_opening(s)
            if not target:
                self.report({"ERROR"}, "No body opening is available")
                return {"CANCELLED"}

        if wants_bone:
            arm = selected_armature_from_context(context, scene=scene, s=s)
            bone_name = selected_bone_name_from_context(context, arm=arm)
            if not bone_name:
                msg = "Select a bone on the parent skeleton, or select a mesh already parented to the target bone"
                s.status_message = msg
                self.report({"WARNING"}, msg)
                return {"CANCELLED"}
            if arm:
                s.armature_name = arm.name
            target.bone_name = bone_name
            label = f"bone {bone_name}"
        else:
            mesh_name = selected_mesh_name_from_context(context)
            if not mesh_name:
                msg = "Select a mesh object first"
                s.status_message = msg
                self.report({"WARNING"}, msg)
                return {"CANCELLED"}
            target.object_name = mesh_name
            label = mesh_name

        owner = f"siren{target.index}" if is_siren else str(getattr(target, "name", "body opening") or "body opening")
        msg = f"Assigned {label} to {owner}"
        s.status_message = msg
        self.report({"INFO"}, msg)
        return {"FINISHED"}


class NELS_OT_body_opening_link(Operator):
    bl_idname = "nels.body_opening_link"
    bl_label = "Body Opening Link"
    bl_options = {"REGISTER", "UNDO"}

    action: EnumProperty(items=[("MARK", "MARK", ""), ("ORIGIN", "ORIGIN", ""), ("BONE", "BONE", "")])
    opening_key: StringProperty(default="")

    def execute(self, context):
        scene = context.scene
        s = getattr(scene, "nels", None)
        opening = body_opening_by_key(s, self.opening_key) if self.opening_key else active_body_opening(s)
        if not s or not opening:
            self.report({"ERROR"}, "No body opening is available")
            return {"CANCELLED"}

        if self.action == "MARK":
            obj = getattr(context, "active_object", None)
            if not obj or getattr(obj, "type", "") != "MESH":
                msg = "Select a mesh object first"
                s.status_message = msg
                self.report({"WARNING"}, msg)
                return {"CANCELLED"}
            opening.object_name = obj.name
            s.status_message = f"Assigned {obj.name} to {opening.name}"
            self.report({"INFO"}, s.status_message)
            return {"FINISHED"}

        if self.action == "ORIGIN":
            obj = body_opening_obj(opening)
            if not obj:
                msg = f"Assign a mesh to {opening.name} before moving its origin"
                s.status_message = msg
                self.report({"WARNING"}, msg)
                return {"CANCELLED"}
            reference = pick_body_opening_reference(context, opening)
            if not reference:
                msg = "Select a helper object to copy its origin"
                s.status_message = msg
                self.report({"WARNING"}, msg)
                return {"CANCELLED"}
            ok, msg = set_object_origin_from_reference(obj, reference)
            s.status_message = msg
            if ok:
                opening.anchor_name = reference.name
                self.report({"INFO"}, msg)
                return {"FINISHED"}
            self.report({"ERROR"}, msg)
            return {"CANCELLED"}

        arm = bpy.data.objects.get(s.armature_name) if getattr(s, "armature_name", "") else None
        if not arm or getattr(arm, "type", "") != "ARMATURE":
            scene_arms = sorted({obj.name for obj in scene.objects if getattr(obj, "type", "") == "ARMATURE"}, key=str.lower)
            if len(scene_arms) == 1:
                s.armature_name = scene_arms[0]
                arm = bpy.data.objects.get(s.armature_name)
            else:
                msg = "Select a Parent Skeleton before placing a body opening bone"
                s.status_message = msg
                self.report({"WARNING"}, msg)
                return {"CANCELLED"}

        obj = body_opening_obj(opening)
        if not obj:
            msg = f"Assign a mesh to {opening.name} before placing its bone"
            s.status_message = msg
            self.report({"WARNING"}, msg)
            return {"CANCELLED"}

        anchor = pick_body_opening_reference(context, opening) or obj
        active = context.view_layer.objects.active
        mode = context.mode
        bone_name = str(getattr(opening, "key", "") or getattr(opening, "bone_name", "") or "body_opening")
        try:
            if mode != "OBJECT":
                bpy.ops.object.mode_set(mode="OBJECT")
            bpy.ops.object.select_all(action="DESELECT")
            arm.select_set(True)
            context.view_layer.objects.active = arm
            bpy.ops.object.mode_set(mode="EDIT")
            eb = arm.data.edit_bones.get(bone_name) or arm.data.edit_bones.new(bone_name)
            head = arm.matrix_world.inverted() @ anchor.matrix_world.translation
            eb.head = head
            eb.tail = head + Vector((0.0, 0.05, 0.0))
            bpy.ops.object.mode_set(mode="OBJECT")
            world_matrix = obj.matrix_world.copy()
            obj.parent = arm
            obj.parent_type = "BONE"
            obj.parent_bone = bone_name
            obj.matrix_world = world_matrix
            opening.bone_name = bone_name
            opening.anchor_name = anchor.name
            _store_rest_loc(obj, force=True)
            s.status_message = f"Placed bone {bone_name} on {arm.name}"
            self.report({"INFO"}, s.status_message)
            return {"FINISHED"}
        finally:
            try:
                if active and active.name in bpy.data.objects:
                    context.view_layer.objects.active = active
            except Exception:
                pass
            if mode != "OBJECT" and context.mode == "OBJECT":
                try:
                    bpy.ops.object.mode_set(mode=mode)
                except Exception:
                    pass


class NELS_OT_body_opening_state(Operator):
    bl_idname = "nels.body_opening_state"
    bl_label = "Body Opening State"
    bl_options = {"REGISTER", "UNDO"}

    action: EnumProperty(items=[("CAPTURE_CLOSED", "CAPTURE_CLOSED", ""), ("CAPTURE_OPEN", "CAPTURE_OPEN", ""), ("APPLY_CLOSED", "APPLY_CLOSED", ""), ("APPLY_OPEN", "APPLY_OPEN", "")])
    opening_key: StringProperty(default="")

    def execute(self, context):
        scene = context.scene
        s = getattr(scene, "nels", None)
        opening = body_opening_by_key(s, self.opening_key) if self.opening_key else active_body_opening(s)
        if not s or not opening:
            self.report({"ERROR"}, "No body opening is available")
            return {"CANCELLED"}

        if self.action.startswith("CAPTURE_"):
            state = self.action.split("_", 1)[1]
            ok, msg = capture_body_opening_state(scene, opening, state)
        else:
            stop_timeline_playback()
            state = self.action.split("_", 1)[1]
            ok, msg = apply_body_opening_state(scene, opening, state)

        s.status_message = msg
        if ok:
            self.report({"INFO"}, msg)
            return {"FINISHED"}
        self.report({"WARNING"}, msg)
        return {"CANCELLED"}


class NELS_OT_sim(Operator):
    bl_idname = "nels.sim"
    bl_label = "Simulate"
    bl_options = {"REGISTER", "UNDO"}
    mode: EnumProperty(items=[("ON", "ON", ""), ("OFF", "OFF", "")])
    all: BoolProperty(default=False)

    def execute(self, context):
        scene = context.scene
        s = scene.nels
        sirens = list(s.sirens) if self.all else ([s.sirens[s.active_siren]] if s.sirens else [])
        if not sirens:
            return {"CANCELLED"}
        clear_preview_keyframes(scene, sirens)
        s.preview_generated = False
        s.preview_dirty = False
        s.auto_timeline_pending = False
        if self.mode == "OFF":
            stop_timeline_playback()
        for si in sirens:
            apply_sim_state(scene, s, si, self.mode)
        try:
            bpy.context.view_layer.update()
        except Exception:
            pass
        return {"FINISHED"}


class NELS_OT_set_siren_scale_state(Operator):
    bl_idname = "nels.set_siren_scale_state"
    bl_label = "Set Siren Scale"
    bl_options = {"REGISTER", "UNDO"}

    mode: EnumProperty(items=[("ON", "On", ""), ("OFF", "Off", "")], default="ON")

    def execute(self, context):
        scene = context.scene
        s = getattr(scene, "nels", None)
        if not s or not s.sirens:
            self.report({"ERROR"}, "No sirens are available in the current configuration")
            return {"CANCELLED"}

        si = resolve_context_siren(scene, s, require_linked=True)
        if not si:
            self.report({"ERROR"}, "No linked siren could be resolved from the current selection")
            return {"CANCELLED"}

        ok, msg = bake_siren_scale_state(scene, s, si, self.mode)
        if not ok:
            self.report({"ERROR"}, msg)
            return {"CANCELLED"}
        self.report({"INFO"}, msg)
        return {"FINISHED"}


class NELS_OT_reset_siren_default_state(Operator):
    bl_idname = "nels.reset_siren_default_state"
    bl_label = "Reset Siren to Default"
    bl_options = {"REGISTER", "UNDO"}

    all: BoolProperty(default=False)

    def execute(self, context):
        scene = context.scene
        s = getattr(scene, "nels", None)
        if not s or not s.sirens:
            self.report({"ERROR"}, "No sirens are available in the current configuration")
            return {"CANCELLED"}

        sirens = list(s.sirens) if self.all else []
        if not self.all:
            si = resolve_context_siren(scene, s, require_linked=False)
            if not si:
                self.report({"ERROR"}, "No siren could be resolved from the current selection")
                return {"CANCELLED"}
            sirens = [si]

        clear_preview_keyframes(scene, sirens)
        restored = 0
        for si in sirens:
            restored += restore_siren_default_state(scene, si)
        s.preview_generated = False
        s.preview_dirty = False
        if hasattr(scene, "view_layers"):
            try:
                bpy.context.view_layer.update()
            except Exception:
                pass
        self.report({"INFO"}, f"Reset {len(sirens)} siren(s) to default state")
        return {"FINISHED"}


def _clear_action_animation(action, path_predicate):
    if not action:
        return 0

    removed = 0
    for fc in _iter_action_fcurves(action):
        data_path = str(getattr(fc, "data_path", ""))
        if not path_predicate(data_path):
            continue

        try:
            points = getattr(fc, "keyframe_points", None)
            if points is not None:
                removed += len(points)
                points.clear()
        except Exception:
            try:
                points = getattr(fc, "keyframe_points", None)
                if points is not None:
                    for kp in list(points):
                        points.remove(kp)
                        removed += 1
            except Exception:
                pass

        try:
            for m in list(fc.modifiers):
                if m.type == "CYCLES":
                    fc.modifiers.remove(m)
        except Exception:
            pass

        try:
            fc.update()
        except Exception:
            pass

    return removed
def clear_preview_keyframes(scene, sirens, frame_start=None, frame_end=None):
    cleared = 0

    for si in sirens:
        o = siren_obj(si)
        if o:
            cleared += _clear_action_animation(
                getattr(getattr(o, "animation_data", None), "action", None),
                lambda p: p in {"location", "rotation_euler", "scale"},
            )

        if getattr(si, "siren_type", "FLASHER") == "ROTATOR":
            for target in rotator_preview_targets(si):
                if not target or target == o:
                    continue
                cleared += _clear_action_animation(
                    getattr(getattr(target, "animation_data", None), "action", None),
                    lambda p: p == "rotation_euler",
                )

        arm, pb = siren_pose_bone(scene, si)
        if arm and pb:
            target_bones = {pb.name}
            if getattr(si, "siren_type", "FLASHER") == "ROTATOR":
                target_bones.update(child.name for child in rotator_preview_pose_bones(scene, si))
            cleared += _clear_action_animation(
                getattr(getattr(arm, "animation_data", None), "action", None),
                lambda p, target_bones=target_bones: any(
                    p.startswith(f'pose.bones["{bone}"].') and (p.endswith(".location") or p.endswith(".rotation_euler") or p.endswith(".scale"))
                    for bone in target_bones
                ),
            )

    return cleared


def generate_timeline_preview(scene, s, sirens):
    st = int(scene.frame_start)
    fps = max(1.0, scene.render.fps / max(scene.render.fps_base, 0.0001))
    step = preview_step_frames(s.bpm, fps)
    used = 0
    cycle_end = float(st)

    for si in sirens:
        if not siren_is_active(si):
            continue

        delay_frames = start_delay_frames(s.bpm, fps, si)

        if getattr(si, "siren_type", "FLASHER") == "ROTATOR":
            cycle_frames = rotator_cycle_frames(s.bpm, fps, si)
            cycle_end = max(cycle_end, st + delay_frames + cycle_frames)

            # Keep rotators statically shown and animate only their rotation channels.
            # This avoids scale/location keyframe churn on the full siren hierarchy.
            apply_sim_state(scene, s, si, "ON", turns=0.0, keyframe_frame=None)
            apply_rotator_preview_targets(si, turns=0.0, keyframe_frame=st)
            apply_rotator_preview_pose_targets(scene, si, turns=0.0, keyframe_frame=st)
            if delay_frames > 0.0:
                apply_rotator_preview_targets(si, turns=0.0, keyframe_frame=st + delay_frames)
                apply_rotator_preview_pose_targets(scene, si, turns=0.0, keyframe_frame=st + delay_frames)
            apply_rotator_preview_targets(si, turns=1.0, keyframe_frame=st + delay_frames + cycle_frames)
            apply_rotator_preview_pose_targets(scene, si, turns=1.0, keyframe_frame=st + delay_frames + cycle_frames)
        else:
            bits, _, _ = pattern_triplet(s, si)
            bit_count = max(1, len(bits))
            cycle_end = max(cycle_end, st + delay_frames + (bit_count * step))
            if delay_frames > 0.0:
                apply_sim_state(scene, s, si, "OFF", turns=0.0, keyframe_frame=st)
            first_mode = "ON" if bits[0] == "1" else "OFF"
            apply_sim_state(scene, s, si, first_mode, turns=0.0, keyframe_frame=st + delay_frames)
            for i in range(1, bit_count):
                if bits[i] == bits[i - 1]:
                    continue
                fr = st + delay_frames + (i * step)
                mode = "ON" if bits[i] == "1" else "OFF"
                apply_sim_state(scene, s, si, mode, turns=0.0, keyframe_frame=fr)
            apply_sim_state(scene, s, si, first_mode, turns=0.0, keyframe_frame=st + delay_frames + (bit_count * step))

        _set_preview_key_interpolation(scene, si)
        used += 1

    if used:
        scene.frame_end = max(int(scene.frame_start), int(math.ceil(cycle_end)))
    return used, cycle_end


class NELS_OT_preview_clear(Operator):
    bl_idname = "nels.preview_clear"
    bl_label = "Clear Timeline"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        s = context.scene.nels
        scene = context.scene
        cleared = clear_preview_keyframes(scene, list(s.sirens))
        s.preview_generated = False
        s.preview_dirty = False
        self.report({"INFO"}, f"Cleared {cleared} keyframes")
        return {"FINISHED"}


class NELS_OT_sollumz_enable(Operator):
    bl_idname = "nels.sollumz_enable"
    bl_label = "Enable Sollumz"
    bl_options = {"REGISTER"}

    def execute(self, context):
        module_name = find_sollumz_module_name()
        if not module_name:
            self.report({"ERROR"}, "Sollumz is not installed")
            return {"CANCELLED"}
        try:
            bpy.ops.preferences.addon_enable(module=module_name)
            scene = getattr(context, "scene", None)
            s = getattr(scene, "nels", None) if scene else None
            if s:
                s.status_message = f"Enabled Sollumz ({module_name})"
            self.report({"INFO"}, f"Enabled Sollumz ({module_name})")
            return {"FINISHED"}
        except Exception as ex:
            self.report({"ERROR"}, f"Could not enable Sollumz: {ex}")
            return {"CANCELLED"}


class NELS_OT_sollumz_install(Operator):
    bl_idname = "nels.sollumz_install"
    bl_label = "Install Sollumz"
    bl_options = {"REGISTER"}

    def execute(self, context):
        scene = getattr(context, "scene", None)
        s = getattr(scene, "nels", None) if scene else None
        try:
            asset = fetch_sollumz_release_asset_info()
            data = download_url_bytes(asset["url"])
            enabled_module = install_addon_from_zip_bytes(data, name_hint="sollumz")
            status = sollumz_status()
            if s:
                version = str(asset.get("tag", "") or asset.get("name", "") or "latest release")
                if status["enabled"]:
                    s.status_message = f"Installed Sollumz {version}"
                else:
                    s.status_message = f"Installed Sollumz {version}. Enable it in Blender Preferences if needed."
            if status["enabled"]:
                self.report({"INFO"}, f"Installed Sollumz {asset.get('tag', '') or enabled_module or ''}".strip())
                return {"FINISHED"}
            self.report({"WARNING"}, "Sollumz downloaded and installed, but Blender did not auto-enable it")
            return {"FINISHED"}
        except Exception as ex:
            if s:
                s.status_message = f"Sollumz install failed: {ex}"
            self.report({"ERROR"}, f"Sollumz install failed: {ex}")
            return {"CANCELLED"}


class NELS_OT_update_check(Operator):
    bl_idname = "nels.update_check"
    bl_label = "Check for Updates"
    bl_options = {"REGISTER"}

    def execute(self, context):
        if begin_update_operation("CHECK", automatic=False):
            self.report({"INFO"}, "Checking GitHub for updates")
            return {"FINISHED"}
        self.report({"WARNING"}, "An update task is already running")
        return {"CANCELLED"}


class NELS_OT_update_install(Operator):
    bl_idname = "nels.update_install"
    bl_label = "Install Update"
    bl_options = {"REGISTER"}

    def execute(self, context):
        s = getattr(context.scene, "nels", None)
        if not s:
            self.report({"ERROR"}, "No scene settings available")
            return {"CANCELLED"}
        if getattr(s, "update_install_in_progress", False) or getattr(s, "update_check_in_progress", False):
            self.report({"WARNING"}, "An update task is already running")
            return {"CANCELLED"}
        if not getattr(s, "update_available", False):
            self.report({"WARNING"}, "No newer update is currently available")
            return {"CANCELLED"}
        if begin_update_operation("INSTALL", automatic=False):
            self.report({"INFO"}, "Installing update from GitHub")
            return {"FINISHED"}
        self.report({"WARNING"}, "An update task is already running")
        return {"CANCELLED"}


class NELS_OT_refresh_pattern_previews(Operator):
    bl_idname = "nels.refresh_pattern_previews"
    bl_label = "Refresh Pattern Previews"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        scene = getattr(context, "scene", None)
        s = getattr(scene, "nels", None) if scene else None
        if not s:
            self.report({"ERROR"}, "No scene settings available")
            return {"CANCELLED"}

        queue_preview_refresh_feedback(scene)
        mark_preview_dirty(context, scene=scene, immediate=False)
        self.report({"INFO"}, "Preview refresh started")
        return {"FINISHED"}


class NELS_OT_preview(Operator):
    bl_idname = "nels.preview"
    bl_label = "Generate Siren Preview"
    bl_options = {"REGISTER", "UNDO"}

    scope: EnumProperty(items=[("ACTIVE", "ACTIVE", ""), ("ALL", "ALL", "")], default="ALL")

    def execute(self, context):
        s = context.scene.nels
        scene = context.scene

        if self.scope == "ACTIVE":
            if not s.sirens:
                return {"CANCELLED"}
            idx = max(0, min(s.active_siren, len(s.sirens) - 1))
            siren_list = [s.sirens[idx]]
        else:
            siren_list = list(s.sirens)

        clear_preview_keyframes(scene, siren_list)

        used, _cycle_end = generate_timeline_preview(scene, s, siren_list)
        if used:
            s.preview_generated = True
            s.preview_dirty = False
            return {"FINISHED"}
        return {"CANCELLED"}

def e(parent, tag, value=None):
    n = ET.SubElement(parent, tag)
    if value is not None:
        n.set("value", str(value))
    return n


def build_xml(s):
    root = ET.Element("CVehicleModelInfoVarGlobal")
    ss = ET.SubElement(root, "Sirens")
    top = ET.SubElement(ss, "Item")
    e(top, "id", s.vehicle_id)
    ET.SubElement(top, "name").text = s.vehicle_name
    e(top, "timeMultiplier", f8(s.time_multiplier))
    e(top, "lightFalloffMax", f8(s.light_falloff_max))
    e(top, "lightFalloffExponent", f8(s.light_falloff_exp))
    e(top, "lightInnerConeAngle", f8(s.light_inner_angle))
    e(top, "lightOuterConeAngle", f8(s.light_outer_angle))
    e(top, "lightOffset", f8(s.light_offset))
    ET.SubElement(top, "textureName").text = s.texture_name
    e(top, "sequencerBpm", int(s.bpm))

    for tn, key in [("leftHeadLight", s.left_head), ("rightHeadLight", s.right_head), ("leftTailLight", s.left_tail), ("rightTailLight", s.right_tail)]:
        x = ET.SubElement(top, tn)
        p = get_pattern(s, key)
        e(x, "sequencer", bits_to_int(p.bits) if p else 0)

    e(top, "leftHeadLightMultiples", s.left_head_mult)
    e(top, "rightHeadLightMultiples", s.right_head_mult)
    e(top, "leftTailLightMultiples", s.left_tail_mult)
    e(top, "rightTailLightMultiples", s.right_tail_mult)
    e(top, "useRealLights", b(s.use_real_lights))

    sir = ET.SubElement(top, "sirens")
    slots = s.siren_count if s.siren_count > 0 else 20
    for i in range(1, slots + 1):
        si = s.sirens[i - 1] if i - 1 < len(s.sirens) else None
        active = siren_has_output(s, si)
        sir.append(ET.Comment(f"siren{i}" if active else f"inactive siren{i}"))
        it = ET.SubElement(sir, "Item")
        if not active:
            for tag in ["rotation", "flashiness"]:
                sec = ET.SubElement(it, tag)
                e(sec, "delta", f8(0))
                e(sec, "start", f8(0))
                e(sec, "speed", f8(0))
                e(sec, "sequencer", 0)
                e(sec, "multiples", 0)
                e(sec, "direction", b(True))
                e(sec, "syncToBpm", b(True))
            c = ET.SubElement(it, "corona")
            e(c, "intensity", f8(0)); e(c, "size", f8(0)); e(c, "pull", f8(0.00000001)); e(c, "faceCamera", b(False))
            e(it, "color", "0xFFFF0000")
            e(it, "intensity", f8(0))
            e(it, "lightGroup", 0)
            e(it, "rotate", b(False)); e(it, "scale", b(True)); e(it, "scaleFactor", 0)
            e(it, "flash", b(True)); e(it, "light", b(True)); e(it, "spotLight", b(True)); e(it, "castShadows", b(False))
            continue

        _, seq, vis = pattern_triplet(s, si)
        d = dir_val(si)
        is_rot = si.siren_type == "ROTATOR"
        rot_speed_val = rot_speed(s.bpm, si) if is_rot else 0.0
        rot_seq = seq if is_rot and vis in {"BOTH", "ROTATOR"} else 0
        rot_mult = si.light_multiples if is_rot else 0
        rot_dir = bool(getattr(si, "rotator_clockwise", True)) if is_rot else True
        rot_delta = d if is_rot else 0.0

        rot = ET.SubElement(it, "rotation")
        e(rot, "delta", f8(rot_delta))
        e(rot, "start", f8(si.start_delay))
        e(rot, "speed", f8(rot_speed_val))
        e(rot, "sequencer", rot_seq)
        e(rot, "multiples", rot_mult)
        e(rot, "direction", b(rot_dir)); e(rot, "syncToBpm", b(si.sync_to_bpm))

        fl = ET.SubElement(it, "flashiness")
        if is_rot:
            e(fl, "delta", f8(rot_delta)); e(fl, "start", f8(si.start_delay)); e(fl, "speed", f8(rot_speed_val))
            e(fl, "sequencer", rot_seq)
            e(fl, "multiples", rot_mult); e(fl, "direction", b(rot_dir)); e(fl, "syncToBpm", b(si.sync_to_bpm))
        else:
            e(fl, "delta", f8(d)); e(fl, "start", f8(si.start_delay)); e(fl, "speed", f8(si.light_speed))
            e(fl, "sequencer", seq if vis in {"BOTH", "FLASHER"} else 0)
            e(fl, "multiples", si.light_multiples); e(fl, "direction", b(True)); e(fl, "syncToBpm", b(si.sync_to_bpm))

        c = ET.SubElement(it, "corona")
        e(c, "intensity", f8(si.corona_intensity)); e(c, "size", f8(si.corona_size)); e(c, "pull", f8(si.corona_pull)); e(c, "faceCamera", b(si.corona_face_camera))
        e(it, "color", color_hex(s, si)); e(it, "intensity", f8(si.light_intensity)); e(it, "lightGroup", si.light_group)
        e(it, "rotate", b(is_rot)); e(it, "scale", b(True)); e(it, "scaleFactor", f8(scale_val(si)))
        e(it, "flash", b(si.flash)); e(it, "light", b(si.light)); e(it, "spotLight", b(si.spot_light)); e(it, "castShadows", b(si.cast_shadows))
    return xml.dom.minidom.parseString(ET.tostring(root, encoding="utf-8")).toprettyxml(indent="\t")


class NELS_OT_export(Operator):
    bl_idname = "nels.export"
    bl_label = "Export carcols.meta"

    def execute(self, context):
        s = context.scene.nels
        fp = bpy.path.abspath(s.export_path)
        if not fp.lower().endswith(".meta"):
            fp += ".meta"
        out_dir = os.path.dirname(fp)
        if out_dir:
            os.makedirs(out_dir, exist_ok=True)
        with open(fp, "w", encoding="utf-8") as h:
            h.write(build_xml(s))
        s.status_message = f"Export complete: {fp}"
        self.report({"INFO"}, s.status_message)
        return {"FINISHED"}

class VIEW3D_MT_nels(Menu):
    bl_label = "GTA 000 Tools"
    bl_idname = "VIEW3D_MT_nels"

    def draw(self, context):
        l = self.layout
        l.menu("NELS_MT_siren_actions", icon="DOWNARROW_HLT")
        l.separator()
        o = l.operator("nels.sim", text="Simulate All Off"); o.all = True; o.mode = "OFF"
        o = l.operator("nels.sim", text="Simulate All On"); o.all = True; o.mode = "ON"
        l.operator("nels.export")


class VIEW3D_MT_nels_context_object(Menu):
    bl_label = "GTA 000 Tools"
    bl_idname = "VIEW3D_MT_nels_context_object"

    def draw(self, context):
        l = self.layout
        o = l.operator("nels.link_bone", text="Assign Selected Mesh", icon="OUTLINER_OB_MESH"); o.action = "MARK"
        o = l.operator("nels.link_bone", text="Match Origin to Selected", icon="OBJECT_ORIGIN"); o.action = "ORIGIN"
        l.operator("nels.move_bone_to_selected", text="Move Bone to Selected", icon="BONE_DATA")
        o = l.operator("nels.link_bone", text="Place Bone at Selected Origin", icon="BONE_DATA"); o.action = "BONE"
        l.separator()
        l.operator("nels.origins_to_bones", text="Set Selected Origins to Bones", icon="CON_TRACKTO")
        l.operator("nels.auto_detect", text="Auto-Detect Sirens/Bones", icon="VIEWZOOM")


class VIEW3D_MT_nels_context_edit(Menu):
    bl_label = "GTA 000 Tools"
    bl_idname = "VIEW3D_MT_nels_context_edit"

    def draw(self, context):
        l = self.layout
        l.operator("nels.origin_to_selection", text="Set Origin to Selection", icon="PIVOT_CURSOR")


def draw_obj_menu(self, context):
    self.layout.separator()
    self.layout.menu(VIEW3D_MT_nels.bl_idname, icon="LIGHT")


def draw_object_context_menu(self, context):
    layout = self.layout
    layout.menu(VIEW3D_MT_nels_context_object.bl_idname, icon="LIGHT")
    layout.separator()


def draw_edit_mesh_context_menu(self, context):
    layout = self.layout
    layout.menu(VIEW3D_MT_nels_context_edit.bl_idname, icon="LIGHT")
    layout.separator()


def register_panel_icons():
    unregister_panel_icons()
    icons_dir = os.path.join(os.path.dirname(__file__), "icons")
    if not os.path.isdir(icons_dir):
        return

    pcoll = bpy.utils.previews.new()
    loaded_any = False
    for key, stem in PANEL_ICON_FILES.items():
        for ext in PANEL_ICON_EXTENSIONS:
            fp = os.path.join(icons_dir, stem + ext)
            if not os.path.isfile(fp):
                continue
            try:
                pcoll.load(key, fp, "IMAGE")
                loaded_any = True
                break
            except Exception:
                continue

    if not loaded_any:
        bpy.utils.previews.remove(pcoll)
        return

    _PREVIEW_COLLECTIONS["panel_icons"] = pcoll


def unregister_panel_icons():
    pcoll = _PREVIEW_COLLECTIONS.pop("panel_icons", None)
    if not pcoll:
        return
    try:
        bpy.utils.previews.remove(pcoll)
    except Exception:
        pass


def get_panel_icon_value(key):
    pcoll = _PREVIEW_COLLECTIONS.get("panel_icons")
    if not pcoll:
        return 0
    try:
        if key in pcoll:
            return pcoll[key].icon_id
    except Exception:
        pass
    return 0


def draw_panel_header_icon(layout, key):
    icon_value = get_panel_icon_value(key)
    if icon_value:
        layout.label(text="", icon_value=icon_value)
    else:
        layout.label(text="", icon=PANEL_FALLBACK_ICONS.get(key, "NONE"))


def siren_row_shows_status_icon(scene, si):
    s = getattr(scene, "nels", None) if scene else None
    if not s or not si:
        return True
    if getattr(si, "siren_type", "FLASHER") == "ROTATOR":
        return True
    bits, seq, vis = pattern_triplet(s, si)
    return bool(seq and vis in {"BOTH", "FLASHER"})


def siren_status_details(scene, si):
    if not si:
        return "ERROR", "Missing siren data"

    issues = []
    expected_name = f"siren{getattr(si, 'index', 0)}"
    scene_objects = list(getattr(scene, "objects", [])) if scene else []
    scene_object_names = {obj.name for obj in scene_objects}
    settings = getattr(scene, "nels", None) if scene else None

    mesh_name = str(getattr(si, "object_name", "") or "").strip()
    if mesh_name:
        mesh_obj = bpy.data.objects.get(mesh_name)
        if mesh_obj is None:
            issues.append(f"Missing mesh: linked object '{mesh_name}' was not found")
        elif mesh_obj.type != "MESH":
            issues.append(f"Invalid mesh link: '{mesh_name}' is not a mesh")
        elif scene and mesh_obj.name not in scene_object_names:
            issues.append(f"Missing mesh: linked object '{mesh_name}' is not in the current scene")
    else:
        fallback = bpy.data.objects.get(expected_name)
        if fallback is None or fallback.type != "MESH" or (scene and fallback.name not in scene_object_names):
            issues.append(f"Missing mesh: assign a mesh or rename it to '{expected_name}'")

    armature_name = str(getattr(settings, "armature_name", "") or "").strip() if settings else ""
    bone_name = str(getattr(si, "bone_name", "") or "").strip()
    armatures = [obj for obj in scene_objects if obj.type == "ARMATURE"]

    def bone_exists(name):
        if not name:
            return False
        for arm in armatures:
            if name in arm.data.bones:
                return True
        return False

    if armature_name:
        arm_obj = bpy.data.objects.get(armature_name)
        if arm_obj is None:
            issues.append(f"Missing parent skeleton: '{armature_name}' was not found")
        elif arm_obj.type != "ARMATURE":
            issues.append(f"Invalid parent skeleton: '{armature_name}' is not an armature")
        elif scene and arm_obj.name not in scene_object_names:
            issues.append(f"Missing parent skeleton: '{armature_name}' is not in the current scene")

    if bone_name:
        if not bone_exists(bone_name):
            issues.append(f"Missing bone: linked bone '{bone_name}' was not found")
    else:
        if not bone_exists(expected_name):
            issues.append(f"Missing bone: place or link bone '{expected_name}'")

    if issues:
        return "ERROR", "; ".join(dict.fromkeys(issues))
    return "LIGHT", "Configured: mesh and bone are linked"


class NELS_OT_siren_status_info(Operator):
    bl_idname = "nels.siren_status_info"
    bl_label = "Siren Status"
    bl_options = {"INTERNAL"}

    message: StringProperty(default="")

    @classmethod
    def description(cls, _context, properties):
        return str(getattr(properties, "message", "") or "Siren status")

    def execute(self, context):
        msg = str(getattr(self, "message", "") or "Siren status")
        self.report({"INFO"}, msg)
        return {"FINISHED"}


class NELS_UL_sirens(UIList):
    def draw_item(self, context, layout, data, item, icon, active_data, active_propname, index=0, flt_flag=0):
        if self.layout_type in {"DEFAULT", "COMPACT"}:
            row = layout.row(align=True)
            split = row.split(factor=0.85, align=True)
            left = split.row(align=True)
            scene = getattr(context, "scene", None)
            if siren_row_shows_status_icon(scene, item):
                icon_name, tooltip = siren_status_details(scene, item)
                op = left.operator("nels.siren_status_info", text="", icon=icon_name, emboss=False)
                op.message = tooltip
            else:
                left.label(text="", icon="BLANK1")
            left.label(text=f"siren{item.index}")
            right = split.row(align=True)
            if getattr(data, "all_flash_previews", True) and getattr(data, "list_flash_preview", True):
                right.prop(item, "preview_color_cache", text="")
            else:
                right.label(text="")
        else:
            layout.alignment = "CENTER"
            layout.label(text=str(item.index))


class NELS_UL_patterns(UIList):
    def draw_item(self, context, layout, data, item, icon, active_data, active_propname, index=0, flt_flag=0):
        if self.layout_type in {"DEFAULT", "COMPACT"}:
            row = layout.row(align=True)
            split = row.split(factor=0.82, align=True)
            left = split.row(align=True)
            if pattern_duplicate_indices(data, index):
                icon_name = "INFO" if pattern_duplicate_is_allowed(data, index) else "ERROR"
            else:
                icon_name = "FILE_TEXT"
            left.label(text=pattern_display_name(data, index), icon=icon_name)
        else:
            layout.alignment = "CENTER"
            layout.label(text=str(index + 1))


class NELS_UL_body_openings(UIList):
    def draw_item(self, context, layout, data, item, icon, active_data, active_propname, index=0, flt_flag=0):
        if self.layout_type in {"DEFAULT", "COMPACT"}:
            row = layout.row(align=True)
            icon_name = "CON_ROTLIKE" if getattr(item, "opening_type", "HINGED") == "HINGED" else "EMPTY_ARROWS"
            row.label(text=str(getattr(item, "name", body_opening_display_name(getattr(item, "key", ""))) or "Body Opening"), icon=icon_name)
        else:
            layout.alignment = "CENTER"
            layout.label(text=str(index + 1))


class VIEW3D_PT_nels_body_openings(Panel):
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "Tool"
    bl_label = "Body Openings"
    bl_options = {"DEFAULT_CLOSED"}

    def draw_header(self, context):
        draw_panel_header_icon(self.layout, "body_openings")

    def draw(self, context):
        l = self.layout
        try:
            s = getattr(context.scene, "nels", None)
            if not s:
                l.label(text="No scene settings available")
                return

            ensure_body_opening_defaults(s)
            row = l.row()
            row.template_list("NELS_UL_body_openings", "nels_body_openings", s, "body_openings", s, "active_body_opening", rows=6)
            opening = active_body_opening(s)
            if not opening:
                l.label(text="No body openings available")
                return

            box = l.box()
            box.label(text=str(getattr(opening, "name", "Body Opening") or "Body Opening"))
            box.prop(opening, "opening_type", text="Type")

            motion = box.box()
            if body_opening_supports_rotation(opening):
                rot_box = motion.box() if body_opening_supports_translation(opening) else motion
                rot_box.label(text="Rotation Axes")
                rr = rot_box.row(align=True)
                rr.prop(opening, "rot_x", text="X", toggle=True)
                rr.prop(opening, "rot_y", text="Y", toggle=True)
                rr.prop(opening, "rot_z", text="Z", toggle=True)
                rot_box.prop(opening, "limit_rotation")
            if body_opening_supports_translation(opening):
                slide_box = motion.box() if body_opening_supports_rotation(opening) else motion
                slide_box.label(text="Movement Axes")
                sr = slide_box.row(align=True)
                sr.prop(opening, "slide_x", text="X", toggle=True)
                sr.prop(opening, "slide_y", text="Y", toggle=True)
                sr.prop(opening, "slide_z", text="Z", toggle=True)
                slide_box.prop(opening, "limit_translation")

            link_box = box.box()
            link_box.label(text="Object/Bone Linking")
            link_box.prop_search(s, "armature_name", bpy.data, "objects", text="Parent Skeleton")
            op = link_box.operator("nels.body_opening_link", text="Assign Selected Mesh", icon="OUTLINER_OB_MESH")
            op.action = "MARK"
            op = link_box.operator("nels.body_opening_link", text="Match Origin to Selected", icon="OBJECT_ORIGIN")
            op.action = "ORIGIN"
            op = link_box.operator("nels.body_opening_link", text="Place Bone at Selected Origin", icon="BONE_DATA")
            op.action = "BONE"
            link_box.prop(opening, "object_name", text="Mesh")
            link_box.prop(opening, "bone_name", text="Bone")
            link_box.label(text="Placed bones always point to vehicle front (Y+)", icon="INFO")

            state_box = box.box()
            state_box.label(text="Capture and Preview")
            state_box.label(text="Move the linked mesh or pose bone manually, then set Closed and Open positions.", icon="INFO")
            capture_row = state_box.row(align=True)
            op = capture_row.operator("nels.body_opening_state", text="Set Closed Position", icon="IMPORT")
            op.action = "CAPTURE_CLOSED"
            op = capture_row.operator("nels.body_opening_state", text="Set Open Position", icon="EXPORT")
            op.action = "CAPTURE_OPEN"
            apply_row = state_box.row(align=True)
            op = apply_row.operator("nels.body_opening_state", text="Preview Closed", icon="LOOP_BACK")
            op.action = "APPLY_CLOSED"
            op = apply_row.operator("nels.body_opening_state", text="Preview Open", icon="PLAY")
            op.action = "APPLY_OPEN"

            closed_loc = Vector(getattr(opening, "closed_location", (0.0, 0.0, 0.0)))
            open_loc = Vector(getattr(opening, "open_location", (0.0, 0.0, 0.0)))
            closed_rot = Vector(getattr(opening, "closed_rotation", (0.0, 0.0, 0.0)))
            open_rot = Vector(getattr(opening, "open_rotation", (0.0, 0.0, 0.0)))
            slide_delta = open_loc - closed_loc
            rot_delta = open_rot - closed_rot

            display = state_box.column(align=True)
            display.enabled = False
            display.prop(opening, "closed_location", text="Closed Position")
            display.prop(opening, "open_location", text="Open Position")
            display.prop(opening, "closed_rotation", text="Closed Rotation")
            display.prop(opening, "open_rotation", text="Open Rotation")
            state_box.label(text=f"Slide Delta: X {slide_delta[0]:.4f}  Y {slide_delta[1]:.4f}  Z {slide_delta[2]:.4f}")
            state_box.label(text=f"Rotation Delta: X {rot_delta[0]:.4f}  Y {rot_delta[1]:.4f}  Z {rot_delta[2]:.4f}")
        except Exception as ex:
            l.box().label(text=f"UI Error: {ex}")


class VIEW3D_PT_nels(Panel):
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "Tool"
    bl_label = "Lightbar Configuration"
    bl_options = {"DEFAULT_CLOSED"}

    def draw_header(self, context):
        draw_panel_header_icon(self.layout, "lightbar")

    def draw(self, context):
        mark_panel_drawn(getattr(context, "scene", None), "lightbar")
        l = self.layout
        try:
            s = getattr(context.scene, "nels", None)
            if not s:
                l.label(text="No scene settings available")
                return

            soll_status = sollumz_status()
            if not soll_status["enabled"]:
                warn = l.box()
                warn.alert = True
                if soll_status["installed"]:
                    draw_wrapped_text(warn, context, "Sollumz is installed but not enabled. Some functions may not work as expected until it is enabled.", icon="ERROR")
                    row = warn.row(align=True)
                    row.operator("nels.sollumz_enable", text="Enable Sollumz", icon="CHECKMARK")
                    row.operator("wm.url_open", text="Open GitHub", icon="URL").url = SOLLUMZ_REPO_URL
                else:
                    draw_wrapped_text(warn, context, "You do not have Sollumz installed, some functions may not work as expected. Please install Sollumz from GitHub.", icon="ERROR")
                    row = warn.row(align=True)
                    row.operator("nels.sollumz_install", text="Install Sollumz", icon="IMPORT")
                    row.operator("wm.url_open", text="Open GitHub", icon="URL").url = SOLLUMZ_REPO_URL

            b0 = l.box(); b0.label(text="Lightbar Setup")
            r = b0.row(align=True)
            r.prop(s, "saved_config", text="Saved")
            o = r.operator("nels.new_save_load", text="", icon="FILE_REFRESH"); o.action = "LOAD"
            r.menu("NELS_MT_config_actions", text="", icon="DOWNARROW_HLT")
            b0.prop(s, "config_name")
            b0.prop(s, "vehicle_name", text="vehicle_name")
            id_row = b0.row(align=True)
            id_row.prop(s, "vehicle_id", text="siren_id")
            id_row.operator("nels.generate_siren_id", text="", icon="FILE_REFRESH")
            b0.prop(s, "bpm")
            b0.prop(s, "scale_factor_choice", text="Scale Factor")
            if s.scale_factor_choice == "CUSTOM":
                b0.prop(s, "scale_factor_custom", text="Custom Scale Factor")
            b0.prop(s, "all_flash_previews", text="Show All Flash Previews")
            preview_row = b0.row(align=True)
            preview_row.prop(s, "head_tail_preview", text="Head/Tail Preview")
            preview_row.operator("nels.refresh_pattern_previews", text="Refresh", icon="FILE_REFRESH")

            b0.label(text="Headlight Flash Patterns")
            hr = b0.row(align=True)
            hsplit = hr.split(factor=0.85, align=True)
            hleft = hsplit.row(align=True)
            hleft.prop(s, "left_head", text="Left")
            hsw = hsplit.row(align=True)
            if getattr(s, "all_flash_previews", True) and getattr(s, "head_tail_preview", True):
                hsw.enabled = False
                hsw.prop(s, "left_head_preview_cache", text="")
            else:
                hsw.label(text="")

            hr2 = b0.row(align=True)
            hsplit2 = hr2.split(factor=0.85, align=True)
            hleft2 = hsplit2.row(align=True)
            hleft2.prop(s, "right_head", text="Right")
            hsw2 = hsplit2.row(align=True)
            if getattr(s, "all_flash_previews", True) and getattr(s, "head_tail_preview", True):
                hsw2.enabled = False
                hsw2.prop(s, "right_head_preview_cache", text="")
            else:
                hsw2.label(text="")

            b0.label(text="Taillight Flash Patterns")
            tr = b0.row(align=True)
            tsplit = tr.split(factor=0.85, align=True)
            tleft = tsplit.row(align=True)
            tleft.prop(s, "left_tail", text="Left")
            tsw = tsplit.row(align=True)
            if getattr(s, "all_flash_previews", True) and getattr(s, "head_tail_preview", True):
                tsw.enabled = False
                tsw.prop(s, "left_tail_preview_cache", text="")
            else:
                tsw.label(text="")

            tr2 = b0.row(align=True)
            tsplit2 = tr2.split(factor=0.85, align=True)
            tleft2 = tsplit2.row(align=True)
            tleft2.prop(s, "right_tail", text="Right")
            tsw2 = tsplit2.row(align=True)
            if getattr(s, "all_flash_previews", True) and getattr(s, "head_tail_preview", True):
                tsw2.enabled = False
                tsw2.prop(s, "right_tail_preview_cache", text="")
            else:
                tsw2.label(text="")

            r = b0.row(align=True)
            r.prop(s, "show_adv_main", text="Advanced Configurations", icon="TRIA_DOWN" if s.show_adv_main else "TRIA_RIGHT", emboss=False)
            if s.show_adv_main:
                for k in ["use_real_lights", "time_multiplier", "light_falloff_max", "light_falloff_exp", "light_inner_angle", "light_outer_angle", "light_offset", "texture_name", "left_head_mult", "right_head_mult", "left_tail_mult", "right_tail_mult"]:
                    b0.prop(s, k)

            b2 = l.box()
            sh = b2.row(align=True)
            sh.prop(s, "show_sirens_section", text=f"Non-ELS Sirens ({len(s.sirens)})", icon="TRIA_DOWN" if s.show_sirens_section else "TRIA_RIGHT", emboss=False)

            if s.show_sirens_section:
                sh = b2.row(align=True)
                sh.menu("NELS_MT_siren_actions", text="Siren Actions", icon="DOWNARROW_HLT")
                sh.operator("nels.refresh_pattern_previews", text="", icon="FILE_REFRESH")
                sh.prop(s, "list_flash_preview", text="", icon="HIDE_OFF" if s.list_flash_preview else "HIDE_ON", toggle=True)
                sh.label(text=f"Count: {len(s.sirens)}")

                b2.template_list("NELS_UL_sirens", "nels_sirens", s, "sirens", s, "active_siren", rows=8)
                idx = max(0, min(s.active_siren, len(s.sirens) - 1))
                si = s.sirens[idx]
                b2.label(text=f"Siren: siren{si.index}")
                show_rotators = alpha_rotators_enabled(context)
                if show_rotators:
                    b2.prop(si, "siren_type")

                if show_rotators and si.siren_type == "ROTATOR":
                    b2.prop(si, "rotator_speed_mode")
                    if si.rotator_speed_mode == "CUSTOM":
                        b2.prop(si, "rotator_custom_percent")
                    b2.prop(si, "rotator_clockwise", text="Clockwise Rotation")
                    speed_row = b2.row(); speed_row.enabled = False
                    speed_row.prop(si, "light_speed", text="Light Speed")
                elif (not show_rotators) and si.siren_type == "ROTATOR":
                    warn_box = b2.box()
                    warn_box.alert = True
                    warn_box.label(text="Rotator controls are hidden in Add-on Preferences", icon="INFO")
                else:
                    b2.prop(si, "pattern_select", text="Pattern")
                    if si.pattern_select in {UNSAVED_PATTERN_KEY, "__CUSTOM__"}:
                        save_row = b2.row(align=True)
                        save_row.label(text="Unsaved Pattern", icon="BOOKMARKS")
                        save_row.operator("nels.save_siren_pattern", text="Save to Library", icon="ADD")
                        b2.prop(si, "custom_bits")
                        tools_row = b2.row(align=True)
                        o = tools_row.operator("nels.pattern_tools", text="Repeat to 32"); o.action = "REPEAT"; o.scope = "SIREN"
                        o = tools_row.operator("nels.pattern_tools", text="Generate Opposite"); o.action = "INVERT"; o.scope = "SIREN"
                        vrow = b2.row()
                        vrow.prop(si, "custom_value", text="Sequencer")
                b2.prop(si, "color_select", text="Colour")
                if si.color_select == "__CUSTOM__":
                    b2.prop(si, "custom_color", text="Custom Colour")
                    b2.label(text=f"Output: {color_hex(s, si)}")

                frow = b2.row(align=True)
                split = frow.split(factor=0.85, align=True)
                left = split.row(align=True)
                left.prop(si, "flash_preview", text="Flash Preview")
                sw = split.row(align=True)
                if getattr(s, "all_flash_previews", True):
                    sw.prop(si, "preview_color_cache", text="")
                else:
                    sw.label(text="")

                b2.prop(si, "direction_select", text="Direction")
                if si.direction_select == "__CUSTOM__":
                    b2.prop(si, "custom_direction", text="Custom Direction")
                b2.prop(si, "sync_to_bpm")

                lb = b2.box(); lb.label(text="Object/Bone Linking")
                lb.prop_search(s, "armature_name", context.scene, "objects", text="Parent Skeleton")
                lb.operator("nels.auto_detect", text="Auto-Detect Sirens/Bones", icon="VIEWZOOM")
                o = lb.operator("nels.link_bone", text="Assign Selected Mesh", icon="OUTLINER_OB_MESH"); o.action = "MARK"
                o = lb.operator("nels.link_bone", text="Place Bone at Selected Origin", icon="BONE_DATA"); o.action = "BONE"

                mesh_row = lb.row(align=True)
                mesh_row.prop_search(si, "object_name", context.scene, "objects", text="Mesh")
                o = mesh_row.operator("nels.pick_selected_link_target", text="", icon="EYEDROPPER")
                if o is not None:
                    o.target = "SIREN_MESH"

                arm = bpy.data.objects.get(getattr(s, "armature_name", "")) if getattr(s, "armature_name", "") else None
                bone_row = lb.row(align=True)
                if arm and getattr(arm, "type", "") == "ARMATURE":
                    bone_row.prop_search(si, "bone_name", arm.data, "bones", text="Bone")
                else:
                    bone_field = bone_row.row(align=True)
                    bone_field.enabled = False
                    bone_field.prop(si, "bone_name", text="Bone")
                o = bone_row.operator("nels.pick_selected_link_target", text="", icon="EYEDROPPER")
                if o is not None:
                    o.target = "SIREN_BONE"

                if not arm or getattr(arm, "type", "") != "ARMATURE":
                    lb.label(text="Select a Parent Skeleton to search scene bones", icon="INFO")
                direction_warning = active_siren_direction_warning(context.scene)
                if direction_warning:
                    warn_box = lb.box()
                    warn_box.alert = True
                    draw_wrapped_text(warn_box, context, direction_warning, icon="ERROR")

                r = b2.row(align=True)
                r.prop(si, "show_advanced", text="Other Configurations", icon="TRIA_DOWN" if si.show_advanced else "TRIA_RIGHT", emboss=False)
                if si.show_advanced:
                    for k in ["flash", "light", "spot_light", "cast_shadows", "light_group", "start_delay", "light_speed", "light_multiples", "corona_intensity", "corona_size", "corona_pull", "light_intensity", "corona_face_camera"]:
                        b2.prop(si, k)
            elif s.show_sirens_section:
                b2.label(text="No sirens configured yet")

            b4 = l.box(); b4.label(text="Export")
            b4.prop(s, "export_path")
            b4.operator("nels.export", icon="EXPORT")

            if getattr(s, "status_message", ""):
                wb = l.box()
                msg = str(s.status_message)
                warn = msg.lower().startswith("warning") or msg.lower().startswith("error")
                wb.alert = warn
                draw_wrapped_text(wb, context, msg, icon="ERROR" if warn else "INFO")
        except Exception as ex:
            l.box().label(text=f"UI Error: {ex}")

class VIEW3D_PT_nels_patterns(Panel):
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "Tool"
    bl_label = "Flash Patterns Library"
    bl_options = {"DEFAULT_CLOSED"}

    def draw_header(self, context):
        draw_panel_header_icon(self.layout, "patterns")

    def draw(self, context):
        l = self.layout
        try:
            s = getattr(context.scene, "nels", None)
            if not s:
                l.label(text="No scene settings available")
                return

            row = l.row()
            row.template_list("NELS_UL_patterns", "nels_patterns", s, "patterns", s, "active_pattern", rows=5)
            col = row.column(align=True)
            o = col.operator("nels.pattern_tools", text="", icon="ADD"); o.action = "ADD"; o.scope = "LIB"
            o = col.operator("nels.pattern_tools", text="", icon="DUPLICATE"); o.action = "DUPLICATE"; o.scope = "LIB"
            o = col.operator("nels.pattern_tools", text="", icon="REMOVE"); o.action = "REMOVE"; o.scope = "LIB"

            lib = l.box(); lib.label(text="Pattern Library File")
            lib.prop(s, "pattern_library_path", text="")
            lr = lib.row(align=True)
            o = lr.operator("nels.pattern_library_io", text="Export Library", icon="EXPORT"); o.action = "EXPORT"
            o = lr.operator("nels.pattern_library_io", text="Import Library", icon="IMPORT"); o.action = "IMPORT"

            if not s.patterns:
                l.label(text="No patterns yet. Click + or initialize defaults.")
                l.operator("nels.initialize_defaults", icon="FILE_REFRESH")
                return

            p = s.patterns[s.active_pattern] if 0 <= s.active_pattern < len(s.patterns) else s.patterns[0]
            dup_matches = pattern_duplicate_indices(s, s.active_pattern)
            if dup_matches:
                dup_box = l.box()
                dup_allowed = pattern_duplicate_is_allowed(s, s.active_pattern)
                dup_box.alert = not dup_allowed
                dup_box.label(text=f"Duplicate pattern name: {p.name} ({len(dup_matches)} entries)", icon="INFO" if dup_allowed else "ERROR")
                dup_row = dup_box.row(align=True)
                if dup_allowed:
                    o = dup_row.operator("nels.pattern_duplicate_resolution", text="Warn Again")
                    o.action = "WARN"
                    o.index = s.active_pattern
                else:
                    o = dup_row.operator("nels.pattern_duplicate_resolution", text="Keep Both")
                    o.action = "ALLOW"
                    o.index = s.active_pattern
                o = dup_row.operator("nels.pattern_duplicate_resolution", text="Keep Selected Only")
                o.action = "KEEP_SELECTED"
                o.index = s.active_pattern
            l.prop(p, "name")
            l.prop(p, "bits")
            r = l.row(align=True)
            o = r.operator("nels.pattern_tools", text="Repeat to 32"); o.action = "REPEAT"; o.scope = "LIB"
            o = r.operator("nels.pattern_tools", text="Opposite Pattern"); o.action = "INVERT"; o.scope = "LIB"
            vrow = l.row()
            vrow.prop(p, "value", text="Sequencer")
        except Exception as ex:
            l.box().label(text=f"UI Error: {ex}")

class VIEW3D_PT_nels_colors(Panel):
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "Tool"
    bl_label = "Colours"
    bl_options = {"DEFAULT_CLOSED"}

    def draw_header(self, context):
        draw_panel_header_icon(self.layout, "colors")

    def draw(self, context):
        l = self.layout
        try:
            s = getattr(context.scene, "nels", None)
            if not s:
                l.label(text="No scene settings available")
                return

            row = l.row()
            row.template_list("UI_UL_list", "nels_colors", s, "colors", s, "active_color", rows=6)
            col = row.column(align=True)
            o = col.operator("nels.color_tools", text="", icon="ADD"); o.action = "ADD"
            o = col.operator("nels.color_tools", text="", icon="REMOVE"); o.action = "REMOVE"

            if not s.colors:
                l.label(text="No colours found. Initialize defaults.")
                l.operator("nels.initialize_defaults", icon="FILE_REFRESH")
                return

            idx = max(0, min(s.active_color, len(s.colors) - 1))
            c = s.colors[idx]
            l.prop(c, "name")
            l.prop(c, "rgb", text="Colour")
            vrow = l.row()
            vrow.enabled = False
            vrow.prop(c, "value", text="Output")
        except Exception as ex:
            l.box().label(text=f"UI Error: {ex}")

class VIEW3D_PT_nels_car_functions(Panel):
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "Tool"
    bl_label = "Car Functions"
    bl_options = {"DEFAULT_CLOSED"}

    def draw_header(self, context):
        draw_panel_header_icon(self.layout, "car_functions")

    def draw(self, context):
        l = self.layout
        try:
            s = getattr(context.scene, "nels", None)
            if not s:
                l.label(text="No scene settings available")
                return

            lights = l.box()
            lights.label(text="Lighting")
            lights.prop(s, "car_headlights_on", text="Headlights")
            lights.prop(s, "car_taillights_on", text="Taillights")
            lights.prop(s, "car_left_indicator_on", text="Left Indicator")
            lights.prop(s, "car_right_indicator_on", text="Right Indicator")
            lights.prop(s, "car_extra_lights_on", text="Extra Lights")
            lr = lights.row(align=True)
            o = lr.operator("nels.car_lights_sim", text="Apply Light Simulation", icon="LIGHT")
            o.action = "APPLY"
            o = lr.operator("nels.car_lights_sim", text="Reset Light Simulation", icon="LOOP_BACK")
            o.action = "RESET"

            wheel_box = l.box()
            wheel_box.label(text="Wheel Preview")
            wheel_box.label(text="Uses the active or linked source wheel mesh", icon="INFO")
            wr = wheel_box.row(align=True)
            o = wr.operator("nels.wheel_simulation", text="Generate Wheel Preview", icon="MESH_TORUS")
            if o is not None:
                o.action = "APPLY"
            o = wr.operator("nels.wheel_simulation", text="Clear Wheel Preview", icon="TRASH")
            if o is not None:
                o.action = "RESET"

            light_id_box = l.box()
            light_id_box.label(text="Light IDs")
            light_id_box.label(text="Uses Sollumz-style polygon Light IDs", icon="LIGHT")
            ready = light_id_face_select_ready(context)
            set_row = light_id_box.row(align=True)
            set_row.enabled = ready
            o = set_row.operator("nels.light_id_faces", text="Set Light ID", icon="MESH_DATA")
            if o is not None:
                o.action = "SET"
            set_row.prop(s, "car_light_id_target", text="")

            select_row = light_id_box.row(align=True)
            select_row.enabled = ready
            o = select_row.operator("nels.light_id_faces", text="Select Light ID", icon="RESTRICT_SELECT_OFF")
            if o is not None:
                o.action = "SELECT"
            select_row.prop(s, "car_light_id_target", text="")

            if s.car_light_id_target == "CUSTOM":
                light_id_box.prop(s, "car_light_id_custom_value", text="Custom Light ID")

            if not ready:
                warn = light_id_box.row()
                warn.alert = True
                warn.label(text="Must be in Edit Mode > Face Select", icon="ERROR")

            extra_box = l.box()
            extra_box.label(text="Extras")
            extras = scene_extra_objects(context.scene)
            if not extras:
                extra_box.label(text="No extras found on scene objects")
            else:
                top = extra_box.row(align=True)
                o = top.operator("nels.extras_visibility_all", text="Show All", icon="HIDE_OFF")
                o.show = True
                o = top.operator("nels.extras_visibility_all", text="Hide All", icon="HIDE_ON")
                o.show = False

                for obj in extras:
                    visible = is_object_visible(obj)
                    row = extra_box.row(align=True)
                    row.label(text=extra_display_name(obj))
                    o = row.operator("nels.extra_visibility", text="Hide" if visible else "Show")
                    o.object_name = obj.name
                    o.show = not visible

            body_box = l.box()
            body_box.label(text="Body Openings")
            if not getattr(s, "body_openings", None):
                body_box.label(text="No body openings available")
            else:
                for opening in s.body_openings:
                    sub = body_box.box()
                    draw_body_opening_controls(sub, context, s, opening)
        except Exception as ex:
            l.box().label(text=f"UI Error: {ex}")


class VIEW3D_PT_nels_simulation(Panel):
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "Tool"
    bl_label = "Simulation Preview"
    bl_options = {"DEFAULT_CLOSED"}

    def draw_header(self, context):
        draw_panel_header_icon(self.layout, "simulation")

    def draw(self, context):
        l = self.layout
        try:
            s = getattr(context.scene, "nels", None)
            if not s:
                l.label(text="No scene settings available")
                return

            if s.show_sirens_section and s.sirens:
                idx = max(0, min(s.active_siren, len(s.sirens) - 1))
                si = s.sirens[idx]
                l.label(text=f"Scale Factor (from config): {format_scale_factor(scale_factor_from_siren(si, scene=context.scene))}")
                l.label(text=f"Active Siren: siren{si.index}")
                r = l.row(align=True)
                o = r.operator("nels.sim", text="Simulate Siren Off"); o.mode = "OFF"; o.all = False
                o = r.operator("nels.sim", text="Simulate Siren On"); o.mode = "ON"; o.all = False
            else:
                sf = max(0.0, float(getattr(s, "scale_factor", 0.5)))
                l.label(text=f"Scale Factor (from config): {format_scale_factor((1.0 / sf) if sf > 0.0 else 0.0)}")

            r = l.row(align=True)
            o = r.operator("nels.sim", text="Simulate All Sirens Off"); o.mode = "OFF"; o.all = True
            o = r.operator("nels.sim", text="Simulate All Sirens On"); o.mode = "ON"; o.all = True

            l.prop(s, "auto_timeline_preview", text="Auto Rebuild")
            l.operator("nels.preview_clear", text="Clear Timeline", icon="TRASH")
            o = l.operator("nels.preview", text="Preview Active", icon="ANIM_DATA")
            o.scope = "ACTIVE"
            o = l.operator("nels.preview", text="Preview All", icon="ANIM")
            o.scope = "ALL"
        except Exception as ex:
            l.box().label(text=f"UI Error: {ex}")


class VIEW3D_PT_nels_useful_tools(Panel):
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "Tool"
    bl_label = "Useful Tools"
    bl_options = {"DEFAULT_CLOSED"}

    def draw_header(self, context):
        draw_panel_header_icon(self.layout, "useful_tools")

    def draw(self, context):
        l = self.layout
        try:
            s = getattr(context.scene, "nels", None)
            if not s or not s.sirens:
                l.label(text="No sirens configured yet")
                return

            selector_box = l.box()
            selector_box.label(text="Working Siren")
            selector_box.prop(s, "tool_working_siren", text="")
            selector_box.label(text="Defaults to the selected scene siren when available", icon="INFO")

            scale_box = l.box()
            scale_box.label(text="Set Siren Scale Position")
            o = scale_box.operator("nels.set_siren_scale_state", text="Set Scale Off", icon="FULLSCREEN_EXIT")
            o.mode = "OFF"
            o = scale_box.operator("nels.set_siren_scale_state", text="Set Scale On", icon="FULLSCREEN_ENTER")
            o.mode = "ON"

            numbering_box = l.box()
            numbering_box.label(text="Siren Numbering")
            numbering_box.operator("nels.duplicate_siren", text="Duplicate Siren", icon="DUPLICATE")
            numbering_box.operator("nels.renumber_siren", text="Renumber Siren", icon="SORTALPHA")

            linking_box = l.box()
            linking_box.label(text="Linking Tools")
            origin_pick = linking_box.row(align=True)
            origin_pick.prop_search(s, "tool_origin_object", context.scene, "objects", text="Match Origin to Object")
            pick = origin_pick.operator("nels.pick_selected_link_target", text="", icon="EYEDROPPER")
            if pick is not None:
                pick.target = "TOOL_ORIGIN_OBJECT"
            linking_box.operator("nels.match_origin_to_object", text="Match Origin", icon="OBJECT_ORIGIN")
            linking_box.operator("nels.move_bone_to_selected", text="Move Bone to Selected", icon="BONE_DATA")
            linking_box.operator("nels.origin_to_selection", text="Set Origin to Selection", icon="PIVOT_CURSOR")
            linking_box.operator("nels.origins_to_bones", text="Set Selected Origins to Bones", icon="CON_TRACKTO")


            reset_box = l.box()
            reset_box.label(text="Reset Siren")
            o = reset_box.operator("nels.reset_siren_default_state", text="Reset Active", icon="LOOP_BACK")
            o.all = False
            o = reset_box.operator("nels.reset_siren_default_state", text="Reset All", icon="FILE_REFRESH")
            o.all = True
        except Exception as ex:
            l.box().label(text=f"UI Error: {ex}")


class VIEW3D_PT_nels_updates(Panel):
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "Tool"
    bl_label = "Updates"
    bl_options = {"DEFAULT_CLOSED"}

    def draw_header(self, context):
        draw_panel_header_icon(self.layout, "updates")

    def draw(self, context):
        l = self.layout
        try:
            s = getattr(context.scene, "nels", None)
            if not s:
                l.label(text="No scene settings available")
                return

            current_version = version_to_str(addon_version_tuple())
            l.label(text=f"Current Version: {current_version}")
            l.label(text=f"Latest Version: {displayed_update_version(s) or 'Not checked yet'}")
            if getattr(s, "update_last_checked", ""):
                l.label(text=f"Last Checked: {s.update_last_checked}")
            l.prop(s, "update_check_on_startup", text="Check on Startup")
            l.label(text="Checks GitHub and installs the latest zip", icon="INFO")

            status = str(getattr(s, "update_status", "") or "")
            if getattr(s, "update_restart_required", False):
                box = l.box()
                box.alert = True
                draw_wrapped_text(box, context, status or "Update installed. Restart Blender.", icon="ERROR")
            elif getattr(s, "update_available", False):
                box = l.box()
                box.alert = True
                draw_wrapped_text(box, context, status or "Update available", icon="IMPORT")
            elif status:
                icon = "TIME" if (getattr(s, "update_check_in_progress", False) or getattr(s, "update_install_in_progress", False)) else "INFO"
                draw_wrapped_text(l, context, status, icon=icon)

            row = l.row(align=True)
            row.enabled = not (getattr(s, "update_check_in_progress", False) or getattr(s, "update_install_in_progress", False))
            row.operator("nels.update_check", text="Check Updates", icon="FILE_REFRESH")
            sub = row.row(align=True)
            sub.enabled = bool(getattr(s, "update_available", False))
            sub.operator("nels.update_install", text="Install Update", icon="IMPORT")

            open_row = l.row(align=True)
            open_row.operator("wm.url_open", text="Open GitHub", icon="URL").url = UPDATE_REPO_URL
        except Exception as ex:
            l.box().label(text=f"UI Error: {ex}")


def init_all_scenes_defaults():
    scenes = getattr(bpy.data, "scenes", None)
    if scenes is None:
        return 0.25

    for sc in scenes:
        try:
            ensure_scene_defaults(sc)
        except Exception:
            pass
    return None


def update_auto_timeline_preview(self, context):
    if getattr(self, "auto_timeline_preview", False):
        self.auto_timeline_pending = True
        self.auto_timeline_requested_at = _time.time()
        mark_preview_dirty(context, immediate=False)
    else:
        self.auto_timeline_pending = False


def rebuild_auto_timeline_preview(scene):
    global _LIVE_PREVIEW_GUARD
    s = getattr(scene, "nels", None) if scene else None
    if not s or not getattr(s, "auto_timeline_preview", False):
        return False
    if preview_updates_suspended() or _LIVE_PREVIEW_GUARD:
        return False

    _LIVE_PREVIEW_GUARD = True
    try:
        sirens = list(getattr(s, "sirens", []))
        clear_preview_keyframes(scene, sirens)
        used, _cycle_end = generate_timeline_preview(scene, s, sirens)
        s.preview_generated = bool(used)
        s.preview_dirty = False
        s.auto_timeline_pending = False
        return bool(used)
    finally:
        _LIVE_PREVIEW_GUARD = False


def refresh_live_preview(scene):
    global _LIVE_PREVIEW_GUARD
    s = getattr(scene, "nels", None) if scene else None
    if not s or (not s.preview_generated) or (not s.preview_dirty):
        return False
    if not timeline_playing():
        return False
    if _LIVE_PREVIEW_GUARD:
        return False

    _LIVE_PREVIEW_GUARD = True
    try:
        clear_preview_keyframes(scene, list(s.sirens))
        used, _cycle_end = generate_timeline_preview(scene, s, list(s.sirens))
        if used:
            s.preview_dirty = False
            return True
        return False
    finally:
        _LIVE_PREVIEW_GUARD = False


def car_light_tick_required(s):
    if not s:
        return False
    return bool(
        getattr(s, "car_headlights_on", False)
        or getattr(s, "car_taillights_on", False)
        or getattr(s, "car_left_indicator_on", False)
        or getattr(s, "car_right_indicator_on", False)
        or getattr(s, "car_extra_lights_on", False)
    )


def preview_cache_required(scene, s=None):
    s = s if s is not None else (getattr(scene, "nels", None) if scene else None)
    if not s:
        return False
    if not getattr(s, "all_flash_previews", True):
        return False
    if getattr(s, "preview_refresh_pending", False):
        return True
    if scene and getattr(s, "preview_generated", False) and timeline_playing():
        return False

    lightbar_open = panel_drawn_recently(scene, "lightbar")
    if not lightbar_open:
        return False

    if getattr(s, "head_tail_preview", True):
        return True
    if getattr(s, "show_sirens_section", True):
        if getattr(s, "list_flash_preview", True):
            return True
        return any(bool(getattr(si, "flash_preview", False)) for si in getattr(s, "sirens", []))
    return False

def preview_timer_interval(scenes=None):
    interval = 0.50
    scene_iter = scenes if scenes is not None else getattr(bpy.data, "scenes", None)
    if not scene_iter:
        return interval

    for sc in scene_iter:
        s = getattr(sc, "nels", None) if sc else None
        if not s:
            continue
        playing_preview = bool(sc and getattr(s, "preview_generated", False) and timeline_playing())
        if playing_preview and not car_light_tick_required(s) and not getattr(s, "preview_refresh_pending", False):
            continue
        if not (preview_cache_required(sc, s) or car_light_tick_required(s)):
            continue
        bpm = max(1.0, float(getattr(s, "bpm", 800) or 800))
        step_seconds = 60.0 / bpm
        # When the timeline preview itself is playing, keep timer work coarse to avoid fighting viewport FPS.
        if playing_preview:
            target = 0.20 if car_light_tick_required(s) else 0.35
        else:
            target = max(0.08, min(0.15, step_seconds))
        interval = min(interval, target)
    return interval


def nels_preview_tick():
    scenes = getattr(bpy.data, "scenes", None)
    interval = preview_timer_interval(scenes)
    needs_redraw = False
    if scenes:
        now = _time.time()
        needs_redraw = apply_update_job_result() or needs_redraw
        for sc in scenes:
            try:
                s = getattr(sc, "nels", None)
                if not s:
                    continue
                playing_preview = bool(getattr(s, "preview_generated", False) and timeline_playing())
                refresh_direction_warning(sc)
                if not playing_preview:
                    last_detect = float(getattr(s, "body_opening_autodetect_at", 0.0) or 0.0)
                    if (now - last_detect) >= 2.5:
                        needs_redraw = auto_detect_body_opening_links(sc, s) or needs_redraw
                        s.body_opening_autodetect_at = now
                    needs_redraw = sync_tool_working_siren(sc, s) or needs_redraw
                if getattr(s, "auto_timeline_preview", False) and getattr(s, "auto_timeline_pending", False):
                    requested = float(getattr(s, "auto_timeline_requested_at", 0.0) or 0.0)
                    if (now - requested) >= 0.15:
                        needs_redraw = rebuild_auto_timeline_preview(sc) or needs_redraw
                if car_light_tick_required(s):
                    apply_car_light_simulation(sc, s, blink_indicators=True)
                if preview_cache_required(sc, s):
                    needs_redraw = refresh_siren_preview_cache(sc) or needs_redraw
                needs_redraw = update_preview_refresh_feedback(sc) or needs_redraw
            except Exception:
                pass

    wm = getattr(bpy.context, "window_manager", None)
    if not wm:
        return interval

    if needs_redraw:
        tag_preview_ui_redraw()
    return interval


class NELS_ToolPanelMixin:
    panel_location_target = "TOOL"

    @classmethod
    def poll(cls, context):
        return panel_location_visible(cls.panel_location_target, context)


class NELS_ViewportPanelMixin:
    panel_location_target = "VIEWPORT"

    @classmethod
    def poll(cls, context):
        return panel_location_visible(cls.panel_location_target, context)


class VIEW3D_PT_nels_group_general(Panel):
    bl_label = "General"
    bl_options = {"DEFAULT_CLOSED"}

    def draw_header(self, context):
        self.layout.label(text="", icon="TOOL_SETTINGS")

    def draw(self, context):
        pass


class VIEW3D_PT_nels_group_libraries(Panel):
    bl_label = "Libraries"
    bl_options = {"DEFAULT_CLOSED"}

    def draw_header(self, context):
        self.layout.label(text="", icon="FILE_FOLDER")

    def draw(self, context):
        pass


class VIEW3D_PT_nels_group_vehicle(Panel):
    bl_label = "Vehicle"
    bl_options = {"DEFAULT_CLOSED"}

    def draw_header(self, context):
        self.layout.label(text="", icon="SCENE_DATA")

    def draw(self, context):
        pass


class VIEW3D_PT_nels_group_general_tool(NELS_ToolPanelMixin, VIEW3D_PT_nels_group_general, Panel):
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "Tool"
    bl_label = "General"
    bl_options = {"DEFAULT_CLOSED"}


class VIEW3D_PT_nels_group_libraries_tool(NELS_ToolPanelMixin, VIEW3D_PT_nels_group_libraries, Panel):
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "Tool"
    bl_label = "Libraries"
    bl_options = {"DEFAULT_CLOSED"}


class VIEW3D_PT_nels_group_vehicle_tool(NELS_ToolPanelMixin, VIEW3D_PT_nels_group_vehicle, Panel):
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "Tool"
    bl_label = "Vehicle"
    bl_options = {"DEFAULT_CLOSED"}


class VIEW3D_PT_nels_tool(NELS_ToolPanelMixin, VIEW3D_PT_nels, Panel):
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "Tool"
    bl_label = "Lightbar Setup"
    bl_parent_id = "VIEW3D_PT_nels_group_general_tool"
    bl_options = {"DEFAULT_CLOSED"}


class VIEW3D_PT_nels_patterns_tool(NELS_ToolPanelMixin, VIEW3D_PT_nels_patterns, Panel):
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "Tool"
    bl_label = "Flash Patterns"
    bl_parent_id = "VIEW3D_PT_nels_group_libraries_tool"
    bl_options = {"DEFAULT_CLOSED"}


class VIEW3D_PT_nels_colors_tool(NELS_ToolPanelMixin, VIEW3D_PT_nels_colors, Panel):
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "Tool"
    bl_label = "Colours"
    bl_parent_id = "VIEW3D_PT_nels_group_libraries_tool"
    bl_options = {"DEFAULT_CLOSED"}


class VIEW3D_PT_nels_body_openings_tool(NELS_ToolPanelMixin, VIEW3D_PT_nels_body_openings, Panel):
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "Tool"
    bl_label = "Body Openings"
    bl_parent_id = "VIEW3D_PT_nels_group_vehicle_tool"
    bl_options = {"DEFAULT_CLOSED"}


class VIEW3D_PT_nels_car_functions_tool(NELS_ToolPanelMixin, VIEW3D_PT_nels_car_functions, Panel):
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "Tool"
    bl_label = "Car Functions"
    bl_parent_id = "VIEW3D_PT_nels_group_vehicle_tool"
    bl_options = {"DEFAULT_CLOSED"}


class VIEW3D_PT_nels_simulation_tool(NELS_ToolPanelMixin, VIEW3D_PT_nels_simulation, Panel):
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "Tool"
    bl_label = "Simulation"
    bl_parent_id = "VIEW3D_PT_nels_tool"
    bl_options = {"DEFAULT_CLOSED"}


class VIEW3D_PT_nels_useful_tools_tool(NELS_ToolPanelMixin, VIEW3D_PT_nels_useful_tools, Panel):
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "Tool"
    bl_label = "Useful Tools"
    bl_parent_id = "VIEW3D_PT_nels_group_general_tool"
    bl_options = {"DEFAULT_CLOSED"}


class VIEW3D_PT_nels_updates_tool(NELS_ToolPanelMixin, VIEW3D_PT_nels_updates, Panel):
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "Tool"
    bl_label = "Updates"
    bl_parent_id = "VIEW3D_PT_nels_group_general_tool"
    bl_options = {"DEFAULT_CLOSED"}


class VIEW3D_PT_nels_group_general_tab(NELS_ViewportPanelMixin, VIEW3D_PT_nels_group_general, Panel):
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "GTA 000"
    bl_label = "General"
    bl_options = {"DEFAULT_CLOSED"}


class VIEW3D_PT_nels_group_libraries_tab(NELS_ViewportPanelMixin, VIEW3D_PT_nels_group_libraries, Panel):
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "GTA 000"
    bl_label = "Libraries"
    bl_options = {"DEFAULT_CLOSED"}


class VIEW3D_PT_nels_group_vehicle_tab(NELS_ViewportPanelMixin, VIEW3D_PT_nels_group_vehicle, Panel):
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "GTA 000"
    bl_label = "Vehicle"
    bl_options = {"DEFAULT_CLOSED"}


class VIEW3D_PT_nels_tab(NELS_ViewportPanelMixin, VIEW3D_PT_nels, Panel):
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "GTA 000"
    bl_label = "Lightbar Setup"
    bl_parent_id = "VIEW3D_PT_nels_group_general_tab"
    bl_options = {"DEFAULT_CLOSED"}


class VIEW3D_PT_nels_patterns_tab(NELS_ViewportPanelMixin, VIEW3D_PT_nels_patterns, Panel):
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "GTA 000"
    bl_label = "Flash Patterns"
    bl_parent_id = "VIEW3D_PT_nels_group_libraries_tab"
    bl_options = {"DEFAULT_CLOSED"}


class VIEW3D_PT_nels_colors_tab(NELS_ViewportPanelMixin, VIEW3D_PT_nels_colors, Panel):
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "GTA 000"
    bl_label = "Colours"
    bl_parent_id = "VIEW3D_PT_nels_group_libraries_tab"
    bl_options = {"DEFAULT_CLOSED"}


class VIEW3D_PT_nels_body_openings_tab(NELS_ViewportPanelMixin, VIEW3D_PT_nels_body_openings, Panel):
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "GTA 000"
    bl_label = "Body Openings"
    bl_parent_id = "VIEW3D_PT_nels_group_vehicle_tab"
    bl_options = {"DEFAULT_CLOSED"}


class VIEW3D_PT_nels_car_functions_tab(NELS_ViewportPanelMixin, VIEW3D_PT_nels_car_functions, Panel):
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "GTA 000"
    bl_label = "Car Functions"
    bl_parent_id = "VIEW3D_PT_nels_group_vehicle_tab"
    bl_options = {"DEFAULT_CLOSED"}


class VIEW3D_PT_nels_simulation_tab(NELS_ViewportPanelMixin, VIEW3D_PT_nels_simulation, Panel):
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "GTA 000"
    bl_label = "Simulation"
    bl_parent_id = "VIEW3D_PT_nels_tab"
    bl_options = {"DEFAULT_CLOSED"}


class VIEW3D_PT_nels_useful_tools_tab(NELS_ViewportPanelMixin, VIEW3D_PT_nels_useful_tools, Panel):
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "GTA 000"
    bl_label = "Useful Tools"
    bl_parent_id = "VIEW3D_PT_nels_group_general_tab"
    bl_options = {"DEFAULT_CLOSED"}


class VIEW3D_PT_nels_updates_tab(NELS_ViewportPanelMixin, VIEW3D_PT_nels_updates, Panel):
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "GTA 000"
    bl_label = "Updates"
    bl_parent_id = "VIEW3D_PT_nels_group_general_tab"
    bl_options = {"DEFAULT_CLOSED"}
@persistent
def nels_load_post(_dummy):
    init_all_scenes_defaults()


OPERATOR_DESCRIPTIONS = {
    "nels.initialize_defaults": "Initialize GTA 000 Tools defaults for the current scene.",
    "nels.pattern_tools": "Add, duplicate, remove, repeat, or invert flash patterns.",
    "nels.save_siren_pattern": "Save the active siren's unsaved pattern to the flash pattern library.",
    "nels.pattern_duplicate_resolution": "Resolve duplicate flash pattern names in the pattern library.",
    "nels.pattern_library_io": "Import or export the flash pattern library as JSON.",
    "nels.color_tools": "Add or remove colour library entries.",
    "nels.other_attr_tools": "Add or remove entries in the Other Attributes list.",
    "nels.light_id_faces": "Assign the chosen Sollumz-style Light ID to selected faces or select faces that already use that Light ID.",
    "nels.car_lights_sim": "Apply or reset the current car light simulation state in the scene.",
    "nels.wheel_simulation": "Generate or clear wheel preview instances on the vehicle wheel bones.",
    "nels.extra_visibility": "Show or hide the selected extra object.",
    "nels.environment_lights": "Create or remove generated environment preview lights aligned to the linked siren mesh or bone direction.",
    "nels.extras_visibility_all": "Show or hide all detected extras in the current scene.",
    "nels.set_siren_count": "Set how many non-ELS sirens are present in the current configuration.",
    "nels.duplicate_siren": "Duplicate the active siren mesh hierarchy to a new siren number and retarget its names, weights, and linked references.",
    "nels.swap_sirens": "Swap two linked siren meshes and bones in the scene while keeping the siren configuration rows unchanged.",
    "nels.auto_detect": "Auto-detect siren meshes and bones from scene names and existing links.",
    "nels.generate_siren_id": "Generate a siren ID value for the current vehicle configuration.",
    "nels.new_save_load": "Create, save, load, delete, or reset Blender-side lightbar configurations.",
    "nels.export_config": "Export the current Blender-side lightbar configuration to a JSON file.",
    "nels.import_config": "Import a Blender-side lightbar configuration from a JSON file.",
    "nels.import_carcols": "Import a GTA V carcols.meta file into the current Blender scene.",
    "nels.choose_parent_skeleton": "Choose which armature should be used as the parent skeleton.",
    "nels.sollumz_enable": "Enable an installed Sollumz addon so GTA 000 Tools features that depend on Sollumz can work.",
    "nels.sollumz_install": "Download the latest official Sollumz release zip from GitHub, install it into Blender, and try to enable it automatically.",
    "nels.link_bone": "Assign the selected object to the siren, place a siren bone at the selected origin, or copy a helper object origin onto the active siren mesh.",
    "nels.pick_selected_link_target": "Assign the active selected mesh or selected bone to the current siren or body opening from the current scene.",
    "nels.match_origin_to_object": "Move the working siren origin to the chosen helper object and then clear the helper selection field.",
    "nels.origin_to_selection": "In Edit Mode, move the active mesh origin to the midpoint of the selected vertices, edges, or faces without moving the mesh in world space.",
    "nels.origins_to_bones": "In Object Mode, move each selected mesh origin to its linked siren bone location without moving the mesh in world space.",
    "nels.move_bone_to_selected": "Move the resolved active siren bone to the selected object origin while preserving its current direction.",
    "nels.sim": "Simulate active or all sirens in their shown or hidden state.",
    "nels.set_siren_scale_state": "Bake the resolved siren mesh so the current visible size becomes the correct shown or hidden state without moving its origin.",
    "nels.reset_siren_default_state": "Clear preview transforms and restore the resolved siren or all sirens to their stored default pose.",
    "nels.renumber_siren": "Rename the selected siren mesh, linked sub-meshes, and linked bone hierarchy to an unused siren number in the current configuration.",
    "nels.preview_clear": "Clear generated siren preview keyframes from the timeline.",
    "nels.update_check": "Check the GTA000Tools GitHub repository for a newer addon version.",
    "nels.update_install": "Download the latest addon zip from GitHub, replace the installed addon files, and prompt for a Blender restart.",
    "nels.refresh_pattern_previews": "Force-refresh all siren, headlight, and taillight preview swatches.",
    "nels.preview": "Generate a timeline preview for the active siren or for all sirens.",
    "nels.export": "Export the current setup as a carcols.meta file.",
    "nels.siren_status_info": "Show the current siren link status and any missing mesh or bone requirements.",
    "nels.body_opening_link": "Assign the selected mesh to the active body opening, match its origin to a helper object, or place its linked bone on the parent skeleton.",
    "nels.body_opening_state": "Capture or apply the open and closed preview state for the active body opening.",
}


def apply_operator_descriptions():
    for cls in classes:
        try:
            if not issubclass(cls, Operator):
                continue
        except Exception:
            continue
        if "description" in cls.__dict__:
            continue
        if "bl_description" in cls.__dict__ and str(getattr(cls, "bl_description", "") or "").strip():
            continue
        desc = str(OPERATOR_DESCRIPTIONS.get(getattr(cls, "bl_idname", ""), "") or "").strip()
        if desc:
            cls.bl_description = desc


classes = (
    GTA000TOOLS_Preferences,
    NELSPattern,
    NELSColor,
    NELSOtherAttribute,
    NELSBodyOpening,
    NELSSiren,
    NELSSettings,
    NELS_OT_pattern_tools,
    NELS_OT_save_siren_pattern,
    NELS_OT_pattern_library_io,
    NELS_OT_pattern_duplicate_resolution,
    NELS_OT_color_tools,
    NELS_OT_other_attr_tools,
    NELS_OT_light_id_faces,
    NELS_OT_car_lights_sim,
    NELS_OT_wheel_simulation,
    NELS_OT_extra_visibility,
    NELS_OT_environment_lights,
    NELS_OT_extras_visibility_all,
    NELS_OT_initialize_defaults,
    NELS_OT_set_siren_count,
    NELS_OT_duplicate_siren,
    NELS_OT_swap_sirens,
    NELS_OT_auto_detect,
    NELS_OT_generate_siren_id,
    NELS_OT_new_save_load,
    NELS_OT_export_config,
    NELS_OT_import_config,
    NELS_OT_import_carcols,
    NELS_MT_siren_actions,
    NELS_MT_config_actions,
    NELS_OT_choose_parent_skeleton,
    NELS_OT_sollumz_enable,
    NELS_OT_sollumz_install,
    NELS_OT_link_bone,
    NELS_OT_pick_selected_link_target,
    NELS_OT_match_origin_to_object,
    NELS_OT_origin_to_selection,
    NELS_OT_origins_to_bones,
    NELS_OT_move_bone_to_selected,
    NELS_OT_body_opening_link,
    NELS_OT_body_opening_state,
    NELS_OT_sim,
    NELS_OT_set_siren_scale_state,
    NELS_OT_reset_siren_default_state,
    NELS_OT_renumber_siren,
    NELS_OT_preview_clear,
    NELS_OT_update_check,
    NELS_OT_update_install,
    NELS_OT_refresh_pattern_previews,
    NELS_OT_preview,
    NELS_OT_export,
    NELS_OT_siren_status_info,
    VIEW3D_MT_nels,
    VIEW3D_MT_nels_context_object,
    VIEW3D_MT_nels_context_edit,
    NELS_UL_sirens,
    NELS_UL_patterns,
    VIEW3D_PT_nels_group_general_tool,
    VIEW3D_PT_nels_group_libraries_tool,
    VIEW3D_PT_nels_group_vehicle_tool,
    VIEW3D_PT_nels_tool,
    VIEW3D_PT_nels_patterns_tool,
    VIEW3D_PT_nels_colors_tool,
    VIEW3D_PT_nels_car_functions_tool,
    VIEW3D_PT_nels_simulation_tool,
    VIEW3D_PT_nels_useful_tools_tool,
    VIEW3D_PT_nels_updates_tool,
    VIEW3D_PT_nels_group_general_tab,
    VIEW3D_PT_nels_group_libraries_tab,
    VIEW3D_PT_nels_group_vehicle_tab,
    VIEW3D_PT_nels_tab,
    VIEW3D_PT_nels_patterns_tab,
    VIEW3D_PT_nels_colors_tab,
    VIEW3D_PT_nels_car_functions_tab,
    VIEW3D_PT_nels_simulation_tab,
    VIEW3D_PT_nels_useful_tools_tab,
    VIEW3D_PT_nels_updates_tab,)

apply_operator_descriptions()

LEGACY_CLASS_NAMES = (
    "NELS_UL_body_openings",
    "VIEW3D_PT_nels_body_openings",
    "VIEW3D_PT_nels_body_openings_tool",
    "VIEW3D_PT_nels_body_openings_tab",
)


def cleanup_legacy_classes():
    for name in LEGACY_CLASS_NAMES:
        cls = getattr(bpy.types, name, None)
        if cls is None:
            continue
        try:
            bpy.utils.unregister_class(cls)
        except Exception:
            pass


def register():
    global _UPDATE_STARTUP_SCHEDULED
    _UPDATE_STARTUP_SCHEDULED = False
    cleanup_legacy_classes()
    register_panel_icons()
    remove_custom_preview_draw_handler()
    apply_operator_descriptions()
    for c in classes:
        bpy.utils.register_class(c)
    bpy.types.Scene.nels = PointerProperty(type=NELSSettings)
    bpy.types.VIEW3D_MT_object.append(draw_obj_menu)
    bpy.types.VIEW3D_MT_object_context_menu.prepend(draw_object_context_menu)
    bpy.types.VIEW3D_MT_edit_mesh_context_menu.prepend(draw_edit_mesh_context_menu)

    if nels_load_post not in bpy.app.handlers.load_post:
        bpy.app.handlers.load_post.append(nels_load_post)

    try:
        if not bpy.app.timers.is_registered(init_all_scenes_defaults):
            bpy.app.timers.register(init_all_scenes_defaults, first_interval=0.1)
        if not bpy.app.timers.is_registered(nels_preview_tick):
            bpy.app.timers.register(nels_preview_tick, first_interval=0.2)
    except Exception:
        pass


def unregister():
    global _UPDATE_STARTUP_SCHEDULED
    _UPDATE_STARTUP_SCHEDULED = False
    try:
        bpy.types.VIEW3D_MT_object.remove(draw_obj_menu)
    except Exception:
        pass
    try:
        bpy.types.VIEW3D_MT_object_context_menu.remove(draw_object_context_menu)
    except Exception:
        pass
    try:
        bpy.types.VIEW3D_MT_edit_mesh_context_menu.remove(draw_edit_mesh_context_menu)
    except Exception:
        pass

    if hasattr(bpy.types.Scene, "nels"):
        del bpy.types.Scene.nels

    try:
        if bpy.app.timers.is_registered(init_all_scenes_defaults):
            bpy.app.timers.unregister(init_all_scenes_defaults)
        if bpy.app.timers.is_registered(nels_preview_tick):
            bpy.app.timers.unregister(nels_preview_tick)
    except Exception:
        pass

    if nels_load_post in bpy.app.handlers.load_post:
        bpy.app.handlers.load_post.remove(nels_load_post)

    for c in reversed(classes):
        bpy.utils.unregister_class(c)

    cleanup_legacy_classes()
    remove_custom_preview_draw_handler()
    unregister_panel_icons()

if __name__ == "__main__":
    register()










































































































































































































































