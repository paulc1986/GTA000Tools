def auto_detect_scene_sirens(scene, create_missing=True, sync_direction=False):
    s = getattr(scene, "nels", None)
    if not s:
        return (0, 0, 0)

    scene_objects = list(getattr(scene, "objects", [])) if scene else list(bpy.data.objects)

    arm = None
    if s.armature_name:
        arm = next((obj for obj in scene_objects if obj.name == s.armature_name and obj.type == "ARMATURE"), None)

    best_arm = arm
    best_bones = {}
    best_count = 0
    for obj in scene_objects:
        if obj.type != "ARMATURE":
            continue
        bone_map = {}
        for b in obj.data.bones:
            idx = siren_index_from_name(b.name)
            if idx and idx not in bone_map:
                bone_map[idx] = b.name
        if len(bone_map) > best_count:
            best_count = len(bone_map)
            best_arm = obj
            best_bones = bone_map

    if best_arm and s.armature_name != best_arm.name:
        s.armature_name = best_arm.name
    if not best_bones and best_arm and best_arm.type == "ARMATURE":
        for b in best_arm.data.bones:
            idx = siren_index_from_name(b.name)
            if idx and idx not in best_bones:
                best_bones[idx] = b.name

    obj_map = {}
    for obj in scene_objects:
        idx = siren_index_from_name(obj.name)
        if idx and idx not in obj_map:
            obj_map[idx] = obj.name
        if best_arm and obj.parent == best_arm and obj.parent_type == "BONE":
            bidx = siren_index_from_name(obj.parent_bone)
            if bidx and bidx not in obj_map:
                obj_map[bidx] = obj.name

    max_idx = max([0, len(s.sirens)] + list(obj_map.keys()) + list(best_bones.keys()))
    if create_missing and max_idx > len(s.sirens):
        ensure_sirens(s, max_idx)

    linked = 0
    for i, si in enumerate(s.sirens, start=1):
        if (not si.bone_name) and i in best_bones:
            si.bone_name = best_bones[i]
            linked += 1

        if (not si.object_name) and i in obj_map:
            si.object_name = obj_map[i]
            o = bpy.data.objects.get(si.object_name)
            if o:
                _store_rest_loc(o)
            linked += 1

        if si.object_name and (not si.bone_name) and best_arm:
            o = bpy.data.objects.get(si.object_name)
            if o and o.parent == best_arm and o.parent_type == "BONE":
                bidx = siren_index_from_name(o.parent_bone)
                if bidx == i:
                    si.bone_name = o.parent_bone

        si.enabled = bool(si.object_name or si.bone_name)

    ensure_body_opening_defaults(s)
    for op in s.body_openings:
        if op.object_name and op.object_name not in bpy.data.objects:
            op.object_name = ""
        if op.anchor_name and op.anchor_name not in bpy.data.objects:
            op.anchor_name = ""
        if op.bone_name:
            has_bone = bool(arm and op.bone_name in arm.data.bones)
            if not has_bone:
                for obj in bpy.data.objects:
                    if obj.type != "ARMATURE":
                        continue
                    if op.bone_name in obj.data.bones:
                        has_bone = True
                        if not arm:
                            arm = obj
                            s.armature_name = obj.name
                        break
            if not has_bone:
                op.bone_name = ""

    if sync_direction:
        apply_all_siren_directions(scene)

    return (len(obj_map), len(best_bones), linked)

def siren_obj(si):
    if si.object_name and si.object_name in bpy.data.objects:
        return bpy.data.objects[si.object_name]
    n = f"siren{si.index}"
    return bpy.data.objects.get(n)



def siren_pose_bone(scene, si):
    s = getattr(scene, "nels", None) if scene else None
    candidates = []
    if s and s.armature_name:
        arm = bpy.data.objects.get(s.armature_name)
        if arm and arm.type == "ARMATURE":
            candidates.append(arm)
    for obj in bpy.data.objects:
        if obj.type == "ARMATURE" and obj not in candidates:
            candidates.append(obj)

    names = []
    if si and si.bone_name:
        names.append(si.bone_name)
    if si:
        names.append(f"siren{si.index}")

    for arm in candidates:
        for bn in names:
            if not bn:
                continue
            pb = arm.pose.bones.get(bn)
            if pb:
                if si and not si.bone_name:
                    si.bone_name = pb.name
                if s and not s.armature_name:
                    s.armature_name = arm.name
                return arm, pb
    return None, None


def swappable_siren_items(self, context):
    scene = getattr(context, "scene", None) if context else getattr(bpy.context, "scene", None)
    s = getattr(scene, "nels", None) if scene else None
    items = []
    if s:
        for si in s.sirens:
            obj = siren_obj(si)
            arm, pb = siren_pose_bone(scene, si)
            if obj and obj.type == "MESH" and arm and pb:
                items.append((str(si.index), f"Siren {si.index}", f"{obj.name} on {arm.name}:{pb.name}"))
    if items:
        return items
    return [("__NONE__", "(No complete sirens found)", "Link mesh and bone for at least two sirens first")]


def siren_slot_by_index(s, idx):
    if not s:
        return None
    try:
        needle = int(idx)
    except Exception:
        return None
    for si in s.sirens:
        if int(getattr(si, "index", 0)) == needle:
            return si
    return None


SIREN_SNAPSHOT_FIELDS = [
    "enabled", "siren_type", "rotator_speed_mode", "rotator_custom_percent", "rotator_clockwise",
    "pattern_source", "pattern_choice", "custom_visibility", "custom_bits", "custom_value",
    "color_mode", "color_preset", "direction_mode", "direction_preset", "custom_direction",
    "scale_mode", "scale_preset", "custom_scale", "sync_to_bpm", "flash_preview",
    "flash", "light", "spot_light", "cast_shadows", "light_group", "start_delay",
    "light_speed", "light_multiples", "corona_intensity", "corona_size", "corona_pull",
    "light_intensity", "corona_face_camera", "object_name", "anchor_name", "bone_name",
]

SIREN_CONFIG_COPY_EXCLUDED_FIELDS = {"enabled", "object_name", "anchor_name", "bone_name"}


def capture_siren_slot_snapshot(si):
    data = {}
    for key in SIREN_SNAPSHOT_FIELDS:
        try:
            value = getattr(si, key)
            if isinstance(value, (list, tuple)):
                value = tuple(value)
            data[key] = value
        except Exception:
            pass
    try:
        data["custom_color"] = tuple(si.custom_color)
    except Exception:
        data["custom_color"] = (1.0, 1.0, 1.0)
    return data


def apply_siren_slot_snapshot(s, si, idx, data):
    add_siren(s, si, idx)
    for key, value in dict(data or {}).items():
        if key in {"index", "name"}:
            continue
        try:
            setattr(si, key, value)
        except Exception:
            pass
    si.index = idx
    si.name = f"siren{idx}"
    sync_siren_selector_controls(si)


def capture_siren_config_snapshot(si):
    snapshot = capture_siren_slot_snapshot(si)
    for key in list(snapshot.keys()):
        if key in SIREN_CONFIG_COPY_EXCLUDED_FIELDS:
            snapshot.pop(key, None)
    return snapshot


def apply_siren_config_snapshot(scene, s, si, data):
    for key, value in dict(data or {}).items():
        if key in {"index", "name"}:
            continue
        if key in SIREN_CONFIG_COPY_EXCLUDED_FIELDS:
            continue
        try:
            setattr(si, key, value)
        except Exception:
            pass
    sync_siren_selector_controls(si)
    try:
        apply_siren_direction_to_bone(scene, si, set_warning=True)
    except Exception:
        pass


def scene_present_siren_indices(scene, s=None):
    used = set()
    if scene:
        for obj in scene.objects:
            try:
                idx = siren_index_from_name(getattr(obj, "name", ""))
                if idx > 0:
                    used.add(idx)
                if getattr(obj, "parent_type", "") == "BONE":
                    idx = siren_index_from_name(getattr(obj, "parent_bone", ""))
                    if idx > 0:
                        used.add(idx)
                if getattr(obj, "type", "") == "ARMATURE":
                    for bone in getattr(getattr(obj, "data", None), "bones", []):
                        idx = siren_index_from_name(getattr(bone, "name", ""))
                        if idx > 0:
                            used.add(idx)
            except Exception:
                continue
    if s:
        for si in getattr(s, "sirens", []):
            try:
                if siren_obj(si) or siren_pose_bone(scene, si)[1]:
                    used.add(int(getattr(si, "index", 0) or 0))
            except Exception:
                pass
    return used


def renumber_target_items(self, context):
    scene = getattr(context, "scene", None) if context else getattr(bpy.context, "scene", None)
    s = getattr(scene, "nels", None) if scene else None
    if not s or not s.sirens:
        return [("__NONE__", "(No sirens configured)", "")]
    source = resolve_context_siren(scene, s, require_linked=False, update_active=False)
    used = scene_present_siren_indices(scene, s=s)
    limit = max(0, min(int(getattr(s, "siren_count", len(s.sirens)) or len(s.sirens)), len(s.sirens)))
    items = [(str(idx), f"Siren {idx}", f"Rename the selected siren hierarchy to siren{idx}") for idx in range(1, limit + 1) if idx not in used]
    return items if items else [("__NONE__", "(No available siren numbers)", "All configured siren numbers already exist in the scene")]


def selected_siren_root_object(context, fallback=None):
    obj = getattr(getattr(context, "view_layer", None), "objects", None)
    active = getattr(obj, "active", None) if obj else getattr(bpy.context, "active_object", None)
    cur = active or fallback
    while cur and getattr(cur, "parent", None) and getattr(cur.parent, "type", "") != "ARMATURE" and getattr(cur, "parent_type", "") != "BONE":
        cur = cur.parent
    return cur or fallback


def bone_tree_names(arm, root_name):
    if not arm or getattr(arm, "type", "") != "ARMATURE" or not root_name:
        return []
    root = getattr(getattr(arm, "data", None), "bones", {}).get(root_name) if hasattr(getattr(arm, "data", None), "bones") else None
    if not root:
        return []
    found = []
    stack = [root]
    while stack:
        cur = stack.pop(0)
        if not cur or cur.name in found:
            continue
        found.append(cur.name)
        stack.extend(list(getattr(cur, "children", [])))
    return found


def rename_pose_rest_keys(arm, name_map):
    if not arm:
        return
    for old_name, new_name in dict(name_map or {}).items():
        old_key = _pose_rest_key(old_name)
        new_key = _pose_rest_key(new_name)
        if old_key == new_key:
            continue
        try:
            if old_key in arm:
                arm[new_key] = list(arm[old_key])
                del arm[old_key]
        except Exception:
            pass


def capture_bone_parent_links(scene, arm, bone_names):
    links = []
    if not scene or not arm:
        return links
    names = set(bone_names or [])
    for obj in scene.objects:
        try:
            if obj.parent == arm and obj.parent_type == "BONE" and obj.parent_bone in names:
                _store_rest_loc(obj)
                links.append((obj, arm, obj.parent_bone, obj.matrix_world.copy()))
        except Exception:
            continue
    return links


def restore_bone_parent_links(links, name_map):
    for obj, arm, old_bone, matrix_world in list(links or []):
        try:
            obj.parent = arm
            obj.parent_type = "BONE"
            obj.parent_bone = name_map.get(old_bone, old_bone)
            obj.matrix_world = matrix_world
            _store_rest_loc(obj, force=True)
        except Exception:
            continue


def siren_bone_subtree_objects(scene, arm, root_bone_name, exclude=None):
    names = set(bone_tree_names(arm, root_bone_name))
    found = []
    exclude = set(exclude or [])
    if not scene or not arm or not names:
        return found
    for obj in scene.objects:
        try:
            if obj in exclude:
                continue
            if obj.parent == arm and obj.parent_type == "BONE" and obj.parent_bone in names:
                found.append(obj)
        except Exception:
            continue
    return found


def rename_siren_bone_hierarchy(scene, arm, root_bone_name, old_index, new_index):
    bone_names = bone_tree_names(arm, root_bone_name)
    if not bone_names:
        return {}, ""

    desired_map = {}
    for old_name in bone_names:
        desired = retarget_siren_name_token(old_name, old_index, new_index)
        desired = re.sub(r'\.\d{3}$', '', desired)
        if old_name == root_bone_name:
            desired = f"siren{int(new_index)}"
        desired_map[old_name] = desired

    conflicts = []
    existing = getattr(getattr(arm, "data", None), "bones", None)
    for old_name, new_name in desired_map.items():
        if not new_name:
            continue
        bone = existing.get(new_name) if existing else None
        if bone and bone.name not in desired_map:
            conflicts.append(new_name)
    if conflicts:
        raise RuntimeError(f"Target bone name already exists: {conflicts[0]}")

    child_links = capture_bone_parent_links(scene, arm, bone_names)
    old_active = getattr(bpy.context.view_layer.objects, "active", None)
    old_mode = getattr(bpy.context, "mode", "OBJECT")
    stamp = _time.time_ns()
    temp_map = {old_name: f"__nels_ren_{stamp}_{i}" for i, old_name in enumerate(bone_names, start=1)}

    try:
        if old_mode != "OBJECT":
            bpy.ops.object.mode_set(mode="OBJECT")
        bpy.ops.object.select_all(action="DESELECT")
        arm.select_set(True)
        bpy.context.view_layer.objects.active = arm
        bpy.ops.object.mode_set(mode="EDIT")
        for old_name in bone_names:
            eb = arm.data.edit_bones.get(old_name)
            if eb:
                eb.name = temp_map[old_name]
        for old_name in bone_names:
            eb = arm.data.edit_bones.get(temp_map[old_name])
            if eb:
                eb.name = desired_map[old_name]
        bpy.ops.object.mode_set(mode="OBJECT")
    finally:
        try:
            if getattr(bpy.context, "mode", "OBJECT") != "OBJECT":
                bpy.ops.object.mode_set(mode="OBJECT")
        except Exception:
            pass
        try:
            if old_active and old_active.name in bpy.data.objects:
                bpy.context.view_layer.objects.active = old_active
        except Exception:
            pass
        try:
            if old_mode != "OBJECT" and getattr(bpy.context, "mode", "OBJECT") == "OBJECT":
                bpy.ops.object.mode_set(mode=old_mode)
        except Exception:
            pass

    restore_bone_parent_links(child_links, desired_map)
    rename_pose_rest_keys(arm, desired_map)
    for new_name in desired_map.values():
        try:
            pb = arm.pose.bones.get(new_name)
            if pb:
                _store_rest_pose_bone(arm, pb, force=True)
        except Exception:
            pass
    return desired_map, desired_map.get(root_bone_name, "")


def pick_anchor_object(context, arm, si):
    active = getattr(context.view_layer.objects, "active", None)
    selected = [o for o in context.selected_objects if o and o.type != "ARMATURE"]

    if si and si.object_name:
        non_siren = [o for o in selected if o.name != si.object_name]
        if non_siren:
            selected = non_siren

    if active and active in selected:
        return active
    if selected:
        return selected[0]
    if active and active.type != "ARMATURE":
        if not si or active.name != si.object_name:
            return active

    if si and si.anchor_name and si.anchor_name in bpy.data.objects:
        anchor = bpy.data.objects[si.anchor_name]
        if anchor.type != "ARMATURE":
            return anchor
    return None


def pick_reference_object(context, si):
    active = getattr(context.view_layer.objects, "active", None)
    selected = [o for o in context.selected_objects if o and o.type != "ARMATURE"]

    if si and si.object_name:
        selected = [o for o in selected if o.name != si.object_name]

    if active and active in selected:
        return active
    if selected:
        return selected[0]
    if active and active.type != "ARMATURE":
        if not si or active.name != si.object_name:
            return active
    return None


def pick_any_reference_object(context):
    active = getattr(getattr(context, "view_layer", None), "objects", None)
    active = getattr(active, "active", None)
    selected = [o for o in getattr(context, "selected_objects", []) if o and getattr(o, "type", "") != "ARMATURE"]

    if active and active in selected:
        return active
    if selected:
        return selected[0]
    if active and getattr(active, "type", "") != "ARMATURE":
        return active
    return None


def set_object_origin_from_reference(obj, reference):
    if not obj or not reference:
        return False, "Missing source or reference object"
    if getattr(obj, "type", "") != "MESH":
        return False, "The linked siren object must be a mesh"
    if getattr(obj, "data", None) is None or not hasattr(obj.data, "transform"):
        return False, "The linked siren object has no editable mesh data"

    old_world = obj.matrix_world.copy()
    new_world = old_world.copy()
    new_world.translation = reference.matrix_world.translation.copy()

    try:
        transform = new_world.inverted() @ old_world
    except Exception:
        return False, "Could not calculate the new siren origin transform"

    try:
        if getattr(obj.data, "users", 1) > 1:
            obj.data = obj.data.copy()
        obj.data.transform(transform)
        if hasattr(obj.data, "update"):
            obj.data.update()
        obj.matrix_world = new_world
        _store_rest_loc(obj, force=True)
        return True, f"Set {obj.name} origin to {reference.name}"
    except Exception as ex:
        return False, f"Could not set siren origin: {ex}"

def set_object_origin_to_local_point(obj, local_point):
    if not obj:
        return False, "Missing object"
    if getattr(obj, "type", "") != "MESH":
        return False, "The active object must be a mesh"
    if getattr(obj, "data", None) is None or not hasattr(obj.data, "transform"):
        return False, "The active mesh has no editable geometry data"

    try:
        point = Vector(local_point)
    except Exception:
        return False, "Could not read the selected midpoint"

    old_world = obj.matrix_world.copy()
    new_world = old_world @ Matrix.Translation(point)

    try:
        if getattr(obj.data, "users", 1) > 1:
            obj.data = obj.data.copy()
        obj.data.transform(Matrix.Translation(-point))
        if hasattr(obj.data, "update"):
            obj.data.update()
        obj.matrix_world = new_world
        _store_rest_loc(obj, force=True)
        return True, f"Set {obj.name} origin to the current selection"
    except Exception as ex:
        return False, f"Could not set the object origin: {ex}"


def set_object_origin_to_world_point(obj, world_point):
    if not obj:
        return False, "Missing object"
    if getattr(obj, "type", "") != "MESH":
        return False, "The selected object must be a mesh"
    if getattr(obj, "data", None) is None or not hasattr(obj.data, "transform"):
        return False, "The selected mesh has no editable geometry data"

    try:
        point = Vector(world_point)
    except Exception:
        return False, "Could not read the target bone location"

    old_world = obj.matrix_world.copy()
    new_world = old_world.copy()
    new_world.translation = point

    try:
        transform = new_world.inverted() @ old_world
    except Exception:
        return False, "Could not calculate the new origin transform"

    try:
        if getattr(obj.data, "users", 1) > 1:
            obj.data = obj.data.copy()
        obj.data.transform(transform)
        if hasattr(obj.data, "update"):
            obj.data.update()
        obj.matrix_world = new_world
        obj["_nels_origin_only_previous_world"] = [float(old_world.translation[0]), float(old_world.translation[1]), float(old_world.translation[2])]
        obj["_nels_origin_only_target_world"] = [float(point[0]), float(point[1]), float(point[2])]
        _store_rest_loc(obj, force=True)
        return True, f"Set {obj.name} origin to its linked bone"
    except Exception as ex:
        return False, f"Could not set the object origin: {ex}"


def move_object_to_world_point_preserve_origin(obj, world_point):
    if not obj:
        return False, "Missing object"
    if getattr(obj, "type", "") != "MESH":
        return False, "The selected object must be a mesh"

    try:
        point = Vector(world_point)
    except Exception:
        return False, "Could not read the target bone location"

    def _vector_from_any_triplet(value):
        if value is None:
            return None
        try:
            seq = list(value)
        except Exception:
            return None
        if len(seq) != 3:
            return None
        try:
            return Vector((float(seq[0]), float(seq[1]), float(seq[2])))
        except Exception:
            return None

    try:
        old_world = obj.matrix_world.copy()
        delta_world = point - old_world.translation
        if delta_world.length <= 0.000001:
            previous_world = _vector_from_any_triplet(obj.get("_nels_origin_only_previous_world"))
            if previous_world is not None:
                delta_world = point - previous_world
            if delta_world.length <= 0.000001:
                return True, f"{obj.name} origin is already on the linked bone"

        ok, msg = set_object_origin_to_world_point(obj, point)
        if not ok:
            return False, msg

        local_delta = obj.matrix_world.to_3x3().inverted_safe() @ delta_world
        if getattr(obj.data, "users", 1) > 1:
            obj.data = obj.data.copy()
        obj.data.transform(Matrix.Translation(local_delta))
        if hasattr(obj.data, "update"):
            obj.data.update()
        try:
            bpy.context.view_layer.update()
        except Exception:
            pass
        for key in ("_nels_origin_only_previous_world", "_nels_origin_only_target_world"):
            try:
                if key in obj:
                    del obj[key]
            except Exception:
                pass
        _store_rest_loc(obj, force=True)
        return True, f"Moved {obj.name} and its origin to the linked bone"
    except Exception as ex:
        return False, f"Could not move the object to its linked bone: {ex}"


def edit_selection_local_center(obj, context):
    if not obj or getattr(obj, "type", "") != "MESH":
        return None, "The active object must be a mesh"
    if getattr(obj, "mode", "") != "EDIT":
        return None, "Switch the active mesh to Edit Mode first"

    try:
        bm = bmesh.from_edit_mesh(obj.data)
    except Exception as ex:
        return None, f"Could not read the edit selection: {ex}"

    mesh_mode = tuple(getattr(getattr(context, "tool_settings", None), "mesh_select_mode", (True, False, False)) or (True, False, False))
    face_points = [f.calc_center_median().copy() for f in bm.faces if getattr(f, "select", False)]
    edge_points = [((e.verts[0].co.copy() + e.verts[1].co.copy()) * 0.5) for e in bm.edges if getattr(e, "select", False)]
    vert_points = [v.co.copy() for v in bm.verts if getattr(v, "select", False)]

    points = []
    if len(mesh_mode) > 2 and mesh_mode[2] and face_points:
        points = face_points
    elif len(mesh_mode) > 1 and mesh_mode[1] and edge_points:
        points = edge_points
    elif len(mesh_mode) > 0 and mesh_mode[0] and vert_points:
        points = vert_points
    elif face_points:
        points = face_points
    elif edge_points:
        points = edge_points
    else:
        points = vert_points

    if not points:
        return None, "Select at least one vertex, edge, or face first"

    center = Vector((0.0, 0.0, 0.0))
    for point in points:
        center += point
    center /= float(len(points))
    return center, ""


def move_siren_bone_to_world_point(scene, si, world_point, preserve_direction=True):
    if not scene or not si:
        return False, "No siren was resolved"

    arm, pb = siren_pose_bone(scene, si)
    if not arm or not pb:
        return False, f"No linked bone was found for siren {getattr(si, 'index', '?')}. Link a bone first in Object/Bone Linking."

    try:
        point_world = Vector(world_point)
    except Exception:
        return False, "Could not read the selected object origin"

    old_active = getattr(bpy.context.view_layer.objects, "active", None)
    old_mode = getattr(bpy.context, "mode", "OBJECT")

    try:
        if old_mode != "OBJECT":
            bpy.ops.object.mode_set(mode="OBJECT")
        bpy.ops.object.select_all(action="DESELECT")
        arm.select_set(True)
        bpy.context.view_layer.objects.active = arm
        bpy.ops.object.mode_set(mode="EDIT")

        eb = arm.data.edit_bones.get(pb.name) or arm.data.edit_bones.get(getattr(si, "bone_name", ""))
        if not eb:
            bpy.ops.object.mode_set(mode="OBJECT")
            return False, f"Could not find linked bone for siren {getattr(si, 'index', '?')}"

        current_vec = (eb.tail - eb.head)
        length = current_vec.length
        if length < 0.000001:
            length = 0.05
        if preserve_direction and current_vec.length >= 0.000001:
            direction_vec = current_vec.normalized()
        else:
            ang = dir_val(si)
            direction_vec = Vector((math.sin(ang), math.cos(ang), 0.0))
            if direction_vec.length < 0.000001:
                direction_vec = Vector((0.0, 1.0, 0.0))
            direction_vec.normalize()

        head = arm.matrix_world.inverted() @ point_world
        eb.head = head
        eb.tail = head + (direction_vec * length)

        bpy.ops.object.mode_set(mode="OBJECT")
        pose_bone = arm.pose.bones.get(eb.name)
        if pose_bone:
            _store_rest_pose_bone(arm, pose_bone, force=True)
        try:
            bpy.context.view_layer.update()
        except Exception:
            pass
        return True, f"Moved bone {eb.name} to the selected object origin"
    except Exception as ex:
        return False, f"Could not move the linked bone: {ex}"
    finally:
        try:
            if old_active and old_active.name in bpy.data.objects:
                bpy.context.view_layer.objects.active = old_active
        except Exception:
            pass
        try:
            if old_mode != "OBJECT" and getattr(bpy.context, "mode", "OBJECT") == "OBJECT":
                bpy.ops.object.mode_set(mode=old_mode)
        except Exception:
            pass


def linked_bone_target(scene, obj, s=None):
    if not obj:
        return None, None, ""

    armature_obj, linked_bone_name = linked_bone_for_object(scene, s, obj)
    if armature_obj and linked_bone_name:
        try:
            pose_bones = getattr(getattr(armature_obj, "pose", None), "bones", None)
            pb = pose_bones.get(linked_bone_name) if hasattr(pose_bones, "get") else None
        except Exception:
            pb = None
        if pb:
            return armature_obj, pb, ""

    try:
        if obj.parent and obj.parent.type == "ARMATURE" and obj.parent_type == "BONE" and obj.parent_bone:
            arm = obj.parent
            pb = getattr(getattr(arm, "pose", None), "bones", {}).get(obj.parent_bone) if hasattr(getattr(arm, "pose", None), "bones") else None
            if pb:
                return arm, pb, ""
    except Exception:
        pass

    si_index = infer_siren_index_from_hierarchy(obj, fallback=infer_siren_index_from_object(obj, s=s))
    if si_index and scene and s:
        try:
            si = siren_slot_by_index(s, int(si_index))
            if si:
                arm, pb = siren_pose_bone(scene, si)
                if arm and pb:
                    return arm, pb, ""
        except Exception:
            pass

    try:
        if scene and s and getattr(s, "body_openings", None):
            obj_name = str(getattr(obj, "name", "") or "")
            for opening in s.body_openings:
                linked_name = str(getattr(opening, "object_name", "") or "")
                key_name = str(getattr(opening, "key", "") or "")
                if linked_name and linked_name == obj_name:
                    arm, pb = body_opening_pose_bone(scene, opening)
                    if arm and pb:
                        return arm, pb, ""
                elif key_name and _body_opening_name_matches(obj_name, key_name):
                    arm, pb = body_opening_pose_bone(scene, opening)
                    if arm and pb:
                        if not linked_name:
                            opening.object_name = obj_name
                        return arm, pb, ""
    except Exception:
        pass

    return None, None, f"No linked bone was found for {getattr(obj, 'name', 'the selected object')}. Link a bone first in Object/Bone Linking."


def move_linked_bone_to_world_point(scene, obj, world_point, s=None, preserve_direction=True):
    arm, pb, msg = linked_bone_target(scene, obj, s=s)
    if not arm or not pb:
        return False, msg or f"No linked bone was found for {getattr(obj, 'name', 'the selected object')}. Link a bone first in Object/Bone Linking."

    try:
        point_world = Vector(world_point)
    except Exception:
        return False, "Could not read the selected object origin"

    old_active = getattr(bpy.context.view_layer.objects, "active", None)
    old_mode = getattr(bpy.context, "mode", "OBJECT")

    try:
        if old_mode != "OBJECT":
            bpy.ops.object.mode_set(mode="OBJECT")
        bpy.ops.object.select_all(action="DESELECT")
        arm.select_set(True)
        bpy.context.view_layer.objects.active = arm
        bpy.ops.object.mode_set(mode="EDIT")

        eb = arm.data.edit_bones.get(pb.name)
        if not eb:
            bpy.ops.object.mode_set(mode="OBJECT")
            return False, f"Could not find linked bone for {getattr(obj, 'name', 'the selected object')}"

        current_vec = (eb.tail - eb.head)
        length = current_vec.length
        if length < 0.000001:
            length = 0.05
        if preserve_direction and current_vec.length >= 0.000001:
            direction_vec = current_vec.normalized()
        else:
            direction_vec = Vector((0.0, 1.0, 0.0))

        head = arm.matrix_world.inverted() @ point_world
        eb.head = head
        eb.tail = head + (direction_vec * length)

        bpy.ops.object.mode_set(mode="OBJECT")
        pose_bone = arm.pose.bones.get(eb.name)
        if pose_bone:
            _store_rest_pose_bone(arm, pose_bone, force=True)
        try:
            bpy.context.view_layer.update()
        except Exception:
            pass
        return True, f"Moved bone {eb.name} to {getattr(obj, 'name', 'the selected object')} origin"
    except Exception as ex:
        return False, f"Could not move the linked bone: {ex}"
    finally:
        try:
            if old_active and old_active.name in bpy.data.objects:
                bpy.context.view_layer.objects.active = old_active
        except Exception:
            pass
        try:
            if old_mode != "OBJECT" and getattr(bpy.context, "mode", "OBJECT") == "OBJECT":
                bpy.ops.object.mode_set(mode=old_mode)
        except Exception:
            pass


def linked_bone_world_location(scene, obj, s=None):
    arm, pb, msg = linked_bone_target(scene, obj, s=s)
    if arm and pb:
        return arm.matrix_world @ Vector(pb.head), ""
    return None, msg or f"No linked bone was found for {getattr(obj, 'name', 'the selected object')}. Link a bone first in Object/Bone Linking."


def body_opening_icon_key(key):
    text = str(key or "").strip().lower()
    if text.startswith("bonnet"):
        return "bonnet"
    if text.startswith("boot"):
        return "boot"
    if text.startswith("door_") or text.startswith("door"):
        return "door"
    return "body_openings"


def body_opening_display_name(key):
    lookup = {k: label for k, label, _opening_type in DEFAULT_BODY_OPENINGS}
    text = str(key or "").strip()
    if text in lookup:
        return lookup[text]
    if not text:
        return "Body Opening"
    return text.replace("_", " ").title()


def body_opening_supports_rotation(opening):
    return str(getattr(opening, "opening_type", "HINGED") or "HINGED") in {"HINGED", "HINGED_SLIDING"}


def body_opening_supports_translation(opening):
    return str(getattr(opening, "opening_type", "HINGED") or "HINGED") in {"SLIDING", "HINGED_SLIDING"}


BODY_OPENING_EXPORT_FLAG_AXIS_MAP = {
    "RotX": ("rot_x", 0),
    "RotY": ("rot_y", 1),
    "RotZ": ("rot_z", 2),
    "TransX": ("slide_x", 0),
    "TransY": ("slide_y", 1),
    "TransZ": ("slide_z", 2),
}

BODY_OPENING_ROTATION_FLAG_NAMES = ("RotX", "RotY", "RotZ")
BODY_OPENING_TRANSLATION_FLAG_NAMES = ("TransX", "TransY", "TransZ")
BODY_OPENING_LIMIT_ENDPOINT_ITEMS = [
    ("AUTO", "Auto", "Use the limit endpoint furthest from the current imported closed pose."),
    ("MIN", "Min", "Use the minimum limit endpoint."),
    ("MAX", "Max", "Use the maximum limit endpoint."),
]
BODY_OPENING_DERIVED_PREVIEW_SOURCE = "BONE_LIMIT"
_BODY_OPENING_SYNC_ACTIVE = False


def _body_opening_vectors_equal(vec_a, vec_b, eps=0.00001):
    try:
        return all(abs(float(a) - float(b)) <= eps for a, b in zip(vec_a, vec_b))
    except Exception:
        return False


def _body_opening_store_vector(opening, attr_name, values):
    current = tuple(float(v) for v in getattr(opening, attr_name, (0.0, 0.0, 0.0)))
    target = tuple(float(v) for v in values)
    if _body_opening_vectors_equal(current, target):
        return False
    setattr(opening, attr_name, target)
    return True


def _body_opening_store_scalar(opening, attr_name, value):
    current = getattr(opening, attr_name, None)
    if current == value:
        return False
    setattr(opening, attr_name, value)
    return True


def _body_opening_sync_guard_set(active):
    global _BODY_OPENING_SYNC_ACTIVE
    previous = _BODY_OPENING_SYNC_ACTIVE
    _BODY_OPENING_SYNC_ACTIVE = bool(active)
    return previous


def body_opening_limit_endpoint_items(self, context):
    del self, context
    return BODY_OPENING_LIMIT_ENDPOINT_ITEMS


def body_opening_rotation_limit_constraint(pose_bone):
    if pose_bone is None:
        return None
    for constraint in getattr(pose_bone, "constraints", []) or []:
        if getattr(constraint, "type", "") == "LIMIT_ROTATION":
            return constraint
    return None


def body_opening_translation_limit_constraint(pose_bone):
    if pose_bone is None:
        return None
    for constraint in getattr(pose_bone, "constraints", []) or []:
        if getattr(constraint, "type", "") == "LIMIT_LOCATION":
            return constraint
    return None


def body_opening_bone_flag_names(pose_bone):
    names = set()
    bone = getattr(pose_bone, "bone", None)
    props = getattr(bone, "bone_properties", None) if bone else None
    flags = getattr(props, "flags", None) if props else None
    for item in flags or []:
        name = str(getattr(item, "name", "") or "").strip()
        if name:
            names.add(name)
    return names


def body_opening_mesh_uses_bone_deform(scene, opening):
    obj = body_opening_obj(opening)
    arm, pb = body_opening_pose_bone(scene, opening)
    if not obj or not arm or not pb:
        return False
    try:
        if obj.parent == arm and obj.parent_type == "BONE" and obj.parent_bone == pb.name:
            return True
    except Exception:
        pass
    try:
        if obj.vertex_groups.get(pb.name) is None:
            return False
    except Exception:
        return False
    for modifier in getattr(obj, "modifiers", []) or []:
        if getattr(modifier, "type", "") != "ARMATURE":
            continue
        if getattr(modifier, "object", None) == arm:
            return True
    return False


def body_opening_prefers_bone_controls(scene, opening):
    if body_opening_object_driven_by_bone(scene, opening):
        return True
    return body_opening_mesh_uses_bone_deform(scene, opening)


def body_opening_constraint_vectors(constraint):
    if constraint is None:
        return Vector((0.0, 0.0, 0.0)), Vector((0.0, 0.0, 0.0))
    return (
        Vector((float(getattr(constraint, "min_x", 0.0)), float(getattr(constraint, "min_y", 0.0)), float(getattr(constraint, "min_z", 0.0)))),
        Vector((float(getattr(constraint, "max_x", 0.0)), float(getattr(constraint, "max_y", 0.0)), float(getattr(constraint, "max_z", 0.0)))),
    )


def body_opening_open_endpoint_vector(min_vec, max_vec, current_vec, mode):
    min_vec = Vector(min_vec)
    max_vec = Vector(max_vec)
    current_vec = Vector(current_vec)
    endpoint_mode = str(mode or "AUTO").upper()
    if endpoint_mode == "MIN":
        return min_vec, "MIN"
    if endpoint_mode == "MAX":
        return max_vec, "MAX"

    min_distance = (min_vec - current_vec).length
    max_distance = (max_vec - current_vec).length
    if min_distance > max_distance + 0.00001:
        return min_vec, "MIN"
    if max_distance > min_distance + 0.00001:
        return max_vec, "MAX"

    if min_vec.length > max_vec.length + 0.00001:
        return min_vec, "MIN"
    return max_vec, "MAX"


def update_body_opening_preview_mapping(self, context):
    if _BODY_OPENING_SYNC_ACTIVE:
        return
    scene = getattr(context, "scene", None) if context else None
    if scene is None:
        return
    refresh_body_opening_preview_from_limits(scene, self, force=True)


def update_body_opening_export_settings(self, context):
    if _BODY_OPENING_SYNC_ACTIVE:
        return
    scene = getattr(context, "scene", None) if context else None
    if scene is None:
        return
    sync_body_opening_to_sollumz(scene, self, refresh_preview=True)


def update_body_opening_type(self, context):
    opening_type = str(getattr(self, "opening_type", "HINGED") or "HINGED")
    if opening_type in {"SLIDING", "HINGED_SLIDING"}:
        if not any(bool(getattr(self, attr, False)) for attr in ("slide_x", "slide_y", "slide_z")):
            self.slide_y = True
        self.limit_translation = True
    if opening_type in {"HINGED", "HINGED_SLIDING"}:
        if not any(bool(getattr(self, attr, False)) for attr in ("rot_x", "rot_y", "rot_z")):
            self.rot_z = True
        self.limit_rotation = True
    update_body_opening_export_settings(self, context)


def ensure_body_opening_defaults(s):
    if not s or not hasattr(s, "body_openings"):
        return
    existing = {str(getattr(op, "key", "") or "") for op in getattr(s, "body_openings", [])}
    for key, label, opening_type in DEFAULT_BODY_OPENINGS:
        if key in existing:
            continue
        op = s.body_openings.add()
        op.key = key
        op.name = label
        op.opening_type = opening_type
        op.rot_x = True
        op.rot_y = True
        op.rot_z = True
        op.slide_x = False
        op.slide_y = opening_type == "SLIDING"
        op.slide_z = False
        op.limit_rotation = True
        op.limit_translation = opening_type == "SLIDING"
        existing.add(key)
    if getattr(s, "body_openings", None):
        s.active_body_opening = min(max(0, int(getattr(s, "active_body_opening", 0) or 0)), len(s.body_openings) - 1)


def body_opening_by_key(s, key=""):
    if not s or not getattr(s, "body_openings", None):
        return None
    wanted = str(key or "").strip()
    if wanted:
        for op in s.body_openings:
            if str(getattr(op, "key", "") or "") == wanted:
                return op
    idx = min(max(0, int(getattr(s, "active_body_opening", 0) or 0)), len(s.body_openings) - 1)
    return s.body_openings[idx]


def active_body_opening(s):
    return body_opening_by_key(s, "")


def body_opening_from_context(scene, s, context):
    if not scene or not s or not getattr(s, "body_openings", None):
        return None

    active = getattr(context, "active_object", None)
    selected = [obj for obj in getattr(context, "selected_objects", []) or [] if obj]
    candidates = []
    if active:
        candidates.append(active)
    for obj in selected:
        if obj not in candidates:
            candidates.append(obj)

    for obj in candidates:
        obj_name = str(getattr(obj, "name", "") or "")
        for opening in getattr(s, "body_openings", []) or []:
            if str(getattr(opening, "object_name", "") or "") == obj_name:
                return opening
        for opening in getattr(s, "body_openings", []) or []:
            key = str(getattr(opening, "key", "") or "")
            if _body_opening_name_matches(obj_name, key):
                return opening

    return active_body_opening(s)


def _body_opening_name_matches(name, key):
    lhs = str(name or "").strip().lower()
    rhs = str(key or "").strip().lower()
    if not lhs or not rhs:
        return False
    return lhs == rhs or lhs.startswith(rhs + "_") or lhs.startswith(rhs + ".")


def find_body_opening_scene_object(scene, key):
    if not scene:
        return None
    exact = None
    fallback = None
    for obj in scene.objects:
        if getattr(obj, "type", "") != "MESH":
            continue
        name = str(getattr(obj, "name", "") or "")
        if name.lower() == str(key or "").lower():
            exact = obj
            break
        if fallback is None and _body_opening_name_matches(name, key):
            fallback = obj
    return exact or fallback


def find_body_opening_scene_bone(scene, settings, key):
    if not scene:
        return None, None
    candidates = []
    arm_name = str(getattr(settings, "armature_name", "") or "") if settings else ""
    if arm_name:
        arm = bpy.data.objects.get(arm_name)
        if arm and getattr(arm, "type", "") == "ARMATURE" and arm.name in scene.objects:
            candidates.append(arm)
    for obj in scene.objects:
        if getattr(obj, "type", "") == "ARMATURE" and obj not in candidates:
            candidates.append(obj)
    for arm in candidates:
        exact = arm.data.bones.get(str(key or ""))
        if exact:
            return arm, exact
        for bone in arm.data.bones:
            if _body_opening_name_matches(getattr(bone, "name", ""), key):
                return arm, bone
    return None, None


def _vector_has_motion(vec, eps=0.00001):
    try:
        return any(abs(float(v)) > eps for v in vec)
    except Exception:
        return False


def body_opening_state_has_values(opening, prefix):
    if not opening:
        return False
    source = str(getattr(opening, f"{prefix}_source", "") or "").strip()
    return bool(source) or _vector_has_motion(getattr(opening, f"{prefix}_location", (0.0, 0.0, 0.0))) or _vector_has_motion(getattr(opening, f"{prefix}_rotation", (0.0, 0.0, 0.0)))


def body_opening_state_configured(opening):
    if not opening:
        return False
    return body_opening_state_has_values(opening, "closed") or body_opening_state_has_values(opening, "open")


def body_opening_object_driven_by_bone(scene, opening):
    obj = body_opening_obj(opening)
    arm, pb = body_opening_pose_bone(scene, opening)
    if not obj or not arm or not pb:
        return False
    return bool(obj.parent == arm and obj.parent_type == "BONE" and obj.parent_bone == pb.name)


def read_body_opening_current_transform(scene, opening):
    obj = body_opening_obj(opening)
    arm, pb = body_opening_pose_bone(scene, opening)
    if pb and body_opening_prefers_bone_controls(scene, opening):
        pb.rotation_mode = "XYZ"
        return Vector(pb.location), Vector(pb.rotation_euler), "BONE"
    if obj and not body_opening_object_driven_by_bone(scene, opening):
        obj.rotation_mode = "XYZ"
        return Vector(obj.location), Vector(obj.rotation_euler), "MESH"
    if pb:
        pb.rotation_mode = "XYZ"
        return Vector(pb.location), Vector(pb.rotation_euler), "BONE"
    if obj:
        obj.rotation_mode = "XYZ"
        return Vector(obj.location), Vector(obj.rotation_euler), "MESH"
    return None, None, ""


def _body_opening_vectors_match(vec_a, vec_b, eps=0.00001):
    return _body_opening_vectors_equal(vec_a, vec_b, eps=eps)


def body_opening_reference_position(scene, opening):
    arm, pb = body_opening_pose_bone(scene, opening)
    if arm and pb:
        try:
            bone = arm.data.bones.get(pb.name)
            if bone is not None:
                return Vector(bone.head_local)
        except Exception:
            pass
        try:
            return Vector(pb.location)
        except Exception:
            pass
    obj = body_opening_obj(opening)
    if obj:
        return Vector(obj.location)
    return Vector((0.0, 0.0, 0.0))


def body_opening_bone_world_pivot(scene, opening):
    arm, pb = body_opening_pose_bone(scene, opening)
    if not arm or not pb:
        return None
    try:
        bone = arm.data.bones.get(pb.name)
        if bone is not None:
            return arm.matrix_world @ Vector(bone.head_local)
    except Exception:
        pass
    try:
        return arm.matrix_world @ Vector(pb.head)
    except Exception:
        return None


def migrate_body_opening_mesh_state_locations(opening, old_loc, new_loc):
    if not opening:
        return False
    changed = False
    old_loc = Vector(old_loc)
    new_loc = Vector(new_loc)
    for prefix in ("closed", "open"):
        source = str(getattr(opening, f"{prefix}_source", "") or "").upper()
        if source != "MESH":
            continue
        stored_loc = Vector(getattr(opening, f"{prefix}_location", (0.0, 0.0, 0.0)))
        if _body_opening_vectors_match(stored_loc, old_loc):
            setattr(opening, f"{prefix}_location", (float(new_loc[0]), float(new_loc[1]), float(new_loc[2])))
            changed = True
    return changed


def ensure_body_opening_mesh_origin_at_bone(scene, opening):
    obj = body_opening_obj(opening)
    if not obj or body_opening_object_driven_by_bone(scene, opening):
        return False, None, None, None, None

    pivot_world = body_opening_bone_world_pivot(scene, opening)
    if pivot_world is None:
        return False, None, None, None, None

    obj.rotation_mode = "XYZ"
    old_loc = Vector(obj.location)
    old_rot = Vector(obj.rotation_euler)
    try:
        if (obj.matrix_world.translation - Vector(pivot_world)).length <= 0.00001:
            return False, old_loc, old_rot, old_loc.copy(), old_rot.copy()
    except Exception:
        return False, old_loc, old_rot, old_loc.copy(), old_rot.copy()

    ok, _msg = set_object_origin_to_world_point(obj, pivot_world)
    if not ok:
        return False, old_loc, old_rot, old_loc.copy(), old_rot.copy()

    obj.rotation_mode = "XYZ"
    new_loc = Vector(obj.location)
    new_rot = Vector(obj.rotation_euler)
    migrate_body_opening_mesh_state_locations(opening, old_loc, new_loc)
    return True, old_loc, old_rot, new_loc, new_rot


def body_opening_apply_flag_membership(opening, pose_bone):
    bone = getattr(pose_bone, "bone", None)
    props = getattr(bone, "bone_properties", None) if bone else None
    flags = getattr(props, "flags", None) if props else None
    if flags is None:
        return False

    desired = []
    for flag_name in BODY_OPENING_ROTATION_FLAG_NAMES:
        prop_name, _axis_index = BODY_OPENING_EXPORT_FLAG_AXIS_MAP[flag_name]
        if bool(getattr(opening, prop_name, False)):
            desired.append(flag_name)
    for flag_name in BODY_OPENING_TRANSLATION_FLAG_NAMES:
        prop_name, _axis_index = BODY_OPENING_EXPORT_FLAG_AXIS_MAP[flag_name]
        if bool(getattr(opening, prop_name, False)):
            desired.append(flag_name)

    preserved = []
    changed = False
    for item in list(flags):
        name = str(getattr(item, "name", "") or "").strip()
        if not name:
            continue
        if name in BODY_OPENING_EXPORT_FLAG_AXIS_MAP:
            changed = True
            continue
        preserved.append(name)
    final = preserved + desired
    existing = [str(getattr(item, "name", "") or "").strip() for item in list(flags)]
    if existing == final:
        return False
    try:
        flags.clear()
    except Exception:
        while len(flags) > 0:
            flags.remove(len(flags) - 1)
    for name in final:
        entry = flags.add()
        entry.name = name
    return True


def body_opening_configure_limit_constraint(constraint, minimum, maximum):
    minimum = Vector(minimum)
    maximum = Vector(maximum)
    constraint.owner_space = "LOCAL"
    if getattr(constraint, "type", "") == "LIMIT_ROTATION":
        constraint.use_limit_x = True
        constraint.use_limit_y = True
        constraint.use_limit_z = True
    else:
        constraint.use_min_x = True
        constraint.use_min_y = True
        constraint.use_min_z = True
        constraint.use_max_x = True
        constraint.use_max_y = True
        constraint.use_max_z = True
    constraint.min_x = float(minimum[0])
    constraint.min_y = float(minimum[1])
    constraint.min_z = float(minimum[2])
    constraint.max_x = float(maximum[0])
    constraint.max_y = float(maximum[1])
    constraint.max_z = float(maximum[2])


def body_opening_ensure_constraint(pose_bone, constraint_type):
    finder = body_opening_rotation_limit_constraint if constraint_type == "LIMIT_ROTATION" else body_opening_translation_limit_constraint
    constraint = finder(pose_bone)
    if constraint is not None:
        return constraint
    return pose_bone.constraints.new(constraint_type)


def body_opening_remove_constraint(pose_bone, constraint_type):
    removed = False
    for constraint in list(getattr(pose_bone, "constraints", []) or []):
        if getattr(constraint, "type", "") != constraint_type:
            continue
        pose_bone.constraints.remove(constraint)
        removed = True
    return removed


def body_opening_refresh_type_from_channels(opening):
    has_rotation = any(bool(getattr(opening, attr, False)) for attr in ("rot_x", "rot_y", "rot_z"))
    has_translation = any(bool(getattr(opening, attr, False)) for attr in ("slide_x", "slide_y", "slide_z"))
    if has_rotation and has_translation:
        desired = "HINGED_SLIDING"
    elif has_translation:
        desired = "SLIDING"
    else:
        desired = "HINGED"
    return _body_opening_store_scalar(opening, "opening_type", desired)


def refresh_body_opening_preview_from_limits(scene, opening, force=False):
    if not opening:
        return False
    arm, pb = body_opening_pose_bone(scene, opening)
    if not arm or not pb:
        return False

    current_loc, current_rot, _source = read_body_opening_current_transform(scene, opening)
    if current_loc is None or current_rot is None:
        current_loc = Vector((0.0, 0.0, 0.0))
        current_rot = Vector((0.0, 0.0, 0.0))
    closed_basis_loc = Vector(getattr(opening, "closed_location", (0.0, 0.0, 0.0)))
    closed_basis_rot = Vector(getattr(opening, "closed_rotation", (0.0, 0.0, 0.0)))
    if not body_opening_state_has_values(opening, "closed"):
        closed_basis_loc = Vector(current_loc)
        closed_basis_rot = Vector(current_rot)

    rot_min = Vector(getattr(opening, "rotation_limit_min", (0.0, 0.0, 0.0)))
    rot_max = Vector(getattr(opening, "rotation_limit_max", (0.0, 0.0, 0.0)))
    loc_min = Vector(getattr(opening, "translation_limit_min", (0.0, 0.0, 0.0)))
    loc_max = Vector(getattr(opening, "translation_limit_max", (0.0, 0.0, 0.0)))

    closed_source = str(getattr(opening, "closed_source", "") or "").strip().upper()
    open_source = str(getattr(opening, "open_source", "") or "").strip().upper()
    should_write_closed = force or closed_source in {"", BODY_OPENING_DERIVED_PREVIEW_SOURCE}
    should_write_open = force or open_source in {"", BODY_OPENING_DERIVED_PREVIEW_SOURCE}

    open_loc = Vector(current_loc)
    open_rot = Vector(current_rot)
    if bool(getattr(opening, "limit_translation", False)) and body_opening_supports_translation(opening):
        chosen_loc, _mode = body_opening_open_endpoint_vector(
            loc_min,
            loc_max,
            closed_basis_loc,
            getattr(opening, "translation_open_endpoint", "AUTO"),
        )
        open_loc = Vector(chosen_loc)
    if bool(getattr(opening, "limit_rotation", False)) and body_opening_supports_rotation(opening):
        chosen_rot, _mode = body_opening_open_endpoint_vector(
            rot_min,
            rot_max,
            closed_basis_rot,
            getattr(opening, "rotation_open_endpoint", "AUTO"),
        )
        open_rot = Vector(chosen_rot)

    changed = False
    previous = _body_opening_sync_guard_set(True)
    try:
        if should_write_closed:
            changed = _body_opening_store_vector(opening, "closed_location", closed_basis_loc) or changed
            changed = _body_opening_store_vector(opening, "closed_rotation", closed_basis_rot) or changed
            changed = _body_opening_store_scalar(opening, "closed_source", BODY_OPENING_DERIVED_PREVIEW_SOURCE) or changed
        if should_write_open:
            changed = _body_opening_store_vector(opening, "open_location", open_loc) or changed
            changed = _body_opening_store_vector(opening, "open_rotation", open_rot) or changed
            changed = _body_opening_store_scalar(opening, "open_source", BODY_OPENING_DERIVED_PREVIEW_SOURCE) or changed
    finally:
        _body_opening_sync_guard_set(previous)
    return changed


def body_opening_has_legacy_preview_seed(scene, opening):
    if not opening:
        return False
    open_source = str(getattr(opening, "open_source", "") or "").strip().upper()
    if open_source not in {"BONE", "MESH"}:
        return False

    closed_loc = Vector(getattr(opening, "closed_location", (0.0, 0.0, 0.0)))
    closed_rot = Vector(getattr(opening, "closed_rotation", (0.0, 0.0, 0.0)))
    stored_loc = Vector(getattr(opening, "open_location", (0.0, 0.0, 0.0)))
    stored_rot = Vector(getattr(opening, "open_rotation", (0.0, 0.0, 0.0)))

    if bool(getattr(opening, "limit_translation", False)) and body_opening_supports_translation(opening):
        loc_min = Vector(getattr(opening, "translation_limit_min", (0.0, 0.0, 0.0)))
        loc_max = Vector(getattr(opening, "translation_limit_max", (0.0, 0.0, 0.0)))
        derived_loc, _endpoint = body_opening_open_endpoint_vector(
            loc_min,
            loc_max,
            closed_loc,
            getattr(opening, "translation_open_endpoint", "AUTO"),
        )
        if _body_opening_vectors_match(stored_loc, derived_loc):
            return False

    if bool(getattr(opening, "limit_rotation", False)) and body_opening_supports_rotation(opening):
        rot_min = Vector(getattr(opening, "rotation_limit_min", (0.0, 0.0, 0.0)))
        rot_max = Vector(getattr(opening, "rotation_limit_max", (0.0, 0.0, 0.0)))
        derived_rot, _endpoint = body_opening_open_endpoint_vector(
            rot_min,
            rot_max,
            closed_rot,
            getattr(opening, "rotation_open_endpoint", "AUTO"),
        )
        if _body_opening_vectors_match(stored_rot, derived_rot):
            return False

    rot_delta_degrees = [abs(math.degrees(float(value))) for value in (stored_rot - closed_rot)]
    loc_delta_values = [abs(float(value)) for value in (stored_loc - closed_loc)]
    legacy_rotation_values = (55.0, 60.0, 70.0)
    legacy_translation_values = (0.2, 0.25, 0.35, 0.75)
    if any(any(abs(delta - legacy) <= 0.25 for legacy in legacy_rotation_values) for delta in rot_delta_degrees):
        return True
    if any(any(abs(delta - legacy) <= 0.02 for legacy in legacy_translation_values) for delta in loc_delta_values):
        return True
    return False


def sync_body_opening_from_sollumz(scene, opening, force_preview=False):
    arm, pb = body_opening_pose_bone(scene, opening)
    if not arm or not pb:
        return False

    rotation_constraint = body_opening_rotation_limit_constraint(pb)
    translation_constraint = body_opening_translation_limit_constraint(pb)
    flag_names = body_opening_bone_flag_names(pb)
    rotation_min, rotation_max = body_opening_constraint_vectors(rotation_constraint)
    translation_min, translation_max = body_opening_constraint_vectors(translation_constraint)

    changed = False
    previous = _body_opening_sync_guard_set(True)
    try:
        for flag_name, (prop_name, axis_index) in BODY_OPENING_EXPORT_FLAG_AXIS_MAP.items():
            explicit = flag_name in flag_names
            inferred = False
            if flag_name in BODY_OPENING_ROTATION_FLAG_NAMES and rotation_constraint is not None:
                inferred = abs(float(rotation_min[axis_index])) > 0.00001 or abs(float(rotation_max[axis_index])) > 0.00001
            if flag_name in BODY_OPENING_TRANSLATION_FLAG_NAMES and translation_constraint is not None:
                inferred = abs(float(translation_min[axis_index])) > 0.00001 or abs(float(translation_max[axis_index])) > 0.00001
            changed = _body_opening_store_scalar(opening, prop_name, bool(explicit or inferred)) or changed

        changed = _body_opening_store_scalar(opening, "limit_rotation", rotation_constraint is not None) or changed
        changed = _body_opening_store_scalar(opening, "limit_translation", translation_constraint is not None) or changed
        changed = _body_opening_store_vector(opening, "rotation_limit_min", rotation_min) or changed
        changed = _body_opening_store_vector(opening, "rotation_limit_max", rotation_max) or changed
        changed = _body_opening_store_vector(opening, "translation_limit_min", translation_min) or changed
        changed = _body_opening_store_vector(opening, "translation_limit_max", translation_max) or changed
        changed = body_opening_refresh_type_from_channels(opening) or changed
    finally:
        _body_opening_sync_guard_set(previous)

    preview_force = force_preview or not body_opening_state_configured(opening) or body_opening_has_legacy_preview_seed(scene, opening)
    if refresh_body_opening_preview_from_limits(scene, opening, force=preview_force):
        changed = True
    return changed


def sync_body_opening_to_sollumz(scene, opening, refresh_preview=True):
    arm, pb = body_opening_pose_bone(scene, opening)
    if not arm or not pb:
        return False

    changed = False
    if body_opening_apply_flag_membership(opening, pb):
        changed = True

    if body_opening_supports_rotation(opening) and bool(getattr(opening, "limit_rotation", False)):
        constraint = body_opening_ensure_constraint(pb, "LIMIT_ROTATION")
        body_opening_configure_limit_constraint(
            constraint,
            getattr(opening, "rotation_limit_min", (0.0, 0.0, 0.0)),
            getattr(opening, "rotation_limit_max", (0.0, 0.0, 0.0)),
        )
        changed = True
    else:
        changed = body_opening_remove_constraint(pb, "LIMIT_ROTATION") or changed

    if body_opening_supports_translation(opening) and bool(getattr(opening, "limit_translation", False)):
        constraint = body_opening_ensure_constraint(pb, "LIMIT_LOCATION")
        body_opening_configure_limit_constraint(
            constraint,
            getattr(opening, "translation_limit_min", (0.0, 0.0, 0.0)),
            getattr(opening, "translation_limit_max", (0.0, 0.0, 0.0)),
        )
        changed = True
    else:
        changed = body_opening_remove_constraint(pb, "LIMIT_LOCATION") or changed

    if refresh_preview:
        refresh_body_opening_preview_from_limits(scene, opening, force=True)
    return changed


def infer_body_opening_rotation_delta(scene, opening):
    key = str(getattr(opening, "key", "") or "").strip().lower()
    ref = body_opening_reference_position(scene, opening)

    def enabled(*names):
        for idx, name in names:
            if bool(getattr(opening, name, False)):
                return idx
        return None

    if "door" in key:
        axis = enabled((2, "rot_z"), (1, "rot_y"), (0, "rot_x"))
        if axis is None:
            return None, 0.0
        sign = 1.0 if float(ref.x) <= 0.0 else -1.0
        imported_angle_deg = abs(float(ref.x)) * 100.0
        if imported_angle_deg < 5.0:
            imported_angle_deg = 70.0
        imported_angle_deg = max(15.0, min(120.0, imported_angle_deg))
        return axis, math.radians(imported_angle_deg) * sign

    if "bonnet" in key or "boot" in key:
        axis = enabled((0, "rot_x"), (2, "rot_z"), (1, "rot_y"))
        if axis is None:
            return None, 0.0
        sign = 1.0 if float(ref.y) >= 0.0 else -1.0
        angle = 55.0 if "bonnet" in key else 70.0
        return axis, math.radians(angle) * sign

    axis = enabled((0, "rot_x"), (1, "rot_y"), (2, "rot_z"))
    if axis is None:
        return None, 0.0
    return axis, math.radians(60.0)


def infer_body_opening_translation_delta(scene, opening):
    key = str(getattr(opening, "key", "") or "").strip().lower()
    ref = body_opening_reference_position(scene, opening)

    def enabled(*names):
        for idx, name in names:
            if bool(getattr(opening, name, False)):
                return idx
        return None

    if "door" in key:
        axis = enabled((1, "slide_y"), (0, "slide_x"), (2, "slide_z"))
        if axis is None:
            return None, 0.0
        if axis == 1:
            return axis, -0.75
        if axis == 0:
            sign = 1.0 if float(ref.x) <= 0.0 else -1.0
            return axis, 0.35 * sign
        return axis, 0.2

    axis = enabled((1, "slide_y"), (0, "slide_x"), (2, "slide_z"))
    if axis is None:
        return None, 0.0
    if axis == 1:
        sign = 1.0 if float(ref.y) >= 0.0 else -1.0
        return axis, 0.35 * sign
    if axis == 0:
        sign = 1.0 if float(ref.x) <= 0.0 else -1.0
        return axis, 0.25 * sign
    return axis, 0.2


def infer_body_opening_open_transform(scene, opening, closed_loc, closed_rot):
    open_loc = Vector(closed_loc)
    open_rot = Vector(closed_rot)

    if body_opening_supports_rotation(opening):
        axis, delta = infer_body_opening_rotation_delta(scene, opening)
        if axis is not None and abs(float(delta)) > 0.0:
            open_rot[axis] += float(delta)

    if body_opening_supports_translation(opening):
        axis, delta = infer_body_opening_translation_delta(scene, opening)
        if axis is not None and abs(float(delta)) > 0.0:
            open_loc[axis] += float(delta)

    return open_loc, open_rot


def seed_body_opening_states_from_import(scene, opening):
    _armature, _pose_bone = body_opening_pose_bone(scene, opening)
    has_sollumz_limits = bool(
        _pose_bone and (
            body_opening_rotation_limit_constraint(_pose_bone) is not None
            or body_opening_translation_limit_constraint(_pose_bone) is not None
        )
    )
    if sync_body_opening_from_sollumz(scene, opening, force_preview=False):
        return True
    if has_sollumz_limits:
        return False

    loc, rot, source = read_body_opening_current_transform(scene, opening)
    if loc is None or rot is None:
        return False

    source = str(source or "").upper()
    current_loc = Vector(loc)
    current_rot = Vector(rot)
    aligned_origin = False
    if source == "MESH":
        aligned_origin, _old_loc, _old_rot, new_loc, new_rot = ensure_body_opening_mesh_origin_at_bone(scene, opening)
        if aligned_origin and new_loc is not None and new_rot is not None:
            current_loc = Vector(new_loc)
            current_rot = Vector(new_rot)
    have_closed = body_opening_state_has_values(opening, "closed")
    have_open = body_opening_state_has_values(opening, "open")
    changed = False

    stale_bone_seed = False
    if source == "MESH" and body_opening_obj(opening) is not None and not body_opening_object_driven_by_bone(scene, opening):
        closed_source = str(getattr(opening, "closed_source", "") or "").upper()
        open_source = str(getattr(opening, "open_source", "") or "").upper()
        stale_bone_seed = closed_source == "BONE" or open_source == "BONE"
        if stale_bone_seed:
            have_closed = False
            have_open = False

    if source == "BONE":
        closed_loc = Vector((0.0, 0.0, 0.0))
        closed_rot = Vector((0.0, 0.0, 0.0))
        if not have_closed:
            opening.closed_location = (0.0, 0.0, 0.0)
            opening.closed_rotation = (0.0, 0.0, 0.0)
            opening.closed_source = "BONE"
            changed = True

        if not have_open:
            if _vector_has_motion(current_loc) or _vector_has_motion(current_rot):
                open_loc = current_loc
                open_rot = current_rot
            else:
                open_loc, open_rot = infer_body_opening_open_transform(scene, opening, closed_loc, closed_rot)
            opening.open_location = (float(open_loc[0]), float(open_loc[1]), float(open_loc[2]))
            opening.open_rotation = (float(open_rot[0]), float(open_rot[1]), float(open_rot[2]))
            opening.open_source = "BONE"
            changed = True
        return changed

    closed_loc = current_loc
    closed_rot = current_rot
    if not have_closed:
        opening.closed_location = (float(closed_loc[0]), float(closed_loc[1]), float(closed_loc[2]))
        opening.closed_rotation = (float(closed_rot[0]), float(closed_rot[1]), float(closed_rot[2]))
        opening.closed_source = source or "MESH"
        changed = True

    rebuild_open = not have_open
    # Migrate the old generic 70-degree door seed to the imported-game angle inferred
    # from the linked bone translation when available.
    if not rebuild_open and source != "BONE" and "door" in str(getattr(opening, "key", "") or "").strip().lower():
        open_source = str(getattr(opening, "open_source", "") or "").upper()
        open_loc = Vector(getattr(opening, "open_location", (0.0, 0.0, 0.0)))
        open_rot = Vector(getattr(opening, "open_rotation", (0.0, 0.0, 0.0)))
        if open_source == (source or "MESH"):
            axis, inferred_delta = infer_body_opening_rotation_delta(scene, opening)
            if axis is not None:
                inferred_open = Vector(closed_rot)
                inferred_open[axis] += float(inferred_delta)
                current_deg = abs(math.degrees(float(open_rot[axis] - closed_rot[axis])))
                inferred_deg = abs(math.degrees(float(inferred_open[axis] - closed_rot[axis])))
                # Older builds stored the generic fallback of 70 degrees. If that exact
                # seed is present, rebuild it from the imported door translation.
                if abs(current_deg - 70.0) <= 0.01 and abs(inferred_deg - current_deg) > 1.0 and _body_opening_vectors_match(open_loc, current_loc):
                    rebuild_open = True
    if not have_closed and have_open:
        open_source = str(getattr(opening, "open_source", "") or "").upper()
        open_loc = getattr(opening, "open_location", (0.0, 0.0, 0.0))
        open_rot = getattr(opening, "open_rotation", (0.0, 0.0, 0.0))
        if open_source == (source or "MESH") and _body_opening_vectors_match(open_loc, current_loc) and _body_opening_vectors_match(open_rot, current_rot):
            rebuild_open = True

    if rebuild_open:
        open_loc, open_rot = infer_body_opening_open_transform(scene, opening, closed_loc, closed_rot)
        opening.open_location = (float(open_loc[0]), float(open_loc[1]), float(open_loc[2]))
        opening.open_rotation = (float(open_rot[0]), float(open_rot[1]), float(open_rot[2]))
        opening.open_source = source or "MESH"
        changed = True

    return changed


def auto_detect_body_opening_links(scene, settings):
    if not scene or not settings or not getattr(settings, "body_openings", None):
        return False

    changed = False
    scene_names = {obj.name for obj in scene.objects}
    armatures = [obj for obj in scene.objects if getattr(obj, "type", "") == "ARMATURE"]
    arm_name = str(getattr(settings, "armature_name", "") or "")
    if (not arm_name or arm_name not in scene_names) and len(armatures) == 1:
        settings.armature_name = armatures[0].name
        changed = True

    for opening in settings.body_openings:
        mesh_name = str(getattr(opening, "object_name", "") or "")
        mesh_obj = bpy.data.objects.get(mesh_name) if mesh_name else None
        if mesh_obj is None or mesh_obj.name not in scene_names:
            found_obj = find_body_opening_scene_object(scene, getattr(opening, "key", ""))
            if found_obj and mesh_name != found_obj.name:
                opening.object_name = found_obj.name
                changed = True

        arm, bone = body_opening_pose_bone(scene, opening)
        if bone is not None and not str(getattr(opening, "bone_name", "") or ""):
            opening.bone_name = bone.name
            changed = True
            if arm and (not getattr(settings, "armature_name", "") or getattr(settings, "armature_name", "") not in scene_names):
                settings.armature_name = arm.name
                changed = True
        elif bone is None:
            found_arm, found_bone = find_body_opening_scene_bone(scene, settings, getattr(opening, "key", ""))
            if found_bone is not None:
                if str(getattr(opening, "bone_name", "") or "") != found_bone.name:
                    opening.bone_name = found_bone.name
                    changed = True
                if found_arm and (not getattr(settings, "armature_name", "") or getattr(settings, "armature_name", "") not in scene_names):
                    settings.armature_name = found_arm.name
                    changed = True

        if seed_body_opening_states_from_import(scene, opening):
            changed = True
    return changed


def draw_body_opening_controls(layout, context, s, opening):
    if not opening:
        layout.label(text="No body opening available")
        return

    icon_name = "CON_ROTLIKE" if getattr(opening, "opening_type", "HINGED") == "HINGED" else "EMPTY_ARROWS"
    header = layout.row(align=True)
    header.prop(opening, "expanded", text="", emboss=False, icon="TRIA_DOWN" if opening.expanded else "TRIA_RIGHT")
    header.label(text=str(getattr(opening, "name", "Body Opening") or "Body Opening"), **panel_icon_draw_kwargs(body_opening_icon_key(getattr(opening, "key", "")), context, fallback_icon=icon_name))
    summary = []
    obj_name = str(getattr(opening, "object_name", "") or "")
    bone_name = str(getattr(opening, "bone_name", "") or "")
    if obj_name:
        summary.append(obj_name)
    elif bone_name:
        summary.append(bone_name)
    if summary:
        header.label(text=" | ".join(summary))
    if not getattr(opening, "expanded", False):
        return

    link_box = layout.box()
    link_box.label(text="Object/Bone Linking")
    link_box.prop_search(s, "armature_name", context.scene, "objects", text="Parent Skeleton")
    op = link_box.operator("nels.body_opening_link", text="Assign Selected Mesh", icon="OUTLINER_OB_MESH")
    if op is not None:
        op.action = "MARK"
        op.opening_key = opening.key
    op = link_box.operator("nels.body_opening_link", text="Match Origin to Object", icon="OBJECT_ORIGIN")
    if op is not None:
        op.action = "ORIGIN"
        op.opening_key = opening.key
    op = link_box.operator("nels.body_opening_link", text="Place Bone at Selected Origin", icon="BONE_DATA")
    if op is not None:
        op.action = "BONE"
        op.opening_key = opening.key
    op = link_box.operator("nels.repair_body_opening_origins", text="Move Object & Origin to Bone", icon="OBJECT_ORIGIN")
    if op is not None:
        op.scope = "ACTIVE"
        op.opening_key = opening.key

    mesh_row = link_box.row(align=True)
    mesh_row.prop_search(opening, "object_name", context.scene, "objects", text="Mesh")
    op = mesh_row.operator("nels.pick_selected_link_target", text="", icon="EYEDROPPER")
    if op is not None:
        op.target = "BODY_MESH"
        op.opening_key = opening.key

    arm = bpy.data.objects.get(getattr(s, "armature_name", "")) if getattr(s, "armature_name", "") else None
    bone_row = link_box.row(align=True)
    if arm and getattr(arm, "type", "") == "ARMATURE":
        bone_row.prop_search(opening, "bone_name", arm.data, "bones", text="Bone")
    else:
        bone_field = bone_row.row(align=True)
        bone_field.enabled = False
        bone_field.prop(opening, "bone_name", text="Bone")
    op = bone_row.operator("nels.pick_selected_link_target", text="", icon="EYEDROPPER")
    if op is not None:
        op.target = "BODY_BONE"
        op.opening_key = opening.key

    link_box.label(text="Mesh and bone links auto-detect from the current scene", icon="INFO")
    if not arm or getattr(arm, "type", "") != "ARMATURE":
        link_box.label(text="Select a Parent Skeleton to search scene bones", icon="INFO")
    link_box.label(text="Placed bones always point to vehicle front (Y+)", icon="INFO")

    motion = layout.box()
    motion.label(text="Export Motion", icon="MOD_ARMATURE")
    motion.prop(opening, "opening_type", text="Type")
    draw_wrapped_text(motion, context, "These values are the GTA / Sollumz export settings. Editing them updates the linked bone flags and local motion limits used for export.", icon="INFO")
    if body_opening_supports_rotation(opening):
        rot_box = motion.box() if body_opening_supports_translation(opening) else motion
        rot_box.label(text="Rotation Axes")
        rr = rot_box.row(align=True)
        rr.prop(opening, "rot_x", text="X", toggle=True)
        rr.prop(opening, "rot_y", text="Y", toggle=True)
        rr.prop(opening, "rot_z", text="Z", toggle=True)
        rot_box.prop(opening, "limit_rotation")
        if bool(getattr(opening, "limit_rotation", False)):
            rot_limits = rot_box.box()
            rot_limits.label(text="Rotation Limits")
            rot_limits.prop(opening, "rotation_limit_min", text="Min")
            rot_limits.prop(opening, "rotation_limit_max", text="Max")
            rot_limits.prop(opening, "rotation_open_endpoint", text="Open Uses")
    if body_opening_supports_translation(opening):
        slide_box = motion.box() if body_opening_supports_rotation(opening) else motion
        slide_box.label(text="Movement Axes")
        sr = slide_box.row(align=True)
        sr.prop(opening, "slide_x", text="X", toggle=True)
        sr.prop(opening, "slide_y", text="Y", toggle=True)
        sr.prop(opening, "slide_z", text="Z", toggle=True)
        slide_box.prop(opening, "limit_translation")
        if bool(getattr(opening, "limit_translation", False)):
            slide_limits = slide_box.box()
            slide_limits.label(text="Translation Limits")
            slide_limits.prop(opening, "translation_limit_min", text="Min")
            slide_limits.prop(opening, "translation_limit_max", text="Max")
            slide_limits.prop(opening, "translation_open_endpoint", text="Open Uses")

    state_box = layout.box()
    state_box.label(text="Preview", icon="HIDE_OFF")
    state_box.label(text="Preview uses the export motion above. If the imported file had valid limits, those are now the default preview values.", icon="INFO")
    apply_row = state_box.row(align=True)
    op = apply_row.operator("nels.body_opening_state", text="Preview Closed", icon="LOOP_BACK")
    if op is not None:
        op.action = "APPLY_CLOSED"
        op.opening_key = opening.key
    op = apply_row.operator("nels.body_opening_state", text="Preview Open", icon="PLAY")
    if op is not None:
        op.action = "APPLY_OPEN"
        op.opening_key = opening.key

    closed_loc = Vector(getattr(opening, "closed_location", (0.0, 0.0, 0.0)))
    open_loc = Vector(getattr(opening, "open_location", (0.0, 0.0, 0.0)))
    closed_rot = Vector(getattr(opening, "closed_rotation", (0.0, 0.0, 0.0)))
    open_rot = Vector(getattr(opening, "open_rotation", (0.0, 0.0, 0.0)))
    slide_delta = open_loc - closed_loc
    rot_delta = open_rot - closed_rot

    preview_values = state_box.box()
    preview_values.label(text="Derived Preview Values")

    def draw_axis_group(box, title, prop_name, enabled=True):
        grp = box.box()
        grp.label(text=title)
        grp.enabled = enabled
        for axis, idx in (("X", 0), ("Y", 1), ("Z", 2)):
            grp.prop(opening, prop_name, index=idx, text=axis, slider=True)
        return grp

    if body_opening_supports_translation(opening):
        draw_axis_group(preview_values, "Closed Position", "closed_location", enabled=False)
        draw_axis_group(preview_values, "Open Position", "open_location", enabled=False)
        preview_values.label(text=f"Position Delta: X {slide_delta[0]:.4f}  Y {slide_delta[1]:.4f}  Z {slide_delta[2]:.4f}")

    if body_opening_supports_rotation(opening):
        draw_axis_group(preview_values, "Closed Rotation", "closed_rotation", enabled=False)
        draw_axis_group(preview_values, "Open Rotation", "open_rotation", enabled=False)
        preview_values.label(text=f"Rotation Delta: X {rot_delta[0]:.4f}  Y {rot_delta[1]:.4f}  Z {rot_delta[2]:.4f}")

    manual_box = state_box.box()
    manual_box.label(text="Manual Preview Override")
    manual_box.label(text="These tools only change the Blender preview state. They do not change the exported GTA motion unless you edit the export limits above.", icon="INFO")
    capture_row = manual_box.row(align=True)
    op = capture_row.operator("nels.body_opening_state", text="Set Closed Position", icon="IMPORT")
    if op is not None:
        op.action = "CAPTURE_CLOSED"
        op.opening_key = opening.key
    op = capture_row.operator("nels.body_opening_state", text="Set Open Position", icon="EXPORT")
    if op is not None:
        op.action = "CAPTURE_OPEN"
        op.opening_key = opening.key


def body_opening_obj(opening):
    if not opening:
        return None
    name = str(getattr(opening, "object_name", "") or "")
    return bpy.data.objects.get(name) if name else None


def body_opening_pose_bone(scene, opening):
    if not scene or not opening:
        return None, None
    s = getattr(scene, "nels", None)
    bone_name = str(getattr(opening, "bone_name", "") or getattr(opening, "key", "") or "")
    if not bone_name:
        return None, None

    candidates = []
    arm_name = str(getattr(s, "armature_name", "") or "") if s else ""
    if arm_name:
        arm = bpy.data.objects.get(arm_name)
        if arm and getattr(arm, "type", "") == "ARMATURE":
            candidates.append(arm)
    if scene:
        for obj in scene.objects:
            if getattr(obj, "type", "") == "ARMATURE" and obj not in candidates:
                candidates.append(obj)

    for arm in candidates:
        try:
            pb = getattr(getattr(arm, "pose", None), "bones", {}).get(bone_name) if hasattr(getattr(arm, "pose", None), "bones") else None
            if pb:
                return arm, pb
        except Exception:
            continue
    return None, None


def pick_body_opening_reference(context, opening):
    opening_obj = body_opening_obj(opening)
    selected = [obj for obj in getattr(context, "selected_objects", []) if obj and getattr(obj, "type", "") != "ARMATURE"]
    if opening_obj:
        selected = [obj for obj in selected if obj != opening_obj]
    active = getattr(getattr(context, "view_layer", None), "objects", None)
    active = getattr(active, "active", None)
    if active and active in selected:
        return active
    if selected:
        return selected[0]
    if active and getattr(active, "type", "") != "ARMATURE" and active != opening_obj:
        return active
    return None


def body_opening_capture_target(scene, opening):
    ctx = bpy.context
    arm, pb = body_opening_pose_bone(scene, opening)
    obj = body_opening_obj(opening)
    active_obj = getattr(getattr(getattr(ctx, "view_layer", None), "objects", None), "active", None)
    active_pose_bone = getattr(ctx, "active_pose_bone", None)
    mode = str(getattr(ctx, "mode", "") or "")

    if arm and pb and mode == "POSE" and active_obj == arm and active_pose_bone and getattr(active_pose_bone, "name", "") == pb.name:
        return "BONE", pb
    if obj and active_obj == obj:
        return "MESH", obj
    if obj:
        return "MESH", obj
    if pb:
        return "BONE", pb
    return "", None


def capture_body_opening_state(scene, opening, state):
    prefix = "closed" if str(state or "CLOSED").upper() == "CLOSED" else "open"
    source, target = body_opening_capture_target(scene, opening)

    if source == "BONE" and target is not None:
        target.rotation_mode = "XYZ"
        setattr(opening, f"{prefix}_location", (float(target.location[0]), float(target.location[1]), float(target.location[2])))
        setattr(opening, f"{prefix}_rotation", (float(target.rotation_euler[0]), float(target.rotation_euler[1]), float(target.rotation_euler[2])))
        setattr(opening, f"{prefix}_source", "BONE")
        return True, f"Captured {prefix} state from bone {target.name}"

    if source == "MESH" and target is not None:
        ensure_body_opening_mesh_origin_at_bone(scene, opening)
        target.rotation_mode = "XYZ"
        setattr(opening, f"{prefix}_location", (float(target.location[0]), float(target.location[1]), float(target.location[2])))
        setattr(opening, f"{prefix}_rotation", (float(target.rotation_euler[0]), float(target.rotation_euler[1]), float(target.rotation_euler[2])))
        setattr(opening, f"{prefix}_source", "MESH")
        return True, f"Captured {prefix} state from mesh {target.name}"

    return False, f"Assign a mesh or place bone {getattr(opening, 'key', 'opening')} first"


def apply_body_opening_state(scene, opening, state):
    prefix = "closed" if str(state or "CLOSED").upper() == "CLOSED" else "open"
    loc = Vector(getattr(opening, f"{prefix}_location", (0.0, 0.0, 0.0)))
    rot = Vector(getattr(opening, f"{prefix}_rotation", (0.0, 0.0, 0.0)))
    source = str(getattr(opening, f"{prefix}_source", "") or "").upper()

    obj = body_opening_obj(opening)
    arm, pb = body_opening_pose_bone(scene, opening)

    if source == "MESH" and obj:
        aligned_origin, _old_loc, _old_rot, _new_loc, _new_rot = ensure_body_opening_mesh_origin_at_bone(scene, opening)
        if aligned_origin:
            loc = Vector(getattr(opening, f"{prefix}_location", (0.0, 0.0, 0.0)))
            rot = Vector(getattr(opening, f"{prefix}_rotation", (0.0, 0.0, 0.0)))
        obj.rotation_mode = "XYZ"
        obj.location = loc
        obj.rotation_euler = rot
        if pb and not body_opening_object_driven_by_bone(scene, opening):
            pb.rotation_mode = "XYZ"
            pb.location = Vector((0.0, 0.0, 0.0))
            pb.rotation_euler = Vector((0.0, 0.0, 0.0))
        try:
            bpy.context.view_layer.update()
        except Exception:
            pass
        return True, f"Applied {prefix} state to mesh {obj.name}"

    if source in {"BONE", BODY_OPENING_DERIVED_PREVIEW_SOURCE} and pb:
        pb.rotation_mode = "XYZ"
        pb.location = loc
        pb.rotation_euler = rot
        try:
            bpy.context.view_layer.update()
        except Exception:
            pass
        return True, f"Applied {prefix} state to bone {pb.name}"

    if obj:
        obj.rotation_mode = "XYZ"
        obj.location = loc
        obj.rotation_euler = rot
        try:
            bpy.context.view_layer.update()
        except Exception:
            pass
        return True, f"Applied {prefix} state to mesh {obj.name}"

    if pb:
        pb.rotation_mode = "XYZ"
        pb.location = loc
        pb.rotation_euler = rot
        try:
            bpy.context.view_layer.update()
        except Exception:
            pass
        return True, f"Applied {prefix} state to bone {pb.name}"

    return False, f"Assign a mesh or place bone {getattr(opening, 'key', 'opening')} first"


def infer_siren_index_from_object(obj, s=None):
    seen = set()
    cur = obj
    while cur and cur not in seen:
        seen.add(cur)
        idx = siren_index_from_name(getattr(cur, "name", ""))
        if idx:
            return idx
        idx = siren_index_from_name(getattr(cur, "parent_bone", ""))
        if idx:
            return idx
        if s:
            for si in getattr(s, "sirens", []):
                if getattr(si, "object_name", "") == getattr(cur, "name", ""):
                    return int(getattr(si, "index", 0) or 0)
        cur = getattr(cur, "parent", None)
    return 0


def retarget_siren_name_token(value, old_index, new_index, extra_name_map=None):
    text = str(value or "")
    if extra_name_map:
        for old_name, new_name in sorted(extra_name_map.items(), key=lambda item: len(str(item[0])), reverse=True):
            old_name = str(old_name or "")
            new_name = str(new_name or "")
            if old_name:
                text = text.replace(old_name, new_name)

    patterns = (
        (r'(?i)siren\s*0*%d(?=[^0-9]|$)' % int(old_index), f"siren{int(new_index)}"),
        (r'(?i)misc_rotator_?\s*0*%d(?=[^0-9]|$)' % int(old_index), lambda m: ("misc_rotator_" if m.group(0).lower().startswith("misc_rotator_") else "misc_rotator") + str(int(new_index))),
    )
    for pattern, repl in patterns:
        text = re.sub(pattern, repl, text)
    return text


def _localize_object_data(obj):
    if not obj:
        return
    data = getattr(obj, "data", None)
    try:
        if data is not None and getattr(data, "users", 1) > 1:
            obj.data = data.copy()
    except Exception:
        pass
    try:
        obj.animation_data_clear()
    except Exception:
        pass


def _retarget_vertex_groups(obj, old_index, new_index, extra_name_map=None):
    for vg in getattr(obj, "vertex_groups", []):
        new_name = retarget_siren_name_token(vg.name, old_index, new_index, extra_name_map=extra_name_map)
        if new_name != vg.name:
            vg.name = new_name


def _retarget_modifier_settings(obj, old_index, new_index, extra_name_map=None):
    for mod in getattr(obj, "modifiers", []):
        try:
            if hasattr(mod, "vertex_group"):
                value = str(getattr(mod, "vertex_group", "") or "")
                new_value = retarget_siren_name_token(value, old_index, new_index, extra_name_map=extra_name_map)
                if new_value != value:
                    setattr(mod, "vertex_group", new_value)
        except Exception:
            pass


def _retarget_id_properties(container, old_index, new_index, extra_name_map=None):
    if not hasattr(container, "keys"):
        return
    try:
        for key in list(container.keys()):
            try:
                value = container[key]
            except Exception:
                continue
            if isinstance(value, str):
                new_value = retarget_siren_name_token(value, old_index, new_index, extra_name_map=extra_name_map)
                if new_value != value:
                    container[key] = new_value
    except Exception:
        pass


def _retarget_pointer_properties(container, old_index, new_index, object_map=None, extra_name_map=None, depth=0, seen=None):
    if container is None or depth > 4:
        return
    if seen is None:
        seen = set()
    marker = id(container)
    if marker in seen:
        return
    seen.add(marker)

    _retarget_id_properties(container, old_index, new_index, extra_name_map=extra_name_map)
    bl_rna = getattr(container, "bl_rna", None)
    if bl_rna is None:
        return

    skip = {
        "rna_type", "name", "data", "parent", "users_collection", "modifiers", "constraints",
        "material_slots", "particle_systems", "vertex_groups", "pose", "children", "matrix_world",
        "matrix_local", "matrix_parent_inverse",
    }
    for prop in bl_rna.properties:
        ident = getattr(prop, "identifier", "")
        if not ident or ident in skip or getattr(prop, "is_readonly", False):
            continue
        try:
            value = getattr(container, ident)
        except Exception:
            continue

        ptype = getattr(prop, "type", "")
        if ptype == 'STRING' and isinstance(value, str):
            new_value = retarget_siren_name_token(value, old_index, new_index, extra_name_map=extra_name_map)
            if new_value != value:
                try:
                    setattr(container, ident, new_value)
                except Exception:
                    pass
        elif ptype == 'POINTER':
            if object_map and isinstance(value, bpy.types.Object) and value in object_map:
                try:
                    setattr(container, ident, object_map[value])
                except Exception:
                    pass
            elif value is not None and hasattr(value, 'bl_rna') and not isinstance(value, bpy.types.ID):
                _retarget_pointer_properties(value, old_index, new_index, object_map=object_map, extra_name_map=extra_name_map, depth=depth + 1, seen=seen)
        elif ptype == 'COLLECTION':
            try:
                for item in value:
                    if item is not None and hasattr(item, 'bl_rna'):
                        _retarget_pointer_properties(item, old_index, new_index, object_map=object_map, extra_name_map=extra_name_map, depth=depth + 1, seen=seen)
            except Exception:
                pass


def retarget_siren_hierarchy(root, old_index, new_index, object_map=None, detach_root=False, force_root_name=True):
    if not root or old_index <= 0 or new_index <= 0:
        return []

    hierarchy = [root] + iter_siren_object_hierarchy(root)
    if object_map is None:
        object_map = {obj: obj for obj in hierarchy}

    name_map = {}
    desired_names = {}
    for obj in hierarchy:
        desired = retarget_siren_name_token(obj.name, old_index, new_index)
        desired = re.sub(r'\.\d{3}$', '', desired)
        if force_root_name and obj == root:
            desired = f"siren{int(new_index)}"
        desired_names[obj] = desired
        name_map[obj.name] = desired

    for obj in hierarchy:
        _localize_object_data(obj)

    for obj in hierarchy:
        desired = desired_names.get(obj, obj.name)
        if desired and obj.name != desired:
            obj.name = desired
        data = getattr(obj, 'data', None)
        if data is not None and hasattr(data, 'name'):
            try:
                data.name = retarget_siren_name_token(data.name, old_index, new_index, extra_name_map=name_map)
            except Exception:
                pass
        if getattr(obj, 'parent_type', '') == 'BONE':
            try:
                obj.parent_bone = retarget_siren_name_token(obj.parent_bone, old_index, new_index, extra_name_map=name_map)
            except Exception:
                pass
        _retarget_vertex_groups(obj, old_index, new_index, extra_name_map=name_map)
        _retarget_modifier_settings(obj, old_index, new_index, extra_name_map=name_map)
        _retarget_pointer_properties(obj, old_index, new_index, object_map=object_map, extra_name_map=name_map)
        data = getattr(obj, 'data', None)
        if data is not None and hasattr(data, 'bl_rna'):
            _retarget_pointer_properties(data, old_index, new_index, object_map=object_map, extra_name_map=name_map)
        _store_rest_loc(obj, force=True)

    if detach_root:
        try:
            world = root.matrix_world.copy()
            root.parent = None
            root.parent_type = 'OBJECT'
            root.parent_bone = ''
            root.matrix_parent_inverse = Matrix.Identity(4)
            root.matrix_world = world
            _store_rest_loc(root, force=True)
        except Exception:
            pass
    return hierarchy


def infer_siren_index_from_hierarchy(root, fallback=0):
    counts = {}
    for obj in [root] + iter_siren_object_hierarchy(root):
        for candidate in (
            infer_siren_index_from_object(obj),
            siren_index_from_name(getattr(obj, "name", "")),
            siren_index_from_name(getattr(obj, "parent_bone", "")),
        ):
            if candidate > 0:
                counts[candidate] = counts.get(candidate, 0) + 1
        for vg in getattr(obj, "vertex_groups", []):
            candidate = siren_index_from_name(getattr(vg, "name", ""))
            if candidate > 0:
                counts[candidate] = counts.get(candidate, 0) + 1
    if counts:
        return max(sorted(counts), key=lambda key: counts[key])
    return int(fallback or 0)


def suggest_duplicate_target_index(s, source_index):
    source_index = int(source_index or 0)
    used = {int(getattr(si, 'index', 0) or 0) for si in getattr(s, 'sirens', []) if getattr(si, 'object_name', '') or getattr(si, 'bone_name', '')}
    for idx in range(1, MAX_SIRENS + 1):
        if idx != source_index and idx not in used:
            return idx
    return max(1, min(MAX_SIRENS, source_index + 1 if source_index < MAX_SIRENS else MAX_SIRENS))


def duplicate_siren_hierarchy(scene, source_obj, old_index, new_index, extra_sources=None):
    if not scene or not source_obj:
        return None, []

    hierarchy_children = iter_siren_object_hierarchy(source_obj)
    extra_sources = [obj for obj in (extra_sources or []) if obj and obj not in {source_obj} and obj not in hierarchy_children]
    extra_source_set = set(extra_sources)
    sources = [source_obj] + hierarchy_children + extra_sources
    object_map = {}
    for src in sources:
        dup = src.copy()
        data = getattr(src, 'data', None)
        if data is not None:
            try:
                dup.data = data.copy()
            except Exception:
                dup.data = data
        try:
            dup.animation_data_clear()
        except Exception:
            pass

        linked = False
        for col in getattr(src, 'users_collection', []) or []:
            try:
                col.objects.link(dup)
                linked = True
            except Exception:
                pass
        if (not linked) and getattr(scene, 'collection', None):
            scene.collection.objects.link(dup)
        object_map[src] = dup

    for src, dup in object_map.items():
        if src == source_obj:
            dup.parent = None
            dup.parent_type = 'OBJECT'
            dup.parent_bone = ''
            dup.matrix_parent_inverse = Matrix.Identity(4)
        elif src in extra_source_set:
            dup.parent = object_map[source_obj]
            dup.parent_type = 'OBJECT'
            dup.parent_bone = ''
            try:
                dup.matrix_parent_inverse = object_map[source_obj].matrix_world.inverted()
            except Exception:
                dup.matrix_parent_inverse = Matrix.Identity(4)
        elif src.parent in object_map:
            dup.parent = object_map[src.parent]
            dup.parent_type = src.parent_type
            dup.parent_bone = src.parent_bone
            try:
                dup.matrix_parent_inverse = src.matrix_parent_inverse.copy()
            except Exception:
                pass
        else:
            dup.parent = src.parent
            dup.parent_type = src.parent_type
            dup.parent_bone = src.parent_bone
            try:
                dup.matrix_parent_inverse = src.matrix_parent_inverse.copy()
            except Exception:
                pass
        dup.matrix_world = src.matrix_world.copy()
        _copy_obj_rotation(dup, src)
        dup.scale = src.scale.copy()

    dup_root = object_map.get(source_obj)
    retarget_siren_hierarchy(dup_root, old_index, new_index, object_map=object_map, detach_root=True)
    return dup_root, [object_map[src] for src in sources if src in object_map]


def resolve_context_siren(scene, s, require_linked=False, update_active=True):
    if not s or not getattr(s, "sirens", None):
        return None

    active_obj = getattr(bpy.context, "active_object", None)
    idx = infer_siren_index_from_object(active_obj, s=s) if active_obj else 0
    if 1 <= idx <= len(s.sirens):
        if update_active:
            s.active_siren = idx - 1
        return s.sirens[idx - 1]

    cur_idx = max(0, min(int(getattr(s, "active_siren", 0) or 0), len(s.sirens) - 1))
    cur_si = s.sirens[cur_idx]
    if not require_linked:
        return cur_si
    if siren_obj(cur_si) or siren_pose_bone(scene, cur_si)[1]:
        return cur_si

    for si in s.sirens:
        if siren_obj(si) or siren_pose_bone(scene, si)[1]:
            if update_active:
                s.active_siren = max(0, int(getattr(si, "index", 1)) - 1)
            return si
    return cur_si


def scene_armature_items(self, context):
    scene = getattr(context, "scene", None) if context else getattr(bpy.context, "scene", None)
    items = []
    if scene:
        arm_names = sorted({obj.name for obj in scene.objects if obj.type == "ARMATURE"}, key=str.lower)
        items = [(name, name, "") for name in arm_names]
    if not items:
        items = [("__NONE__", "(No armatures found)", "")]
    return items


def scene_siren_mesh_pairs(scene, s=None):
    if not scene:
        return []

    pairs = []
    seen_names = set()
    slot_by_idx = {}
    if s and getattr(s, "sirens", None):
        for si in getattr(s, "sirens", []) or []:
            idx = int(getattr(si, "index", 0) or 0)
            if idx > 0 and idx not in slot_by_idx:
                slot_by_idx[idx] = si
            obj = siren_obj(si)
            if not obj or obj.name not in getattr(scene, "objects", {}):
                continue
            if obj.name in seen_names:
                continue
            seen_names.add(obj.name)
            pairs.append((idx, obj, si))

    for obj in sorted(getattr(scene, "objects", []) or [], key=lambda item: str(getattr(item, "name", "") or "").lower()):
        if not obj or getattr(obj, "type", "") != "MESH":
            continue
        idx = siren_index_from_name(getattr(obj, "name", ""))
        if idx <= 0:
            continue
        if obj.name in seen_names:
            continue
        seen_names.add(obj.name)
        pairs.append((idx, obj, slot_by_idx.get(idx)))

    return sorted(pairs, key=lambda item: (int(item[0] or 0), str(getattr(item[1], "name", "") or "").lower()))

def scene_siren_items(self, context):
    scene = getattr(context, "scene", None) if context else getattr(bpy.context, "scene", None)
    s = getattr(scene, "nels", None) if scene else None
    items = []
    seen = set()
    if s and getattr(s, "sirens", None):
        for si in s.sirens:
            idx = int(getattr(si, "index", 0) or 0)
            if idx <= 0:
                continue
            label = f"siren{idx}"
            if label in seen:
                continue
            seen.add(label)
            obj = siren_obj(si)
            arm, pb = siren_pose_bone(scene, si) if scene else (None, None)
            desc = str(getattr(obj, "name", "") or getattr(pb, "name", "") or label)
            items.append((label, label, desc))
    if scene:
        for idx, obj, _si in scene_siren_mesh_pairs(scene, s=s):
            label = f"siren{idx}"
            if label in seen:
                continue
            seen.add(label)
            items.append((label, label, str(getattr(obj, "name", "") or label)))
    if not items:
        items = [("__NONE__", "(No sirens found)", "")]
    return items


def update_tool_working_siren(self, context):
    s = getattr(getattr(context, "scene", None), "nels", None) if context else None
    if not s or not getattr(s, "sirens", None):
        return
    val = str(getattr(s, "tool_working_siren", "") or "")
    if not val or val == "__NONE__":
        return
    idx = siren_index_from_name(val)
    if 1 <= idx <= len(s.sirens):
        s.active_siren = idx - 1


def update_siren_expanded(self, context):
    if not getattr(self, "expanded", False):
        return
    scene = getattr(context, "scene", None) if context else getattr(bpy.context, "scene", None)
    s = getattr(scene, "nels", None) if scene else None
    if not s or not getattr(s, "sirens", None):
        return
    target_idx = max(0, int(getattr(self, "index", 1) or 1) - 1)
    for si in s.sirens:
        if si != self and getattr(si, "expanded", False):
            si.expanded = False
    s.active_siren = min(target_idx, max(0, len(s.sirens) - 1))
    try:
        s.tool_working_siren = f"siren{int(getattr(self, 'index', 1) or 1)}"
    except Exception:
        pass
    tag_preview_ui_redraw()


def sync_tool_working_siren(scene, s):
    if not scene or not s or not getattr(s, "sirens", None):
        return False
    si = resolve_context_siren(scene, s, require_linked=False, update_active=True)
    if not si:
        return False
    idx = int(getattr(si, "index", 0) or 0)
    target = f"siren{idx}"
    if str(getattr(s, "tool_working_siren", "") or "") != target:
        s.tool_working_siren = target
        return True
    return False


def selected_siren_slots(context, scene, s, require_linked=False):
    if not scene or not s or not getattr(s, "sirens", None):
        return []

    slots = []
    seen = set()
    for obj in getattr(context, "selected_objects", []) or []:
        if not obj:
            continue
        idx = infer_siren_index_from_object(obj, s=s)
        if not (1 <= idx <= len(s.sirens)):
            continue
        if idx in seen:
            continue
        si = siren_slot_by_index(s, idx)
        if not si:
            continue
        if require_linked and not (siren_obj(si) or siren_pose_bone(scene, si)[1]):
            continue
        seen.add(idx)
        slots.append(si)
    return slots


def _norm_angle(v):
    try:
        a = float(v)
    except Exception:
        a = 0.0
    return (a + math.pi) % (2.0 * math.pi) - math.pi


def direction_preset_from_value(v, tol=0.0002):
    vn = _norm_angle(v)
    best_key = None
    best_delta = 1e9
    for key, ang in DIRECTIONS.items():
        d = abs(_norm_angle(vn - ang))
        if d < best_delta:
            best_delta = d
            best_key = key
    if best_key is not None and best_delta <= tol:
        return best_key
    return None


def dir_val(si):
    return float(si.custom_direction) if si.direction_mode == "CUSTOM" else DIRECTIONS.get(si.direction_preset, 0.0)


def sync_scale_factor_controls(s):
    global _SCALE_FACTOR_SYNC_GUARD
    if not s or _SCALE_FACTOR_SYNC_GUARD:
        return

    _SCALE_FACTOR_SYNC_GUARD = True
    try:
        sf = max(0.0, float(getattr(s, "scale_factor", 0.5)))
        s.scale_factor_choice = scale_factor_choice_from_value(sf)
        s.scale_factor_custom = sf
    except Exception:
        pass
    finally:
        _SCALE_FACTOR_SYNC_GUARD = False


def update_scale_factor_choice(self, context):
    global _SCALE_FACTOR_SYNC_GUARD
    if _SCALE_FACTOR_SYNC_GUARD:
        return

    _SCALE_FACTOR_SYNC_GUARD = True
    try:
        ch = getattr(self, "scale_factor_choice", "SF_2")
        if ch == "CUSTOM":
            self.scale_factor = max(0.0, float(getattr(self, "scale_factor_custom", 0.5)))
        else:
            self.scale_factor = float(SCALE_FACTOR_PRESET_VALUES.get(ch, 0.5))
            self.scale_factor_custom = self.scale_factor
    except Exception:
        pass
    finally:
        _SCALE_FACTOR_SYNC_GUARD = False
    mark_preview_dirty(context)


def update_scale_factor_custom(self, context):
    if getattr(self, "scale_factor_choice", "SF_2") != "CUSTOM":
        return
    update_scale_factor_choice(self, context)


def update_scale_factor_value(self, context):
    sync_scale_factor_controls(self)
    mark_preview_dirty(context)


def sync_siren_selector_controls(si):
    if not si:
        return
    try:
        si.pattern_select = UNSAVED_PATTERN_KEY if getattr(si, "pattern_source", "LIBRARY") == "CUSTOM" else normalize_pattern_key(getattr(si, "pattern_choice", "PAT_0"))
    except Exception:
        pass
    try:
        si.color_select = "__CUSTOM__" if getattr(si, "color_mode", "PRESET") == "CUSTOM" else normalize_color_key(getattr(si, "color_preset", "COL_0"))
    except Exception:
        pass
    try:
        si.direction_select = "__CUSTOM__" if getattr(si, "direction_mode", "PRESET") == "CUSTOM" else str(getattr(si, "direction_preset", "FRONT") or "FRONT")
    except Exception:
        pass


def update_pattern_select(self, context):
    scene = getattr(context, "scene", None) if context else None
    s = getattr(scene, "nels", None) if scene else None
    current_select = getattr(self, "pattern_select", "PAT_0")
    if current_select in {UNSAVED_PATTERN_KEY, "__CUSTOM__"}:
        if getattr(self, "pattern_source", "LIBRARY") != "CUSTOM" and s:
            p = get_pattern(s, getattr(self, "pattern_choice", "PAT_0"))
            if p:
                self.custom_visibility = getattr(p, "visibility", "BOTH") or "BOTH"
                bits = clean_bits(getattr(p, "bits", "0"))
                self.custom_bits = bits
                self.custom_value = str(parse_u32(getattr(p, "value", bits_to_int(bits))))
        self.pattern_source = "CUSTOM"
        if current_select == "__CUSTOM__":
            self.pattern_select = UNSAVED_PATTERN_KEY
    else:
        self.pattern_source = "LIBRARY"
        self.pattern_choice = normalize_pattern_key(current_select)
    queue_preview_refresh_feedback(scene)
    mark_preview_dirty(context, scene=scene, immediate=False)


def update_color_select(self, context):
    scene = getattr(context, "scene", None) if context else None
    s = getattr(scene, "nels", None) if scene else None
    if getattr(self, "color_select", "COL_0") == "__CUSTOM__":
        if getattr(self, "color_mode", "PRESET") != "CUSTOM" and s:
            c = get_color(s, getattr(self, "color_preset", "COL_0"))
            if c:
                self.custom_color = color_to_rgb(getattr(c, "value", COLORS["GENERAL_WHITE"]))
        self.color_mode = "CUSTOM"
    else:
        self.color_mode = "PRESET"
        self.color_preset = normalize_color_key(self.color_select)
    mark_preview_dirty(context)


def update_direction_select(self, context):
    if getattr(self, "direction_select", "FRONT") == "__CUSTOM__":
        if getattr(self, "direction_mode", "PRESET") != "CUSTOM":
            self.custom_direction = float(DIRECTIONS.get(getattr(self, "direction_preset", "FRONT"), 0.0))
        self.direction_mode = "CUSTOM"
    else:
        self.direction_mode = "PRESET"
        self.direction_preset = self.direction_select
        self.custom_direction = float(DIRECTIONS.get(self.direction_preset, 0.0))
    update_siren_direction(self, context)

def scale_val(si, scene=None):
    scn = scene if scene is not None else getattr(bpy.context, "scene", None)
    settings = getattr(scn, "nels", None) if scn else None
    if settings and hasattr(settings, "scale_factor"):
        try:
            return max(0.0, float(settings.scale_factor))
        except Exception:
            pass

    # Backward compatibility fallback.
    try:
        if getattr(si, "scale_mode", "PRESET") == "CUSTOM":
            return max(0.0, float(getattr(si, "custom_scale", 0.5)))
        return SCALES.get(getattr(si, "scale_preset", "SCALE_50"), 0.5)
    except Exception:
        return 0.5


def scale_factor_from_siren(si, scene=None):
    sc = max(0.0, scale_val(si, scene=scene))
    if sc <= 0.0:
        return 0.0
    return 1.0 / sc


def format_scale_factor(v):
    try:
        fv = float(v)
    except Exception:
        fv = 0.0
    if abs(fv - round(fv)) < 0.000001:
        return str(int(round(fv)))
    return f8(fv)


def shown_sim_scale(s, si):
    return 1.0


def hidden_sim_scale(s, si):
    return max(0.0, scale_val(si))


def _store_rest_loc(obj, force=False):
    if (not force) and ("_nels_rest_loc" in obj):
        return
    obj["_nels_rest_loc"] = [float(obj.location[0]), float(obj.location[1]), float(obj.location[2])]
    obj["_nels_rest_rot"] = [float(obj.rotation_euler[0]), float(obj.rotation_euler[1]), float(obj.rotation_euler[2])]
    obj["_nels_rest_scale"] = [float(obj.scale[0]), float(obj.scale[1]), float(obj.scale[2])]
    try:
        obj["_nels_rest_world"] = [float(v) for row in obj.matrix_world for v in row]
    except Exception:
        pass


def _rest_loc(obj):
    data = obj.get("_nels_rest_loc")
    if isinstance(data, (list, tuple)) and len(data) == 3:
        return Vector((float(data[0]), float(data[1]), float(data[2])))
    _store_rest_loc(obj)
    data = obj.get("_nels_rest_loc")
    return Vector((float(data[0]), float(data[1]), float(data[2])))


def _rest_rot(obj):
    data = obj.get("_nels_rest_rot")
    if isinstance(data, (list, tuple)) and len(data) == 3:
        return Vector((float(data[0]), float(data[1]), float(data[2])))
    _store_rest_loc(obj)
    data = obj.get("_nels_rest_rot", [0.0, 0.0, 0.0])
    return Vector((float(data[0]), float(data[1]), float(data[2])))


def _rest_scale(obj):
    data = obj.get("_nels_rest_scale")
    if isinstance(data, (list, tuple)) and len(data) == 3:
        return Vector((float(data[0]), float(data[1]), float(data[2])))
    _store_rest_loc(obj)
    data = obj.get("_nels_rest_scale", [1.0, 1.0, 1.0])
    return Vector((float(data[0]), float(data[1]), float(data[2])))


def _rest_world_matrix(obj):
    data = obj.get("_nels_rest_world")
    if isinstance(data, (list, tuple)) and len(data) == 16:
        return Matrix((
            (float(data[0]), float(data[1]), float(data[2]), float(data[3])),
            (float(data[4]), float(data[5]), float(data[6]), float(data[7])),
            (float(data[8]), float(data[9]), float(data[10]), float(data[11])),
            (float(data[12]), float(data[13]), float(data[14]), float(data[15])),
        ))
    _store_rest_loc(obj)
    data = obj.get("_nels_rest_world", [1.0, 0.0, 0.0, 0.0, 0.0, 1.0, 0.0, 0.0, 0.0, 0.0, 1.0, 0.0, 0.0, 0.0, 0.0, 1.0])
    return Matrix((
        (float(data[0]), float(data[1]), float(data[2]), float(data[3])),
        (float(data[4]), float(data[5]), float(data[6]), float(data[7])),
        (float(data[8]), float(data[9]), float(data[10]), float(data[11])),
        (float(data[12]), float(data[13]), float(data[14]), float(data[15])),
    ))


def rotator_preview_targets(si):
    o = siren_obj(si)
    if not o:
        return []
    direct_children = [child for child in o.children if getattr(child, "type", "") != "ARMATURE"]
    return direct_children if direct_children else [o]


def rotator_preview_pose_bones(scene, si):
    arm, pb = siren_pose_bone(scene, si)
    if not arm or not pb:
        return []
    return [child for child in getattr(pb, "children", []) if child]


def iter_pose_bone_descendants(pb):
    found = []
    stack = list(getattr(pb, "children", []))
    while stack:
        cur = stack.pop(0)
        if not cur or cur in found:
            continue
        found.append(cur)
        stack.extend(list(getattr(cur, "children", [])))
    return found


def siren_descendant_bone_names(scene, si):
    arm, pb = siren_pose_bone(scene, si)
    if not arm or not pb:
        return set()
    return {child.name for child in iter_pose_bone_descendants(pb)}


def siren_descendant_bone_objects(scene, si):
    arm, pb = siren_pose_bone(scene, si)
    if not arm or not pb or not scene:
        return []
    names = siren_descendant_bone_names(scene, si)
    if not names:
        return []
    found = []
    for obj in scene.objects:
        try:
            if obj.parent == arm and obj.parent_type == "BONE" and obj.parent_bone in names:
                found.append(obj)
        except Exception:
            continue
    return found


def apply_rotator_preview_targets(si, turns=0.0, keyframe_frame=None):
    if not si or getattr(si, "siren_type", "FLASHER") != "ROTATOR":
        return 0

    rot_sign = 1.0 if getattr(si, "rotator_clockwise", True) else -1.0
    updated = 0
    for obj in rotator_preview_targets(si):
        _store_rest_loc(obj)
        rest_loc = _rest_loc(obj)
        rest_rot = _rest_rot(obj)
        rest_scale = _rest_scale(obj)
        obj.rotation_mode = "XYZ"
        obj.location = rest_loc
        obj.scale = rest_scale
        obj.rotation_euler = rest_rot
        obj.rotation_euler[2] = rest_rot[2] + rot_sign * turns * math.tau
        if keyframe_frame is not None:
            obj.keyframe_insert(data_path="rotation_euler", index=2, frame=keyframe_frame)
        updated += 1
    return updated


def apply_rotator_preview_pose_targets(scene, si, turns=0.0, keyframe_frame=None):
    if not si or getattr(si, "siren_type", "FLASHER") != "ROTATOR":
        return 0

    arm, _pb = siren_pose_bone(scene, si)
    if not arm:
        return 0

    rot_sign = 1.0 if getattr(si, "rotator_clockwise", True) else -1.0
    updated = 0
    for target in rotator_preview_pose_bones(scene, si):
        _store_rest_pose_bone(arm, target)
        rest_loc, rest_rot, rest_sc = _rest_pose_bone(arm, target)
        target.rotation_mode = "XYZ"
        target.location = rest_loc
        target.scale = rest_sc
        target.rotation_euler = rest_rot
        target.rotation_euler[2] = rest_rot[2] + rot_sign * turns * math.tau
        if keyframe_frame is not None:
            target.keyframe_insert(data_path="rotation_euler", index=2, frame=keyframe_frame)
        updated += 1
    return updated


def target_sim_loc(obj, mode):
    rest = _rest_loc(obj)
    if mode == "ON":
        return rest
    if obj.parent_type == "BONE":
        return Vector((0.0, 0.0, 0.0))
    return rest


def _vector_mul(a, b):
    return Vector((float(a[0]) * float(b[0]), float(a[1]) * float(b[1]), float(a[2]) * float(b[2])))


def _vector_div_scalar(v, scalar):
    val = float(scalar)
    return Vector((float(v[0]) / val, float(v[1]) / val, float(v[2]) / val))


def siren_object_driven_by_bone(scene, si):
    o = siren_obj(si)
    arm, pb = siren_pose_bone(scene, si)
    return bool(o and arm and pb and o.parent == arm and o.parent_type == "BONE" and o.parent_bone == pb.name)


def iter_siren_object_hierarchy(root):
    if not root:
        return []
    found = []
    stack = list(getattr(root, "children", []))
    while stack:
        obj = stack.pop(0)
        if not obj or obj in found:
            continue
        if getattr(obj, "type", "") != "ARMATURE":
            found.append(obj)
        stack.extend(list(getattr(obj, "children", [])))
    return found


def scale_object_data(obj, factor_vec):
    if not obj:
        return False
    data = getattr(obj, "data", None)
    if data is None or not hasattr(data, "transform"):
        return False
    try:
        if getattr(data, "users", 1) > 1:
            obj.data = data.copy()
            data = obj.data
        data.transform(Matrix.Diagonal((float(factor_vec[0]), float(factor_vec[1]), float(factor_vec[2]), 1.0)))
        if hasattr(data, "update"):
            data.update()
        return True
    except Exception:
        return False


def siren_child_objects(si):
    o = siren_obj(si)
    if not o:
        return []
    return [child for child in getattr(o, "children", []) if child and getattr(child, "type", "") != "ARMATURE"]


def apply_siren_child_object_compensation(si, scalar):
    root = siren_obj(si)
    if not root:
        return
    root.rotation_mode = "XYZ"
    parent_loc = root.matrix_world.translation.copy()
    parent_rot = root.matrix_world.to_quaternion()
    parent_noscale = Matrix.LocRotScale(parent_loc, parent_rot, Vector((1.0, 1.0, 1.0)))
    for child in siren_child_objects(si):
        _store_rest_loc(child)
        rest_loc = _rest_loc(child)
        rest_rot = Euler(_rest_rot(child), "XYZ")
        rest_scale = _rest_scale(child)
        child_local = Matrix.LocRotScale(rest_loc, rest_rot.to_quaternion(), rest_scale)
        child.matrix_world = parent_noscale @ child_local


def apply_siren_child_pose_compensation(scene, si, scalar):
    val = max(0.000001, float(scalar))
    arm, _pb = siren_pose_bone(scene, si)
    if not arm:
        return
    for child in rotator_preview_pose_bones(scene, si):
        _store_rest_pose_bone(arm, child)
        rest_loc, rest_rot, rest_sc = _rest_pose_bone(arm, child)
        child.rotation_mode = "XYZ"
        child.location = _vector_div_scalar(rest_loc, val)
        child.rotation_euler = rest_rot
        child.scale = (rest_sc[0] / val, rest_sc[1] / val, rest_sc[2] / val)


def apply_siren_descendant_bone_object_compensation(scene, si, mode, keyframe_frame=None, preserved_world=None):
    preserved_world = dict(preserved_world or {})
    for obj in siren_descendant_bone_objects(scene, si):
        _store_rest_loc(obj)
        obj.rotation_mode = "XYZ"
        rest_loc = _rest_loc(obj)
        rest_rot = Euler(_rest_rot(obj), "XYZ")
        rest_scale = _rest_scale(obj)

        preserved = preserved_world.get(obj)
        if preserved is not None:
            obj.matrix_world = preserved
        else:
            arm = getattr(obj, "parent", None)
            bone_name = str(getattr(obj, "parent_bone", "") or "")
            pose_bone = None
            try:
                if arm and getattr(arm, "type", "") == "ARMATURE" and bone_name:
                    pose_bone = getattr(getattr(arm, "pose", None), "bones", {}).get(bone_name)
            except Exception:
                pose_bone = None

            if pose_bone:
                parent_world = (arm.matrix_world @ pose_bone.matrix).copy()
                parent_noscale = Matrix.LocRotScale(parent_world.translation.copy(), parent_world.to_quaternion(), Vector((1.0, 1.0, 1.0)))
                child_local = Matrix.LocRotScale(rest_loc, rest_rot.to_quaternion(), rest_scale)
                obj.matrix_world = parent_noscale @ child_local
            elif mode == "OFF":
                obj.matrix_world = _rest_world_matrix(obj)
            else:
                obj.location = rest_loc
                obj.rotation_euler = rest_rot
                obj.scale = rest_scale

        if keyframe_frame is not None:
            obj.keyframe_insert(data_path="location", frame=keyframe_frame)
            obj.keyframe_insert(data_path="scale", frame=keyframe_frame)


def restore_siren_default_state(scene, si):
    restored = 0
    o = siren_obj(si)
    if o:
        _store_rest_loc(o)
        o.rotation_mode = "XYZ"
        o.location = _rest_loc(o)
        o.rotation_euler = _rest_rot(o)
        o.scale = _rest_scale(o)
        restored += 1
        for child in iter_siren_object_hierarchy(o):
            if any(k in child for k in ("_nels_rest_loc", "_nels_rest_rot", "_nels_rest_scale")):
                child.rotation_mode = "XYZ"
                child.location = _rest_loc(child)
                child.rotation_euler = _rest_rot(child)
                child.scale = _rest_scale(child)
                restored += 1

    arm, pb = siren_pose_bone(scene, si)
    if arm and pb:
        _store_rest_pose_bone(arm, pb)
        rest_loc, rest_rot, rest_sc = _rest_pose_bone(arm, pb)
        pb.rotation_mode = "XYZ"
        pb.location = rest_loc
        pb.rotation_euler = rest_rot
        pb.scale = rest_sc
        restored += 1
        for child in rotator_preview_pose_bones(scene, si):
            key = _pose_rest_key(child.name)
            if key in arm:
                rest_loc, rest_rot, rest_sc = _rest_pose_bone(arm, child)
                child.rotation_mode = "XYZ"
                child.location = rest_loc
                child.rotation_euler = rest_rot
                child.scale = rest_sc
                restored += 1
    for obj in siren_descendant_bone_objects(scene, si):
        if any(k in obj for k in ("_nels_rest_loc", "_nels_rest_rot", "_nels_rest_scale")):
            obj.rotation_mode = "XYZ"
            obj.location = _rest_loc(obj)
            obj.rotation_euler = _rest_rot(obj)
            obj.scale = _rest_scale(obj)
            restored += 1

    return restored


def bake_siren_scale_state(scene, s, si, mode):
    o = siren_obj(si)
    if not o:
        return False, "No linked siren mesh found for the selected siren"

    target_scalar = shown_sim_scale(s, si) if mode == "ON" else hidden_sim_scale(s, si)
    if target_scalar <= 0.0:
        return False, "Scale Factor must be above 0 before baking the hidden siren scale"

    arm, pb = siren_pose_bone(scene, si)
    bone_driven = siren_object_driven_by_bone(scene, si)

    current_effective = Vector((float(o.scale[0]), float(o.scale[1]), float(o.scale[2])))
    if bone_driven and pb:
        current_effective = _vector_mul(current_effective, Vector((float(pb.scale[0]), float(pb.scale[1]), float(pb.scale[2]))))

    factor_vec = _vector_div_scalar(current_effective, target_scalar)
    baked = 1 if scale_object_data(o, factor_vec) else 0

    o.rotation_mode = "XYZ"
    o.scale = (1.0, 1.0, 1.0)
    _store_rest_loc(o, force=True)

    if arm and pb:
        pb.rotation_mode = "XYZ"
        pb.scale = (1.0, 1.0, 1.0)
        _store_rest_pose_bone(arm, pb, force=True)

    apply_sim_state(scene, s, si, mode)

    if hasattr(scene, "view_layers"):
        try:
            bpy.context.view_layer.update()
        except Exception:
            pass

    queue_preview_refresh_feedback(scene)
    mark_preview_dirty(scene=scene, immediate=False)
    return True, f"Baked {mode.lower()} scale for siren{si.index} on {max(1, baked)} object(s)"



def _pose_rest_key(bone_name):
    return f"_nels_rest_pose_{bone_name}"


def _store_rest_pose_bone(arm, pb, force=False):
    key = _pose_rest_key(pb.name)
    if (not force) and (key in arm):
        return
    old_mode = pb.rotation_mode
    try:
        pb.rotation_mode = "XYZ"
        arm[key] = [
            float(pb.location[0]),
            float(pb.location[1]),
            float(pb.location[2]),
            float(pb.rotation_euler[0]),
            float(pb.rotation_euler[1]),
            float(pb.rotation_euler[2]),
            float(pb.scale[0]),
            float(pb.scale[1]),
            float(pb.scale[2]),
        ]
    finally:
        pb.rotation_mode = old_mode


def _rest_pose_bone(arm, pb):
    key = _pose_rest_key(pb.name)
    data = arm.get(key)
    if isinstance(data, (list, tuple)) and len(data) == 9:
        loc = Vector((float(data[0]), float(data[1]), float(data[2])))
        rot = Vector((float(data[3]), float(data[4]), float(data[5])))
        sc = Vector((float(data[6]), float(data[7]), float(data[8])))
        return loc, rot, sc
    _store_rest_pose_bone(arm, pb)
    data = arm.get(key, [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 1.0, 1.0, 1.0])
    loc = Vector((float(data[0]), float(data[1]), float(data[2])))
    rot = Vector((float(data[3]), float(data[4]), float(data[5])))
    sc = Vector((float(data[6]), float(data[7]), float(data[8])))
    return loc, rot, sc


def apply_sim_state(scene, s, si, mode, turns=0.0, keyframe_frame=None):
    o = siren_obj(si)
    arm, pb = siren_pose_bone(scene, si)
    sc = shown_sim_scale(s, si) if mode == "ON" else hidden_sim_scale(s, si)
    applied = False

    preserved_desc_world = {}
    if keyframe_frame is None and mode == "OFF":
        try:
            for child_obj in siren_descendant_bone_objects(scene, si):
                preserved_desc_world[child_obj] = child_obj.matrix_world.copy()
        except Exception:
            preserved_desc_world = {}

    is_rotator = getattr(si, "siren_type", "FLASHER") == "ROTATOR"
    rotation_only_key = bool(keyframe_frame is not None and is_rotator and mode == "ON" and abs(float(turns)) > 0.000001)
    object_driven_by_bone = bool(o and arm and pb and o.parent == arm and o.parent_type == "BONE" and o.parent_bone == pb.name)

    if o:
        _store_rest_loc(o)
        rest_loc = _rest_loc(o)
        rest_rot = _rest_rot(o)
        rest_scale = _rest_scale(o)

        o.rotation_mode = "XYZ"
        o.rotation_euler = rest_rot
        if is_rotator and not (arm and pb):
            rot_sign = 1.0 if getattr(si, "rotator_clockwise", True) else -1.0
            o.rotation_euler[2] = rest_rot[2] + rot_sign * turns * math.tau

        o.location = rest_loc
        if object_driven_by_bone or (arm and pb and is_rotator):
            o.scale = rest_scale
        else:
            o.scale = (rest_scale[0] * sc, rest_scale[1] * sc, rest_scale[2] * sc)

        if keyframe_frame is not None:
            if (not rotation_only_key) and not (object_driven_by_bone or (arm and pb and is_rotator)):
                o.keyframe_insert(data_path="scale", frame=keyframe_frame)
            if is_rotator and not (arm and pb):
                o.keyframe_insert(data_path="rotation_euler", index=2, frame=keyframe_frame)
        applied = True

    if arm and pb:
        _store_rest_pose_bone(arm, pb)
        rest_loc, rest_rot, rest_sc = _rest_pose_bone(arm, pb)
        pb.rotation_mode = "XYZ"
        pb.location = rest_loc
        pb.rotation_euler = rest_rot
        if is_rotator:
            rot_sign = 1.0 if getattr(si, "rotator_clockwise", True) else -1.0
            pb.rotation_euler = (rest_rot[0], rest_rot[1], rest_rot[2] + rot_sign * turns * math.tau)
        pb.scale = (rest_sc[0] * sc, rest_sc[1] * sc, rest_sc[2] * sc)

        if keyframe_frame is not None:
            if not rotation_only_key:
                pb.keyframe_insert(data_path="scale", frame=keyframe_frame)
            if is_rotator:
                pb.keyframe_insert(data_path="rotation_euler", index=2, frame=keyframe_frame)
        applied = True

    if applied:
        try:
            bpy.context.view_layer.update()
        except Exception:
            pass

    if o:
        apply_siren_child_object_compensation(si, sc)
    if arm and pb:
        apply_siren_child_pose_compensation(scene, si, sc)
        apply_siren_descendant_bone_object_compensation(scene, si, mode, keyframe_frame=keyframe_frame, preserved_world=preserved_desc_world)

    return applied


def _ensure_cycles_fcurve(fc):
    if not fc:
        return
    for m in fc.modifiers:
        if m.type == "CYCLES":
            return
    mod = fc.modifiers.new(type="CYCLES")
    mod.mode_before = "REPEAT"
    mod.mode_after = "REPEAT"


def _iter_action_fcurves(action):
    if not action:
        return

    # Blender <= 4.x API.
    legacy = getattr(action, "fcurves", None)
    if legacy is not None:
        for fc in legacy:
            yield fc
        return

    # Blender 5.x layered Action API.
    for layer in getattr(action, "layers", []):
        for strip in getattr(layer, "strips", []):
            for bag in getattr(strip, "channelbags", []):
                for fc in getattr(bag, "fcurves", []):
                    yield fc

def _clear_cycles_modifiers(action, path_predicate):
    for fc in _iter_action_fcurves(action):
        data_path = str(getattr(fc, "data_path", ""))
        if not path_predicate(data_path):
            continue
        try:
            for m in list(fc.modifiers):
                if m.type == "CYCLES":
                    fc.modifiers.remove(m)
        except Exception:
            pass


def _set_preview_key_interpolation(scene, si):
    def _set_interp(fc, mode):
        try:
            for kp in fc.keyframe_points:
                kp.interpolation = mode
        except Exception:
            pass

    o = siren_obj(si)
    if o and o.animation_data and o.animation_data.action:
        for fc in _iter_action_fcurves(o.animation_data.action):
            if fc.data_path in {"location", "scale"}:
                _set_interp(fc, "CONSTANT")
            elif si.siren_type == "ROTATOR" and fc.data_path == "rotation_euler" and int(getattr(fc, "array_index", -1)) == 2:
                _set_interp(fc, "LINEAR")

    if getattr(si, "siren_type", "FLASHER") == "ROTATOR":
        for target in rotator_preview_targets(si):
            if not target or target == o:
                continue
            act = getattr(getattr(target, "animation_data", None), "action", None)
            if not act:
                continue
            for fc in _iter_action_fcurves(act):
                if fc.data_path == "rotation_euler" and int(getattr(fc, "array_index", -1)) == 2:
                    _set_interp(fc, "LINEAR")

    arm, pb = siren_pose_bone(scene, si)
    if arm and pb and arm.animation_data and arm.animation_data.action:
        target_bones = {pb.name}
        if getattr(si, "siren_type", "FLASHER") == "ROTATOR":
            target_bones.update(child.name for child in rotator_preview_pose_bones(scene, si))

        for fc in _iter_action_fcurves(arm.animation_data.action):
            path = str(getattr(fc, "data_path", ""))
            prefix = 'pose.bones["'
            if not path.startswith(prefix):
                continue
            bone_name = path[len(prefix):].split('"]', 1)[0]
            if bone_name not in target_bones:
                continue
            if path.endswith(".location") or path.endswith(".scale"):
                _set_interp(fc, "CONSTANT")
            elif si.siren_type == "ROTATOR" and path.endswith(".rotation_euler") and int(getattr(fc, "array_index", -1)) == 2:
                _set_interp(fc, "LINEAR")


def preview_step_frames(bpm, fps):
    bpm_val = max(1.0, float(bpm))
    fps_val = max(1.0, float(fps))
    return max(0.01, (60.0 / bpm_val) * fps_val)


def preview_cycle_frames(bpm, fps, bit_count=32):
    return preview_step_frames(bpm, fps) * max(1, int(bit_count))


def start_delay_frames(bpm, fps, si):
    try:
        delay = max(0.0, float(getattr(si, "start_delay", 0.0) or 0.0))
    except Exception:
        delay = 0.0
    return delay * preview_step_frames(bpm, fps)

def ensure_siren_preview_cycles(scene, si):
    o = siren_obj(si)
    if o and o.animation_data and o.animation_data.action:
        act = o.animation_data.action
        for fc in _iter_action_fcurves(act):
            if fc.data_path in {"location", "scale", "rotation_euler"}:
                _ensure_cycles_fcurve(fc)

    if getattr(si, "siren_type", "FLASHER") == "ROTATOR":
        for target in rotator_preview_targets(si):
            if not target or target == o:
                continue
            act = getattr(getattr(target, "animation_data", None), "action", None)
            if not act:
                continue
            for fc in _iter_action_fcurves(act):
                if fc.data_path == "rotation_euler" and int(getattr(fc, "array_index", -1)) == 2:
                    _ensure_cycles_fcurve(fc)

    arm, pb = siren_pose_bone(scene, si)
    if arm and pb and arm.animation_data and arm.animation_data.action:
        target_bones = {pb.name}
        if getattr(si, "siren_type", "FLASHER") == "ROTATOR":
            target_bones.update(child.name for child in rotator_preview_pose_bones(scene, si))
        act = arm.animation_data.action
        for fc in _iter_action_fcurves(act):
            path = str(getattr(fc, "data_path", ""))
            prefix = 'pose.bones["'
            if not path.startswith(prefix):
                continue
            bone_name = path[len(prefix):].split('"]', 1)[0]
            if bone_name not in target_bones:
                continue
            if path.endswith(".location") or path.endswith(".scale") or path.endswith(".rotation_euler"):
                _ensure_cycles_fcurve(fc)
def rot_speed(bpm, si):
    if si.rotator_speed_mode == "CUSTOM":
        return float(bpm) / 100.0 * (max(0.0, si.rotator_custom_percent) / 6.25)
    return float(bpm) / 100.0 * ROT_SPEED.get(si.rotator_speed_mode, 1.0)


def rotator_cycle_frames(bpm, fps, si):
    rpm = max(0.000001, float(rot_speed(bpm, si)))
    fps_val = max(1.0, float(fps))
    return max(1.0, (60.0 / rpm) * fps_val)


def siren_base_color_rgb(s, si):
    if si.color_mode == "PRESET":
        c = get_color(s, si.color_preset)
        return color_to_rgb(c.value) if c else (1.0, 0.0, 0.0)
    return tuple(si.custom_color)


def get_siren_configured_color(self):
    try:
        scene = getattr(bpy.context, "scene", None)
        s = getattr(scene, "nels", None) if scene else None
        return tuple(siren_base_color_rgb(s, self)) if s else tuple(self.custom_color)
    except Exception:
        return (1.0, 1.0, 1.0)


def color_hex(s, si):
    if si.color_mode == "PRESET":
        c = get_color(s, si.color_preset)
        return clean_color_value(c.value) if c else "0xFFFF0000"
    return rgb_to_color(si.custom_color)

def pattern_triplet(s, si):
    if si.pattern_source == "CUSTOM":
        bits = repeat_32(si.custom_bits)
        return bits, bits_to_int(bits), si.custom_visibility
    p = get_pattern(s, si.pattern_choice)
    if not p:
        return "0" * 32, 0, "BOTH"
    bits = repeat_32(p.bits)
    return bits, bits_to_int(bits), p.visibility


def siren_is_active(si):
    if not si:
        return False

    has_object = bool(si.object_name and si.object_name in bpy.data.objects)
    has_bone = False
    try:
        scene = getattr(bpy.context, "scene", None)
        arm, pb = siren_pose_bone(scene, si)
        has_bone = bool(arm and pb)
    except Exception:
        has_bone = False
    return has_object or has_bone

def siren_has_output(s, si):
    if not s or not si:
        return False
    _, seq, vis = pattern_triplet(s, si)
    if seq == 0:
        return False
    if si.siren_type == "ROTATOR":
        return vis in {"BOTH", "ROTATOR"}
    return vis in {"BOTH", "FLASHER"}


def ensure_defaults(s):
    if not s.patterns:
        data = load_global_library_data()
        loaded = False
        pats = data.get("patterns", []) if isinstance(data, dict) else []
        if isinstance(pats, list) and pats:
            for pd in pats:
                if not isinstance(pd, dict):
                    continue
                p = s.patterns.add()
                p.name = str(pd.get("name", "Pattern") or "Pattern")
                p.visibility = "FLASHER" if pd.get("visibility", "BOTH") == "FLASHER" else "BOTH"
                p.bits = clean_bits(pd.get("bits", int_to_bits(pd.get("value", 0)))) or "0"
                p.value = str(parse_u32(pd.get("value", bits_to_int(p.bits))))
                p.allow_duplicate = bool(pd.get("allow_duplicate", False))
            loaded = bool(s.patterns)

        if not loaded:
            populate_default_patterns(s)

    migrate_legacy_default_patterns(s)

    ensure_off_pattern(s)
    if s.patterns:
        s.active_pattern = min(max(0, s.active_pattern), len(s.patterns) - 1)
    save_global_library(s)


def ensure_off_pattern(s):
    for p in s.patterns:
        if (p.name or "").strip().lower() == "off":
            if not hasattr(p, "allow_duplicate"):
                continue
            return
    p = s.patterns.add()
    p.name = "Off"
    p.visibility = "BOTH"
    p.bits = "0"
    p.value = "0"
    p.allow_duplicate = False


def ensure_default_color_entries(s):
    if not s:
        return False
    changed = False
    existing = {(str(getattr(c, "name", "") or "").strip().lower(), clean_color_value(getattr(c, "value", "0xFFFF0000"))) for c in getattr(s, "colors", [])}
    existing_values = {clean_color_value(getattr(c, "value", "0xFFFF0000")) for c in getattr(s, "colors", [])}
    for _key, label, value in COLOR_ITEMS:
        sig = (label.strip().lower(), clean_color_value(value))
        if sig in existing or sig[1] in existing_values:
            continue
        c = s.colors.add()
        c.name = label
        c.value = clean_color_value(value)
        c.rgb = color_to_rgb(c.value)
        existing.add(sig)
        existing_values.add(sig[1])
        changed = True
    return changed


def ensure_color_defaults(s):
    loaded = bool(getattr(s, "colors", None))
    if not loaded:
        data = load_global_library_data()
        cols = data.get("colors", []) if isinstance(data, dict) else []
        if isinstance(cols, list) and cols:
            for cd in cols:
                if not isinstance(cd, dict):
                    continue
                c = s.colors.add()
                c.name = str(cd.get("name", "Colour") or "Colour")
                c.value = clean_color_value(cd.get("value", "0xFFFF0000"))
                c.rgb = color_to_rgb(c.value)
            loaded = bool(s.colors)

    if not loaded:
        for name, value in DEFAULT_COLOR_LIBRARY:
            c = s.colors.add()
            c.name = name
            c.value = clean_color_value(value)
            c.rgb = color_to_rgb(c.value)

    changed = ensure_default_color_entries(s)
    s.active_color = min(max(0, s.active_color), max(0, len(s.colors) - 1)) if s.colors else 0
    if changed or not loaded:
        save_global_library(s)


def ensure_other_attributes_defaults(s):
    if not s or s.other_attributes:
        return

    defaults = [
        ("Scale Factor 2", "0.5"),
        ("Scale Factor 10", "0.1"),
        ("Scale Factor 100", "0.01"),
    ]
    for disp, ret in defaults:
        a = s.other_attributes.add()
        a.display_value = disp
        a.return_value = ret
    s.active_other_attribute = 0


def add_siren(s, si, idx):
    si.index = idx
    si.name = f"siren{idx}"
    si.enabled = False
    si.siren_type = "FLASHER"
    si.rotator_speed_mode = "P50"
    si.rotator_custom_percent = 50.0
    si.rotator_clockwise = True
    si.pattern_source = "LIBRARY"
    si.pattern_choice = off_pattern_key(s)
    si.custom_visibility = "BOTH"
    si.custom_bits = "0"
    si.custom_value = "0"
    si.color_mode = "PRESET"
    si.color_preset = white_color_key(s)
    si.custom_color = (1.0, 1.0, 1.0)
    si.flash_preview = True
    si.direction_mode = "PRESET"
    si.direction_preset = "FRONT"
    si.scale_mode = "PRESET"
    si.scale_preset = "SCALE_50"
    si.custom_scale = 0.5
    si.sync_to_bpm = True
    si.flash = True
    si.light = False
    si.spot_light = False
    si.cast_shadows = False
    si.light_group = 1
    si.start_delay = 0.0
    si.light_speed = 0.0
    si.light_multiples = 2
    si.corona_intensity = 0.5
    si.corona_size = 0.0
    si.corona_pull = 0.00000001
    si.light_intensity = 0.5
    si.corona_face_camera = False
    si.object_name = ""
    si.anchor_name = ""
    si.bone_name = ""
    si.filter_selected = True
    si.expanded = (idx == 1)
    sync_siren_selector_controls(si)


def ensure_sirens(s, count):
    count = max(0, min(MAX_SIRENS, int(count)))
    while len(s.sirens) < count:
        i = len(s.sirens) + 1
        si = s.sirens.add()
        add_siren(s, si, i)
    while len(s.sirens) > count:
        s.sirens.remove(len(s.sirens) - 1)
    s.siren_count = count
    s.active_siren = min(s.active_siren, max(0, count - 1))
    for i, si in enumerate(s.sirens, start=1):
        si.index = i
        si.name = f"siren{i}"
    if count > 0 and not any(bool(getattr(si, "expanded", False)) for si in s.sirens):
        s.sirens[min(int(getattr(s, "active_siren", 0) or 0), count - 1)].expanded = True
    if hasattr(s, "preview_dirty"):
        s.preview_dirty = True



def _sync_pattern_bits(pg):
    bits = repeat_32(pg.bits)
    val = str(bits_to_int(bits))
    if pg.bits != bits:
        pg.bits = bits
    if pg.value != val:
        pg.value = val


def _sync_pattern_value(pg):
    val = str(parse_u32(pg.value))
    bits = int_to_bits(val)
    if pg.value != val:
        pg.value = val
    if pg.bits != bits:
        pg.bits = bits


def update_pattern_bits(self, context):
    scene = getattr(context, "scene", None) if context else getattr(bpy.context, "scene", None)
    _sync_pattern_bits(self)
    save_library_from_context(context)
    queue_preview_refresh_feedback(scene)
    mark_preview_dirty(context, scene=scene, immediate=False)


def update_pattern_value(self, context):
    scene = getattr(context, "scene", None) if context else getattr(bpy.context, "scene", None)
    _sync_pattern_value(self)
    save_library_from_context(context)
    queue_preview_refresh_feedback(scene)
    mark_preview_dirty(context, scene=scene, immediate=False)


def update_pattern_meta(self, context):
    scene = getattr(context, "scene", None) if context else getattr(bpy.context, "scene", None)
    save_library_from_context(context)
    queue_preview_refresh_feedback(scene)
    mark_preview_dirty(context, scene=scene, immediate=False)


def update_color_name(self, context):
    save_library_from_context(context)


def _sync_siren_bits(si):
    bits = repeat_32(si.custom_bits)
    val = str(bits_to_int(bits))
    if si.custom_bits != bits:
        si.custom_bits = bits
    if si.custom_value != val:
        si.custom_value = val


def _sync_siren_value(si):
    val = str(parse_u32(si.custom_value))
    bits = int_to_bits(val)
    if si.custom_value != val:
        si.custom_value = val
    if si.custom_bits != bits:
        si.custom_bits = bits


def update_siren_bits(self, context):
    scene = getattr(context, "scene", None) if context else getattr(bpy.context, "scene", None)
    _sync_siren_bits(self)
    queue_preview_refresh_feedback(scene)
    mark_preview_dirty(context, scene=scene, immediate=False)


def update_siren_value(self, context):
    scene = getattr(context, "scene", None) if context else getattr(bpy.context, "scene", None)
    _sync_siren_value(self)
    queue_preview_refresh_feedback(scene)
    mark_preview_dirty(context, scene=scene, immediate=False)

PREVIEW_OFF_RGB = (0.18, 0.18, 0.18)


def _emissive_level(rgb, gain):
    g = max(0.0, float(gain))
    return tuple(max(0.0, min(1.0, float(c) * g)) for c in rgb)


def _preview_lit_color(rgb, intensity=1.0):
    base = tuple(max(0.0, min(1.0, float(c))) for c in rgb)
    peak = max(base) if base else 0.0
    if peak > 0.000001:
        vivid = tuple(min(1.0, c / peak) for c in base)
    else:
        vivid = (1.0, 1.0, 1.0)
    t = max(0.0, min(1.0, float(intensity)))
    return tuple((PREVIEW_OFF_RGB[i] * (1.0 - t)) + (vivid[i] * t) for i in range(3))


def _emissive_color(rgb, lit):
    if lit:
        return _preview_lit_color(rgb, 1.0)
    return PREVIEW_OFF_RGB


def apply_sollumz_emissive_multiplier(obj, value=10.0):
    if not obj or getattr(obj, "type", "") != "MESH":
        return
    mats = getattr(getattr(obj, "data", None), "materials", None)
    if not mats:
        return
    try:
        target = float(value)
    except Exception:
        target = 10.0

    for mat in mats:
        if mat is None:
            continue
        try:
            sp = getattr(mat, "shader_properties", None)
            if sp is not None:
                if hasattr(sp, "emissive_multiplier"):
                    setattr(sp, "emissive_multiplier", target)
                elif hasattr(sp, "emissiveMultiplier"):
                    setattr(sp, "emissiveMultiplier", target)

            if hasattr(mat, "emissive_multiplier"):
                setattr(mat, "emissive_multiplier", target)
            if hasattr(mat, "emissiveMultiplier"):
                setattr(mat, "emissiveMultiplier", target)

            if "emissiveMultiplier" in mat:
                mat["emissiveMultiplier"] = target
        except Exception:
            pass


def _head_tail_preview(s, key, base_rgb, preview_on=True):
    if not s:
        return tuple(base_rgb)
    if not preview_on:
        return tuple(base_rgb)
    scn = getattr(bpy.context, "scene", None)
    p = get_pattern(s, key)
    bits = repeat_32(p.bits) if p else ("0" * 32)
    return _emissive_color(base_rgb, preview_pattern_is_on(bits, s.bpm, scene=scn))


def get_left_head_preview(self):
    try:
        return tuple(self.left_head_preview_cache)
    except Exception:
        return _head_tail_preview(self, self.left_head, (1.0, 1.0, 1.0), getattr(self, "head_tail_preview", True))


def get_right_head_preview(self):
    try:
        return tuple(self.right_head_preview_cache)
    except Exception:
        return _head_tail_preview(self, self.right_head, (1.0, 1.0, 1.0), getattr(self, "head_tail_preview", True))


def get_left_tail_preview(self):
    try:
        return tuple(self.left_tail_preview_cache)
    except Exception:
        return _head_tail_preview(self, self.left_tail, (1.0, 0.0, 0.0), getattr(self, "head_tail_preview", True))


def get_right_tail_preview(self):
    try:
        return tuple(self.right_tail_preview_cache)
    except Exception:
        return _head_tail_preview(self, self.right_tail, (1.0, 0.0, 0.0), getattr(self, "head_tail_preview", True))


def update_rotator_settings(self, context):
    scene = getattr(context, "scene", None) if context else None
    s = getattr(scene, "nels", None) if scene else None
    if self.siren_type == "ROTATOR":
        if s:
            off_key = off_pattern_key(s)
            if normalize_pattern_key(self.pattern_choice) == off_key:
                self.pattern_choice = find_pattern_key_by_name(s, "Single Sweep")
        bpm = getattr(s, "bpm", 800) if s else 800
        self.light_speed = rot_speed(bpm, self)
    mark_preview_dirty(context, scene=scene)


def update_siren_type(self, context):
    if self.siren_type == "ROTATOR":
        self.pattern_source = "LIBRARY"
    update_rotator_settings(self, context)
    sync_siren_selector_controls(self)
    mark_preview_dirty(context)


def update_bpm(self, context):
    for si in self.sirens:
        if si.siren_type == "ROTATOR":
            try:
                si.light_speed = rot_speed(self.bpm, si)
            except Exception:
                pass
    mark_preview_dirty(context)



def preview_updates_suspended():
    return _PREVIEW_UPDATE_SUSPEND > 0


def suspend_preview_updates():
    global _PREVIEW_UPDATE_SUSPEND
    _PREVIEW_UPDATE_SUSPEND += 1


def resume_preview_updates():
    global _PREVIEW_UPDATE_SUSPEND
    _PREVIEW_UPDATE_SUSPEND = max(0, _PREVIEW_UPDATE_SUSPEND - 1)


def tag_all_ui_redraw():
    wm = getattr(bpy.context, "window_manager", None)
    if not wm:
        return
    try:
        for win in wm.windows:
            screen = getattr(win, "screen", None)
            if not screen:
                continue
            for area in screen.areas:
                try:
                    area.tag_redraw()
                except Exception:
                    pass
                for region in getattr(area, "regions", []):
                    try:
                        region.tag_redraw()
                    except Exception:
                        pass
    except Exception:
        pass


def custom_preview_overlay_enabled():
    return False
def tag_preview_ui_redraw():
    wm = getattr(bpy.context, "window_manager", None)
    if not wm:
        return
    try:
        for win in wm.windows:
            screen = getattr(win, "screen", None)
            if not screen:
                continue
            for area in screen.areas:
                if getattr(area, "type", "") != "VIEW_3D":
                    continue
                for region in getattr(area, "regions", []):
                    if getattr(region, "type", "") != "UI":
                        continue
                    try:
                        region.tag_redraw()
                    except Exception:
                        pass
    except Exception:
        pass

def ui_wrap_width_chars(context, fallback=34):
    try:
        region = getattr(context, "region", None)
        width = int(getattr(region, "width", 0) or 0)
        if width <= 0:
            return fallback
        return max(18, min(56, int((width - 42) / 6.8)))
    except Exception:
        return fallback


def draw_wrapped_text(layout, context, text, icon="NONE"):
    msg = str(text or "").strip()
    if not msg:
        return
    width = ui_wrap_width_chars(context)
    lines = textwrap.wrap(msg, width=width, break_long_words=False, break_on_hyphens=False) or [msg]
    for i, line in enumerate(lines):
        if i == 0 and icon and icon != "NONE":
            layout.label(text=line, icon=icon)
        else:
            layout.label(text=line)


def preview_cache_signature(scene):
    s = getattr(scene, "nels", None) if scene else None
    if not s:
        return ""

    values = []
    for prop in ("left_head_preview_cache", "right_head_preview_cache", "left_tail_preview_cache", "right_tail_preview_cache"):
        try:
            values.extend(round(float(c), 4) for c in getattr(s, prop))
        except Exception:
            values.extend((0.0, 0.0, 0.0))

    for si in s.sirens:
        try:
            values.extend(round(float(c), 4) for c in si.preview_color_cache)
        except Exception:
            values.extend((0.0, 0.0, 0.0))
    return "|".join(f"{v:.4f}" for v in values)


def preview_targets_animated(scene):
    s = getattr(scene, "nels", None) if scene else None
    if not s:
        return False

    if getattr(s, "head_tail_preview", True):
        for key in (getattr(s, "left_head", ""), getattr(s, "right_head", ""), getattr(s, "left_tail", ""), getattr(s, "right_tail", "")):
            p = get_pattern(s, key)
            bits = repeat_32(p.bits) if p else ("0" * 32)
            if "1" in bits:
                return True

    for si in s.sirens:
        if not getattr(si, "flash_preview", True):
            continue
        if getattr(si, "siren_type", "FLASHER") == "ROTATOR":
            return True
        bits, seq, vis = pattern_triplet(s, si)
        if seq and vis in {"BOTH", "FLASHER"} and "1" in bits:
            return True
    return False


def queue_preview_refresh_feedback(scene, message="Preview refresh in progress..."):
    s = getattr(scene, "nels", None) if scene else None
    if not s:
        return
    now = _time.time()
    s.preview_refresh_pending = True
    s.preview_refresh_started_at = now
    s.preview_refresh_done_at = 0.0
    s.preview_refresh_signature = preview_cache_signature(scene)
    s.preview_refresh_has_motion = preview_targets_animated(scene)
    s.preview_animating_until = max(float(getattr(s, "preview_animating_until", 0.0) or 0.0), now + 2.5)
    s.status_message = message
    tag_preview_ui_redraw()


def update_preview_refresh_feedback(scene):
    s = getattr(scene, "nels", None) if scene else None
    if not s:
        return False

    changed = False
    now = _time.time()
    status = str(getattr(s, "status_message", "") or "")

    if getattr(s, "preview_refresh_pending", False):
        started = float(getattr(s, "preview_refresh_started_at", now) or now)
        has_motion = bool(getattr(s, "preview_refresh_has_motion", False))
        current_signature = preview_cache_signature(scene)
        previous_signature = str(getattr(s, "preview_refresh_signature", "") or "")
        if current_signature != previous_signature or ((not has_motion) and (now - started) >= 0.25):
            s.preview_refresh_pending = False
            s.preview_refresh_signature = current_signature
            s.preview_refresh_done_at = now
            if status.startswith("Preview refresh"):
                s.status_message = "Preview refresh complete"
            changed = True
        return changed

    done_at = float(getattr(s, "preview_refresh_done_at", 0.0) or 0.0)
    if done_at > 0.0 and status == "Preview refresh complete" and (now - done_at) >= 1.0:
        s.preview_refresh_done_at = 0.0
        s.status_message = ""
        changed = True
    return changed


def mark_preview_dirty(context=None, scene=None, immediate=True):
    sc = scene
    if sc is None and context is not None:
        sc = getattr(context, "scene", None)
    if sc is None:
        sc = getattr(bpy.context, "scene", None)
    s = getattr(sc, "nels", None) if sc else None
    if not s:
        return
    now = _time.time()
    s.preview_dirty = True
    s.preview_last_step = -1
    s.preview_animating_until = max(float(getattr(s, "preview_animating_until", 0.0) or 0.0), now + 1.5)
    if not timeline_playing():
        try:
            s.preview_time_origin = now
        except Exception:
            pass
    if getattr(s, "auto_timeline_preview", False) and (not preview_updates_suspended()):
        s.auto_timeline_pending = True
        s.auto_timeline_requested_at = _time.time()
        try:
            rebuild_auto_timeline_preview(sc)
        except Exception:
            pass
    if preview_updates_suspended() or (not immediate):
        tag_preview_ui_redraw()
        return
    try:
        refresh_siren_preview_cache(sc)
    except Exception:
        pass
    tag_preview_ui_redraw()



def refresh_preview_visibility_state(scene, restart_clock=False):
    s = getattr(scene, "nels", None) if scene else None
    if not s:
        return False
    now = _time.time()
    if restart_clock:
        try:
            s.preview_time_origin = now
        except Exception:
            pass
    s.preview_last_step = -1
    changed = False
    try:
        changed = bool(refresh_siren_preview_cache(scene)) or changed
    except Exception:
        pass
    tag_preview_ui_redraw()
    return changed


def update_preview_visibility_state(self, context):
    scene = getattr(context, "scene", None) if context else getattr(bpy.context, "scene", None)
    mark_preview_dirty(context, scene=scene, immediate=False)
    s = getattr(scene, "nels", None) if scene else None
    restart_clock = bool(
        s
        and getattr(s, "all_flash_previews", True)
        and getattr(s, "show_sirens_section", True)
        and getattr(s, "show_siren_preview_panel", False)
        and getattr(s, "siren_preview_running", True)
    )
    refresh_preview_visibility_state(scene, restart_clock=restart_clock)

def update_preview_only(self, context):
    mark_preview_dirty(context)


def update_pattern_preview_only(self, context):
    scene = getattr(context, "scene", None) if context else getattr(bpy.context, "scene", None)
    queue_preview_refresh_feedback(scene)
    mark_preview_dirty(context, scene=scene, immediate=False)



def env_light_name_for_siren(index):
    return f"nels_env_siren{int(index)}"


def siren_env_transform(scene, si):
    obj = siren_obj(si)
    arm, pb = siren_pose_bone(scene, si)

    if arm and pb:
        base_matrix = arm.matrix_world @ pb.matrix
        pos = base_matrix.translation.copy()
        direction = (base_matrix.to_quaternion() @ Vector((0.0, 1.0, 0.0))).normalized()
        return pos, direction

    if obj:
        base_matrix = obj.matrix_world.copy()
        pos = base_matrix.translation.copy()
        direction = (base_matrix.to_quaternion() @ Vector((0.0, 1.0, 0.0))).normalized()
        return pos, direction

    return None, None


def env_light_world_matrix(position, direction):
    try:
        direction = Vector(direction)
    except Exception:
        direction = Vector((0.0, 1.0, 0.0))
    if direction.length <= 0.000001:
        direction = Vector((0.0, 1.0, 0.0))
    direction.normalize()
    quat = Vector((0.0, 0.0, -1.0)).rotation_difference(direction)
    return Matrix.LocRotScale(Vector(position), quat, Vector((1.0, 1.0, 1.0)))


def clear_environment_lights(scene):
    removed = 0
    scene_objects = set(getattr(scene, "objects", [])) if scene else set()
    for obj in list(bpy.data.objects):
        if not obj or not obj.get("_nels_env_light"):
            continue
        if scene and scene_objects and obj not in scene_objects:
            continue
        try:
            data = getattr(obj, "data", None)
            bpy.data.objects.remove(obj, do_unlink=True)
            if data and getattr(data, "users", 0) == 0:
                bpy.data.lights.remove(data)
            removed += 1
        except Exception:
            pass
    return removed


def enable_viewport_scene_lights():
    wm = getattr(bpy.context, "window_manager", None)
    if not wm:
        return
    try:
        for win in wm.windows:
            screen = getattr(win, "screen", None)
            if not screen:
                continue
            for area in screen.areas:
                if getattr(area, "type", "") != "VIEW_3D":
                    continue
                for space in getattr(area, "spaces", []):
                    if getattr(space, "type", "") != "VIEW_3D":
                        continue
                    shading = getattr(space, "shading", None)
                    if not shading:
                        continue
                    for attr in ("use_scene_lights", "use_scene_lights_render"):
                        if hasattr(shading, attr):
                            try:
                                setattr(shading, attr, True)
                            except Exception:
                                pass
    except Exception:
        pass


def generate_environment_lights(scene, s):
    if not scene or not s:
        return 0, 0

    enable_viewport_scene_lights()
    collection = getattr(scene, "collection", None)
    created = 0
    updated = 0
    outer_angle = max(1.0, min(179.0, float(getattr(s, "light_outer_angle", 70.0) or 70.0)))
    inner_angle = max(0.0, min(outer_angle, float(getattr(s, "light_inner_angle", 2.29061) or 2.29061)))
    falloff = max(1.0, float(getattr(s, "light_falloff_max", 100.0) or 100.0))
    offset = max(0.05, float(getattr(s, "light_offset", 0.0) or 0.0) + 0.05)
    blend = 0.15
    if outer_angle > 0.0001:
        blend = max(0.0, min(1.0, 1.0 - (inner_angle / outer_angle)))

    for si in s.sirens:
        if not siren_is_active(si):
            continue
        position, direction = siren_env_transform(scene, si)
        if position is None or direction is None:
            continue
        try:
            direction = Vector(direction)
        except Exception:
            direction = Vector((0.0, 1.0, 0.0))
        if direction.length <= 0.000001:
            direction = Vector((0.0, 1.0, 0.0))
        direction.normalize()
        base_rgb = tuple(max(0.0, min(1.0, float(c))) for c in siren_base_color_rgb(s, si))
        peak = max(base_rgb) if base_rgb else 0.0
        vivid_rgb = tuple(min(1.0, c / peak) for c in base_rgb) if peak > 0.000001 else (1.0, 1.0, 1.0)

        name = env_light_name_for_siren(si.index)
        light_obj = bpy.data.objects.get(name)
        if not light_obj or getattr(light_obj, "type", "") != "LIGHT":
            light_data = bpy.data.lights.new(name=name, type="SPOT")
            light_obj = bpy.data.objects.new(name, light_data)
            light_obj["_nels_env_light"] = True
            if collection:
                collection.objects.link(light_obj)
            created += 1
        else:
            updated += 1

        light_obj["_nels_env_light"] = True
        light_data = light_obj.data
        light_data.type = "SPOT"
        light_data.color = vivid_rgb
        light_data.energy = max(2500.0, float(getattr(si, "light_intensity", 0.5) or 0.5) * 20000.0)
        light_data.shadow_soft_size = max(0.001, float(getattr(si, "corona_size", 0.0) or 0.0) + 0.05)
        light_data.spot_size = math.radians(outer_angle)
        light_data.spot_blend = blend
        if hasattr(light_data, "use_custom_distance"):
            light_data.use_custom_distance = True
        if hasattr(light_data, "cutoff_distance"):
            light_data.cutoff_distance = falloff
        if hasattr(light_data, "use_shadow"):
            light_data.use_shadow = bool(getattr(si, "cast_shadows", False))
        if hasattr(light_data, "diffuse_factor"):
            light_data.diffuse_factor = 1.0
        if hasattr(light_data, "specular_factor"):
            light_data.specular_factor = 1.0
        light_obj.hide_select = False
        light_obj.hide_viewport = False
        light_obj.hide_render = False
        light_obj.location = Vector(position) + (direction * offset)
        light_obj.rotation_mode = "QUATERNION"
        light_obj.rotation_quaternion = Vector((0.0, 0.0, -1.0)).rotation_difference(direction)

    return created, updated

def apply_car_light_simulation(scene, s, blink_indicators=False, now=None):
    if not scene or not s:
        return 0

    sim_now = playback_seconds(scene=scene, now=now)

    blink_on = True
    if blink_indicators and (s.car_left_indicator_on or s.car_right_indicator_on):
        ts = sim_now
        blink_on = ((ts * 1.5) % 1.0) < 0.5  # Standard-like turn signal cadence.

    head_l_on = bool(s.car_headlights_on) and pattern_is_on(s, s.left_head, s.bpm, now=sim_now, scene=scene)
    head_r_on = bool(s.car_headlights_on) and pattern_is_on(s, s.right_head, s.bpm, now=sim_now, scene=scene)
    tail_l_on = bool(s.car_taillights_on) and pattern_is_on(s, s.left_tail, s.bpm, now=sim_now, scene=scene)
    tail_r_on = bool(s.car_taillights_on) and pattern_is_on(s, s.right_tail, s.bpm, now=sim_now, scene=scene)

    left_on = bool(s.car_left_indicator_on) and blink_on
    right_on = bool(s.car_right_indicator_on) and blink_on
    extra_on = bool(s.car_extra_lights_on)

    touched = set()

    def _apply(objs, show):
        for obj in objs:
            if is_object_visible(obj) != bool(show):
                set_object_visible(obj, show)
                touched.add(obj.name)

    heads = scene_objects_by_keywords(scene, HEADLIGHT_KEYS)
    tails = scene_objects_by_keywords(scene, TAILLIGHT_KEYS)
    hl, hr, hc = split_side_objects(heads)
    tl, tr, tc = split_side_objects(tails)

    _apply(hl, head_l_on)
    _apply(hr, head_r_on)
    _apply(hc, bool(head_l_on or head_r_on))

    _apply(tl, tail_l_on)
    _apply(tr, tail_r_on)
    _apply(tc, bool(tail_l_on or tail_r_on))

    _apply(scene_objects_by_keywords(scene, LEFT_INDICATOR_KEYS), left_on)
    _apply(scene_objects_by_keywords(scene, RIGHT_INDICATOR_KEYS), right_on)
    _apply(scene_objects_by_keywords(scene, EXTRA_LIGHT_KEYS), extra_on)

    preview_states = {
        "always_on": True,
        "headlight_l": head_l_on,
        "headlight_r": head_r_on,
        "taillight_l": tail_l_on,
        "taillight_r": tail_r_on,
        "brakelight_l": tail_l_on,
        "brakelight_r": tail_r_on,
        "brakelight_m": bool(tail_l_on or tail_r_on),
        "reversinglight_l": False,
        "reversinglight_r": False,
        "indicator_lf": left_on,
        "indicator_lr": left_on,
        "indicator_rf": right_on,
        "indicator_rr": right_on,
        "extralight_1": extra_on,
        "extralight_2": extra_on,
        "extralight_3": extra_on,
        "extralight_4": extra_on,
    }
    touched_count = apply_light_id_preview(scene, s, preview_states)
    return len(touched) + int(touched_count)

def update_car_light_toggle(self, context):
    scene = getattr(context, "scene", None) if context else getattr(bpy.context, "scene", None)
    s = getattr(scene, "nels", None) if scene else None
    if not s:
        return
    apply_car_light_simulation(scene, s, blink_indicators=True, now=playback_seconds(scene=scene))


def timeline_playing():
    wm = getattr(bpy.context, "window_manager", None)
    if not wm:
        return False
    try:
        for win in wm.windows:
            screen = getattr(win, "screen", None)
            if screen and getattr(screen, "is_animation_playing", False):
                return True
    except Exception:
        return False
    return False



def stop_timeline_playback():
    wm = getattr(bpy.context, "window_manager", None)
    if not wm:
        return False
    stopped = False
    try:
        for win in wm.windows:
            screen = getattr(win, "screen", None)
            if not screen or not getattr(screen, "is_animation_playing", False):
                continue
            area = next((a for a in screen.areas if getattr(a, "type", "") == "VIEW_3D"), None)
            if area is None and getattr(screen, "areas", None):
                area = screen.areas[0]
            region = next((r for r in getattr(area, "regions", []) if getattr(r, "type", "") == "WINDOW"), None) if area else None
            try:
                with bpy.context.temp_override(window=win, screen=screen, area=area, region=region):
                    bpy.ops.screen.animation_cancel(restore_frame=False)
                stopped = True
            except Exception:
                try:
                    with bpy.context.temp_override(window=win, screen=screen, area=area, region=region):
                        bpy.ops.screen.animation_play()
                    stopped = True
                except Exception:
                    pass
    except Exception:
        return False
    return stopped

def set_scene_warning(scene, msg):
    s = getattr(scene, "nels", None) if scene else None
    if s and hasattr(s, "status_message"):
        s.status_message = str(msg or "")


def siren_direction_warning(scene, si):
    if not scene or not si:
        return ""
    if not siren_obj(si):
        return ""

    arm, pb = siren_pose_bone(scene, si)
    has_bone = bool(arm and pb and getattr(si, "bone_name", ""))
    if has_bone:
        return ""
    return f"Warning: Siren {si.index} has no linked bone for direction sync"


def active_siren_direction_warning(scene):
    s = getattr(scene, "nels", None) if scene else None
    if not s or not s.sirens:
        return ""

    idx = max(0, min(int(s.active_siren), len(s.sirens) - 1))
    return siren_direction_warning(scene, s.sirens[idx])


def refresh_direction_warning(scene):
    s = getattr(scene, "nels", None) if scene else None
    if not s:
        return
    msg = str(getattr(s, "status_message", "") or "")
    if msg.startswith("Warning: Siren ") and msg.endswith(" has no linked bone for direction sync"):
        s.status_message = ""


def apply_siren_direction_to_bone(scene, si, set_warning=True):
    if not scene or not si:
        return False

    arm, pb = siren_pose_bone(scene, si)
    if not arm or not pb:
        if set_warning:
            set_scene_warning(scene, f"Warning: Siren {si.index} has no linked bone for direction sync")
        return False

    ang = dir_val(si)
    vec = Vector((math.sin(ang), math.cos(ang), 0.0))
    if vec.length < 0.000001:
        vec = Vector((0.0, 1.0, 0.0))

    old_active = getattr(bpy.context.view_layer.objects, "active", None)
    old_mode = getattr(bpy.context, "mode", "OBJECT")

    try:
        if old_mode != "OBJECT":
            bpy.ops.object.mode_set(mode="OBJECT")
        bpy.ops.object.select_all(action="DESELECT")
        arm.select_set(True)
        bpy.context.view_layer.objects.active = arm
        bpy.ops.object.mode_set(mode="EDIT")

        eb = arm.data.edit_bones.get(pb.name) or arm.data.edit_bones.get(si.bone_name)
        if not eb:
            bpy.ops.object.mode_set(mode="OBJECT")
            if set_warning:
                set_scene_warning(scene, f"Warning: Could not find linked bone for siren {si.index}")
            return False

        head = eb.head.copy()
        length = (eb.tail - eb.head).length
        if length < 0.000001:
            length = 0.05
        eb.tail = head + vec.normalized() * length

        bpy.ops.object.mode_set(mode="OBJECT")
        pose_bone = arm.pose.bones.get(eb.name)
        if pose_bone:
            _store_rest_pose_bone(arm, pose_bone, force=True)

        if set_warning:
            set_scene_warning(scene, "")
        return True
    except Exception:
        if set_warning:
            set_scene_warning(scene, f"Warning: Failed to apply direction to siren {si.index} bone")
        return False
    finally:
        try:
            if old_active and old_active.name in bpy.data.objects:
                bpy.context.view_layer.objects.active = old_active
        except Exception:
            pass
        try:
            if old_mode != "OBJECT" and getattr(bpy.context, "mode", "OBJECT") == "OBJECT":
                bpy.ops.object.mode_set(mode=old_mode)
        except Exception:
            pass



def apply_all_siren_directions(scene):
    s = getattr(scene, "nels", None) if scene else None
    if not s or not s.sirens:
        return 0

    groups = {}
    for si in s.sirens:
        arm, pb = siren_pose_bone(scene, si)
        if arm and pb:
            groups.setdefault(arm.name, []).append((si, pb.name))

    if not groups:
        return 0

    updated = 0
    old_active = getattr(bpy.context.view_layer.objects, "active", None)
    old_mode = getattr(bpy.context, "mode", "OBJECT")

    try:
        if old_mode != "OBJECT":
            bpy.ops.object.mode_set(mode="OBJECT")
        bpy.ops.object.select_all(action="DESELECT")

        for arm_name, entries in groups.items():
            arm = bpy.data.objects.get(arm_name)
            if not arm or arm.type != "ARMATURE":
                continue

            bpy.ops.object.select_all(action="DESELECT")
            arm.select_set(True)
            bpy.context.view_layer.objects.active = arm
            bpy.ops.object.mode_set(mode="EDIT")

            updated_names = []
            for si, bone_name in entries:
                eb = arm.data.edit_bones.get(bone_name)
                if not eb:
                    continue
                ang = dir_val(si)
                vec = Vector((math.sin(ang), math.cos(ang), 0.0))
                if vec.length < 0.000001:
                    vec = Vector((0.0, 1.0, 0.0))
                head = eb.head.copy()
                length = (eb.tail - eb.head).length
                if length < 0.000001:
                    length = 0.05
                eb.tail = head + vec.normalized() * length
                updated_names.append(eb.name)
                updated += 1

            bpy.ops.object.mode_set(mode="OBJECT")
            for bone_name in updated_names:
                pb = arm.pose.bones.get(bone_name)
                if pb:
                    _store_rest_pose_bone(arm, pb, force=True)
    except Exception:
        return updated
    finally:
        try:
            if getattr(bpy.context, "mode", "OBJECT") != "OBJECT":
                bpy.ops.object.mode_set(mode="OBJECT")
        except Exception:
            pass
        try:
            if old_active and old_active.name in bpy.data.objects:
                bpy.context.view_layer.objects.active = old_active
        except Exception:
            pass
        try:
            if old_mode != "OBJECT" and getattr(bpy.context, "mode", "OBJECT") == "OBJECT":
                bpy.ops.object.mode_set(mode=old_mode)
        except Exception:
            pass

    return updated

def update_siren_direction(self, context):
    scene = getattr(context, "scene", None) if context else getattr(bpy.context, "scene", None)
    apply_siren_direction_to_bone(scene, self, set_warning=False)
    mark_preview_dirty(context, scene=scene)


def update_siren_bone_link(self, context):
    scene = getattr(context, "scene", None) if context else getattr(bpy.context, "scene", None)
    if self.bone_name:
        apply_siren_direction_to_bone(scene, self, set_warning=True)
    mark_preview_dirty(context, scene=scene)


def selected_mesh_name_from_context(context):
    active = getattr(context, "active_object", None)
    if active and getattr(active, "type", "") == "MESH":
        return active.name
    for obj in getattr(context, "selected_objects", []) or []:
        if obj and getattr(obj, "type", "") == "MESH":
            return obj.name
    return ""


def selected_armature_from_context(context, scene=None, s=None):
    active = getattr(context, "active_object", None)
    if active and getattr(active, "type", "") == "ARMATURE":
        return active
    if active and getattr(active, "parent", None) and getattr(active.parent, "type", "") == "ARMATURE":
        return active.parent
    for obj in getattr(context, "selected_objects", []) or []:
        if obj and getattr(obj, "type", "") == "ARMATURE":
            return obj
        if obj and getattr(obj, "parent", None) and getattr(obj.parent, "type", "") == "ARMATURE":
            return obj.parent
    arm_name = str(getattr(s, "armature_name", "") or "")
    if arm_name:
        arm = bpy.data.objects.get(arm_name)
        if arm and getattr(arm, "type", "") == "ARMATURE":
            if not scene or arm.name in getattr(scene, "objects", {}):
                return arm
    return None


def source_rig_armature_from_context(context, scene=None, s=None, exclude=None):
    excluded = set()
    if exclude is not None:
        if isinstance(exclude, (list, tuple, set)):
            excluded.update(obj.name for obj in exclude if obj is not None)
        else:
            excluded.add(getattr(exclude, "name", str(exclude)))

    def _valid_armature(obj):
        if not obj or getattr(obj, "type", "") != "ARMATURE":
            return None
        if getattr(obj, "name", "") in excluded:
            return None
        if scene and getattr(obj, "name", "") not in getattr(scene, "objects", {}):
            return None
        return obj

    def _armature_from_object(obj):
        if not obj:
            return None
        arm = _valid_armature(obj if getattr(obj, "type", "") == "ARMATURE" else None)
        if arm:
            return arm
        parent = getattr(obj, "parent", None)
        arm = _valid_armature(parent if getattr(parent, "type", "") == "ARMATURE" else None)
        if arm:
            return arm
        try:
            found = obj.find_armature() if hasattr(obj, "find_armature") else None
        except Exception:
            found = None
        arm = _valid_armature(found)
        if arm:
            return arm
        for mod in getattr(obj, "modifiers", []) or []:
            if getattr(mod, "type", "") != "ARMATURE":
                continue
            arm = _valid_armature(getattr(mod, "object", None))
            if arm:
                return arm
        return None

    active = getattr(context, "active_object", None)
    arm = _armature_from_object(active)
    if arm:
        return arm

    for obj in getattr(context, "selected_objects", []) or []:
        arm = _armature_from_object(obj)
        if arm:
            return arm
    return None


def armature_transfer_bone_names(scene, armature_obj, ignore_names=None, linked_objects=None):
    if not scene or not armature_obj or getattr(armature_obj, "type", "") != "ARMATURE":
        return []

    ignore = {str(name or "").strip().lower() for name in (ignore_names or []) if str(name or "").strip()}
    source_bones = getattr(getattr(armature_obj, "data", None), "bones", None)
    if not source_bones:
        return []

    source_names = {bone.name for bone in source_bones}
    used_names = set()
    source_objects = linked_objects if linked_objects is not None else collect_armature_linked_objects(scene, armature_obj)
    for obj in source_objects:
        parent_bone = str(getattr(obj, "parent_bone", "") or "")
        if parent_bone in source_names and parent_bone.strip().lower() not in ignore:
            used_names.add(parent_bone)
        for vg in getattr(obj, "vertex_groups", []) or []:
            vg_name = str(getattr(vg, "name", "") or "")
            if vg_name in source_names and vg_name.strip().lower() not in ignore:
                used_names.add(vg_name)

    if not used_names:
        return []

    branch_roots = set()
    for bone_name in used_names:
        bone = source_bones.get(bone_name)
        if bone is None:
            continue
        current = bone
        seen = set()
        while getattr(current, "parent", None) and getattr(current.parent, "parent", None) and current.name not in seen:
            seen.add(current.name)
            current = current.parent
        if current.name.strip().lower() not in ignore:
            branch_roots.add(current.name)

    transfer_names = set()
    for root_name in branch_roots:
        stack = [source_bones.get(root_name)]
        while stack:
            bone = stack.pop()
            if bone is None:
                continue
            if bone.name.strip().lower() not in ignore:
                transfer_names.add(bone.name)
            for child in getattr(bone, "children", []) or []:
                stack.append(child)

    def _depth(name):
        depth = 0
        bone = source_bones.get(name)
        seen = set()
        while bone and getattr(bone, "parent", None) and bone.name not in seen:
            seen.add(bone.name)
            parent = bone.parent
            if parent.name not in transfer_names:
                break
            depth += 1
            bone = parent
        return depth

    return sorted(transfer_names, key=lambda name: (_depth(name), str(name).lower()))


def target_chassis_bone_name(armature_obj):
    if not armature_obj or getattr(armature_obj, "type", "") != "ARMATURE":
        return ""
    bones = getattr(getattr(armature_obj, "data", None), "bones", None)
    if not bones:
        return ""
    exact = bones.get("chassis") if hasattr(bones, "get") else None
    if exact is not None:
        return exact.name
    for bone in bones:
        try:
            if str(getattr(bone, "name", "") or "").strip().lower() == "chassis":
                return bone.name
        except Exception:
            continue
    return ""


def armature_bone_name_conflicts(source_armature, target_armature, bone_names=None, ignore_names=None):
    if not source_armature or not target_armature:
        return []
    try:
        if bone_names is None:
            source_names = {bone.name for bone in getattr(getattr(source_armature, "data", None), "bones", [])}
        else:
            source_names = {str(name or "").strip() for name in bone_names if str(name or "").strip()}
        ignore = {str(name or "").strip().lower() for name in (ignore_names or []) if str(name or "").strip()}
        source_names = {name for name in source_names if name.strip().lower() not in ignore}
        target_names = {bone.name for bone in getattr(getattr(target_armature, "data", None), "bones", [])}
        return sorted(source_names & target_names, key=str.lower)
    except Exception:
        return []


def _collect_object_subtree(root, linked, seen):
    if not root or getattr(root, "type", "") == "ARMATURE":
        return
    if root.name not in seen:
        linked.append(root)
        seen.add(root.name)
    for child in getattr(root, "children", []) or []:
        _collect_object_subtree(child, linked, seen)


def rig_branch_root_from_context(context, armature_obj):
    if not context or not armature_obj:
        return None

    def _branch_root(obj):
        current = obj
        seen = set()
        while current and current not in seen:
            seen.add(current)
            parent = getattr(current, "parent", None)
            if parent == armature_obj:
                return current
            if parent is None or getattr(parent, "type", "") == "ARMATURE":
                return current
            current = parent
        return obj

    active = getattr(context, "active_object", None)
    if active and active != armature_obj:
        current = active
        seen = set()
        while current and current not in seen:
            seen.add(current)
            if getattr(current, "parent", None) == armature_obj:
                return _branch_root(active)
            current = getattr(current, "parent", None)

    for obj in getattr(context, "selected_objects", []) or []:
        if not obj or obj == armature_obj:
            continue
        current = obj
        seen = set()
        while current and current not in seen:
            seen.add(current)
            if getattr(current, "parent", None) == armature_obj:
                return _branch_root(obj)
            current = getattr(current, "parent", None)

    children = [child for child in getattr(armature_obj, "children", []) or [] if getattr(child, "type", "") != "ARMATURE"]
    if len(children) == 1:
        return children[0]
    return None


def collect_armature_linked_objects(scene, armature_obj, branch_root=None):
    if not scene or not armature_obj:
        return []

    linked = []
    seen = set()

    if branch_root is not None:
        _collect_object_subtree(branch_root, linked, seen)
        return linked

    for child in getattr(armature_obj, "children", []) or []:
        _collect_object_subtree(child, linked, seen)

    for obj in getattr(scene, "objects", []) or []:
        if not obj or obj == armature_obj or getattr(obj, "type", "") == "ARMATURE":
            continue
        if obj.name in seen:
            continue

        is_linked = False
        current = getattr(obj, "parent", None)
        while current is not None:
            if current == armature_obj:
                is_linked = True
                break
            current = getattr(current, "parent", None)
        if not is_linked:
            for mod in getattr(obj, "modifiers", []) or []:
                if getattr(mod, "type", "") == "ARMATURE" and getattr(mod, "object", None) == armature_obj:
                    is_linked = True
                    break
        if not is_linked:
            try:
                found = obj.find_armature() if hasattr(obj, "find_armature") else None
                is_linked = (found == armature_obj)
            except Exception:
                is_linked = False

        if is_linked:
            _collect_object_subtree(obj, linked, seen)
    return linked


def is_armature_mesh_container(obj):
    if not obj or getattr(obj, "type", "") == "ARMATURE":
        return False
    name = str(getattr(obj, "name", "") or "").strip().lower()
    return bool(name.endswith(".mesh"))


def armature_mesh_container_object(armature_obj):
    if not armature_obj or getattr(armature_obj, "type", "") != "ARMATURE":
        return None

    exact_name = f"{armature_obj.name}.mesh"
    exact = bpy.data.objects.get(exact_name)
    if exact and getattr(exact, "parent", None) == armature_obj:
        return exact

    candidates = []
    for child in getattr(armature_obj, "children", []) or []:
        if is_armature_mesh_container(child):
            candidates.append(child)

    if not candidates:
        return None

    exact_lower = exact_name.lower()
    for child in candidates:
        if strip_blender_duplicate_suffix(child.name).lower() == exact_lower:
            return child

    if len(candidates) == 1:
        return candidates[0]
    return None


def strip_blender_duplicate_suffix(name):
    text = str(name or "")
    return re.sub(r"\.\d{3}$", "", text)


_MESH_LIST_CACHE = None
_MESH_LIST_CACHE_MTIME = -1.0


def addon_package_dir():
    current = os.path.abspath(os.path.dirname(__file__))
    visited = set()
    while current and current not in visited:
        visited.add(current)
        if os.path.basename(current).lower() == "gta000tools":
            return current
        parent = os.path.dirname(current)
        if parent == current:
            break
        current = parent
    return os.path.abspath(os.path.dirname(__file__))



def addon_project_dir():
    return os.path.abspath(os.path.join(addon_package_dir(), os.pardir))



def mesh_list_reference_path():
    return os.path.join(addon_project_dir(), "References", "mesh_list.txt")



def load_mesh_list_definitions(force=False):
    global _MESH_LIST_CACHE, _MESH_LIST_CACHE_MTIME
    path = mesh_list_reference_path()
    try:
        mtime = os.path.getmtime(path)
    except Exception:
        mtime = -1.0
    if (not force) and _MESH_LIST_CACHE is not None and mtime == _MESH_LIST_CACHE_MTIME:
        return _MESH_LIST_CACHE

    groups = {}
    order = []
    if os.path.exists(path):
        try:
            with open(path, 'r', encoding='utf-8') as handle:
                for raw_line in handle:
                    line = str(raw_line or '').strip()
                    if not line:
                        continue
                    if line.lower().startswith('group name'):
                        continue
                    parts = [part.strip() for part in line.split('	')]
                    if len(parts) < 2:
                        parts = [part.strip() for part in re.split(r'\s{2,}', line) if part.strip()]
                    if len(parts) < 2:
                        continue
                    group_name = str(parts[0] or '').strip()
                    mesh_name = str(parts[1] or '').strip()
                    if not group_name or not mesh_name:
                        continue
                    if group_name not in groups:
                        groups[group_name] = []
                        order.append(group_name)
                    if mesh_name not in groups[group_name]:
                        groups[group_name].append(mesh_name)
        except Exception:
            groups = {}
            order = []

    _MESH_LIST_CACHE = (order, groups)
    _MESH_LIST_CACHE_MTIME = mtime
    return _MESH_LIST_CACHE



def mesh_list_group_names():
    order, _groups = load_mesh_list_definitions()
    return list(order or [])



def mesh_list_names_for_group(group_name):
    _order, groups = load_mesh_list_definitions()
    return list(groups.get(str(group_name or '').strip(), []) or [])



def infer_mesh_list_group_for_name(name):
    needle = strip_blender_duplicate_suffix(name).strip().lower()
    if not needle:
        return ''
    order, groups = load_mesh_list_definitions()
    for group_name in order:
        for item_name in groups.get(group_name, []) or []:
            if str(item_name or '').strip().lower() == needle:
                return group_name
    return order[0] if order else ''



def mesh_rename_group_items(self, context):
    groups = mesh_list_group_names()
    if not groups:
        return [('__NONE__', '(No groups found)', '')]
    return [(name, name, f'Select a target name from {name}') for name in groups]



def scene_object_by_name(scene, name):
    if not scene or not name:
        return None
    obj = bpy.data.objects.get(str(name))
    if obj is None:
        return None
    scene_names = {item.name for item in getattr(scene, 'objects', []) or []}
    return obj if obj.name in scene_names else None



def mesh_rename_name_exists_in_scene(scene, target_name, exclude_obj=None):
    obj = scene_object_by_name(scene, target_name)
    if not obj:
        return False
    return obj != exclude_obj



def mesh_rename_name_items(self, context):
    scene = getattr(context, 'scene', None) if context else getattr(bpy.context, 'scene', None)
    active = getattr(context, 'active_object', None) if context else getattr(bpy.context, 'active_object', None)
    group_name = str(getattr(self, 'group_name', '') or infer_mesh_list_group_for_name(getattr(active, 'name', '')))
    names = mesh_list_names_for_group(group_name)
    if not names:
        return [('__NONE__', '(No names found)', '')]
    items = []
    for item_name in names:
        exists = mesh_rename_name_exists_in_scene(scene, item_name, exclude_obj=active)
        label = f'? {item_name}' if exists else item_name
        desc = 'Name already exists in the current scene' if exists else 'Name is available in the current scene'
        items.append((item_name, label, desc))
    return items



def mesh_rename_target_status(scene, active_obj, target_name):
    target = str(target_name or '').strip()
    if not target or target == '__NONE__':
        return 'Choose a target name', 'INFO'
    existing = scene_object_by_name(scene, target)
    if existing and existing == active_obj:
        return 'The selected object already uses this name', 'CHECKMARK'
    if existing is not None:
        return 'This name already exists in the scene', 'CHECKMARK'
    return 'This name is available', 'CHECKMARK'


RENAME_TARGET_KIND_MESH = "MESH"
RENAME_TARGET_KIND_BONE = "BONE"
RENAME_LOD_SUFFIXES = (
    "_very_high",
    "_veryhigh",
    "_vhigh",
    "_high",
    "_hi",
    "_medium",
    "_med",
    "_low",
    "_very_low",
    "_verylow",
    "_vlow",
)


def rename_target_token(kind, primary_name, secondary_name=""):
    kind = str(kind or "").strip().upper()
    primary_name = str(primary_name or "").strip()
    secondary_name = str(secondary_name or "").strip()
    if kind == RENAME_TARGET_KIND_BONE:
        return f"{kind}|{primary_name}|{secondary_name}"
    return f"{RENAME_TARGET_KIND_MESH}|{primary_name}"


def parse_rename_target_token(token):
    raw = str(token or "").strip()
    if not raw:
        return "", "", ""
    parts = raw.split("|", 2)
    if len(parts) == 1:
        return RENAME_TARGET_KIND_MESH, parts[0], ""
    if parts[0] == RENAME_TARGET_KIND_BONE:
        arm_name = parts[1] if len(parts) > 1 else ""
        bone_name = parts[2] if len(parts) > 2 else ""
        return RENAME_TARGET_KIND_BONE, arm_name, bone_name
    return RENAME_TARGET_KIND_MESH, parts[1] if len(parts) > 1 else parts[0], ""


def split_blender_duplicate_suffix_name(name):
    text = str(name or "")
    match = re.match(r"^(.*?)(\.\d{3})$", text)
    if match:
        return match.group(1), match.group(2)
    return text, ""


def split_lod_suffix_name(name):
    base_name, duplicate_suffix = split_blender_duplicate_suffix_name(name)
    lowered = base_name.lower()
    for suffix in sorted(RENAME_LOD_SUFFIXES, key=len, reverse=True):
        if lowered.endswith(suffix):
            return base_name[:-len(suffix)], base_name[-len(suffix):] + duplicate_suffix
    return base_name, duplicate_suffix


def rename_variant_name(old_name, root_old_name, root_new_name):
    base_name, duplicate_suffix = split_blender_duplicate_suffix_name(old_name)
    split_base, lod_suffix = split_lod_suffix_name(base_name)
    if str(split_base or "").strip().lower() == str(root_old_name or "").strip().lower() and lod_suffix:
        return f"{root_new_name}{lod_suffix}{duplicate_suffix}"
    return f"{root_new_name}{duplicate_suffix}" if base_name == root_old_name else root_new_name


def candidate_rename_armatures(scene, s=None, context=None):
    scene = scene or getattr(bpy.context, "scene", None)
    context = context or bpy.context
    arms = []
    seen = set()

    def add_arm(obj):
        if not obj or getattr(obj, "type", "") != "ARMATURE":
            return
        if scene and getattr(obj, "name", "") not in {item.name for item in getattr(scene, "objects", []) or []}:
            return
        if obj.name in seen:
            return
        seen.add(obj.name)
        arms.append(obj)

    try:
        add_arm(selected_armature_from_context(context, scene=scene, s=s))
    except Exception:
        pass
    arm_name = str(getattr(s, "armature_name", "") or "") if s else ""
    if arm_name:
        add_arm(bpy.data.objects.get(arm_name))
    if not arms and scene:
        for obj in getattr(scene, "objects", []) or []:
            if getattr(obj, "type", "") == "ARMATURE":
                add_arm(obj)
    return arms


def relevant_rename_bone_names(scene, armature_obj):
    names = set()
    if not armature_obj or getattr(armature_obj, "type", "") != "ARMATURE":
        return []
    reference_names = {str(name or "").strip().lower() for name in sum((mesh_list_names_for_group(group) for group in mesh_list_group_names()), [])}
    for obj in getattr(scene, "objects", []) or []:
        if not object_related_to_armature(obj, armature_obj):
            continue
        if getattr(obj, "parent", None) == armature_obj and getattr(obj, "parent_type", "") == "BONE" and getattr(obj, "parent_bone", ""):
            names.add(str(obj.parent_bone))
        for vg in getattr(obj, "vertex_groups", []) or []:
            vg_name = str(getattr(vg, "name", "") or "").strip()
            if not vg_name:
                continue
            if getattr(armature_obj.data, "bones", None) and armature_obj.data.bones.get(vg_name):
                names.add(vg_name)
    for bone in getattr(getattr(armature_obj, "data", None), "bones", []) or []:
        bone_name = str(getattr(bone, "name", "") or "").strip()
        if not bone_name:
            continue
        if names or bone_name.lower() in reference_names or bone_name.lower().startswith(("siren", "extra_", "door_", "window_", "boot", "bonnet", "bumper_", "wheel_", "chassis", "bodyshell")):
            names.add(bone_name)
    return sorted(names, key=lambda item: item.lower())


def relevant_rename_mesh_objects(scene, armatures=None):
    armatures = [arm for arm in (armatures or []) if arm is not None]
    result = []
    seen = set()
    for obj in getattr(scene, "objects", []) or []:
        if getattr(obj, "type", "") != "MESH":
            continue
        if armatures and not any(object_related_to_armature(obj, arm) for arm in armatures):
            continue
        if obj.name in seen:
            continue
        seen.add(obj.name)
        result.append(obj)
    if result:
        return sorted(result, key=lambda item: str(getattr(item, "name", "") or "").lower())
    return sorted([obj for obj in getattr(scene, "objects", []) or [] if getattr(obj, "type", "") == "MESH"], key=lambda item: str(getattr(item, "name", "") or "").lower())


def scene_rename_target_items(self, context):
    scene = getattr(context, "scene", None) if context else getattr(bpy.context, "scene", None)
    s = getattr(scene, "nels", None) if scene else getattr(getattr(bpy.context, "scene", None), "nels", None)
    if not scene:
        return [("__NONE__", "(No scene items found)", "")]

    active_obj = getattr(context, "active_object", None) if context else getattr(bpy.context, "active_object", None)
    active_bone_name = ""
    try:
        active_bone_name = str(selected_bone_name_from_context(context or bpy.context) or "")
    except Exception:
        active_bone_name = ""

    armatures = candidate_rename_armatures(scene, s=s, context=context or bpy.context)
    items = []
    for obj in relevant_rename_mesh_objects(scene, armatures=armatures):
        token = rename_target_token(RENAME_TARGET_KIND_MESH, obj.name)
        label = f"MESH: {obj.name}"
        desc = f"Rename mesh object {obj.name} and its linked data safely"
        sort_key = (0 if obj == active_obj else 1, label.lower())
        items.append((sort_key, (token, label, desc)))

    for armature_obj in armatures:
        for bone_name in relevant_rename_bone_names(scene, armature_obj):
            token = rename_target_token(RENAME_TARGET_KIND_BONE, armature_obj.name, bone_name)
            label = f"BONE: {bone_name}"
            desc = f"Rename bone {bone_name} on {armature_obj.name} and its linked data safely"
            sort_key = (0 if bone_name == active_bone_name else 1, label.lower(), armature_obj.name.lower())
            items.append((sort_key, (token, label, desc)))

    if not items:
        return [("__NONE__", "(No scene items found)", "")]
    items.sort(key=lambda entry: entry[0])
    return [entry[1] for entry in items]


def resolve_scene_rename_target(scene, s, token):
    kind, primary_name, secondary_name = parse_rename_target_token(token)
    if kind == RENAME_TARGET_KIND_MESH:
        obj = scene_object_by_name(scene, primary_name)
        if not obj or getattr(obj, "type", "") != "MESH":
            return None
        armature_obj, linked_bone_name = linked_bone_for_object(scene, s, obj)
        return {
            "kind": RENAME_TARGET_KIND_MESH,
            "name": str(obj.name),
            "label": f"MESH: {obj.name}",
            "object": obj,
            "armature": armature_obj,
            "bone_name": str(linked_bone_name or ""),
        }
    if kind == RENAME_TARGET_KIND_BONE:
        armature_obj = scene_object_by_name(scene, primary_name) or bpy.data.objects.get(primary_name)
        if not armature_obj or getattr(armature_obj, "type", "") != "ARMATURE":
            return None
        bone_name = str(secondary_name or "").strip()
        if not bone_name:
            return None
        bones = getattr(getattr(armature_obj, "data", None), "bones", None)
        if not bones or not bones.get(bone_name):
            return None
        return {
            "kind": RENAME_TARGET_KIND_BONE,
            "name": bone_name,
            "label": f"BONE: {bone_name}",
            "object": None,
            "armature": armature_obj,
            "bone_name": bone_name,
        }
    return None


def rename_options_from_settings(s):
    return {
        "rename_vertex_groups": bool(getattr(s, "rename_include_vertex_groups", True)),
        "rename_linked_bones": bool(getattr(s, "rename_include_linked_bones", True)),
        "rename_lods": bool(getattr(s, "rename_include_lods", True)),
        "rename_mesh_data": bool(getattr(s, "rename_include_mesh_data", True)),
        "rename_shape_keys": bool(getattr(s, "rename_include_shape_keys", True)),
        "rename_custom_props": bool(getattr(s, "rename_include_custom_props", True)),
        "dry_run": bool(getattr(s, "rename_dry_run", False)),
    }


def related_mesh_object_renames(scene, armature_obj, root_old_name, root_new_name, selected_obj=None, include_lods=True):
    renames = []
    root_old_lower = str(root_old_name or "").strip().lower()
    if not root_old_lower:
        return renames
    for obj in getattr(scene, "objects", []) or []:
        if getattr(obj, "type", "") != "MESH":
            continue
        if armature_obj and not object_related_to_armature(obj, armature_obj) and obj != selected_obj:
            continue
        obj_name = str(getattr(obj, "name", "") or "")
        base_name, _duplicate_suffix = split_blender_duplicate_suffix_name(obj_name)
        split_base, lod_suffix = split_lod_suffix_name(base_name)
        matches_exact = obj_name.lower() == root_old_lower
        matches_lod = include_lods and str(split_base or "").strip().lower() == root_old_lower and bool(lod_suffix)
        if obj == selected_obj or matches_exact or matches_lod:
            new_name = rename_variant_name(obj_name, root_old_name, root_new_name) if (matches_lod or obj == selected_obj or matches_exact) else root_new_name
            renames.append((obj, obj_name, new_name))
    seen = set()
    unique = []
    for obj, old_name, new_name in renames:
        if obj in seen:
            continue
        seen.add(obj)
        unique.append((obj, old_name, new_name))
    return unique


def related_object_name_variants(scene, old_name, armature_obj=None):
    variants = {}
    old_lower = str(old_name or "").strip().lower()
    for obj in getattr(scene, "objects", []) or []:
        if getattr(obj, "type", "") != "MESH":
            continue
        if armature_obj and not object_related_to_armature(obj, armature_obj):
            continue
        base_name, _duplicate_suffix = split_blender_duplicate_suffix_name(obj.name)
        split_base, lod_suffix = split_lod_suffix_name(base_name)
        if obj.name.lower() == old_lower or (str(split_base or "").strip().lower() == old_lower and lod_suffix):
            variants[obj.name] = obj
    return variants


def collect_shape_key_rename_steps(object_renames, root_old_name, root_new_name, include_shape_keys=True):
    updates = []
    if not include_shape_keys:
        return updates
    for obj, old_object_name, new_object_name in object_renames:
        data = getattr(obj, "data", None)
        shape_keys = getattr(data, "shape_keys", None)
        key_blocks = getattr(shape_keys, "key_blocks", None)
        if not key_blocks:
            continue
        for key_block in key_blocks:
            old_key_name = str(getattr(key_block, "name", "") or "")
            if old_key_name != old_object_name and old_key_name != root_old_name:
                continue
            desired = new_object_name if old_key_name == old_object_name else root_new_name
            if desired == old_key_name:
                continue
            existing = key_blocks.get(desired)
            if existing and existing != key_block:
                continue
            updates.append((obj, key_block, old_key_name, desired))
    return updates


def collect_rna_string_property_updates(owner, old_name, new_name, ignore_identifiers=None):
    updates = []
    old_name = str(old_name or "")
    new_name = str(new_name or "")
    ignore = {"rna_type", "name", "type", "bl_idname"}
    ignore.update(set(ignore_identifiers or []))
    if not owner or not old_name or old_name == new_name:
        return updates
    try:
        props = getattr(owner, "bl_rna", None).properties
    except Exception:
        return updates
    for prop in props:
        identifier = str(getattr(prop, "identifier", "") or "")
        if not identifier or identifier in ignore:
            continue
        if getattr(prop, "type", "") != "STRING" or getattr(prop, "is_readonly", False):
            continue
        try:
            value = getattr(owner, identifier)
        except Exception:
            continue
        if str(value or "") != old_name:
            continue
        updates.append((owner, identifier, old_name, new_name))
    return updates


def collect_scene_constraint_updates(scene, armature_obj, old_name, new_name):
    updates = []
    for obj in getattr(scene, "objects", []) or []:
        for constraint in getattr(obj, "constraints", []) or []:
            updates.extend(collect_rna_string_property_updates(constraint, old_name, new_name))
        if getattr(obj, "type", "") == "ARMATURE":
            for pose_bone in getattr(getattr(obj, "pose", None), "bones", []) or []:
                for constraint in getattr(pose_bone, "constraints", []) or []:
                    if armature_obj and getattr(constraint, "target", None) not in (None, armature_obj):
                        continue
                    updates.extend(collect_rna_string_property_updates(constraint, old_name, new_name))
    return updates


def collect_scene_modifier_updates(scene, armature_obj, old_name, new_name):
    updates = []
    for obj in getattr(scene, "objects", []) or []:
        if armature_obj and not object_related_to_armature(obj, armature_obj):
            continue
        for modifier in getattr(obj, "modifiers", []) or []:
            updates.extend(collect_rna_string_property_updates(modifier, old_name, new_name))
    return updates


def collect_custom_property_updates_for_owner(owner, old_name, new_name):
    updates = []
    if owner is None:
        return updates

    def walk(container, label):
        if hasattr(container, "items"):
            try:
                entries = list(container.items())
            except Exception:
                entries = []
            for key, value in entries:
                next_label = f"{label}[{key}]"
                if isinstance(value, str):
                    if value == old_name:
                        updates.append((container, key, old_name, new_name, next_label))
                else:
                    walk(value, next_label)
            return
        if isinstance(container, list):
            for index, value in enumerate(list(container)):
                next_label = f"{label}[{index}]"
                if isinstance(value, str):
                    if value == old_name:
                        updates.append((container, index, old_name, new_name, next_label))
                else:
                    walk(value, next_label)

    walk(owner, getattr(owner, "name", owner.__class__.__name__))
    return updates


def collect_scene_custom_property_updates(scene, related_objects, related_armatures, old_name, new_name):
    updates = []
    owners = set()
    if scene is not None:
        owners.add(scene)
    for obj in related_objects or []:
        owners.add(obj)
        data = getattr(obj, "data", None)
        if data is not None:
            owners.add(data)
        for slot in getattr(obj, "material_slots", []) or []:
            material = getattr(slot, "material", None)
            if material is not None:
                owners.add(material)
    for arm in related_armatures or []:
        owners.add(arm)
        data = getattr(arm, "data", None)
        if data is not None:
            owners.add(data)
    for owner in owners:
        updates.extend(collect_custom_property_updates_for_owner(owner, old_name, new_name))
    return updates


def build_safe_scene_rename_plan(scene, s, target_info, new_name, options=None):
    options = dict(options or {})
    plan = {
        "target_info": target_info,
        "new_name": str(new_name or "").strip(),
        "object_renames": [],
        "bone_renames": [],
        "mesh_data_renames": [],
        "vertex_group_renames": [],
        "constraint_updates": [],
        "modifier_updates": [],
        "shape_key_renames": [],
        "custom_property_updates": [],
        "link_ref_updates": [],
        "warnings": [],
        "errors": [],
    }
    if not scene or not target_info:
        plan["errors"].append("Choose an existing mesh or bone first.")
        return plan

    target_name = str(target_info.get("name", "") or "").strip()
    target_kind = str(target_info.get("kind", "") or "")
    new_name = str(plan["new_name"] or "").strip()
    if not new_name:
        plan["errors"].append("Enter a new name.")
        return plan
    if new_name == "__NONE__":
        plan["errors"].append("Choose a valid new name.")
        return plan
    if new_name == target_name:
        plan["warnings"].append(f"{target_name} already uses that name.")
        return plan

    armature_obj = target_info.get("armature")
    related_objects = set()
    related_armatures = set()

    object_renames = []
    if target_kind == RENAME_TARGET_KIND_MESH:
        selected_obj = target_info.get("object")
        if not selected_obj or getattr(selected_obj, "type", "") != "MESH":
            plan["errors"].append("The selected rename target mesh could not be resolved.")
            return plan
        object_renames = related_mesh_object_renames(
            scene,
            armature_obj,
            target_name,
            new_name,
            selected_obj=selected_obj,
            include_lods=bool(options.get("rename_lods", True)),
        )
        related_objects.update(obj for obj, _old, _new in object_renames)
        if armature_obj:
            related_armatures.add(armature_obj)
        linked_bone_name = str(target_info.get("bone_name", "") or "").strip()
        if bool(options.get("rename_linked_bones", True)) and armature_obj and linked_bone_name and strip_blender_duplicate_suffix(linked_bone_name).lower() == strip_blender_duplicate_suffix(target_name).lower():
            plan["bone_renames"].append((armature_obj, linked_bone_name, new_name))
    elif target_kind == RENAME_TARGET_KIND_BONE:
        if not armature_obj or getattr(armature_obj, "type", "") != "ARMATURE":
            plan["errors"].append("The selected rename target bone could not be resolved.")
            return plan
        related_armatures.add(armature_obj)
        plan["bone_renames"].append((armature_obj, target_name, new_name))
        object_renames = related_mesh_object_renames(
            scene,
            armature_obj,
            target_name,
            new_name,
            selected_obj=None,
            include_lods=bool(options.get("rename_lods", True)),
        )
        related_objects.update(obj for obj, _old, _new in object_renames)
    else:
        plan["errors"].append("Choose a mesh or bone target first.")
        return plan

    seen_objects = set()
    for obj, old_object_name, desired_name in object_renames:
        if obj in seen_objects:
            continue
        seen_objects.add(obj)
        existing_obj = scene_object_by_name(scene, desired_name)
        if existing_obj and existing_obj not in seen_objects and existing_obj != obj:
            plan["errors"].append(f"Object '{desired_name}' already exists in the current scene.")
            continue
        plan["object_renames"].append((obj, old_object_name, desired_name))

    for armature_obj, old_bone_name, desired_name in list(plan["bone_renames"]):
        bones = getattr(getattr(armature_obj, "data", None), "bones", None)
        existing_bone = bones.get(desired_name) if bones else None
        if existing_bone and existing_bone.name != old_bone_name:
            plan["errors"].append(f"Bone '{desired_name}' already exists on {armature_obj.name}.")

    if plan["errors"]:
        return plan

    if bool(options.get("rename_mesh_data", True)):
        data_targets = {}
        data_source_names = {}
        for obj, old_object_name, desired_name in plan["object_renames"]:
            data = getattr(obj, "data", None)
            if data is None or not hasattr(data, "name"):
                continue
            old_data_name = str(getattr(data, "name", "") or "")
            if old_data_name not in {old_object_name, target_name, rename_variant_name(old_object_name, target_name, target_name)}:
                continue
            current_target = data_targets.get(data)
            if current_target and current_target != desired_name:
                plan["warnings"].append(f"Skipped mesh datablock rename for shared mesh '{old_data_name}' because it is used by multiple renamed objects.")
                data_targets[data] = None
                continue
            data_targets[data] = desired_name
            data_source_names.setdefault(data, old_data_name)
        for data, desired_name in data_targets.items():
            if not desired_name:
                continue
            old_data_name = data_source_names.get(data, str(getattr(data, "name", "") or ""))
            if old_data_name != desired_name:
                plan["mesh_data_renames"].append((data, old_data_name, desired_name))

    for armature_obj, old_bone_name, desired_name in plan["bone_renames"]:
        if bool(options.get("rename_vertex_groups", True)):
            for obj in getattr(scene, "objects", []) or []:
                if getattr(obj, "type", "") != "MESH":
                    continue
                if not object_related_to_armature(obj, armature_obj):
                    continue
                vg = getattr(obj, "vertex_groups", None)
                if vg is None:
                    continue
                source_group = vg.get(old_bone_name)
                if source_group is None:
                    continue
                if vg.get(desired_name) is not None and vg.get(desired_name) != source_group:
                    plan["errors"].append(f"Object '{obj.name}' already has a vertex group named '{desired_name}'.")
                    continue
                plan["vertex_group_renames"].append((obj, source_group, old_bone_name, desired_name))
        plan["constraint_updates"].extend(collect_scene_constraint_updates(scene, armature_obj, old_bone_name, desired_name))
        plan["modifier_updates"].extend(collect_scene_modifier_updates(scene, armature_obj, old_bone_name, desired_name))
        if bool(options.get("rename_custom_props", True)):
            plan["custom_property_updates"].extend(collect_scene_custom_property_updates(scene, related_objects or set(scene.objects), related_armatures or {armature_obj}, old_bone_name, desired_name))
        plan["link_ref_updates"].append({
            "old_object_name": "",
            "new_object_name": "",
            "old_bone_name": old_bone_name,
            "new_bone_name": desired_name,
        })

    if bool(options.get("rename_shape_keys", True)):
        plan["shape_key_renames"].extend(collect_shape_key_rename_steps(plan["object_renames"], target_name, new_name, include_shape_keys=True))

    for obj, old_object_name, desired_name in plan["object_renames"]:
        if bool(options.get("rename_custom_props", True)):
            plan["custom_property_updates"].extend(collect_scene_custom_property_updates(scene, related_objects or set(scene.objects), related_armatures, old_object_name, desired_name))
        plan["link_ref_updates"].append({
            "old_object_name": old_object_name,
            "new_object_name": desired_name,
            "old_bone_name": "",
            "new_bone_name": "",
        })

    dedup_keyed = {}
    for owner, identifier, old_value, desired_value in plan["constraint_updates"] + plan["modifier_updates"]:
        key = (id(owner), identifier, old_value, desired_value)
        dedup_keyed[key] = (owner, identifier, old_value, desired_value)
    plan["constraint_updates"] = []
    plan["modifier_updates"] = []
    for owner, identifier, old_value, desired_value in dedup_keyed.values():
        owner_name = getattr(owner, "name", owner.__class__.__name__)
        if owner.__class__.__name__.lower().endswith("constraint"):
            plan["constraint_updates"].append((owner, identifier, old_value, desired_value))
        else:
            plan["modifier_updates"].append((owner, identifier, old_value, desired_value))

    if plan["errors"]:
        return plan
    return plan


def summarize_safe_scene_rename_plan(plan, max_lines=16):
    if not plan:
        return []
    lines = []
    for message in plan.get("errors", []) or []:
        lines.append(f"Error: {message}")
    for message in plan.get("warnings", []) or []:
        lines.append(f"Warning: {message}")
    if plan.get("errors"):
        return lines[:max_lines]
    target_info = plan.get("target_info") or {}
    target_label = str(target_info.get("label", "") or target_info.get("name", "") or "Target")
    new_name = str(plan.get("new_name", "") or "")
    lines.append(f"{target_label} -> {new_name}")
    for _obj, old_name, desired_name in plan.get("object_renames", [])[:max_lines]:
        lines.append(f"Object: {old_name} -> {desired_name}")
    for _arm, old_name, desired_name in plan.get("bone_renames", [])[:max_lines]:
        lines.append(f"Bone: {old_name} -> {desired_name}")
    if plan.get("mesh_data_renames"):
        lines.append(f"Mesh datablocks: {len(plan['mesh_data_renames'])}")
    if plan.get("vertex_group_renames"):
        lines.append(f"Vertex groups: {len(plan['vertex_group_renames'])}")
    if plan.get("constraint_updates"):
        lines.append(f"Constraints: {len(plan['constraint_updates'])}")
    if plan.get("modifier_updates"):
        lines.append(f"Modifiers: {len(plan['modifier_updates'])}")
    if plan.get("shape_key_renames"):
        lines.append(f"Shape keys: {len(plan['shape_key_renames'])}")
    if plan.get("custom_property_updates"):
        lines.append(f"Custom properties: {len(plan['custom_property_updates'])}")
    if plan.get("link_ref_updates"):
        lines.append(f"GTA 000 links: {len(plan['link_ref_updates'])}")
    return lines[:max_lines]


def safe_scene_rename_preview(scene, s, target_token, new_name, options=None):
    target_info = resolve_scene_rename_target(scene, s, target_token)
    if not target_info:
        return None, ["Choose an existing mesh or bone first."]
    plan = build_safe_scene_rename_plan(scene, s, target_info, new_name, options=options)
    return plan, summarize_safe_scene_rename_plan(plan)


def object_related_to_armature(obj, armature_obj):
    if not obj or not armature_obj:
        return False
    current = obj
    seen = set()
    while current and current not in seen:
        seen.add(current)
        if current == armature_obj:
            return True
        current = getattr(current, "parent", None)
    for mod in getattr(obj, "modifiers", []) or []:
        if getattr(mod, "type", "") == "ARMATURE" and getattr(mod, "object", None) == armature_obj:
            return True
    try:
        found = obj.find_armature() if hasattr(obj, "find_armature") else None
        if found == armature_obj:
            return True
    except Exception:
        pass
    return False


def cleanup_duplicate_mesh_suffixes(scene, selected_only=False):
    objects = []
    if selected_only and scene:
        try:
            objects = [obj for obj in bpy.context.selected_objects if obj and getattr(obj, "type", "") == "MESH"]
        except Exception:
            objects = []
    if not objects and scene:
        objects = [obj for obj in scene.objects if obj and getattr(obj, "type", "") == "MESH"]

    renamed = []
    for obj in sorted(objects, key=lambda item: str(getattr(item, "name", "")).lower()):
        name = str(getattr(obj, "name", "") or "")
        base = strip_blender_duplicate_suffix(name)
        if base == name:
            continue
        existing = bpy.data.objects.get(base)
        if existing and existing != obj:
            continue
        try:
            old_name = obj.name
            obj.name = base
            renamed.append((old_name, base))
        except Exception:
            pass
    return renamed



def rename_armature_bone(scene, armature_obj, old_name, new_name):
    old_name = str(old_name or '').strip()
    new_name = str(new_name or '').strip()
    if not armature_obj or getattr(armature_obj, 'type', '') != 'ARMATURE':
        return False, 'No linked armature was found'
    if not old_name:
        return False, 'No linked bone was found to rename'
    if old_name == new_name:
        return True, ''
    existing = getattr(getattr(armature_obj, 'data', None), 'bones', None)
    if not existing or old_name not in existing:
        return False, f"Bone '{old_name}' was not found on {armature_obj.name}"
    if new_name in existing and new_name != old_name:
        return False, f"Bone '{new_name}' already exists on {armature_obj.name}"

    child_links = capture_bone_parent_links(scene, armature_obj, [old_name])
    old_active = getattr(getattr(bpy.context, 'view_layer', None), 'objects', None)
    old_active = getattr(old_active, 'active', None)
    old_mode = str(getattr(bpy.context, 'mode', 'OBJECT') or 'OBJECT')
    temp_name = f"__nels_rename_{_time.time_ns()}"

    try:
        if old_mode != 'OBJECT':
            bpy.ops.object.mode_set(mode='OBJECT')
        bpy.ops.object.select_all(action='DESELECT')
        armature_obj.select_set(True)
        bpy.context.view_layer.objects.active = armature_obj
        bpy.ops.object.mode_set(mode='EDIT')
        edit_bones = armature_obj.data.edit_bones
        edit_bone = edit_bones.get(old_name)
        if edit_bone is None:
            raise RuntimeError(f"Missing editable bone {old_name}")
        edit_bone.name = temp_name
        edit_bone = edit_bones.get(temp_name)
        if edit_bone is None:
            raise RuntimeError(f"Missing temporary bone {temp_name}")
        edit_bone.name = new_name
        bpy.ops.object.mode_set(mode='OBJECT')
    except Exception as ex:
        try:
            if getattr(bpy.context, 'mode', 'OBJECT') != 'OBJECT':
                bpy.ops.object.mode_set(mode='OBJECT')
        except Exception:
            pass
        return False, f'Could not rename the linked bone: {ex}'
    finally:
        try:
            if old_active and old_active.name in bpy.data.objects:
                bpy.context.view_layer.objects.active = old_active
        except Exception:
            pass
        try:
            if old_mode != 'OBJECT' and getattr(bpy.context, 'mode', 'OBJECT') == 'OBJECT':
                bpy.ops.object.mode_set(mode=old_mode)
        except Exception:
            pass

    restore_bone_parent_links(child_links, {old_name: new_name})
    rename_pose_rest_keys(armature_obj, {old_name: new_name})
    try:
        pb = armature_obj.pose.bones.get(new_name)
        if pb:
            _store_rest_pose_bone(armature_obj, pb, force=True)
    except Exception:
        pass
    return True, ''



def rename_related_vertex_groups(scene, armature_obj, old_name, new_name):
    renamed = 0
    if not scene or not armature_obj or not old_name or not new_name or old_name == new_name:
        return renamed
    for obj in getattr(scene, 'objects', []) or []:
        if getattr(obj, 'type', '') != 'MESH':
            continue
        if not object_related_to_armature(obj, armature_obj):
            continue
        vg = getattr(obj, 'vertex_groups', None)
        if vg is None:
            continue
        source_group = vg.get(old_name)
        if source_group is None:
            continue
        if vg.get(new_name) is not None:
            continue
        try:
            source_group.name = new_name
            renamed += 1
        except Exception:
            pass
    return renamed
def linked_armature_candidates(scene, s, obj):
    candidates = []
    seen = set()

    def add_candidate(arm):
        if not arm or getattr(arm, 'type', '') != 'ARMATURE':
            return
        name = str(getattr(arm, 'name', '') or '')
        if not name or name in seen:
            return
        if scene and name not in getattr(scene, 'objects', {}):
            return
        seen.add(name)
        candidates.append(arm)

    parent = getattr(obj, 'parent', None)
    if parent and getattr(parent, 'type', '') == 'ARMATURE':
        add_candidate(parent)

    try:
        add_candidate(obj.find_armature() if hasattr(obj, 'find_armature') else None)
    except Exception:
        pass

    for mod in getattr(obj, 'modifiers', []) or []:
        if getattr(mod, 'type', '') == 'ARMATURE':
            add_candidate(getattr(mod, 'object', None))

    arm_name = str(getattr(s, 'armature_name', '') or '') if s else ''
    if arm_name:
        add_candidate(bpy.data.objects.get(arm_name))

    if not candidates and scene:
        scene_armatures = [arm for arm in getattr(scene, 'objects', []) or [] if getattr(arm, 'type', '') == 'ARMATURE']
        if len(scene_armatures) == 1:
            add_candidate(scene_armatures[0])

    return candidates


def inferred_bone_name_for_object(scene, s, obj):
    if not obj:
        return None, ''

    for arm in linked_armature_candidates(scene, s, obj):
        bones = getattr(getattr(arm, 'data', None), 'bones', None)
        if not bones:
            continue

        name_candidates = [
            str(getattr(obj, 'name', '') or ''),
            strip_blender_duplicate_suffix(getattr(obj, 'name', '')),
            str(getattr(getattr(obj, 'data', None), 'name', '') or ''),
            strip_blender_duplicate_suffix(getattr(getattr(obj, 'data', None), 'name', '')),
        ]
        seen_names = set()
        for candidate in name_candidates:
            candidate = str(candidate or '').strip()
            if not candidate or candidate in seen_names:
                continue
            seen_names.add(candidate)
            if hasattr(bones, 'get') and bones.get(candidate):
                return arm, candidate

        vg_matches = []
        seen_vg = set()
        for vg in getattr(obj, 'vertex_groups', []) or []:
            vg_name = str(getattr(vg, 'name', '') or '').strip()
            if not vg_name or vg_name in seen_vg:
                continue
            seen_vg.add(vg_name)
            if hasattr(bones, 'get') and bones.get(vg_name):
                vg_matches.append(vg_name)
        if len(vg_matches) == 1:
            return arm, vg_matches[0]

    return None, ''


def linked_bone_for_object(scene, s, obj):
    if not obj:
        return None, ''
    parent = getattr(obj, 'parent', None)
    if parent and getattr(parent, 'type', '') == 'ARMATURE' and getattr(obj, 'parent_type', '') == 'BONE' and getattr(obj, 'parent_bone', ''):
        return parent, str(obj.parent_bone)

    if s and getattr(s, 'sirens', None):
        for si in getattr(s, 'sirens', []) or []:
            linked_obj = siren_obj(si)
            if linked_obj == obj or str(getattr(si, 'object_name', '') or '') == str(getattr(obj, 'name', '') or ''):
                arm, pb = siren_pose_bone(scene, si)
                if arm and pb:
                    return arm, pb.name
                bone_name = str(getattr(si, 'bone_name', '') or '')
                if bone_name and getattr(s, 'armature_name', ''):
                    arm = bpy.data.objects.get(str(getattr(s, 'armature_name', '') or ''))
                    if arm and getattr(arm, 'type', '') == 'ARMATURE':
                        return arm, bone_name

    if s and getattr(s, 'body_openings', None):
        for opening in getattr(s, 'body_openings', []) or []:
            linked_obj = body_opening_obj(opening)
            if linked_obj == obj or str(getattr(opening, 'object_name', '') or '') == str(getattr(obj, 'name', '') or ''):
                arm, pb = body_opening_pose_bone(scene, opening)
                if arm and pb:
                    return arm, pb.name
                bone_name = str(getattr(opening, 'bone_name', '') or '')
                if bone_name and getattr(s, 'armature_name', ''):
                    arm = bpy.data.objects.get(str(getattr(s, 'armature_name', '') or ''))
                    if arm and getattr(arm, 'type', '') == 'ARMATURE':
                        return arm, bone_name

    arm, bone_name = inferred_bone_name_for_object(scene, s, obj)
    if arm and bone_name:
        return arm, bone_name
    return None, ''


def linked_object_is_chassis_target(scene, s, obj):
    if not obj or getattr(obj, "type", "") != "MESH":
        return False

    def _normalized_name(value):
        text = str(value or "").strip()
        if not text:
            return ""
        try:
            root_name, _lod_suffix = split_lod_suffix_name(text)
        except Exception:
            root_name = strip_blender_duplicate_suffix(text)
        return str(root_name or "").strip().lower()

    candidate_names = [
        getattr(obj, "name", ""),
        getattr(getattr(obj, "data", None), "name", ""),
        getattr(obj, "parent_bone", ""),
    ]
    for candidate in candidate_names:
        if _normalized_name(candidate) == "chassis":
            return True

    armature_obj, linked_bone_name = linked_bone_for_object(scene, s, obj)
    del armature_obj
    if _normalized_name(linked_bone_name) == "chassis":
        return True
    return False



def update_link_name_references(s, old_object_name='', new_object_name='', old_bone_name='', new_bone_name=''):
    if not s:
        return
    old_object_name = str(old_object_name or '')
    new_object_name = str(new_object_name or '')
    old_bone_name = str(old_bone_name or '')
    new_bone_name = str(new_bone_name or '')

    for si in getattr(s, 'sirens', []) or []:
        if old_object_name and str(getattr(si, 'object_name', '') or '') == old_object_name:
            si.object_name = new_object_name
        if old_object_name and str(getattr(si, 'anchor_name', '') or '') == old_object_name:
            si.anchor_name = new_object_name
        if old_bone_name and str(getattr(si, 'bone_name', '') or '') == old_bone_name:
            si.bone_name = new_bone_name

    for opening in getattr(s, 'body_openings', []) or []:
        if old_object_name and str(getattr(opening, 'object_name', '') or '') == old_object_name:
            opening.object_name = new_object_name
        if old_object_name and str(getattr(opening, 'anchor_name', '') or '') == old_object_name:
            opening.anchor_name = new_object_name
        if old_bone_name and str(getattr(opening, 'bone_name', '') or '') == old_bone_name:
            opening.bone_name = new_bone_name

    if old_object_name and str(getattr(s, 'tool_origin_object', '') or '') == old_object_name:
        s.tool_origin_object = new_object_name



def apply_safe_scene_rename_plan(scene, s, plan):
    if not plan:
        return False, "Nothing to rename"
    if plan.get("errors"):
        return False, "; ".join(plan.get("errors") or ["Rename plan is invalid"])
    if not (plan.get("object_renames") or plan.get("bone_renames") or plan.get("mesh_data_renames") or plan.get("vertex_group_renames") or plan.get("constraint_updates") or plan.get("modifier_updates") or plan.get("shape_key_renames") or plan.get("custom_property_updates") or plan.get("link_ref_updates")):
        warnings = plan.get("warnings") or []
        return True, warnings[0] if warnings else "No linked data needed renaming"

    undo_actions = []

    def push_undo(callback, *args, **kwargs):
        undo_actions.append((callback, args, kwargs))

    try:
        for armature_obj, old_name, new_name in plan.get("bone_renames", []):
            ok, message = rename_armature_bone(scene, armature_obj, old_name, new_name)
            if not ok:
                raise RuntimeError(message or f"Could not rename bone {old_name}")
            push_undo(rename_armature_bone, scene, armature_obj, new_name, old_name)

        for obj, old_name, new_name in plan.get("object_renames", []):
            obj.name = new_name
            push_undo(setattr, obj, "name", old_name)

        for data, old_name, new_name in plan.get("mesh_data_renames", []):
            data.name = new_name
            push_undo(setattr, data, "name", old_name)

        for _obj, group, old_name, new_name in plan.get("vertex_group_renames", []):
            group.name = new_name
            push_undo(setattr, group, "name", old_name)

        for owner, identifier, old_value, new_value in plan.get("constraint_updates", []):
            setattr(owner, identifier, new_value)
            push_undo(setattr, owner, identifier, old_value)

        for owner, identifier, old_value, new_value in plan.get("modifier_updates", []):
            setattr(owner, identifier, new_value)
            push_undo(setattr, owner, identifier, old_value)

        for _obj, key_block, old_name, new_name in plan.get("shape_key_renames", []):
            key_block.name = new_name
            push_undo(setattr, key_block, "name", old_name)

        for container, key, old_value, new_value, _label in plan.get("custom_property_updates", []):
            container[key] = new_value
            push_undo(lambda c, k, v: c.__setitem__(k, v), container, key, old_value)

        for update in plan.get("link_ref_updates", []):
            update_link_name_references(
                s,
                old_object_name=str(update.get("old_object_name", "") or ""),
                new_object_name=str(update.get("new_object_name", "") or ""),
                old_bone_name=str(update.get("old_bone_name", "") or ""),
                new_bone_name=str(update.get("new_bone_name", "") or ""),
            )
            push_undo(
                update_link_name_references,
                s,
                str(update.get("new_object_name", "") or ""),
                str(update.get("old_object_name", "") or ""),
                str(update.get("new_bone_name", "") or ""),
                str(update.get("old_bone_name", "") or ""),
            )

        for obj, _old_name, _new_name in plan.get("object_renames", []):
            try:
                _store_rest_loc(obj, force=True)
            except Exception:
                pass
        if s:
            try:
                current_target = resolve_scene_rename_target(scene, s, getattr(s, "rename_target", ""))
            except Exception:
                current_target = None
            if current_target and current_target.get("name", "") == plan.get("target_info", {}).get("name", ""):
                s.rename_target = rename_target_token(plan.get("target_info", {}).get("kind", ""), getattr(plan.get("target_info", {}).get("armature", None), "name", "") if plan.get("target_info", {}).get("kind", "") == RENAME_TARGET_KIND_BONE else plan.get("new_name", ""), plan.get("new_name", "") if plan.get("target_info", {}).get("kind", "") == RENAME_TARGET_KIND_BONE else "")
            s.rename_new_name = plan.get("new_name", "")
            s.rename_target_source_name = plan.get("new_name", "")
        parts = []
        if plan.get("object_renames"):
            parts.append(f"{len(plan['object_renames'])} object{'s' if len(plan['object_renames']) != 1 else ''}")
        if plan.get("bone_renames"):
            parts.append(f"{len(plan['bone_renames'])} bone{'s' if len(plan['bone_renames']) != 1 else ''}")
        if plan.get("mesh_data_renames"):
            parts.append(f"{len(plan['mesh_data_renames'])} mesh datablock{'s' if len(plan['mesh_data_renames']) != 1 else ''}")
        if plan.get("vertex_group_renames"):
            parts.append(f"{len(plan['vertex_group_renames'])} vertex group{'s' if len(plan['vertex_group_renames']) != 1 else ''}")
        if plan.get("constraint_updates"):
            parts.append(f"{len(plan['constraint_updates'])} constraint reference{'s' if len(plan['constraint_updates']) != 1 else ''}")
        if plan.get("modifier_updates"):
            parts.append(f"{len(plan['modifier_updates'])} modifier reference{'s' if len(plan['modifier_updates']) != 1 else ''}")
        if plan.get("shape_key_renames"):
            parts.append(f"{len(plan['shape_key_renames'])} shape key{'s' if len(plan['shape_key_renames']) != 1 else ''}")
        if plan.get("custom_property_updates"):
            parts.append(f"{len(plan['custom_property_updates'])} custom propert{'ies' if len(plan['custom_property_updates']) != 1 else 'y'}")
        message = f"Renamed {plan.get('target_info', {}).get('name', 'target')} to {plan.get('new_name', '')}"
        if parts:
            message += f" and updated {', '.join(parts)}"
        return True, message
    except Exception as ex:
        for callback, args, kwargs in reversed(undo_actions):
            try:
                callback(*args, **kwargs)
            except Exception:
                continue
        return False, f"Rename failed: {ex}"


def safe_rename_scene_target(scene, s, target_token, new_name, options=None):
    target_info = resolve_scene_rename_target(scene, s, target_token)
    if not target_info:
        return False, "Choose an existing mesh or bone first."
    plan = build_safe_scene_rename_plan(scene, s, target_info, new_name, options=options)
    if plan.get("errors"):
        return False, "; ".join(plan.get("errors") or ["Rename plan is invalid"])
    if bool(dict(options or {}).get("dry_run", False)):
        return True, "; ".join(summarize_safe_scene_rename_plan(plan))
    return apply_safe_scene_rename_plan(scene, s, plan)


def safe_rename_scene_object(scene, s, obj, new_name, options=None):
    if not scene or not obj:
        return False, "Select an object to rename first"
    token = rename_target_token(RENAME_TARGET_KIND_MESH, getattr(obj, "name", ""))
    return safe_rename_scene_target(scene, s, token, new_name, options=options)


def update_scene_rename_target(self, context):
    scene = getattr(context, "scene", None) if context else getattr(bpy.context, "scene", None)
    s = getattr(scene, "nels", None) if scene else None
    if not s:
        return
    target_info = resolve_scene_rename_target(scene, s, getattr(s, "rename_target", ""))
    source_name = str(target_info.get("name", "") or "") if target_info else ""
    previous_source = str(getattr(s, "rename_target_source_name", "") or "")
    current_new_name = str(getattr(s, "rename_new_name", "") or "")
    if not current_new_name or current_new_name == previous_source:
        s.rename_new_name = source_name
    s.rename_target_source_name = source_name


def rename_selected_vehicle_part(scene, s, obj, new_name):
    options = rename_options_from_settings(s)
    options["dry_run"] = False
    return safe_rename_scene_object(scene, s, obj, new_name, options=options)


def object_hierarchy_depth(obj):
    depth = 0
    current = getattr(obj, "parent", None)
    seen = set()
    while current is not None and current not in seen:
        seen.add(current)
        depth += 1
        current = getattr(current, "parent", None)
    return depth


def selected_bone_name_from_context(context, arm=None):
    active = getattr(context, "active_object", None)
    if arm and active and getattr(active, "parent", None) == arm and getattr(active, "parent_type", "") == "BONE" and getattr(active, "parent_bone", ""):
        return str(active.parent_bone)

    active_pose_bone = getattr(context, "active_pose_bone", None)
    if active_pose_bone and ((not arm) or active == arm):
        return str(active_pose_bone.name)

    active_bone = getattr(context, "active_bone", None)
    if active_bone and ((not arm) or active == arm):
        return str(active_bone.name)

    if active and getattr(active, "parent_type", "") == "BONE" and getattr(active, "parent_bone", ""):
        if (not arm) or getattr(active, "parent", None) == arm:
            return str(active.parent_bone)
    return ""


_ARMATURE_EDIT_BONE_COPY_PROPS = (
    "head_radius",
    "tail_radius",
    "envelope_distance",
    "envelope_weight",
    "use_connect",
    "use_deform",
    "use_inherit_rotation",
    "inherit_scale",
    "use_local_location",
    "use_relative_parent",
    "use_endroll_as_inroll",
    "bbone_segments",
    "bbone_x",
    "bbone_z",
    "bbone_curveinx",
    "bbone_curveiny",
    "bbone_curveoutx",
    "bbone_curveouty",
    "bbone_rollin",
    "bbone_rollout",
    "bbone_easein",
    "bbone_easeout",
    "bbone_scalein",
    "bbone_scaleout",
    "use_cyclic_offset",
    "hide",
)


def _clone_bpy_value(value):
    if isinstance(value, (str, int, float, bool)) or value is None:
        return value
    try:
        return tuple(value)
    except Exception:
        return value


def _copy_id_properties_dict(source):
    data = {}
    if not source:
        return data
    try:
        keys = list(source.keys())
    except Exception:
        return data
    for key in keys:
        try:
            data[str(key)] = _clone_bpy_value(source[key])
        except Exception:
            pass
    return data


def _apply_id_properties(owner, values):
    if not owner or not values:
        return
    for key, value in (values or {}).items():
        try:
            owner[key] = value
        except Exception:
            pass


def _enter_armature_edit_session(armature_obj):
    if not armature_obj or getattr(armature_obj, "type", "") != "ARMATURE":
        return None, "No armature was found"

    view_layer = getattr(bpy.context, "view_layer", None)
    old_active = getattr(getattr(view_layer, "objects", None), "active", None)
    old_mode = str(getattr(bpy.context, "mode", "OBJECT") or "OBJECT")
    old_selected = [obj for obj in getattr(bpy.context, "selected_objects", []) or [] if obj and obj.name in bpy.data.objects]

    try:
        if old_mode != "OBJECT":
            bpy.ops.object.mode_set(mode="OBJECT")
        bpy.ops.object.select_all(action="DESELECT")
        armature_obj.select_set(True)
        bpy.context.view_layer.objects.active = armature_obj
        bpy.ops.object.mode_set(mode="EDIT")
        return {
            "active": old_active,
            "mode": old_mode,
            "selected": old_selected,
        }, ""
    except Exception as ex:
        return None, f"Could not enter Armature Edit Mode: {ex}"


def _restore_armature_edit_session(state):
    if not state:
        return
    try:
        if getattr(bpy.context, "mode", "OBJECT") != "OBJECT":
            bpy.ops.object.mode_set(mode="OBJECT")
    except Exception:
        pass
    try:
        bpy.ops.object.select_all(action="DESELECT")
    except Exception:
        pass
    for obj in state.get("selected", []) or []:
        try:
            if obj and obj.name in bpy.data.objects:
                obj.select_set(True)
        except Exception:
            pass
    try:
        active = state.get("active")
        if active and active.name in bpy.data.objects:
            bpy.context.view_layer.objects.active = active
    except Exception:
        pass
    try:
        target_mode = str(state.get("mode", "OBJECT") or "OBJECT")
        if target_mode != "OBJECT" and getattr(bpy.context, "mode", "OBJECT") == "OBJECT":
            if target_mode.startswith("EDIT"):
                target_mode = "EDIT"
            bpy.ops.object.mode_set(mode=target_mode)
    except Exception:
        pass


def _snapshot_armature_edit_hierarchy(armature_obj):
    edit_bones = getattr(getattr(armature_obj, "data", None), "edit_bones", None)
    if edit_bones is None:
        return [], {}, ""

    order = []
    specs = {}
    active_name = str(getattr(getattr(edit_bones, "active", None), "name", "") or "")
    for eb in list(edit_bones):
        order.append(eb.name)
        spec = {
            "name": eb.name,
            "head": eb.head.copy(),
            "tail": eb.tail.copy(),
            "roll": float(getattr(eb, "roll", 0.0)),
            "parent": str(getattr(getattr(eb, "parent", None), "name", "") or "") or None,
            "select": bool(getattr(eb, "select", False)),
            "select_head": bool(getattr(eb, "select_head", False)),
            "select_tail": bool(getattr(eb, "select_tail", False)),
            "custom_props": _copy_id_properties_dict(eb),
        }
        for prop_name in _ARMATURE_EDIT_BONE_COPY_PROPS:
            if hasattr(eb, prop_name):
                try:
                    spec[prop_name] = _clone_bpy_value(getattr(eb, prop_name))
                except Exception:
                    pass
        specs[eb.name] = spec
    return order, specs, active_name


def _children_by_parent_from_order(order, parent_of):
    children = {}
    for bone_name in order:
        parent_name = parent_of.get(bone_name)
        children.setdefault(parent_name, []).append(bone_name)
        children.setdefault(bone_name, [])
    children.setdefault(None, [])
    return children


def _flatten_bone_hierarchy(children_by_parent, parent_name=None, out=None):
    if out is None:
        out = []
    for bone_name in children_by_parent.get(parent_name, []) or []:
        out.append(bone_name)
        _flatten_bone_hierarchy(children_by_parent, bone_name, out)
    return out


def _bone_descendants(children_by_parent, bone_name):
    result = set()

    def walk(parent_name):
        for child_name in children_by_parent.get(parent_name, []) or []:
            if child_name in result:
                continue
            result.add(child_name)
            walk(child_name)

    walk(bone_name)
    return result


def _rebuild_armature_hierarchy_from_specs(armature_obj, order, specs, parent_of=None, active_bone_name="", preserve_selection=True):
    session, msg = _enter_armature_edit_session(armature_obj)
    if session is None:
        return False, msg

    try:
        edit_bones = armature_obj.data.edit_bones
        current_parent_of = {
            bone_name: str((specs.get(bone_name, {}) or {}).get("parent") or "") or None
            for bone_name in order
        }
        if parent_of:
            current_parent_of.update({name: (str(parent) if parent else None) for name, parent in parent_of.items() if name in specs})

        preserved_selection = {
            bone_name
            for bone_name in order
            if preserve_selection and bool((specs.get(bone_name, {}) or {}).get("select", False))
        }
        if preserve_selection and active_bone_name and active_bone_name not in specs:
            active_bone_name = ""

        for eb in list(edit_bones):
            edit_bones.remove(eb)

        for bone_name in order:
            spec = specs.get(bone_name)
            if not spec:
                continue
            eb = edit_bones.new(bone_name)
            eb.head = spec.get("head", Vector((0.0, 0.0, 0.0)))
            eb.tail = spec.get("tail", Vector((0.0, 1.0, 0.0)))
            eb.roll = float(spec.get("roll", 0.0))
            for prop_name in _ARMATURE_EDIT_BONE_COPY_PROPS:
                if prop_name in {"use_connect"}:
                    continue
                if prop_name not in spec or not hasattr(eb, prop_name):
                    continue
                try:
                    setattr(eb, prop_name, spec[prop_name])
                except Exception:
                    pass
            _apply_id_properties(eb, spec.get("custom_props", {}))

        for bone_name in order:
            eb = edit_bones.get(bone_name)
            spec = specs.get(bone_name, {})
            if not eb:
                continue
            parent_name = current_parent_of.get(bone_name)
            if parent_name:
                parent_eb = edit_bones.get(parent_name)
                if parent_eb:
                    try:
                        eb.parent = parent_eb
                    except Exception:
                        pass
            desired_connect = bool(spec.get("use_connect", False))
            if desired_connect and getattr(eb, "parent", None):
                try:
                    desired_connect = (Vector(eb.head) - Vector(eb.parent.tail)).length <= 0.00001
                except Exception:
                    desired_connect = False
            try:
                eb.use_connect = bool(desired_connect)
            except Exception:
                pass

        if preserve_selection:
            for bone_name in preserved_selection:
                eb = edit_bones.get(bone_name)
                if not eb:
                    continue
                try:
                    eb.select = True
                    eb.select_head = True
                    eb.select_tail = True
                except Exception:
                    pass
            if active_bone_name:
                try:
                    edit_bones.active = edit_bones.get(active_bone_name)
                except Exception:
                    pass

        bpy.ops.object.mode_set(mode="OBJECT")
        try:
            bpy.context.view_layer.update()
        except Exception:
            pass
        for bone_name in order:
            try:
                pb = armature_obj.pose.bones.get(bone_name)
            except Exception:
                pb = None
            if pb:
                try:
                    _store_rest_pose_bone(armature_obj, pb, force=True)
                except Exception:
                    pass
        return True, ""
    except Exception as ex:
        return False, f"Could not rebuild the armature hierarchy: {ex}"
    finally:
        _restore_armature_edit_session(session)


def armature_bone_name_items(self, context):
    scene = getattr(context, "scene", None) if context else getattr(bpy.context, "scene", None)
    armature_name = str(getattr(self, "armature_name", "") or "").strip()
    source_name = str(getattr(self, "source_bone_name", "") or "").strip()
    if not armature_name:
        return [("__NONE__", "(No bones found)", "")]
    armature_obj = bpy.data.objects.get(armature_name)
    if not armature_obj or getattr(armature_obj, "type", "") != "ARMATURE":
        return [("__NONE__", "(No bones found)", "")]
    bones = getattr(getattr(armature_obj, "data", None), "bones", None)
    if not bones:
        return [("__NONE__", "(No bones found)", "")]

    try:
        order = [bone.name for bone in bones]
        parent_of = {bone.name: (bone.parent.name if bone.parent else None) for bone in bones}
        children = _children_by_parent_from_order(order, parent_of)
        descendants = _bone_descendants(children, source_name) if source_name else set()
    except Exception:
        descendants = set()

    items = []
    for bone in bones:
        bone_name = str(getattr(bone, "name", "") or "")
        if not bone_name or bone_name == source_name or bone_name in descendants:
            continue
        items.append((bone_name, bone_name, f"Use {bone_name}"))
    if not items:
        return [("__NONE__", "(No valid bones found)", "")]
    return items


def selected_armature_bone_target(context, scene=None, s=None):
    scene = scene or getattr(context, "scene", None)
    s = s or (getattr(scene, "nels", None) if scene else None)
    armature_obj = selected_armature_from_context(context, scene=scene, s=s)
    if not armature_obj:
        return None, "", "Select an armature or a mesh linked to an armature first"
    bone_name = str(selected_bone_name_from_context(context, arm=armature_obj) or "")
    if not bone_name:
        return armature_obj, "", "Select a bone first"
    bones = getattr(getattr(armature_obj, "data", None), "bones", None)
    if not bones or not bones.get(bone_name):
        return armature_obj, "", f"Bone '{bone_name}' was not found on {armature_obj.name}"
    return armature_obj, bone_name, ""


def bone_mesh_association_names(scene, armature_obj):
    used_names = set()
    if not scene or not armature_obj or getattr(armature_obj, "type", "") != "ARMATURE":
        return used_names

    normalized_object_names = set()
    bones = getattr(getattr(armature_obj, "data", None), "bones", None)
    bone_lookup = bones if bones is not None else {}
    for obj in getattr(scene, "objects", []) or []:
        if getattr(obj, "type", "") != "MESH":
            continue
        if not object_related_to_armature(obj, armature_obj):
            continue
        obj_names = [str(getattr(obj, "name", "") or "")]
        data_name = str(getattr(getattr(obj, "data", None), "name", "") or "")
        if data_name:
            obj_names.append(data_name)
        for raw_name in obj_names:
            base_name = strip_blender_duplicate_suffix(raw_name)
            try:
                split_base, _lod_suffix = split_lod_suffix_name(base_name)
                base_name = str(split_base or base_name)
            except Exception:
                pass
            normalized_object_names.add(base_name.strip().lower())

        if getattr(obj, "parent", None) == armature_obj and getattr(obj, "parent_type", "") == "BONE":
            parent_bone = str(getattr(obj, "parent_bone", "") or "").strip()
            if parent_bone:
                used_names.add(parent_bone)

        for vg in getattr(obj, "vertex_groups", []) or []:
            vg_name = str(getattr(vg, "name", "") or "").strip()
            if vg_name and hasattr(bone_lookup, "get") and bone_lookup.get(vg_name):
                used_names.add(vg_name)

    for bone in getattr(getattr(armature_obj, "data", None), "bones", []) or []:
        bone_name = str(getattr(bone, "name", "") or "").strip()
        if not bone_name:
            continue
        if strip_blender_duplicate_suffix(bone_name).strip().lower() in normalized_object_names:
            used_names.add(bone_name)
    return used_names


def clear_removed_bone_links(scene, removed_names):
    removed = {str(name or "").strip() for name in (removed_names or []) if str(name or "").strip()}
    if not scene or not removed:
        return 0
    s = getattr(scene, "nels", None)
    if not s:
        return 0

    cleared = 0
    for si in getattr(s, "sirens", []) or []:
        if str(getattr(si, "bone_name", "") or "").strip() in removed:
            si.bone_name = ""
            cleared += 1
    for opening in getattr(s, "body_openings", []) or []:
        if str(getattr(opening, "bone_name", "") or "").strip() in removed:
            opening.bone_name = ""
            cleared += 1
    return cleared


def remove_unused_armature_bones(scene, armature_obj):
    if not scene or not armature_obj or getattr(armature_obj, "type", "") != "ARMATURE":
        return False, "No armature was found", []

    bones = list(getattr(getattr(armature_obj, "data", None), "bones", []) or [])
    if not bones:
        return False, f"{armature_obj.name} has no bones to clean", []

    used_names = bone_mesh_association_names(scene, armature_obj)
    order = [bone.name for bone in bones]
    parent_of = {bone.name: (bone.parent.name if bone.parent else None) for bone in bones}
    children = _children_by_parent_from_order(order, parent_of)

    removed = []
    protected = {
        bone.name
        for bone in bones
        if bone.parent is None or str(getattr(bone, "name", "") or "").strip().lower() == "chassis"
    }

    root_children = list(children.get(None, []) or [])
    for bone_name in order:
        if bone_name in protected or bone_name in used_names:
            continue
        parent_name = parent_of.get(bone_name)
        siblings = children.get(parent_name, [])
        child_names = list(children.get(bone_name, []) or [])
        if bone_name in siblings:
            idx = siblings.index(bone_name)
            siblings[idx:idx + 1] = child_names
        for child_name in child_names:
            parent_of[child_name] = parent_name
        children[parent_name] = siblings
        children.pop(bone_name, None)
        parent_of.pop(bone_name, None)
        removed.append(bone_name)

    if not removed:
        return False, f"No removable unused bones were found on {armature_obj.name}", []

    final_order = _flatten_bone_hierarchy(children, None, [])
    session, msg = _enter_armature_edit_session(armature_obj)
    if session is None:
        return False, msg, []
    try:
        edit_order, specs, active_name = _snapshot_armature_edit_hierarchy(armature_obj)
    finally:
        _restore_armature_edit_session(session)
    specs = {name: spec for name, spec in specs.items() if name in final_order}
    ok, msg = _rebuild_armature_hierarchy_from_specs(
        armature_obj,
        final_order,
        specs,
        parent_of=parent_of,
        active_bone_name=active_name if active_name in final_order else "",
        preserve_selection=True,
    )
    if not ok:
        return False, msg, []

    clear_removed_bone_links(scene, removed)
    return True, f"Removed {len(removed)} unused bone{'s' if len(removed) != 1 else ''}", removed


def nest_armature_bone(scene, armature_obj, bone_name, new_parent_name):
    if not armature_obj or getattr(armature_obj, "type", "") != "ARMATURE":
        return False, "No armature was found"
    bone_name = str(bone_name or "").strip()
    new_parent_name = str(new_parent_name or "").strip()
    bones = list(getattr(getattr(armature_obj, "data", None), "bones", []) or [])
    if not bone_name or not new_parent_name:
        return False, "Choose both a bone and a new parent bone"
    if bone_name == new_parent_name:
        return False, "A bone cannot be parented to itself"
    order = [bone.name for bone in bones]
    parent_of = {bone.name: (bone.parent.name if bone.parent else None) for bone in bones}
    children = _children_by_parent_from_order(order, parent_of)
    if bone_name not in parent_of or new_parent_name not in parent_of:
        return False, "The selected bones were not found on the armature"
    if new_parent_name in _bone_descendants(children, bone_name):
        return False, f"{new_parent_name} is a child of {bone_name}. That would create a cycle."

    old_parent = parent_of.get(bone_name)
    old_siblings = children.get(old_parent, [])
    if bone_name in old_siblings:
        old_siblings.remove(bone_name)
    children[old_parent] = old_siblings
    parent_of[bone_name] = new_parent_name
    children.setdefault(new_parent_name, []).append(bone_name)

    final_order = _flatten_bone_hierarchy(children, None, [])
    session, msg = _enter_armature_edit_session(armature_obj)
    if session is None:
        return False, msg
    try:
        _edit_order, specs, active_name = _snapshot_armature_edit_hierarchy(armature_obj)
    finally:
        _restore_armature_edit_session(session)
    ok, msg = _rebuild_armature_hierarchy_from_specs(
        armature_obj,
        final_order,
        specs,
        parent_of=parent_of,
        active_bone_name=bone_name if bone_name in final_order else active_name,
        preserve_selection=True,
    )
    if not ok:
        return False, msg
    return True, f"Nested {bone_name} under {new_parent_name}"


def unnest_armature_bone(scene, armature_obj, bone_name):
    if not armature_obj or getattr(armature_obj, "type", "") != "ARMATURE":
        return False, "No armature was found"
    bone_name = str(bone_name or "").strip()
    bones = list(getattr(getattr(armature_obj, "data", None), "bones", []) or [])
    order = [bone.name for bone in bones]
    parent_of = {bone.name: (bone.parent.name if bone.parent else None) for bone in bones}
    if bone_name not in parent_of:
        return False, "The selected bone was not found on the armature"
    old_parent = parent_of.get(bone_name)
    if not old_parent:
        return False, f"{bone_name} is already at the top level"
    new_parent = parent_of.get(old_parent)
    children = _children_by_parent_from_order(order, parent_of)

    old_siblings = children.get(old_parent, [])
    if bone_name in old_siblings:
        old_siblings.remove(bone_name)
    children[old_parent] = old_siblings
    parent_of[bone_name] = new_parent

    new_siblings = children.get(new_parent, [])
    insert_index = len(new_siblings)
    if old_parent in new_siblings:
        insert_index = new_siblings.index(old_parent) + 1
    new_siblings.insert(insert_index, bone_name)
    children[new_parent] = new_siblings

    final_order = _flatten_bone_hierarchy(children, None, [])
    session, msg = _enter_armature_edit_session(armature_obj)
    if session is None:
        return False, msg
    try:
        _edit_order, specs, active_name = _snapshot_armature_edit_hierarchy(armature_obj)
    finally:
        _restore_armature_edit_session(session)
    ok, msg = _rebuild_armature_hierarchy_from_specs(
        armature_obj,
        final_order,
        specs,
        parent_of=parent_of,
        active_bone_name=bone_name if bone_name in final_order else active_name,
        preserve_selection=True,
    )
    if not ok:
        return False, msg
    return True, f"Moved {bone_name} up one level"


def move_armature_bone_in_hierarchy(scene, armature_obj, bone_name, anchor_bone_name, position="ABOVE"):
    if not armature_obj or getattr(armature_obj, "type", "") != "ARMATURE":
        return False, "No armature was found"
    bone_name = str(bone_name or "").strip()
    anchor_bone_name = str(anchor_bone_name or "").strip()
    move_position = str(position or "ABOVE").strip().upper()
    bones = list(getattr(getattr(armature_obj, "data", None), "bones", []) or [])
    if not bone_name or not anchor_bone_name:
        return False, "Choose both a source bone and a reference bone"
    if bone_name == anchor_bone_name:
        return False, "Choose a different reference bone"

    order = [bone.name for bone in bones]
    parent_of = {bone.name: (bone.parent.name if bone.parent else None) for bone in bones}
    if bone_name not in parent_of or anchor_bone_name not in parent_of:
        return False, "The selected bones were not found on the armature"
    children = _children_by_parent_from_order(order, parent_of)
    if anchor_bone_name in _bone_descendants(children, bone_name):
        return False, f"{anchor_bone_name} is a child of {bone_name}. That would create a cycle."

    old_parent = parent_of.get(bone_name)
    old_siblings = children.get(old_parent, [])
    if bone_name in old_siblings:
        old_siblings.remove(bone_name)
    children[old_parent] = old_siblings

    new_parent = parent_of.get(anchor_bone_name)
    parent_of[bone_name] = new_parent
    new_siblings = children.get(new_parent, [])
    try:
        anchor_index = new_siblings.index(anchor_bone_name)
    except ValueError:
        anchor_index = len(new_siblings)
    insert_index = anchor_index if move_position == "ABOVE" else anchor_index + 1
    new_siblings.insert(insert_index, bone_name)
    children[new_parent] = new_siblings

    final_order = _flatten_bone_hierarchy(children, None, [])
    session, msg = _enter_armature_edit_session(armature_obj)
    if session is None:
        return False, msg
    try:
        _edit_order, specs, active_name = _snapshot_armature_edit_hierarchy(armature_obj)
    finally:
        _restore_armature_edit_session(session)
    ok, msg = _rebuild_armature_hierarchy_from_specs(
        armature_obj,
        final_order,
        specs,
        parent_of=parent_of,
        active_bone_name=bone_name if bone_name in final_order else active_name,
        preserve_selection=True,
    )
    if not ok:
        return False, msg
    relation = "above" if move_position == "ABOVE" else "below"
    return True, f"Moved {bone_name} {relation} {anchor_bone_name}"

def compute_siren_preview_color(scene, s, si, now=None):
    try:
        base = siren_base_color_rgb(s, si) if s else tuple(si.custom_color)
        if not getattr(si, "flash_preview", True) or not s:
            return tuple(base)

        bits, _, vis = pattern_triplet(s, si)
        ts = preview_seconds(scene=scene, now=now)

        if si.siren_type == "ROTATOR":
            if vis not in {"BOTH", "ROTATOR"}:
                return _emissive_color(base, False)
            return _preview_lit_color(base, 1.0)

        vis_ok = vis in {"BOTH", "FLASHER"}
        bpm = max(1.0, float(getattr(s, "bpm", 800)))
        steps_per_second = bpm / 60.0
        idx = int(ts * steps_per_second) % 32
        on = bits[idx] == "1"
        return _emissive_color(base, bool(vis_ok and on))
    except Exception:
        return (1.0, 0.0, 0.0)


def get_siren_preview_color(self):
    scene = getattr(bpy.context, "scene", None)
    s = getattr(scene, "nels", None) if scene else None
    return compute_siren_preview_color(scene, s, self)

def compute_siren_preview_static_color(s, si):
    try:
        base = siren_base_color_rgb(s, si) if s else tuple(getattr(si, "custom_color", (1.0, 1.0, 1.0)))
        if getattr(si, "siren_type", "FLASHER") == "ROTATOR":
            return tuple(base)
        _bits, seq, vis = pattern_triplet(s, si)
        if (not seq) or (vis not in {"BOTH", "FLASHER"}):
            return PREVIEW_OFF_RGB
        return tuple(base)
    except Exception:
        return PREVIEW_OFF_RGB



def refresh_siren_preview_cache(scene):
    s = getattr(scene, "nels", None) if scene else None
    if not s:
        return False
    if scene and getattr(s, "preview_generated", False) and timeline_playing() and (not getattr(s, "preview_refresh_pending", False)):
        return False

    ts = playback_seconds(scene=scene)
    bpm = max(1.0, float(getattr(s, "bpm", 800) or 800))
    step_idx = int(ts * (bpm / 60.0)) % 32
    if (not getattr(s, "preview_refresh_pending", False)) and int(getattr(s, "preview_last_step", -1) or -1) == step_idx:
        return False

    changed = False
    animate_sirens = bool(getattr(s, "show_sirens_section", True) and getattr(s, "show_siren_preview_panel", False) and getattr(s, "siren_preview_running", True))

    head_tail = (
        ("left_head_preview_cache", _head_tail_preview(s, s.left_head, (1.0, 1.0, 1.0), getattr(s, "head_tail_preview", True))),
        ("right_head_preview_cache", _head_tail_preview(s, s.right_head, (1.0, 1.0, 1.0), getattr(s, "head_tail_preview", True))),
        ("left_tail_preview_cache", _head_tail_preview(s, s.left_tail, (1.0, 0.0, 0.0), getattr(s, "head_tail_preview", True))),
        ("right_tail_preview_cache", _head_tail_preview(s, s.right_tail, (1.0, 0.0, 0.0), getattr(s, "head_tail_preview", True))),
    )
    for prop, col in head_tail:
        try:
            if tuple(getattr(s, prop)) != tuple(col):
                setattr(s, prop, col)
                changed = True
        except Exception:
            pass

    for si in s.sirens:
        col = compute_siren_preview_color(scene, s, si, now=ts) if animate_sirens else compute_siren_preview_static_color(s, si)
        try:
            if tuple(si.preview_color_cache) != tuple(col):
                si.preview_color_cache = col
                changed = True
        except Exception:
            pass

    s.preview_last_step = step_idx
    return changed


def update_lib_color_rgb(self, context):
    v = rgb_to_color(self.rgb)
    if self.value != v:
        self.value = v
    save_library_from_context(context)


def update_lib_color_value(self, context):
    v = clean_color_value(self.value)
    if self.value != v:
        self.value = v
    rgb = color_to_rgb(v)
    if tuple(self.rgb) != rgb:
        self.rgb = rgb
    save_library_from_context(context)


def _draw_preview_rect(shader, x0, y0, x1, y1, color):
    if not shader or not batch_for_shader:
        return
    verts = ((x0, y0), (x1, y0), (x1, y1), (x0, y1))
    batch = batch_for_shader(shader, "TRI_FAN", {"pos": verts})
    shader.uniform_float("color", color)
    batch.draw(shader)


def _clip_range(start, end, lower, upper):
    return max(lower, start), min(upper, end)


def draw_custom_preview_overlay():
    return





