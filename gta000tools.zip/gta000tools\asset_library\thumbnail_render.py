from __future__ import annotations

from math import radians
from pathlib import Path
import shutil
import subprocess
import tempfile

from mathutils import Vector

import bpy

from .library_io import gather_imported_objects, gather_related_ids, imported_bounds, link_to_collection, load_asset_datablocks
from .preview_cache import preview_manager
from . import runtime
from .utils import ensure_directory, library_textures_directory, safe_remove_ids


def _crop_transparent_borders(output_path: Path, padding: int = 8) -> None:
    image = None
    cropped = None
    try:
        image = bpy.data.images.load(str(output_path), check_existing=False)
        width, height = image.size
        pixels = list(image.pixels[:])
        if not pixels or width <= 0 or height <= 0:
            return

        min_x = width
        min_y = height
        max_x = -1
        max_y = -1
        for y in range(height):
            row_offset = y * width * 4
            for x in range(width):
                alpha = pixels[row_offset + x * 4 + 3]
                if alpha <= 0.01:
                    continue
                min_x = min(min_x, x)
                min_y = min(min_y, y)
                max_x = max(max_x, x)
                max_y = max(max_y, y)

        if max_x < min_x or max_y < min_y:
            return

        min_x = max(min_x - padding, 0)
        min_y = max(min_y - padding, 0)
        max_x = min(max_x + padding, width - 1)
        max_y = min(max_y + padding, height - 1)
        crop_w = max_x - min_x + 1
        crop_h = max_y - min_y + 1

        if crop_w == width and crop_h == height:
            return

        cropped_pixels = [0.0] * (crop_w * crop_h * 4)
        for y in range(crop_h):
            src_y = min_y + y
            src_start = (src_y * width + min_x) * 4
            src_end = src_start + crop_w * 4
            dst_start = y * crop_w * 4
            cropped_pixels[dst_start : dst_start + crop_w * 4] = pixels[src_start:src_end]

        cropped = bpy.data.images.new(f"{image.name}_cropped", width=crop_w, height=crop_h, alpha=True)
        cropped.pixels = cropped_pixels
        cropped.filepath_raw = str(output_path)
        cropped.file_format = "PNG"
        cropped.save()
    finally:
        safe_remove_ids([cropped, image])


def _image_has_render_content(output_path: Path, tolerance: float = 0.02, min_changed_pixels: int = 48) -> bool:
    image = None
    try:
        if not output_path.exists():
            return False
        image = bpy.data.images.load(str(output_path), check_existing=False)
        pixels = list(image.pixels[:])
        if len(pixels) < 8:
            return False
        background = pixels[:4]
        changed = 0
        for index in range(0, len(pixels), 4):
            r, g, b, a = pixels[index : index + 4]
            if (
                abs(r - background[0]) > tolerance
                or abs(g - background[1]) > tolerance
                or abs(b - background[2]) > tolerance
                or abs(a - background[3]) > tolerance
            ):
                changed += 1
                if changed >= min_changed_pixels:
                    return True
        return False
    finally:
        safe_remove_ids([image])


def _look_at_rotation(camera_location: Vector, target: Vector):
    direction = (target - camera_location).normalized()
    return direction.to_track_quat("-Z", "Y").to_euler()


def _preview_angle(context: bpy.types.Context | None) -> str:
    browser = getattr(getattr(context, "window_manager", None), "bgal_browser", None) if context is not None else None
    value = str(getattr(browser, "preview_angle", "DEFAULT") or "DEFAULT")
    return value if value in {"DEFAULT", "OPPOSITE"} else "DEFAULT"




def _gather_material_images(objects: list[bpy.types.Object]) -> list[bpy.types.Image]:
    images: list[bpy.types.Image] = []
    seen: set[int] = set()
    for obj in objects:
        for slot in getattr(obj, "material_slots", []):
            material = getattr(slot, "material", None)
            if material is None or not getattr(material, "use_nodes", False) or material.node_tree is None:
                continue
            for node in material.node_tree.nodes:
                image = getattr(node, "image", None)
                if image is None:
                    continue
                marker = id(image)
                if marker in seen:
                    continue
                seen.add(marker)
                images.append(image)
    return images


def _remap_missing_images_to_library_textures(images: list[bpy.types.Image], root_path: Path | None) -> int:
    if root_path is None:
        return 0
    texture_dir = library_textures_directory(root_path, create=False)
    if not texture_dir.exists():
        return 0

    candidates: dict[str, str] = {}
    for path in texture_dir.rglob("*"):
        if not path.is_file():
            continue
        candidates.setdefault(path.name.casefold(), str(path.resolve()))

    remapped = 0
    for image in images:
        if image is None or getattr(image, "source", "FILE") != "FILE":
            continue
        if getattr(image, "packed_file", None) is not None:
            continue
        filepath = getattr(image, "filepath", "") or ""
        if not filepath:
            continue
        try:
            source = Path(bpy.path.abspath(filepath, library=image.library)).resolve()
        except Exception:
            source = Path(filepath)
        if source.exists():
            continue
        match = candidates.get(source.name.casefold())
        if not match:
            continue
        try:
            image.filepath = match
            image.reload()
        except Exception:
            image.filepath = match
        remapped += 1
    return remapped

def _asset_output_path(asset, context: bpy.types.Context | None) -> Path:
    from .properties import _thumbnail_cache_path

    cache_path = _thumbnail_cache_path(asset, context)
    if cache_path is None:
        cache_path = Path(asset.thumbnail_cache)
    return Path(cache_path)


def _build_preview_scene(name: str) -> tuple[bpy.types.Scene, bpy.types.Collection, list]:
    scene = bpy.data.scenes.new(name)
    root_collection = bpy.data.collections.new(f"{name}_Root")
    scene.collection.children.link(root_collection)

    world = bpy.data.worlds.new(f"{name}_World")
    scene.world = world
    try:
        world.use_nodes = True
        background = world.node_tree.nodes.get("Background")
        if background is not None:
            background.inputs[0].default_value = (0.14, 0.14, 0.14, 1.0)
            background.inputs[1].default_value = 0.16
    except Exception:
        pass

    camera_data = bpy.data.cameras.new(f"{name}_Camera")
    camera_data.type = "ORTHO"
    camera_data.clip_end = 1000.0
    camera = bpy.data.objects.new(camera_data.name, camera_data)
    root_collection.objects.link(camera)
    scene.camera = camera

    key_light = bpy.data.lights.new(f"{name}_Key", type="AREA")
    key_light.energy = 2400.0
    key_light.shape = "RECTANGLE"
    key_light.size = 1.3
    key_light.size_y = 1.3
    key_object = bpy.data.objects.new(key_light.name, key_light)
    root_collection.objects.link(key_object)

    fill_light = bpy.data.lights.new(f"{name}_Fill", type="AREA")
    fill_light.energy = 900.0
    fill_light.shape = "RECTANGLE"
    fill_light.size = 1.1
    fill_light.size_y = 1.1
    fill_object = bpy.data.objects.new(fill_light.name, fill_light)
    root_collection.objects.link(fill_object)

    rim_light = bpy.data.lights.new(f"{name}_Rim", type="AREA")
    rim_light.energy = 1200.0
    rim_light.shape = "RECTANGLE"
    rim_light.size = 1.0
    rim_light.size_y = 1.0
    rim_object = bpy.data.objects.new(rim_light.name, rim_light)
    root_collection.objects.link(rim_object)

    scene.render.image_settings.file_format = "PNG"
    scene.render.film_transparent = False
    scene.render.resolution_x = 512
    scene.render.resolution_y = 512
    scene.render.resolution_percentage = 100
    try:
        scene.render.engine = "BLENDER_EEVEE"
    except Exception:
        pass
    try:
        scene.view_settings.view_transform = "Standard"
        scene.view_settings.look = "None"
        scene.view_settings.exposure = -0.85
    except Exception:
        pass

    return scene, root_collection, [camera, camera_data, key_object, key_light, fill_object, fill_light, rim_object, rim_light, world]


def _camera_offset(distance: float, angle_mode: str) -> Vector:
    if angle_mode == "OPPOSITE":
        return Vector((distance, -distance, distance * 0.72))
    return Vector((-distance, distance, distance * 0.72))


def _frame_camera(
    scene: bpy.types.Scene,
    root_collection: bpy.types.Collection,
    imported_objects: list[bpy.types.Object],
    *,
    angle_mode: str = "DEFAULT",
) -> None:
    camera = scene.camera
    if camera is None:
        return
    renderable_objects = [
        obj
        for obj in imported_objects
        if obj.type in {"MESH", "CURVE", "SURFACE", "FONT", "META", "VOLUME"}
        or obj.instance_collection is not None
    ]
    bounds = imported_bounds(renderable_objects or imported_objects)
    if bounds is None:
        camera.location = Vector((4.0, -4.0, 3.0))
        camera.rotation_euler = (radians(60.0), 0.0, radians(45.0))
        return

    mins, maxs = bounds
    center = (mins + maxs) * 0.5
    size = max(maxs.x - mins.x, maxs.y - mins.y, maxs.z - mins.z, 0.25)
    distance = size * 1.15 + 0.35

    camera.location = center + _camera_offset(distance, angle_mode)
    camera.rotation_euler = _look_at_rotation(camera.location, center)

    camera_local = camera.matrix_world.inverted()
    min_x = float("inf")
    max_x = float("-inf")
    min_y = float("inf")
    max_y = float("-inf")
    found = False
    for obj in renderable_objects or imported_objects:
        for corner in obj.bound_box:
            local = camera_local @ (obj.matrix_world @ Vector(corner))
            min_x = min(min_x, local.x)
            max_x = max(max_x, local.x)
            min_y = min(min_y, local.y)
            max_y = max(max_y, local.y)
            found = True
    if found:
        width = max_x - min_x
        height = max_y - min_y
        camera.data.ortho_scale = max(max(width, height) * 1.08, 0.35)
    else:
        camera.data.ortho_scale = max(size * 1.15, 0.35)

    key_object = root_collection.objects.get(f"{scene.name}_Key")
    if key_object is not None:
        if angle_mode == "OPPOSITE":
            key_object.location = center + Vector((distance * 0.8, -distance * 0.3, distance * 1.2))
            key_object.rotation_euler = (radians(58.0), 0.0, radians(35.0))
        else:
            key_object.location = center + Vector((-distance * 0.95, distance * 0.45, distance * 1.15))
            key_object.rotation_euler = (radians(55.0), 0.0, radians(-145.0))

    fill_object = root_collection.objects.get(f"{scene.name}_Fill")
    if fill_object is not None:
        if angle_mode == "OPPOSITE":
            fill_object.location = center + Vector((-distance * 0.7, distance * 0.7, distance * 0.85))
            fill_object.rotation_euler = (radians(58.0), 0.0, radians(-145.0))
        else:
            fill_object.location = center + Vector((distance * 0.75, -distance * 0.55, distance * 0.8))
            fill_object.rotation_euler = (radians(58.0), 0.0, radians(35.0))

    rim_object = root_collection.objects.get(f"{scene.name}_Rim")
    if rim_object is not None:
        if angle_mode == "OPPOSITE":
            rim_object.location = center + Vector((-distance * 0.35, -distance * 1.05, distance * 0.9))
            rim_object.rotation_euler = (radians(76.0), 0.0, radians(180.0))
        else:
            rim_object.location = center + Vector((distance * 0.35, distance * 1.05, distance * 0.9))
            rim_object.rotation_euler = (radians(76.0), 0.0, radians(0.0))


def _source_scene_render_script(output_path: Path, target_kind: str, target_names: list[str], angle_mode: str, texture_dir: str = "") -> str:
    return f'''
from math import radians
from pathlib import Path

from mathutils import Vector

import bpy

OUTPUT_PATH = Path(r"{str(output_path)}")
TARGET_KIND = {target_kind!r}
TARGET_NAMES = {list(target_names)!r}
ANGLE_MODE = {angle_mode!r}
TEXTURE_DIR = Path(r"{str(texture_dir)}") if {bool(texture_dir)!r} else None




def remap_missing_images_to_texture_dir(texture_dir: Path | None) -> int:
    if texture_dir is None or not texture_dir.exists():
        return 0
    candidates = {{}}
    for path in texture_dir.rglob("*"):
        if not path.is_file():
            continue
        candidates.setdefault(path.name.casefold(), str(path.resolve()))

    remapped = 0
    for image in bpy.data.images:
        if image is None or getattr(image, "source", "FILE") != "FILE":
            continue
        if getattr(image, "packed_file", None) is not None:
            continue
        filepath = getattr(image, "filepath", "") or ""
        if not filepath:
            continue
        try:
            source = Path(bpy.path.abspath(filepath, library=image.library)).resolve()
        except Exception:
            source = Path(filepath)
        if source.exists():
            continue
        match = candidates.get(source.name.casefold())
        if not match:
            continue
        try:
            image.filepath = match
            image.reload()
        except Exception:
            image.filepath = match
        remapped += 1
    return remapped


def recursive_collection_objects(collection):
    objects = list(collection.objects)
    for child in collection.children:
        objects.extend(recursive_collection_objects(child))
    seen = []
    names = set()
    for obj in objects:
        if obj is None or obj.name in names:
            continue
        names.add(obj.name)
        seen.append(obj)
    return seen


def gather_target_objects(scene):
    if TARGET_KIND == "COLLECTION":
        objects = []
        for name in TARGET_NAMES:
            collection = bpy.data.collections.get(name)
            if collection is not None:
                objects.extend(recursive_collection_objects(collection))
        return objects
    if TARGET_NAMES:
        objects = []
        seen = set()
        for name in TARGET_NAMES:
            obj = bpy.data.objects.get(name)
            if obj is None:
                continue
            for item in [obj] + list(obj.children_recursive):
                if item.name in seen:
                    continue
                seen.add(item.name)
                objects.append(item)
        return objects
    return list(scene.objects)


def imported_bounds(objects):
    if not objects:
        return None
    mins = Vector((float("inf"), float("inf"), float("inf")))
    maxs = Vector((float("-inf"), float("-inf"), float("-inf")))
    found = False
    for obj in objects:
        if obj.type == "EMPTY" and obj.instance_collection is None:
            continue
        for corner in obj.bound_box:
            world_corner = obj.matrix_world @ Vector(corner)
            mins.x = min(mins.x, world_corner.x)
            mins.y = min(mins.y, world_corner.y)
            mins.z = min(mins.z, world_corner.z)
            maxs.x = max(maxs.x, world_corner.x)
            maxs.y = max(maxs.y, world_corner.y)
            maxs.z = max(maxs.z, world_corner.z)
            found = True
    if not found:
        return None
    return mins, maxs


def look_at_rotation(camera_location, target):
    direction = (target - camera_location).normalized()
    return direction.to_track_quat("-Z", "Y").to_euler()


def camera_offset(distance, angle_mode):
    if angle_mode == "OPPOSITE":
        return Vector((distance, -distance, distance * 0.72))
    return Vector((-distance, distance, distance * 0.72))


scene = bpy.context.scene
remap_missing_images_to_texture_dir(TEXTURE_DIR)
objects = gather_target_objects(scene)
renderable = [obj for obj in objects if obj.type in {{"MESH", "CURVE", "SURFACE", "FONT", "META", "VOLUME"}} or obj.instance_collection is not None]
if not renderable:
    raise RuntimeError("No renderable objects were found for the thumbnail asset.")

try:
    scene.render.engine = "BLENDER_EEVEE"
except Exception:
    pass
try:
    scene.view_settings.view_transform = "Standard"
    scene.view_settings.look = "None"
    scene.view_settings.exposure = -0.85
except Exception:
    pass
scene.render.image_settings.file_format = "PNG"
scene.render.film_transparent = False
scene.render.resolution_x = 512
scene.render.resolution_y = 512
scene.render.resolution_percentage = 100
scene.use_nodes = False

if scene.world is None:
    scene.world = bpy.data.worlds.new("BGAL_RuntimePreviewWorld")
try:
    scene.world.use_nodes = True
    background = scene.world.node_tree.nodes.get("Background")
    if background is not None:
        background.inputs[0].default_value = (0.14, 0.14, 0.14, 1.0)
        background.inputs[1].default_value = 0.16
except Exception:
    pass

for obj in scene.objects:
    if obj.type in {{"CAMERA", "LIGHT"}}:
        continue
    obj.hide_render = obj not in objects

for name in ["BGAL_RuntimeCamera", "BGAL_RuntimeKey", "BGAL_RuntimeFill", "BGAL_RuntimeRim"]:
    obj = bpy.data.objects.get(name)
    if obj is not None:
        bpy.data.objects.remove(obj, do_unlink=True)

bounds = imported_bounds(renderable)
if bounds is None:
    raise RuntimeError("Unable to frame the asset for preview rendering.")
mins, maxs = bounds
center = (mins + maxs) * 0.5
size = max(maxs.x - mins.x, maxs.y - mins.y, maxs.z - mins.z, 0.25)
distance = size * 1.15 + 0.35

camera_data = bpy.data.cameras.new("BGAL_RuntimeCamera")
camera_data.type = "ORTHO"
camera = bpy.data.objects.new("BGAL_RuntimeCamera", camera_data)
scene.collection.objects.link(camera)
scene.camera = camera
camera.location = center + camera_offset(distance, ANGLE_MODE)
camera.rotation_euler = look_at_rotation(camera.location, center)

camera_local = camera.matrix_world.inverted()
min_x = float("inf")
max_x = float("-inf")
min_y = float("inf")
max_y = float("-inf")
for obj in renderable:
    for corner in obj.bound_box:
        local = camera_local @ (obj.matrix_world @ Vector(corner))
        min_x = min(min_x, local.x)
        max_x = max(max_x, local.x)
        min_y = min(min_y, local.y)
        max_y = max(max_y, local.y)
camera.data.ortho_scale = max(max(max_x - min_x, max_y - min_y) * 1.08, 0.35)

light_specs = []
if ANGLE_MODE == "OPPOSITE":
    light_specs = [
        ("BGAL_RuntimeKey", (distance * 0.8, -distance * 0.3, distance * 1.2), (radians(58.0), 0.0, radians(35.0)), 2400.0),
        ("BGAL_RuntimeFill", (-distance * 0.7, distance * 0.7, distance * 0.85), (radians(58.0), 0.0, radians(-145.0)), 900.0),
        ("BGAL_RuntimeRim", (-distance * 0.35, -distance * 1.05, distance * 0.9), (radians(76.0), 0.0, radians(180.0)), 1200.0),
    ]
else:
    light_specs = [
        ("BGAL_RuntimeKey", (-distance * 0.95, distance * 0.45, distance * 1.15), (radians(55.0), 0.0, radians(-145.0)), 2400.0),
        ("BGAL_RuntimeFill", (distance * 0.75, -distance * 0.55, distance * 0.8), (radians(58.0), 0.0, radians(35.0)), 900.0),
        ("BGAL_RuntimeRim", (distance * 0.35, distance * 1.05, distance * 0.9), (radians(76.0), 0.0, radians(0.0)), 1200.0),
    ]

for name, offset, rotation, energy in light_specs:
    light = bpy.data.lights.new(name, type="AREA")
    light.energy = energy
    light.shape = "RECTANGLE"
    light.size = 1.2
    light.size_y = 1.2
    obj = bpy.data.objects.new(name, light)
    scene.collection.objects.link(obj)
    obj.location = center + Vector(offset)
    obj.rotation_euler = rotation

scene.render.filepath = str(OUTPUT_PATH)
bpy.ops.render.render(write_still=True, use_viewport=False)
'''.strip()


def _render_thumbnail_in_source_blend(asset, output_path: Path, angle_mode: str) -> tuple[bool, str]:
    ensure_directory(output_path.parent)
    texture_dir = str(library_textures_directory(Path(asset.root_path), create=False)) if getattr(asset, "root_path", "") else ""
    script_text = _source_scene_render_script(output_path, asset.target_kind, list(asset.target_names), angle_mode, texture_dir)
    working_dir = Path(__file__).resolve().parents[2] / "Working Files"
    working_dir.mkdir(parents=True, exist_ok=True)
    handle, script_name = tempfile.mkstemp(prefix=f"_thumb_{asset.asset_id}_", suffix=".py", dir=str(working_dir))
    try:
        script_path = Path(script_name)
        try:
            Path(script_name).unlink(missing_ok=True)
        except Exception:
            pass
        script_path.write_text(script_text, encoding="utf-8")
        result = subprocess.run(
            [bpy.app.binary_path, "-b", str(asset.file_path), "-P", str(script_path)],
            capture_output=True,
            text=True,
            check=False,
        )
    except Exception as exc:
        return False, str(exc)
    finally:
        try:
            Path(script_name).unlink(missing_ok=True)
        except Exception:
            pass

    if result.returncode != 0:
        output = "\n".join(part for part in [result.stdout, result.stderr] if part).strip()
        return False, output.splitlines()[-1] if output else "Failed to render the asset preview from the source blend."
    return output_path.exists(), ("" if output_path.exists() else "Source blend preview render did not create an output file.")


def render_thumbnail_for_asset(context: bpy.types.Context, asset_id: str) -> tuple[bool, str]:
    asset = runtime.get_asset(asset_id)
    if asset is None:
        return False, "Asset not found in the runtime index."

    output_path = _asset_output_path(asset, context)
    ensure_directory(output_path.parent)
    angle_mode = _preview_angle(context)

    scene = None
    root_collection = None
    preview_ids = []
    cleanup_ids = []
    imported = {"collections": [], "objects": [], "actions": []}
    original_scene = context.window.scene if getattr(context, "window", None) else None

    try:
        scene, root_collection, preview_ids = _build_preview_scene(f"BGALPreview_{asset.asset_id}")
        imported = load_asset_datablocks(
            asset.file_path,
            asset.target_kind,
            list(asset.target_names),
            link=False,
        )
        link_to_collection(root_collection, imported["collections"], imported["objects"])

        imported_objects = gather_imported_objects(imported["collections"], imported["objects"])
        root_path = Path(asset.root_path) if getattr(asset, "root_path", "") else None
        _remap_missing_images_to_library_textures(_gather_material_images(imported_objects), root_path)
        for obj in imported_objects:
            try:
                obj.hide_render = False
                obj.hide_viewport = False
            except Exception:
                pass
        _frame_camera(scene, root_collection, imported_objects, angle_mode=angle_mode)
        scene.render.filepath = str(output_path)

        if getattr(context, "window", None):
            context.window.scene = scene
            try:
                context.view_layer.update()
            except Exception:
                pass
        bpy.ops.render.render(write_still=True, use_viewport=False)
        preview_manager.invalidate(asset.asset_id)
    except Exception as exc:
        return False, str(exc)
    finally:
        if getattr(context, "window", None) and original_scene is not None:
            context.window.scene = original_scene
        cleanup_ids.extend(gather_related_ids(imported["collections"], imported["objects"], imported["actions"]))
        if scene is not None:
            cleanup_ids.extend(preview_ids)
            cleanup_ids.append(root_collection)
            cleanup_ids.append(scene)
        safe_remove_ids(cleanup_ids)

    if not _image_has_render_content(output_path):
        success, message = _render_thumbnail_in_source_blend(asset, output_path, angle_mode)
        if not success:
            return False, message

    preview_manager.invalidate(asset.asset_id)
    return output_path.exists(), ("" if output_path.exists() else "Thumbnail render did not create an output file.")


def generate_missing_previews(context: bpy.types.Context, asset_ids: list[str]) -> int:
    generated = 0
    for asset_id in asset_ids:
        asset = runtime.get_asset(asset_id)
        if asset is None:
            continue
        cache_path = _asset_output_path(asset, context)
        if cache_path.exists():
            continue
        success, _message = render_thumbnail_for_asset(context, asset_id)
        if success:
            generated += 1
    return generated


