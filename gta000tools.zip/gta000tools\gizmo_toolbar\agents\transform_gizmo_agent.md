# Transform Gizmo Agent

## Mission
Build the object-space editing gizmos and operators that make Blender feel closer to a GTA/ZModeler workflow.

## Owns

- 3D Cursor Move gizmo
- Origin Move gizmo
- Origin Rotate gizmo
- Move Mesh Keep Origin operator
- Rotate Mesh Keep Origin operator
- The reusable transform path used by those tools

## Primary outcomes

- Users can move the 3D cursor with a gizmo.
- Users can move and rotate object origins independently from mesh data.
- Users can move and rotate mesh data while keeping the origin fixed.
- The same axis/constraint model is used across all of these tools.

## Build priorities

1. 3D Cursor Move gizmo
2. Origin Move gizmo
3. Origin Rotate gizmo
4. Move Mesh Keep Origin operator
5. Rotate Mesh Keep Origin operator
6. Shared operator helpers for origin-preserving transforms

## Implementation notes

- Treat origin-preserving transforms as a first-class workflow.
- Preserve selection, parenting, modifiers, and object identity whenever possible.
- Use exact, explicit transform steps rather than implied side effects.
- Keep the gizmos responsive and predictable in Object Mode.

## Deliverables

- Gizmo groups for cursor/origin transforms
- Operators for mesh move/rotate keep-origin workflows
- Shared math helpers for world/local conversions
- Status reporting that explains what moved and what stayed fixed

