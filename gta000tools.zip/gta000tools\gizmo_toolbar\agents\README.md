# Gizmo Toolbar Agents

This folder contains sub-agent briefs for building the GTA 000 Tools gizmo system from the Blender spec in `gta000tools/Gizmo Toolbar/Specs/gta000_gizmo_blender_spec.docx`.

The goal is to keep the work modular and production-ready:

- one agent owns the shared gizmo framework and viewport toolbar
- one agent owns the object-space transform gizmos and operators
- one agent owns the vehicle-specific gizmos and technical placement tools

Shared rules for every agent:

- Use Blender-supported `Gizmo`, `GizmoGroup`, `Operator`, `Panel`, and `PropertyGroup` patterns.
- Keep register/unregister hooks local to the owned module set.
- Reuse shared axis/constraint helpers instead of duplicating transform logic.
- Prefer exact, predictable behavior over clever heuristics.
- Keep undo/redo safe and avoid mutating unrelated scene data.
- Design the implementation so the main addon can integrate the modules later without refactoring.

Build order from the spec:

1. Top viewport GTA toolbar and floating overlay strip
2. 3D Cursor Move Gizmo
3. Origin Move Gizmo
4. Origin Rotate Gizmo
5. Move Mesh Keep Origin
6. Rotate Mesh Keep Origin
7. Axis Constraint system
8. Door Hinge Gizmo
9. Door Swing Arc Gizmo
10. Dummy / Locator tool
11. Mirror Placement
12. Export Readiness Overlay

Each agent brief below narrows scope so the work can be split safely.
