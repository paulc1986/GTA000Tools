"""Header, panel, and operator scaffold for the GTA 000 gizmo toolbar."""

from __future__ import annotations

import bpy
from bpy.props import EnumProperty
from bpy.types import Operator, Panel

from . import operators as gt_ops
from . import runtime
from .properties import GIZMO_MODE_ITEMS, GIZMO_MODE_LABELS


_CLASSES = ()


class GTA000_OT_gizmo_toolbar_set_mode(Operator):
    bl_idname = "gta000.gizmo_toolbar_set_mode"
    bl_label = "Set Gizmo Mode"
    bl_description = "Switch the GTA gizmo toolbar to a different mode"
    bl_options = {"REGISTER", "UNDO"}

    mode: EnumProperty(items=GIZMO_MODE_ITEMS)

    def execute(self, context):
        settings = runtime.get_settings(context)
        if settings is None:
            self.report({"ERROR"}, "Gizmo toolbar settings are not registered")
            return {"CANCELLED"}

        settings.active_mode = self.mode
        label = GIZMO_MODE_LABELS.get(self.mode, self.mode.title())
        runtime.set_status(context, f"Mode: {label}")
        self.report({"INFO"}, f"Gizmo mode set to {label}")
        return {"FINISHED"}


class GTA000_OT_gizmo_toolbar_toggle_overlay(Operator):
    bl_idname = "gta000.gizmo_toolbar_toggle_overlay"
    bl_label = "Toggle Gizmo Overlay"
    bl_description = "Show or hide the compact floating gizmo overlay strip"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        settings = runtime.get_settings(context)
        if settings is None:
            self.report({"ERROR"}, "Gizmo toolbar settings are not registered")
            return {"CANCELLED"}

        settings.show_overlay = not settings.show_overlay
        runtime.set_status(context, "Overlay enabled" if settings.show_overlay else "Overlay hidden")
        self.report({"INFO"}, "Gizmo overlay toggled")
        return {"FINISHED"}


class GTA000_PT_gizmo_toolbar_settings(Panel):
    bl_idname = "GTA000_PT_gizmo_toolbar_settings"
    bl_label = "Gizmo Toolbar Settings"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "GTA 000"
    bl_options = {"DEFAULT_CLOSED"}

    def draw(self, context):
        layout = self.layout
        settings = runtime.get_settings(context)
        if settings is None:
            layout.label(text="Gizmo toolbar settings are unavailable", icon="ERROR")
            return

        layout.prop(settings, "show_header_strip")
        layout.prop(settings, "show_overlay")
        layout.prop(settings, "overlay_scale")
        layout.prop(settings, "overlay_position")
        layout.prop(settings, "show_mode_labels")
        layout.prop(settings, "show_status_text")
        layout.prop(settings, "snap_increment")
        layout.prop(settings, "use_local_space")
        layout.prop(settings, "preserve_origin")


class GTA000_PT_gizmo_toolbar(Panel):
    bl_idname = "GTA000_PT_gizmo_toolbar"
    bl_label = "Gizmo Toolbar"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "GTA 000"

    def draw(self, context):
        layout = self.layout
        settings = runtime.get_settings(context)
        runtime_state = runtime.get_runtime_state(context)
        active_mesh = gt_ops.active_mesh_object(context)

        if settings is None:
            layout.label(text="Gizmo toolbar settings are unavailable", icon="ERROR")
            return

        header = layout.row(align=True)
        header.label(text="Modes")
        header.operator("gta000.gizmo_toolbar_toggle_overlay", text="", icon="OVERLAY")
        header.popover(panel="GTA000_PT_gizmo_toolbar_settings", text="", icon="PREFERENCES")

        mode_box = layout.box()
        mode_box.label(text="Implemented Modes")
        mode_box.prop(settings, "active_mode", expand=True)

        settings_box = layout.box()
        settings_box.label(text="Current Settings")
        settings_box.prop(settings, "show_header_strip")
        settings_box.prop(settings, "show_overlay")
        settings_box.prop(settings, "overlay_scale")
        settings_box.prop(settings, "overlay_position")
        settings_box.prop(settings, "snap_increment")

        tools_box = layout.box()
        tools_box.label(text="Active Mode Tools")
        if settings.active_mode == "CURSOR":
            tools_box.label(text="Use the viewport gizmo to move the 3D cursor.", icon="PIVOT_CURSOR")
        elif settings.active_mode == "ORIGIN":
            if active_mesh is None:
                tools_box.label(text="Select a mesh object to use the origin gizmos.", icon="INFO")
            else:
                tools_box.label(text=f"Active mesh: {active_mesh.name}", icon="OBJECT_ORIGIN")
                tools_box.label(text="Use the viewport gizmos to move or rotate the active mesh origin.", icon="OBJECT_ORIGIN")
        elif settings.active_mode == "MESH":
            if active_mesh is None:
                tools_box.label(text="Select a mesh object to use mesh keep-origin tools.", icon="INFO")
            else:
                tools_box.label(text=f"Active mesh: {active_mesh.name}", icon="OUTLINER_OB_MESH")
                move_row = tools_box.row(align=True)
                op = move_row.operator("gta000.move_mesh_keep_origin", text="Move Mesh", icon="EMPTY_ARROWS")
                op.axis = "X"
                rotate_row = tools_box.row(align=True)
                op = rotate_row.operator("gta000.rotate_mesh_keep_origin", text="Rotate Mesh", icon="DRIVER_ROTATIONAL_DIFFERENCE")
                op.axis = "Z"
        else:
            tools_box.label(text="This mode is scaffolded and ready for the next gizmo pass.", icon="INFO")

        status_box = layout.box()
        status_box.label(text="Status")
        if settings.show_status_text:
            status_box.label(text=settings.last_action or "Ready", icon="INFO")
        if settings.last_warning:
            status_box.label(text=settings.last_warning, icon="ERROR")
        if runtime_state is not None:
            status_box.label(text=f"Runtime: {runtime_state.status_level}", icon="DOT")


def draw_view3d_header(self, context):
    settings = runtime.get_settings(context)
    if settings is None or not settings.show_header_strip:
        return

    layout = self.layout
    row = layout.row(align=True)
    row.label(text="GTA 000")
    row.prop(settings, "active_mode", text="", expand=True)

    row.operator("gta000.gizmo_toolbar_toggle_overlay", text="", icon="OVERLAY")
    row.popover(panel="GTA000_PT_gizmo_toolbar_settings", text="", icon="PREFERENCES")


def register() -> None:
    global _CLASSES
    _CLASSES = (
        GTA000_OT_gizmo_toolbar_set_mode,
        GTA000_OT_gizmo_toolbar_toggle_overlay,
        GTA000_PT_gizmo_toolbar_settings,
        GTA000_PT_gizmo_toolbar,
    )

    for cls in _CLASSES:
        bpy.utils.register_class(cls)

    bpy.types.VIEW3D_HT_header.append(draw_view3d_header)


def unregister() -> None:
    try:
        bpy.types.VIEW3D_HT_header.remove(draw_view3d_header)
    except Exception:
        pass

    for cls in reversed(_CLASSES):
        try:
            bpy.utils.unregister_class(cls)
        except RuntimeError:
            pass
