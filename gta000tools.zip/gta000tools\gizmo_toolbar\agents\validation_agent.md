# Validation Agent

## Mission
Build the viewport validation and repair layer that keeps gizmo-driven edits export-safe.

## Owns

- Export Readiness Overlay
- Part Role assignment UI
- LOD Sync helpers
- Parent Link Overlay
- Validation rules and repair suggestions
- Warnings for naming, hierarchy, and pivot issues

## Primary outcomes

- The viewport can surface actionable warnings directly.
- Users can see when a part naming or hierarchy issue is likely to break export.
- Common problems can be repaired without leaving the viewport workflow.

## Build priorities

1. Validation data model
2. Overlay warning rendering
3. Naming and hierarchy checks
4. Pivot and axis sanity checks
5. LOD sync checks

## Implementation notes

- Keep validation rules centralized and reusable.
- Surface errors in a way that supports click-to-fix workflows later.
- Make sure validation can run without mutating the scene unless a fix is explicitly requested.

## Deliverables

- Validation helpers
- Overlay rendering for warnings and errors
- Repair operator scaffolds
- Persistent validation state in Blender properties
