# GTA 000 Tools

`GTA 000 Tools` is a Blender add-on for building GTA V non-ELS lightbar setups, previewing linked scene content, exporting `carcols.meta`, and managing grouped asset libraries.

## Main Areas
### General
- `Lightbar Setup`
- `Simulation`
- `Useful Tools`

### Vehicle
- `Body Openings`
- `Extra's`
- `Lighting`
- `Light ID's`
- `Wheel Preview`

### Asset Library
- `Asset's`
- `Asset Details`

### Config Libraries
- `Flash Patterns`
- `Colours`
- `Categories`
- `Sub-Categories`
- `Tags`

### Updates and Information
- `Updates`
- `Asset Library Path`
- `Information`

## Basic Workflow
1. Set `vehicle_name`, `siren_id`, `BPM`, and `Scale Factor`.
2. Add or import flash patterns and colours.
3. Add sirens and configure each one.
4. Link each siren to the correct mesh and bone.
5. Use `Simulation` to preview the active siren or all sirens.
6. Export `carcols.meta`.

## Optional Sollumz Support
Sollumz is optional, but it enables:
- `Preview Wheel Instances`
- polygon `Light ID's`
- better support for some vehicle scene workflows

If Sollumz is missing, GTA 000 Tools shows a warning and offers an install or enable button.

## Asset Library
The integrated Asset Library lets you:
- add library roots
- scan and refresh asset folders
- search, filter, and sort assets
- switch between grid and list view
- `Append` or `Link` assets
- edit category, sub-category, and tags for the selected asset

## Preferences
Open `Edit > Preferences > Add-ons > GTA 000 Tools`.

Important settings:
- `Panel Location`
- `Icon Colour Mode`
- `Alpha Features > Rotators`
- `Asset Preview Size (px)`
- Asset Library scan and refresh options

## More Documentation
For the full wiki and project documentation, open the GitHub repository wiki:
- `https://github.com/paulc1986/GTA000Tools/wiki`
