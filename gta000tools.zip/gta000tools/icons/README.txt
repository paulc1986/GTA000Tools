﻿Drop custom panel icons into this folder.

Supported formats:
- PNG
- GIF

Lookup order:
1. PNG
2. GIF
3. Built-in Blender fallback icon

Expected filenames:
- lightbar.png or lightbar.gif
- patterns.png or patterns.gif
- colours.png or colours.gif
- car_functions.png or car_functions.gif
- simulation.png or simulation.gif

Notes:
- Square images work best.
- 32x32 or 64x64 is recommended.
- GIF icons are loaded as image previews; do not expect animated playback in the panel header.
- If a file is missing or Blender cannot load it, the addon will use the built-in fallback icon for that panel.
