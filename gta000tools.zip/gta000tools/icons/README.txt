Drop custom panel header icons into this folder.

Supported formats:
- PNG
- GIF

Lookup order:
1. Theme variant file for the selected icon colour mode
2. Base file without a theme suffix
3. Built-in Blender fallback icon

Icon colour mode:
- Set this in Blender Preferences > Add-ons > GTA 000 Tools > Icons > Icon Colour Mode
- `Default` follows the current Blender theme
- `Light` forces `_light` variants when available
- `Dark` forces `_dark` variants when available

Replaceable addon icons:
- `gta000_icon_dark.png` or `.gif`
  Used for: GTA 000 group header on dark Blender themes
- `gta000_icon_light.png` or `.gif`
  Used for: GTA 000 group header on light Blender themes
- `lightbar.png`, `lightbar_light.png`, `lightbar_dark.png`
  Used for: Lightbar Setup
- `patterns.png`, `patterns_light.png`, `patterns_dark.png`
  Used for: Flash Patterns
- `colours.png`, `colours_light.png`, `colours_dark.png`
  Used for: Colours
- `body_openings.png`, `body_openings_light.png`, `body_openings_dark.png`
  Used for: Body Openings panel header
- `door.png`, `door_light.png`, `door_dark.png`
  Used for: Door body opening rows
- `bonnet.png`, `bonnet_light.png`, `bonnet_dark.png`
  Used for: Bonnet body opening rows
- `boot.png`, `boot_light.png`, `boot_dark.png`
  Used for: Boot body opening rows
- `simulation.png`, `simulation_light.png`, `simulation_dark.png`
  Used for: Simulation
- `useful_tools.png`, `useful_tools_light.png`, `useful_tools_dark.png`
  Used for: Useful Tools
- `updates.png`, `updates_light.png`, `updates_dark.png`
  Used for: Updates

Naming notes:
- The filename must match exactly, including underscores.
- The Colours panel uses the British spelling filename: `colours`.
- These files replace addon panel and body opening header icons only.
- The GTA 000 sidebar tab icon itself is not loaded from this folder.
- If only the base filename exists, it is used for both light and dark themes.

Recommended image setup:
- Square images work best.
- 32x32 or 64x64 is recommended.
- Transparent backgrounds are recommended.

GIF notes:
- GIF icons are loaded as image previews.
- Do not expect animated playback in the panel header.

Fallback behavior:
- If a file is missing or Blender cannot load it, the addon falls back to the built-in Blender icon for that panel or body opening type.