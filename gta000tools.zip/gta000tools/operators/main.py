class NELS_OT_initialize_defaults(Operator):
    bl_idname = "nels.initialize_defaults"
    bl_label = "Initialize Defaults"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        ensure_scene_defaults(context.scene)
        return {"FINISHED"}

class NELS_OT_pattern_tools(Operator):
    bl_idname = "nels.pattern_tools"
    bl_label = "Pattern Tools"
    bl_options = {"REGISTER", "UNDO"}

    action: EnumProperty(items=[("ADD", "ADD", ""), ("DUPLICATE", "DUPLICATE", ""), ("REMOVE", "REMOVE", ""), ("REPEAT", "REPEAT", ""), ("INVERT", "INVERT", "")])
    scope: EnumProperty(items=[("LIB", "LIB", ""), ("SIREN", "SIREN", "")], default="LIB")

    def execute(self, context):
        s = context.scene.nels
        if self.action == "ADD":
            p = s.patterns.add()
            p.name = f"Pattern {len(s.patterns)}"
            p.allow_duplicate = False
            p.visibility = "BOTH"
            p.bits = "00001111000011110000111100001111"
            p.value = str(bits_to_int(p.bits))
            s.active_pattern = len(s.patterns) - 1
            save_global_library(s)
            return {"FINISHED"}
        if self.action == "DUPLICATE":
            if not s.patterns:
                return {"CANCELLED"}
            i = max(0, min(s.active_pattern, len(s.patterns) - 1))
            src = s.patterns[i]
            p = s.patterns.add()
            p.name = f"{(src.name or f'Pattern {i + 1}')} Copy"
            p.allow_duplicate = False
            p.visibility = src.visibility
            p.bits = src.bits
            p.value = src.value
            s.active_pattern = len(s.patterns) - 1
            save_global_library(s)
            return {"FINISHED"}
        if self.action == "REMOVE":
            if s.patterns:
                i = max(0, min(s.active_pattern, len(s.patterns) - 1))
                s.patterns.remove(i)
                s.active_pattern = min(i, max(0, len(s.patterns) - 1))
            save_global_library(s)
            return {"FINISHED"}

        si = s.sirens[s.active_siren] if s.sirens and 0 <= s.active_siren < len(s.sirens) else None
        if self.scope == "LIB":
            p = s.patterns[s.active_pattern] if s.patterns and 0 <= s.active_pattern < len(s.patterns) else None
            if not p:
                return {"CANCELLED"}
            if self.action == "REPEAT":
                p.bits = repeat_32(p.bits)
            elif self.action == "INVERT":
                p.bits = invert_bits(p.bits)
            save_global_library(s)
            return {"FINISHED"}

        if not si:
            return {"CANCELLED"}
        if self.action == "REPEAT":
            si.custom_bits = repeat_32(si.custom_bits)
        elif self.action == "INVERT":
            si.custom_bits = invert_bits(si.custom_bits)
        return {"FINISHED"}


class NELS_OT_save_siren_pattern(Operator):
    bl_idname = "nels.save_siren_pattern"
    bl_label = "Save Pattern to Library"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        scene = getattr(context, "scene", None)
        s = getattr(scene, "nels", None) if scene else None
        if not s or not s.sirens:
            self.report({"ERROR"}, "No siren selected")
            return {"CANCELLED"}

        idx = max(0, min(getattr(s, "active_siren", 0), len(s.sirens) - 1))
        si = s.sirens[idx]
        bits = repeat_32(getattr(si, "custom_bits", "0"))
        value = str(bits_to_int(bits))
        visibility = getattr(si, "custom_visibility", "BOTH")

        existing_key = find_pattern_key_by_bits(s, bits, visibility)
        if existing_key:
            si.pattern_source = "LIBRARY"
            si.pattern_choice = existing_key
            sync_siren_selector_controls(si)
            mark_preview_dirty(context)
            self.report({"INFO"}, "Matched existing library pattern")
            return {"FINISHED"}

        p = s.patterns.add()
        p.name = next_pattern_name(s, "Unsaved Pattern")
        p.allow_duplicate = False
        p.visibility = normalize_pattern_visibility(visibility)
        p.bits = bits
        p.value = value
        s.active_pattern = len(s.patterns) - 1

        save_global_library(s)

        si.pattern_source = "LIBRARY"
        si.pattern_choice = f"PAT_{s.active_pattern}"
        si.custom_bits = bits
        si.custom_value = value
        sync_siren_selector_controls(si)
        mark_preview_dirty(context)
        self.report({"INFO"}, f"Saved pattern as {p.name}")
        return {"FINISHED"}


class NELS_OT_pattern_duplicate_resolution(Operator):
    bl_idname = "nels.pattern_duplicate_resolution"
    bl_label = "Resolve Pattern Duplicate"
    bl_options = {"REGISTER", "UNDO"}

    action: EnumProperty(items=[("ALLOW", "Allow Duplicate", ""), ("KEEP_SELECTED", "Keep Selected Only", ""), ("WARN", "Warn Again", "")], default="ALLOW")
    index: IntProperty(default=-1)

    def execute(self, context):
        s = context.scene.nels
        idx = max(0, min(self.index, len(s.patterns) - 1)) if s.patterns else -1
        matches = pattern_duplicate_indices(s, idx)
        if idx < 0 or not matches:
            self.report({"INFO"}, "No duplicate pattern name detected")
            return {"CANCELLED"}

        if self.action == "ALLOW":
            count = set_pattern_duplicate_allowed(s, idx, True)
            save_global_library(s)
            self.report({"INFO"}, f"Duplicate allowed for {count} patterns")
            return {"FINISHED"}

        if self.action == "WARN":
            count = set_pattern_duplicate_allowed(s, idx, False)
            save_global_library(s)
            self.report({"INFO"}, f"Duplicate warning restored for {count} patterns")
            return {"FINISHED"}

        removed, keep_idx = remove_pattern_duplicates_keep_selected(s, idx)
        s.active_pattern = min(max(0, keep_idx), max(0, len(s.patterns) - 1))
        save_global_library(s)
        self.report({"INFO"}, f"Removed {removed} duplicate patterns")
        return {"FINISHED"}



class NELS_OT_siren_filter_bulk(Operator):
    bl_idname = "nels.siren_filter_bulk"
    bl_label = "Filter Sirens"
    bl_options = {"REGISTER", "UNDO"}

    action: EnumProperty(items=[("SHOW_ALL", "Show All", ""), ("HIDE_ALL", "Hide All", ""), ("BY_DIRECTION", "By Direction", "")], default="SHOW_ALL")
    direction: EnumProperty(items=DIRECTION_ITEMS, default="FRONT")

    def execute(self, context):
        s = getattr(getattr(context, "scene", None), "nels", None)
        if not s or not getattr(s, "sirens", None):
            self.report({"WARNING"}, "Please add Sirens to configure them.")
            return {"CANCELLED"}

        changed = 0
        visible = []
        target_direction = str(getattr(self, "direction", "") or getattr(s, "siren_filter_direction", "FRONT") or "FRONT")
        s.siren_filter_direction = target_direction

        for si in s.sirens:
            if self.action == "SHOW_ALL":
                new_state = True
            elif self.action == "HIDE_ALL":
                new_state = False
            else:
                preset = str(getattr(si, "direction_select", "") or "")
                if preset == "__CUSTOM__" or not preset:
                    preset = direction_preset_from_value(dir_val(si)) or "FRONT"
                new_state = (preset == target_direction)
            if bool(getattr(si, "filter_selected", False)) != bool(new_state):
                si.filter_selected = bool(new_state)
                changed += 1
            if bool(new_state):
                visible.append(si)

        if visible and not any(bool(getattr(si, "expanded", False)) for si in visible):
            try:
                visible[0].expanded = True
            except Exception:
                pass

        mark_preview_dirty(context)
        if self.action == "SHOW_ALL":
            self.report({"INFO"}, f"Showing all {len(s.sirens)} sirens")
        elif self.action == "HIDE_ALL":
            self.report({"INFO"}, "Hid all sirens from the filter")
        else:
            self.report({"INFO"}, f"Showing {len(visible)} sirens facing {target_direction.replace('_', ' ').title()}")
        return {"FINISHED"}

class NELS_OT_pattern_library_io(Operator):
    bl_idname = "nels.pattern_library_io"
    bl_label = "Pattern Library Import/Export"
    bl_options = {"REGISTER", "UNDO"}

    action: EnumProperty(items=[("EXPORT", "EXPORT", ""), ("IMPORT", "IMPORT", "")], default="EXPORT")

    def execute(self, context):
        s = context.scene.nels
        fp = bpy.path.abspath(getattr(s, "pattern_library_path", "") or "").strip()
        if not fp:
            self.report({"ERROR"}, "Pattern library path is empty")
            return {"CANCELLED"}
        if not fp.lower().endswith(".json"):
            fp += ".json"

        try:
            if self.action == "EXPORT":
                out_dir = os.path.dirname(fp)
                if out_dir:
                    os.makedirs(out_dir, exist_ok=True)

                data = {
                    "patterns": [
                        {
                            "name": p.name,
                            "visibility": "FLASHER" if p.visibility == "FLASHER" else "BOTH",
                            "bits": repeat_32(p.bits),
                            "value": parse_u32(p.value),
                            "allow_duplicate": bool(getattr(p, "allow_duplicate", False)),
                        }
                        for p in s.patterns
                    ]
                }
                with open(fp, "w", encoding="utf-8") as h:
                    json.dump(data, h, indent=2)
                s.pattern_library_path = fp
                s.status_message = f"Pattern library exported: {fp}"
                self.report({"INFO"}, s.status_message)
                return {"FINISHED"}

            if not os.path.exists(fp):
                self.report({"ERROR"}, f"Pattern library not found: {fp}")
                return {"CANCELLED"}

            with open(fp, "r", encoding="utf-8") as h:
                data = json.load(h)

            if isinstance(data, dict):
                pats = data.get("patterns", [])
            elif isinstance(data, list):
                pats = data
            else:
                self.report({"ERROR"}, "Invalid pattern library format")
                return {"CANCELLED"}

            if not isinstance(pats, list):
                self.report({"ERROR"}, "Pattern library must contain a list of patterns")
                return {"CANCELLED"}

            s.patterns.clear()
            for pd in pats:
                if not isinstance(pd, dict):
                    continue
                p = s.patterns.add()
                p.name = str(pd.get("name", "Pattern") or "Pattern")
                p.allow_duplicate = bool(pd.get("allow_duplicate", False))
                p.visibility = "FLASHER" if pd.get("visibility", "BOTH") == "FLASHER" else "BOTH"
                bits = clean_bits(pd.get("bits", int_to_bits(pd.get("value", 0)))) or "0"
                p.bits = bits
                p.value = str(parse_u32(pd.get("value", bits_to_int(bits))))

            ensure_off_pattern(s)
            s.active_pattern = min(max(0, s.active_pattern), max(0, len(s.patterns) - 1))
            save_global_library(s)
            s.pattern_library_path = fp
            s.status_message = f"Pattern library imported: {fp}"
            self.report({"INFO"}, s.status_message)
            return {"FINISHED"}
        except Exception as ex:
            self.report({"ERROR"}, f"Pattern library {self.action.lower()} failed: {ex}")
            return {"CANCELLED"}
class NELS_OT_color_tools(Operator):
    bl_idname = "nels.color_tools"
    bl_label = "Color Tools"
    bl_options = {"REGISTER", "UNDO"}

    action: EnumProperty(items=[("ADD", "ADD", ""), ("REMOVE", "REMOVE", "")])

    def execute(self, context):
        s = context.scene.nels
        ensure_color_defaults(s)

        if self.action == "ADD":
            c = s.colors.add()
            c.name = f"Custom Colour {len(s.colors)}"
            c.rgb = (1.0, 0.0, 0.0)
            c.value = rgb_to_color(c.rgb)
            s.active_color = len(s.colors) - 1
            save_global_library(s)
            return {"FINISHED"}

        if not s.colors:
            return {"CANCELLED"}
        i = max(0, min(s.active_color, len(s.colors) - 1))
        s.colors.remove(i)
        if not s.colors:
            ensure_color_defaults(s)
        s.active_color = min(i, max(0, len(s.colors) - 1))
        for si in s.sirens:
            si.color_preset = normalize_color_key(si.color_preset)
        save_global_library(s)
        return {"FINISHED"}


class NELS_OT_other_attr_tools(Operator):
    bl_idname = "nels.other_attr_tools"
    bl_label = "Other Attribute Tools"
    bl_options = {"REGISTER", "UNDO"}

    action: EnumProperty(items=[("ADD", "ADD", ""), ("REMOVE", "REMOVE", "")], default="ADD")

    def execute(self, context):
        s = context.scene.nels
        ensure_other_attributes_defaults(s)

        if self.action == "ADD":
            a = s.other_attributes.add()
            a.display_value = f"Attribute {len(s.other_attributes)}"
            a.return_value = ""
            s.active_other_attribute = len(s.other_attributes) - 1
            return {"FINISHED"}

        if not s.other_attributes:
            return {"CANCELLED"}
        i = max(0, min(s.active_other_attribute, len(s.other_attributes) - 1))
        s.other_attributes.remove(i)
        if not s.other_attributes:
            ensure_other_attributes_defaults(s)
        s.active_other_attribute = min(i, max(0, len(s.other_attributes) - 1))
        return {"FINISHED"}


class NELS_OT_light_id_faces(Operator):
    bl_idname = "nels.light_id_faces"
    bl_label = "Light IDs"
    bl_options = {"REGISTER", "UNDO"}

    action: EnumProperty(items=[("SET", "Set", "Assign the selected Light ID to the selected faces"), ("SELECT", "Select", "Select faces that already use the chosen Light ID")], default="SET")

    def execute(self, context):
        scene = getattr(context, "scene", None)
        s = getattr(scene, "nels", None) if scene else None
        if not s:
            self.report({"WARNING"}, "No scene settings available")
            return {"CANCELLED"}
        if not light_id_face_select_ready(context):
            self.report({"WARNING"}, "Must be in Edit Mode > Face Select")
            return {"CANCELLED"}

        obj = getattr(context, "active_object", None)
        if not obj or getattr(obj, "type", "") != "MESH":
            self.report({"WARNING"}, "Select a mesh in Edit Mode")
            return {"CANCELLED"}

        bm = bmesh.from_edit_mesh(obj.data)
        bm.faces.ensure_lookup_table()
        value = current_light_id_value(s)
        label = next((item[1] for item in SOLLUMZ_LIGHT_ID_UI_ITEMS if item[0] == getattr(s, "car_light_id_target", "always_on")), "Custom")

        if self.action == "SET":
            selected_indices = [face.index for face in bm.faces if face.select]
            if not selected_indices:
                self.report({"WARNING"}, "Select one or more faces first")
                return {"CANCELLED"}
            layer = editable_light_id_face_layer(bm, create=True)
            if layer is None:
                self.report({"ERROR"}, "Could not access a face integer layer for Light IDs")
                return {"CANCELLED"}
            bm.faces.ensure_lookup_table()
            for face_index in selected_indices:
                if 0 <= face_index < len(bm.faces):
                    bm.faces[face_index][layer] = int(value)
            bmesh.update_edit_mesh(obj.data, loop_triangles=False, destructive=False)
            s.car_light_id_signature = ""
            s.car_light_id_checked_at = 0.0
            apply_car_light_simulation(scene, s, blink_indicators=True, now=playback_seconds(scene=scene))
            self.report({"INFO"}, f"Assigned {label} to {len(selected_indices)} face(s)")
            return {"FINISHED"}

        layer = editable_light_id_face_layer(bm, create=False)
        if layer is None:
            self.report({"WARNING"}, "No editable Light ID layer was found on this mesh")
            return {"CANCELLED"}

        match_count = 0
        for face in bm.faces:
            is_match = int(face[layer]) == int(value)
            face.select_set(is_match)
            if is_match:
                match_count += 1
        bmesh.update_edit_mesh(obj.data, loop_triangles=False, destructive=False)
        if match_count <= 0:
            self.report({"WARNING"}, f"No faces use {label}")
            return {"CANCELLED"}
        self.report({"INFO"}, f"Selected {match_count} face(s) using {label}")
        return {"FINISHED"}

class NELS_OT_car_lights_sim(Operator):
    bl_idname = "nels.car_lights_sim"
    bl_label = "Apply Car Light Simulation"
    bl_options = {"REGISTER", "UNDO"}

    action: EnumProperty(items=[("APPLY", "APPLY", ""), ("RESET", "RESET", "")], default="APPLY")

    def execute(self, context):
        s = context.scene.nels
        scene = context.scene

        if self.action == "RESET":
            s.car_headlights_on = False
            s.car_taillights_on = False
            s.car_left_indicator_on = False
            s.car_right_indicator_on = False
            s.car_extra_lights_on = False

        touched = apply_car_light_simulation(scene, s, blink_indicators=True, now=playback_seconds(scene=scene))
        msg = f"Applied car light simulation to {touched} objects"
        s.status_message = msg
        self.report({"INFO"}, msg)
        return {"FINISHED"}


class NELS_OT_wheel_simulation(Operator):
    bl_idname = "nels.wheel_simulation"
    bl_label = "Wheel Preview"
    bl_options = {"REGISTER", "UNDO"}

    action: EnumProperty(items=[("APPLY", "APPLY", ""), ("RESET", "RESET", "")], default="APPLY")

    @classmethod
    def poll(cls, context):
        return bool(sollumz_enabled())

    def execute(self, context):
        s = context.scene.nels
        scene = context.scene

        if self.action == "RESET":
            removed = clear_sollumz_wheel_preview_objects(scene) + clear_wheel_preview_objects(scene)
            msg = f"Cleared {removed} wheel preview objects"
            s.status_message = msg
            self.report({"INFO"}, msg)
            return {"FINISHED"}

        ok, used_name, error_message = run_sollumz_wheel_preview(context, scene)
        if not ok:
            msg = error_message or "Could not run Sollumz wheel preview. Select an object inside the Sollumz fragment and try again."
            s.status_message = msg
            self.report({"WARNING"}, msg)
            return {"CANCELLED"}

        msg = f"Generated Sollumz wheel preview using {used_name}" if used_name else "Generated Sollumz wheel preview"
        s.status_message = msg
        self.report({"INFO"}, msg)
        return {"FINISHED"}


def clear_sollumz_wheel_preview_objects(scene):
    scene_names = {obj.name for obj in getattr(scene, "objects", [])} if scene else set()
    roots = []
    for obj in bpy.data.objects:
        name = str(getattr(obj, "name", "") or "")
        if scene_names and name not in scene_names:
            continue
        if name.endswith(".wheel_previews"):
            roots.append(obj)

    seen = set()
    ordered = []

    def collect(obj):
        if not obj:
            return
        name = str(getattr(obj, "name", "") or "")
        if name in seen:
            return
        seen.add(name)
        for child in list(getattr(obj, "children", [])):
            collect(child)
        ordered.append(obj)

    for root in roots:
        collect(root)

    removed = 0
    for obj in ordered:
        try:
            bpy.data.objects.remove(obj, do_unlink=True)
            removed += 1
        except Exception:
            pass
    return removed


def run_sollumz_wheel_preview(context, scene):
    op_group = getattr(bpy.ops, "sollumz", None)
    op = getattr(op_group, "generate_wheel_instances", None) if op_group else None
    if op is None:
        return False, "", "Sollumz wheel preview is not available. Enable Sollumz first."

    arm, bones = wheel_pose_bones(scene)
    wheel_candidates = scene_wheel_mesh_objects(scene, arm, bones)
    if not wheel_candidates:
        return False, "", "No wheel meshes were found for the current vehicle."

    candidates = []
    seen = set()

    def add_candidate(obj):
        if not obj:
            return
        try:
            name = str(obj.name)
        except Exception:
            return
        if name in seen:
            return
        seen.add(name)
        candidates.append(obj)

    active = getattr(context, "active_object", None)
    if active in wheel_candidates:
        add_candidate(active)

    preferred = find_source_wheel_object(context, arm, bones)
    if preferred in wheel_candidates:
        add_candidate(preferred)

    for obj in wheel_candidates:
        add_candidate(obj)

    last_error = ""
    for obj in candidates:
        try:
            with context.temp_override(
                active_object=obj,
                object=obj,
                selected_objects=[obj],
                selected_editable_objects=[obj],
            ):
                if not bpy.ops.sollumz.generate_wheel_instances.poll():
                    continue
                bpy.ops.sollumz.generate_wheel_instances()
                return True, str(getattr(obj, "name", "") or ""), ""
        except Exception as ex:
            last_error = str(ex)

    return False, "", last_error or "No usable wheel mesh was found for Sollumz wheel preview."


class NELS_OT_environment_lights(Operator):
    bl_idname = "nels.environment_lights"
    bl_label = "Environmental Lights"
    bl_options = {"REGISTER", "UNDO"}

    action: EnumProperty(
        items=[
            ("GENERATE", "Generate", "Create or update environment preview lights for active sirens"),
            ("CLEAR", "Clear", "Remove previously generated environment preview lights"),
        ],
        default="GENERATE",
    )

    def execute(self, context):
        scene = getattr(context, "scene", None)
        s = getattr(scene, "nels", None) if scene else None
        if not scene or not s:
            self.report({"WARNING"}, "No scene settings available")
            return {"CANCELLED"}

        if self.action == "CLEAR":
            removed = clear_environment_lights(scene)
            self.report({"INFO"}, f"Removed {removed} generated environment light(s)")
            return {"FINISHED"}

        created, updated = generate_environment_lights(scene, s)
        self.report({"INFO"}, f"Environment lights updated: {created} created, {updated} updated")
        return {"FINISHED"}


class NELS_OT_extra_visibility(Operator):
    bl_idname = "nels.extra_visibility"
    bl_label = "Set Extra Visibility"
    bl_options = {"REGISTER", "UNDO"}

    object_name: StringProperty(default="")
    show: BoolProperty(default=True)

    def execute(self, context):
        obj = bpy.data.objects.get(self.object_name)
        if not obj:
            return {"CANCELLED"}
        set_object_visible(obj, self.show)
        return {"FINISHED"}


class NELS_OT_extras_visibility_all(Operator):
    bl_idname = "nels.extras_visibility_all"
    bl_label = "Set All Extras Visibility"
    bl_options = {"REGISTER", "UNDO"}

    show: BoolProperty(default=True)

    def execute(self, context):
        objs = scene_extra_objects(context.scene)
        for obj in objs:
            set_object_visible(obj, self.show)
        self.report({"INFO"}, f"Updated {len(objs)} extras")
        return {"FINISHED"}


class NELS_OT_toggle_extra_visibility(Operator):
    bl_idname = "nels.toggle_extra_visibility"
    bl_label = "Toggle Extra Visibility"
    bl_options = {"REGISTER", "UNDO"}

    object_name: StringProperty(default="")

    def execute(self, context):
        scene = getattr(context, "scene", None)
        s = getattr(scene, "nels", None) if scene else None
        obj = bpy.data.objects.get(self.object_name)
        if not obj:
            msg = "The chosen extra could not be found"
            if s:
                s.status_message = msg
            self.report({"WARNING"}, msg)
            return {"CANCELLED"}
        show = not is_object_visible(obj)
        set_object_visible(obj, show)
        msg = f"{'Showed' if show else 'Hid'} {extra_display_name(obj)}"
        if s:
            s.status_message = msg
        self.report({"INFO"}, msg)
        return {"FINISHED"}


class NELS_OT_select_extra(Operator):
    bl_idname = "nels.select_extra"
    bl_label = "Select Extra"
    bl_options = {"REGISTER", "UNDO"}

    object_name: StringProperty(default="")

    def execute(self, context):
        scene = getattr(context, "scene", None)
        s = getattr(scene, "nels", None) if scene else None
        obj = bpy.data.objects.get(self.object_name)
        if not obj:
            msg = "The chosen extra could not be found"
            if s:
                s.status_message = msg
            self.report({"WARNING"}, msg)
            return {"CANCELLED"}
        try:
            if getattr(context, "mode", "OBJECT") != "OBJECT":
                bpy.ops.object.mode_set(mode="OBJECT")
        except Exception:
            pass
        try:
            bpy.ops.object.select_all(action="DESELECT")
        except Exception:
            pass
        try:
            obj.select_set(True)
            context.view_layer.objects.active = obj
        except Exception:
            msg = f"Could not select {extra_display_name(obj)}"
            if s:
                s.status_message = msg
            self.report({"WARNING"}, msg)
            return {"CANCELLED"}
        msg = f"Selected {extra_display_name(obj)}"
        if s:
            s.status_message = msg
        self.report({"INFO"}, msg)
        return {"FINISHED"}


class NELS_OT_collisions_visibility_all(Operator):
    bl_idname = "nels.collisions_visibility_all"
    bl_label = "Set Collision Visibility"
    bl_options = {"REGISTER", "UNDO"}

    show: BoolProperty(default=True)

    def execute(self, context):
        scene = getattr(context, "scene", None)
        s = getattr(scene, "nels", None) if scene else None
        objs = scene_collision_objects(scene)
        if not objs:
            msg = "No collision objects were found in the current scene"
            if s:
                s.status_message = msg
            self.report({"WARNING"}, msg)
            return {"CANCELLED"}
        for obj in objs:
            set_object_visible(obj, self.show)
        msg = f"{'Showed' if self.show else 'Hid'} {len(objs)} collision object{'s' if len(objs) != 1 else ''}"
        if s:
            s.status_message = msg
        self.report({"INFO"}, msg)
        return {"FINISHED"}

class NELS_OT_set_siren_count(Operator):
    bl_idname = "nels.set_siren_count"
    bl_label = "Set Siren Count"
    bl_options = {"REGISTER", "UNDO"}
    count: IntProperty(default=20)

    def execute(self, context):
        ensure_sirens(context.scene.nels, self.count)
        return {"FINISHED"}



class NELS_OT_swap_sirens(Operator):
    bl_idname = "nels.swap_sirens"
    bl_label = "Swap Sirens"
    bl_options = {"REGISTER", "UNDO"}

    siren_a: EnumProperty(name="First Siren", items=swappable_siren_items)
    siren_b: EnumProperty(name="Second Siren", items=swappable_siren_items)

    def invoke(self, context, event):
        items = [item[0] for item in swappable_siren_items(self, context) if item[0] != "__NONE__"]
        if len(items) < 2:
            msg = "Warning: Link mesh and bone for at least two sirens before swapping"
            context.scene.nels.status_message = msg
            self.report({"WARNING"}, msg)
            return {"CANCELLED"}
        if self.siren_a not in items:
            self.siren_a = items[0]
        if self.siren_b not in items or self.siren_b == self.siren_a:
            self.siren_b = next((item for item in items if item != self.siren_a), items[0])
        return context.window_manager.invoke_props_dialog(self, width=360)

    def draw(self, context):
        l = self.layout
        l.label(text="Swap the scene mesh and bone names for two configured sirens.")
        l.prop(self, "siren_a", text="First Siren")
        l.prop(self, "siren_b", text="Second Siren")

    def execute(self, context):
        scene = context.scene
        s = scene.nels
        if self.siren_a == "__NONE__" or self.siren_b == "__NONE__":
            msg = "Warning: Link mesh and bone for at least two sirens before swapping"
            s.status_message = msg
            self.report({"WARNING"}, msg)
            return {"CANCELLED"}
        if self.siren_a == self.siren_b:
            msg = "Warning: Choose two different sirens to swap"
            s.status_message = msg
            self.report({"WARNING"}, msg)
            return {"CANCELLED"}

        si_a = siren_slot_by_index(s, self.siren_a)
        si_b = siren_slot_by_index(s, self.siren_b)
        if not si_a or not si_b:
            msg = "Warning: Could not resolve the selected sirens"
            s.status_message = msg
            self.report({"WARNING"}, msg)
            return {"CANCELLED"}

        obj_a = siren_obj(si_a)
        obj_b = siren_obj(si_b)
        arm_a, pb_a = siren_pose_bone(scene, si_a)
        arm_b, pb_b = siren_pose_bone(scene, si_b)
        if not obj_a or obj_a.type != "MESH" or not obj_b or obj_b.type != "MESH":
            msg = "Warning: Both selected sirens must have linked mesh objects before swapping"
            s.status_message = msg
            self.report({"WARNING"}, msg)
            return {"CANCELLED"}
        if not arm_a or not pb_a or not arm_b or not pb_b:
            msg = "Warning: Both selected sirens must have linked bones before swapping"
            s.status_message = msg
            self.report({"WARNING"}, msg)
            return {"CANCELLED"}

        old_obj_a_name = obj_a.name
        old_obj_b_name = obj_b.name
        old_bone_a_name = pb_a.name
        old_bone_b_name = pb_b.name
        new_obj_a_name = f"siren{si_b.index}"
        new_obj_b_name = f"siren{si_a.index}"
        new_bone_a_name = f"siren{si_b.index}"
        new_bone_b_name = f"siren{si_a.index}"

        def object_name_conflict(target_name):
            other = bpy.data.objects.get(target_name)
            return other is not None and other not in (obj_a, obj_b)

        def bone_name_conflict(arm, target_name, allowed_names):
            bone = arm.data.bones.get(target_name) if arm and getattr(arm, "data", None) else None
            return bone is not None and bone.name not in allowed_names

        if object_name_conflict(new_obj_a_name) or object_name_conflict(new_obj_b_name):
            msg = "Warning: A different scene object is already using one of the target siren names"
            s.status_message = msg
            self.report({"WARNING"}, msg)
            return {"CANCELLED"}

        allowed_a = {old_bone_a_name}
        allowed_b = {old_bone_b_name}
        if arm_a == arm_b:
            allowed_a.add(old_bone_b_name)
            allowed_b.add(old_bone_a_name)
        if bone_name_conflict(arm_a, new_bone_a_name, allowed_a) or bone_name_conflict(arm_b, new_bone_b_name, allowed_b):
            msg = "Warning: A different siren bone is already using one of the target siren names"
            s.status_message = msg
            self.report({"WARNING"}, msg)
            return {"CANCELLED"}

        def capture_children(arm, bone_name):
            links = []
            for child in scene.objects:
                try:
                    if child.parent == arm and child.parent_type == "BONE" and child.parent_bone == bone_name:
                        links.append((child, child.matrix_world.copy()))
                except Exception:
                    continue
            return links

        def restore_children(links, arm, bone_name):
            for child, matrix_world in links:
                try:
                    child.parent = arm
                    child.parent_type = "BONE"
                    child.parent_bone = bone_name
                    child.matrix_world = matrix_world
                except Exception:
                    continue

        child_links_a = capture_children(arm_a, old_bone_a_name)
        child_links_b = capture_children(arm_b, old_bone_b_name)
        temp_tag = _time.time_ns()
        temp_obj_a_name = f"__nels_swap_obj_{si_a.index}_{temp_tag}_a"
        temp_obj_b_name = f"__nels_swap_obj_{si_b.index}_{temp_tag}_b"
        temp_bone_a_name = f"__nels_swap_bone_{si_a.index}_{temp_tag}_a"
        temp_bone_b_name = f"__nels_swap_bone_{si_b.index}_{temp_tag}_b"

        old_active = getattr(context.view_layer.objects, "active", None)
        old_mode = getattr(context, "mode", "OBJECT")
        try:
            obj_a.name = temp_obj_a_name
            obj_b.name = temp_obj_b_name
            obj_a.name = new_obj_a_name
            obj_b.name = new_obj_b_name

            plans = []
            if arm_a == arm_b:
                plans.append((arm_a, [(old_bone_a_name, temp_bone_a_name), (old_bone_b_name, temp_bone_b_name)], [(temp_bone_a_name, new_bone_a_name), (temp_bone_b_name, new_bone_b_name)]))
            else:
                plans.append((arm_a, [(old_bone_a_name, temp_bone_a_name)], [(temp_bone_a_name, new_bone_a_name)]))
                plans.append((arm_b, [(old_bone_b_name, temp_bone_b_name)], [(temp_bone_b_name, new_bone_b_name)]))

            if old_mode != "OBJECT":
                bpy.ops.object.mode_set(mode="OBJECT")
            for arm, temp_pairs, final_pairs in plans:
                bpy.ops.object.select_all(action="DESELECT")
                arm.select_set(True)
                context.view_layer.objects.active = arm
                bpy.ops.object.mode_set(mode="EDIT")
                for old_name, temp_name in temp_pairs:
                    eb = arm.data.edit_bones.get(old_name)
                    if not eb:
                        raise RuntimeError(f"Missing editable bone {old_name}")
                    eb.name = temp_name
                for temp_name, final_name in final_pairs:
                    eb = arm.data.edit_bones.get(temp_name)
                    if not eb:
                        raise RuntimeError(f"Missing temporary bone {temp_name}")
                    eb.name = final_name
                bpy.ops.object.mode_set(mode="OBJECT")
        except Exception as exc:
            msg = f"Warning: Failed to swap sirens: {exc}"
            s.status_message = msg
            self.report({"WARNING"}, msg)
            return {"CANCELLED"}
        finally:
            try:
                if getattr(context, "mode", "OBJECT") != "OBJECT":
                    bpy.ops.object.mode_set(mode="OBJECT")
            except Exception:
                pass
            try:
                if old_active and old_active.name in bpy.data.objects:
                    context.view_layer.objects.active = old_active
            except Exception:
                pass
            try:
                if old_mode != "OBJECT" and getattr(context, "mode", "OBJECT") == "OBJECT":
                    bpy.ops.object.mode_set(mode=old_mode)
            except Exception:
                pass

        restore_children(child_links_a, arm_a, new_bone_a_name)
        restore_children(child_links_b, arm_b, new_bone_b_name)

        object_map = {old_obj_a_name: new_obj_a_name, old_obj_b_name: new_obj_b_name}
        bone_map = {old_bone_a_name: new_bone_a_name, old_bone_b_name: new_bone_b_name}
        for si in s.sirens:
            if si.object_name in object_map:
                si.object_name = object_map[si.object_name]
            if si.bone_name in bone_map:
                si.bone_name = bone_map[si.bone_name]
            si.enabled = bool(si.object_name or si.bone_name)

        anchor_a = si_a.anchor_name
        anchor_b = si_b.anchor_name
        si_a.object_name = f"siren{si_a.index}"
        si_b.object_name = f"siren{si_b.index}"
        si_a.bone_name = f"siren{si_a.index}"
        si_b.bone_name = f"siren{si_b.index}"
        si_a.anchor_name = anchor_b
        si_b.anchor_name = anchor_a
        si_a.enabled = True
        si_b.enabled = True

        apply_all_siren_directions(scene)
        refresh_direction_warning(scene)
        mark_preview_dirty(context)
        tag_all_ui_redraw()

        msg = f"Swapped Siren {si_a.index} and Siren {si_b.index}"
        s.status_message = msg
        self.report({"INFO"}, msg)
        return {"FINISHED"}


class NELS_OT_renumber_siren(Operator):
    bl_idname = "nels.renumber_siren"
    bl_label = "Renumber Siren"
    bl_options = {"REGISTER", "UNDO"}

    source_siren: EnumProperty(name="Source Siren", items=scene_siren_items)
    target_index: EnumProperty(name="New Siren Number", items=renumber_target_items)

    def invoke(self, context, event):
        scene = context.scene
        s = getattr(scene, "nels", None)
        if not s or not s.sirens:
            self.report({"WARNING"}, "No sirens are configured")
            return {"CANCELLED"}
        clear_missing_associations(scene)
        source_items = [item[0] for item in scene_siren_items(self, context) if item[0] != "__NONE__"]
        if not source_items:
            self.report({"WARNING"}, "No sirens were found in the current scene")
            return {"CANCELLED"}
        source = resolve_context_siren(scene, s, require_linked=False)
        default_source = f"siren{int(getattr(source, 'index', 0) or 0)}" if source else source_items[0]
        if self.source_siren not in source_items:
            self.source_siren = default_source if default_source in source_items else source_items[0]
        items = [item[0] for item in renumber_target_items(self, context) if item[0] != "__NONE__"]
        if not items:
            self.report({"WARNING"}, "No available siren numbers exist in the current configuration")
            return {"CANCELLED"}
        if self.target_index not in items:
            self.target_index = items[0]
        return context.window_manager.invoke_props_dialog(self, width=340)

    def draw(self, context):
        self.layout.label(text="Rename a scene siren hierarchy to an unused configured siren number.")
        self.layout.prop(self, "source_siren", text="Source")
        self.layout.prop(self, "target_index", text="Target")

    def execute(self, context):
        scene = context.scene
        s = getattr(scene, "nels", None)
        if not s or not s.sirens:
            self.report({"ERROR"}, "No sirens are configured")
            return {"CANCELLED"}

        clear_missing_associations(scene)
        if self.target_index == "__NONE__":
            self.report({"ERROR"}, "No target siren number is available")
            return {"CANCELLED"}

        try:
            target_index = int(self.target_index)
        except Exception:
            self.report({"ERROR"}, "Invalid target siren number")
            return {"CANCELLED"}

        limit = max(0, min(int(getattr(s, "siren_count", len(s.sirens)) or len(s.sirens)), len(s.sirens)))
        if target_index < 1 or target_index > limit:
            self.report({"ERROR"}, f"Target siren must be between 1 and {limit}")
            return {"CANCELLED"}

        target_slot = siren_slot_by_index(s, target_index)
        if not target_slot:
            self.report({"ERROR"}, f"Could not resolve Siren {target_index}")
            return {"CANCELLED"}
        if (siren_obj(target_slot) or siren_pose_bone(scene, target_slot)[1]):
            self.report({"ERROR"}, f"Siren {target_index} already exists in the scene")
            return {"CANCELLED"}

        source_idx = siren_index_from_name(str(getattr(self, "source_siren", "") or ""))
        source_slot = siren_slot_by_index(s, source_idx) or resolve_context_siren(scene, s, require_linked=False)
        if not source_slot:
            self.report({"ERROR"}, "Choose a source siren first")
            return {"CANCELLED"}
        source_obj = siren_obj(source_slot)
        active = getattr(context, "active_object", None)
        active_idx = infer_siren_index_from_hierarchy(active, fallback=infer_siren_index_from_object(active, s=s)) if active else 0
        if active and active_idx == int(getattr(source_slot, "index", 0) or 0):
            source_obj = selected_siren_root_object(context, fallback=source_obj)
        if not source_obj:
            self.report({"ERROR"}, "The chosen source siren has no linked mesh")
            return {"CANCELLED"}

        old_index = infer_siren_index_from_hierarchy(source_obj, fallback=int(getattr(source_slot, "index", 0) or 0))
        if old_index <= 0:
            self.report({"ERROR"}, "Could not determine the siren number from the selected hierarchy")
            return {"CANCELLED"}
        if old_index == target_index:
            self.report({"ERROR"}, "Choose a different siren number")
            return {"CANCELLED"}

        source_slot = siren_slot_by_index(s, old_index) or source_slot
        source_snapshot = capture_siren_slot_snapshot(source_slot) if source_slot else None
        old_object_name = getattr(source_obj, "name", "")
        old_anchor_name = getattr(source_slot, "anchor_name", "") if source_slot else ""
        old_bone_name = str(getattr(source_slot, "bone_name", "") or f"siren{old_index}")

        try:
            arm, pb = siren_pose_bone(scene, source_slot) if source_slot else (None, None)
            renamed_bones = {}
            new_root_bone_name = ""
            if arm and pb:
                renamed_bones, new_root_bone_name = rename_siren_bone_hierarchy(scene, arm, pb.name, old_index, target_index)
            hierarchy = retarget_siren_hierarchy(source_obj, old_index, target_index, detach_root=False)
            renamed_objects = set(hierarchy or [])
            if arm and renamed_bones:
                subtree_bones = set(renamed_bones.values())
                extra_roots = []
                for obj in scene.objects:
                    try:
                        if obj in renamed_objects:
                            continue
                        if obj.parent == arm and obj.parent_type == "BONE" and obj.parent_bone in subtree_bones:
                            extra_roots.append(obj)
                    except Exception:
                        continue
                for obj in extra_roots:
                    renamed_objects.update(retarget_siren_hierarchy(obj, old_index, target_index, detach_root=False, force_root_name=False) or [])
            new_object_name = getattr(source_obj, "name", f"siren{target_index}")
        except Exception as exc:
            self.report({"ERROR"}, f"Failed to renumber siren: {exc}")
            return {"CANCELLED"}

        if source_snapshot:
            apply_siren_slot_snapshot(s, target_slot, target_index, source_snapshot)
        else:
            add_siren(s, target_slot, target_index)

        target_slot.object_name = new_object_name
        if new_root_bone_name:
            target_slot.bone_name = new_root_bone_name
        elif renamed_bones:
            target_slot.bone_name = renamed_bones.get(old_bone_name, f"siren{target_index}")
        target_slot.anchor_name = old_anchor_name
        target_slot.enabled = True

        if source_slot:
            add_siren(s, source_slot, old_index)
        s.active_siren = max(0, target_index - 1)

        refresh_direction_warning(scene)
        apply_all_siren_directions(scene)
        clear_preview_keyframes(scene, list(s.sirens))
        s.preview_generated = False
        mark_preview_dirty(context)
        tag_all_ui_redraw()

        msg = f"Renumbered siren{old_index} to siren{target_index}"
        s.status_message = msg
        self.report({"INFO"}, msg)
        return {"FINISHED"}


class NELS_OT_duplicate_siren(Operator):
    bl_idname = "nels.duplicate_siren"
    bl_label = "Duplicate Siren"
    bl_options = {"REGISTER", "UNDO"}

    source_siren: EnumProperty(name="Source Siren", items=scene_siren_items)
    target_index: EnumProperty(name="Target Siren", items=renumber_target_items)

    def invoke(self, context, event):
        scene = context.scene
        s = getattr(scene, "nels", None)
        if not s or not s.sirens:
            return {"CANCELLED"}
        source_items = [item[0] for item in scene_siren_items(self, context) if item[0] != "__NONE__"]
        if not source_items:
            self.report({"WARNING"}, "No sirens were found in the current scene")
            return {"CANCELLED"}
        source = resolve_context_siren(scene, s, require_linked=True)
        default_source = f"siren{int(getattr(source, 'index', 0) or 0)}" if source else source_items[0]
        if self.source_siren not in source_items:
            self.source_siren = default_source if default_source in source_items else source_items[0]
        items = [item[0] for item in renumber_target_items(self, context) if item[0] != "__NONE__"]
        if not items:
            self.report({"WARNING"}, "No available siren numbers exist in the current configuration")
            return {"CANCELLED"}
        suggested = str(suggest_duplicate_target_index(s, source.index)) if source else items[0]
        self.target_index = suggested if suggested in items else items[0]
        return context.window_manager.invoke_props_dialog(self, width=340)

    def draw(self, context):
        self.layout.label(text="Duplicate a scene siren hierarchy to an unused configured siren number.")
        self.layout.prop(self, "source_siren", text="Source")
        self.layout.prop(self, "target_index", text="Target")

    def execute(self, context):
        scene = context.scene
        s = getattr(scene, "nels", None)
        if not s or not s.sirens:
            self.report({"ERROR"}, "Please add Sirens to configure them.")
            return {"CANCELLED"}

        source_idx = siren_index_from_name(str(getattr(self, "source_siren", "") or ""))
        source = siren_slot_by_index(s, source_idx) or resolve_context_siren(scene, s, require_linked=True)
        if not source:
            self.report({"ERROR"}, "Choose a source siren first")
            return {"CANCELLED"}

        if self.target_index == "__NONE__":
            self.report({"ERROR"}, "No target siren number is available")
            return {"CANCELLED"}
        target_index = int(self.target_index or 0)
        limit = max(0, min(int(getattr(s, "siren_count", len(s.sirens)) or len(s.sirens)), len(s.sirens)))
        if target_index < 1 or target_index > limit:
            self.report({"ERROR"}, f"Target siren must be between 1 and {limit}")
            return {"CANCELLED"}
        if target_index == int(source.index):
            self.report({"ERROR"}, "Choose a different siren number for the duplicate")
            return {"CANCELLED"}

        ensure_sirens(s, max(len(s.sirens), target_index))
        target = siren_slot_by_index(s, target_index)
        if not target:
            self.report({"ERROR"}, f"Could not resolve Siren {target_index}")
            return {"CANCELLED"}
        if target.object_name or target.bone_name:
            self.report({"ERROR"}, f"Siren {target_index} is already configured")
            return {"CANCELLED"}
        if bpy.data.objects.get(f"siren{target_index}") is not None:
            self.report({"ERROR"}, f"An object named siren{target_index} already exists")
            return {"CANCELLED"}

        source_obj = siren_obj(source)
        if not source_obj:
            self.report({"ERROR"}, "The active siren has no linked mesh to duplicate")
            return {"CANCELLED"}

        arm, pb = siren_pose_bone(scene, source)
        extra_sources = siren_bone_subtree_objects(scene, arm, pb.name, exclude={source_obj}) if arm and pb else []
        dup_root, duplicates = duplicate_siren_hierarchy(scene, source_obj, source.index, target_index, extra_sources=extra_sources)
        if not dup_root:
            self.report({"ERROR"}, "Could not duplicate the selected siren hierarchy")
            return {"CANCELLED"}

        source_snapshot = capture_siren_slot_snapshot(source)
        apply_siren_slot_snapshot(s, target, target_index, source_snapshot)
        target.object_name = dup_root.name
        target.bone_name = ""
        target.anchor_name = ""
        target.enabled = True
        s.active_siren = max(0, target_index - 1)
        clear_preview_keyframes(scene, [target])
        refresh_direction_warning(scene)
        mark_preview_dirty(context)

        try:
            bpy.ops.object.select_all(action='DESELECT')
            for obj in duplicates:
                obj.select_set(True)
            context.view_layer.objects.active = dup_root
        except Exception:
            pass

        msg = f"Duplicated Siren {source.index} to Siren {target_index}"
        s.status_message = msg
        self.report({"INFO"}, msg)
        return {"FINISHED"}


class NELS_OT_auto_detect(Operator):
    bl_idname = "nels.auto_detect"
    bl_label = "Auto-Detect Sirens/Bones"
    bl_options = {"REGISTER", "UNDO"}

    create_missing: BoolProperty(default=True)

    def execute(self, context):
        obj_count, bone_count, linked = auto_detect_scene_sirens(context.scene, create_missing=self.create_missing, sync_direction=True)
        self.report({"INFO"}, f"Detected objects: {obj_count}, bones: {bone_count}, linked: {linked}")
        return {"FINISHED"}


class NELS_OT_generate_siren_id(Operator):
    bl_idname = "nels.generate_siren_id"
    bl_label = "Generate Siren ID"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        s = context.scene.nels
        s.vehicle_id = generate_siren_id(s.vehicle_name)
        return {"FINISHED"}


def reset_scene_config_defaults(s, keep_name=False):
    cfg_name = s.config_name if keep_name and str(s.config_name).strip() else "new_lightbar"
    s.config_name = cfg_name
    s.vehicle_name = "police"
    s.vehicle_id = generate_siren_id(s.vehicle_name)
    s.bpm = 800
    s.scale_factor = 0.5
    s.scale_factor_choice = "SF_2"
    s.scale_factor_custom = 0.5
    s.patterns.clear()
    ensure_defaults(s)
    s.colors.clear()
    ensure_color_defaults(s)
    s.other_attributes.clear()
    ensure_other_attributes_defaults(s)
    s.sirens.clear()
    s.siren_count = 0
    off_key = off_pattern_key(s)
    s.left_head = off_key
    s.right_head = off_key
    s.left_tail = off_key
    s.right_tail = off_key
    s.saved_config = NO_SAVED_CFG
    s.car_headlights_on = False
    s.car_taillights_on = False
    s.car_left_indicator_on = False
    s.car_right_indicator_on = False
    s.car_extra_lights_on = False
    sync_scale_factor_controls(s)


class NELS_OT_new_save_load(Operator):
    bl_idname = "nels.new_save_load"
    bl_label = "Config IO"
    bl_options = {"REGISTER", "UNDO"}
    action: EnumProperty(items=[("NEW", "NEW", ""), ("SAVE", "SAVE", ""), ("LOAD", "LOAD", ""), ("DELETE", "DELETE", ""), ("RESET", "RESET", "")])

    def execute(self, context):
        s = context.scene.nels
        if self.action == "NEW":
            reset_scene_config_defaults(s, keep_name=False)
            auto_detect_scene_sirens(context.scene, create_missing=True, sync_direction=True)
            return {"FINISHED"}

        if self.action == "SAVE":
            fp = os.path.join(cfg_dir(), safe_name(s.config_name) + ".json")
            with open(fp, "w", encoding="utf-8") as h:
                json.dump(settings_to_dict(s), h, indent=2)
            s.saved_config = os.path.basename(fp)
            return {"FINISHED"}

        if self.action == "RESET":
            if s.saved_config and s.saved_config != NO_SAVED_CFG:
                fp = os.path.join(cfg_dir(), s.saved_config)
                if os.path.exists(fp):
                    with open(fp, "r", encoding="utf-8") as h:
                        data = json.load(h)
                    apply_settings_dict(s, data)
                    ensure_scene_defaults(context.scene)
                    return {"FINISHED"}
            reset_scene_config_defaults(s, keep_name=True)
            auto_detect_scene_sirens(context.scene, create_missing=True, sync_direction=True)
            return {"FINISHED"}

        if self.action == "DELETE":
            if not s.saved_config or s.saved_config == NO_SAVED_CFG:
                return {"CANCELLED"}
            fp = os.path.join(cfg_dir(), s.saved_config)
            if os.path.exists(fp):
                os.remove(fp)
            choices = config_json_files()
            s.saved_config = choices[0] if choices else NO_SAVED_CFG
            return {"FINISHED"}

        if not s.saved_config or s.saved_config == NO_SAVED_CFG:
            return {"CANCELLED"}
        fp = os.path.join(cfg_dir(), s.saved_config)
        if not os.path.exists(fp):
            return {"CANCELLED"}
        with open(fp, "r", encoding="utf-8") as h:
            data = json.load(h)
        apply_settings_dict(s, data)
        ensure_scene_defaults(context.scene)
        return {"FINISHED"}


class NELS_OT_export_config(Operator):
    bl_idname = "nels.export_config"
    bl_label = "Export Configuration"

    filepath: StringProperty(subtype="FILE_PATH")
    filter_glob: StringProperty(default="*.json", options={"HIDDEN"})

    def execute(self, context):
        s = context.scene.nels
        fp = self.filepath or bpy.path.abspath(f"//{safe_name(s.config_name)}.json")
        if not fp.lower().endswith(".json"):
            fp += ".json"
        out_dir = os.path.dirname(fp)
        if out_dir:
            os.makedirs(out_dir, exist_ok=True)
        with open(fp, "w", encoding="utf-8") as h:
            json.dump(settings_to_dict(s), h, indent=2)
        self.report({"INFO"}, f"Exported configuration: {fp}")
        return {"FINISHED"}

    def invoke(self, context, event):
        s = context.scene.nels
        if not self.filepath:
            self.filepath = bpy.path.abspath(f"//{safe_name(s.config_name)}.json")
        context.window_manager.fileselect_add(self)
        return {"RUNNING_MODAL"}


class NELS_OT_import_config(Operator):
    bl_idname = "nels.import_config"
    bl_label = "Import Configuration"

    filepath: StringProperty(subtype="FILE_PATH")
    filter_glob: StringProperty(default="*.json", options={"HIDDEN"})

    def execute(self, context):
        s = context.scene.nels
        fp = self.filepath
        if not fp or not os.path.exists(fp):
            self.report({"ERROR"}, "Configuration file not found")
            return {"CANCELLED"}

        with open(fp, "r", encoding="utf-8") as h:
            data = json.load(h)
        apply_settings_dict(s, data)
        ensure_scene_defaults(context.scene)
        self.report({"INFO"}, f"Imported configuration: {fp}")
        return {"FINISHED"}

    def invoke(self, context, event):
        self.filepath = bpy.path.abspath("//")
        context.window_manager.fileselect_add(self)
        return {"RUNNING_MODAL"}



def _read_xml_value(node, tag, default=None):
    if node is None:
        return default
    child = node.find(tag)
    if child is None:
        return default
    return child.attrib.get("value", default)


def _read_bool(value, default=False):
    txt = str(value).strip().lower()
    if txt in {"true", "1", "yes"}:
        return True
    if txt in {"false", "0", "no"}:
        return False
    return bool(default)


class NELS_OT_import_carcols(Operator):
    bl_idname = "nels.import_carcols"
    bl_label = "Import carcols.meta"

    filepath: StringProperty(subtype="FILE_PATH")
    filter_glob: StringProperty(default="*.meta;*.xml", options={"HIDDEN"})

    def execute(self, context):
        s = context.scene.nels
        fp = self.filepath
        if not fp or not os.path.exists(fp):
            self.report({"ERROR"}, "carcols.meta file not found")
            return {"CANCELLED"}

        suspend_preview_updates()
        try:
            try:
                tree = ET.parse(fp)
                root = tree.getroot()
            except Exception as ex:
                self.report({"ERROR"}, f"Invalid XML: {ex}")
                return {"CANCELLED"}

            top = root.find("./Sirens/Item")
            if top is None:
                self.report({"ERROR"}, "Invalid carcols format: missing Sirens/Item")
                return {"CANCELLED"}

            if not s.patterns:
                ensure_defaults(s)
            migrate_legacy_default_patterns(s)
            ensure_off_pattern(s)
            ensure_color_defaults(s)
            ensure_other_attributes_defaults(s)
            sync_scale_factor_controls(s)

            try:
                s.vehicle_id = int(_read_xml_value(top, "id", s.vehicle_id))
            except Exception:
                pass
            nm = top.find("name")
            if nm is not None and nm.text:
                s.vehicle_name = nm.text.strip() or s.vehicle_name

            try:
                s.bpm = int(_read_xml_value(top, "sequencerBpm", s.bpm))
            except Exception:
                pass

            off_key = off_pattern_key(s)
            s.left_head = off_key
            s.right_head = off_key
            s.left_tail = off_key
            s.right_tail = off_key
            s.head_tail_initialized = True

            for tag, prop in [("leftHeadLight", "left_head"), ("rightHeadLight", "right_head"), ("leftTailLight", "left_tail"), ("rightTailLight", "right_tail")]:
                sec = top.find(tag)
                if sec is None:
                    continue
                seq = parse_u32(_read_xml_value(sec, "sequencer", 0))
                bits = int_to_bits(seq)
                setattr(s, prop, off_key if seq == 0 else normalize_pattern_key(get_or_add_pattern(s, f"Imported {tag}", "BOTH", bits)))

            sirens_node = top.find("sirens")
            if sirens_node is None:
                self.report({"ERROR"}, "Invalid carcols format: missing sirens block")
                return {"CANCELLED"}

            items = [n for n in sirens_node.findall("Item")]
            ensure_sirens(s, len(items))
            imported_scale_factor = None

            for i, it in enumerate(items):
                if i >= len(s.sirens):
                    break
                si = s.sirens[i]
                rot = it.find("rotation")
                fl = it.find("flashiness")
                rotate_flag = _read_bool(_read_xml_value(it, "rotate", "false"), False)
                si.siren_type = "ROTATOR" if rotate_flag else "FLASHER"

                seq_val = 0
                vis = "BOTH"
                if si.siren_type == "ROTATOR" and rot is not None:
                    seq_val = parse_u32(_read_xml_value(rot, "sequencer", 0))
                    vis = "ROTATOR"
                elif fl is not None:
                    seq_val = parse_u32(_read_xml_value(fl, "sequencer", 0))
                    vis = "FLASHER"

                if seq_val == 0:
                    si.pattern_source = "LIBRARY"
                    si.pattern_choice = off_key
                else:
                    matched_pattern = find_pattern_key_by_bits(s, int_to_bits(seq_val), vis)
                    if matched_pattern:
                        si.pattern_source = "LIBRARY"
                        si.pattern_choice = matched_pattern
                    else:
                        si.pattern_source = "CUSTOM"
                        si.custom_visibility = normalize_pattern_visibility(vis)
                        si.custom_value = str(seq_val)
                        si.custom_bits = int_to_bits(seq_val)

                col_hex = clean_color_value(_read_xml_value(it, "color", COLORS["GENERAL_WHITE"]))
                preset = find_color_key_by_value(s, col_hex)
                if preset != "COL_0" or col_hex == clean_color_value(COLORS["GENERAL_WHITE"]):
                    si.color_mode = "PRESET"
                    si.color_preset = preset
                else:
                    si.color_mode = "CUSTOM"
                    si.custom_color = color_to_rgb(col_hex)

                scale_factor = _read_xml_value(it, "scaleFactor", None)
                if imported_scale_factor is None and scale_factor is not None:
                    imported_scale_factor = normalize_import_scale_factor(scale_factor)
                apply_scale_to_siren(si, scale_factor)

                dir_val_txt = _read_xml_value(rot if rotate_flag and rot is not None else fl, "delta", 0.0)
                try:
                    imported_dir = float(dir_val_txt)
                except Exception:
                    imported_dir = 0.0
                preset_dir = direction_preset_from_value(imported_dir)
                if preset_dir:
                    si.direction_mode = "PRESET"
                    si.direction_preset = preset_dir
                    si.custom_direction = float(DIRECTIONS.get(preset_dir, 0.0))
                else:
                    si.direction_mode = "CUSTOM"
                    si.custom_direction = imported_dir
                si.sync_to_bpm = _read_bool(_read_xml_value(rot if rotate_flag and rot is not None else fl, "syncToBpm", "true"), True)
                si.start_delay = float(_read_xml_value(fl if fl is not None else rot, "start", 0.0) or 0.0)
                si.light_speed = float(_read_xml_value(fl if fl is not None else rot, "speed", 0.0) or 0.0)
                si.light_multiples = int(float(_read_xml_value(fl if fl is not None else rot, "multiples", 0) or 0))
                si.rotator_clockwise = _read_bool(_read_xml_value(rot, "direction", "true"), True) if rot is not None else True

                si.flash = _read_bool(_read_xml_value(it, "flash", "true"), True)
                si.light = _read_bool(_read_xml_value(it, "light", "false"), False)
                si.spot_light = _read_bool(_read_xml_value(it, "spotLight", "false"), False)
                si.cast_shadows = _read_bool(_read_xml_value(it, "castShadows", "false"), False)
                si.light_group = int(float(_read_xml_value(it, "lightGroup", 1) or 1))

                cor = it.find("corona")
                if cor is not None:
                    si.corona_intensity = float(_read_xml_value(cor, "intensity", si.corona_intensity) or si.corona_intensity)
                    si.corona_size = float(_read_xml_value(cor, "size", si.corona_size) or si.corona_size)
                    si.corona_pull = float(_read_xml_value(cor, "pull", si.corona_pull) or si.corona_pull)
                    si.corona_face_camera = _read_bool(_read_xml_value(cor, "faceCamera", si.corona_face_camera), si.corona_face_camera)

                update_rotator_settings(si, context)

            if imported_scale_factor is not None:
                apply_scale_to_settings(s, imported_scale_factor)

            off_key = off_pattern_key(s)
            s.left_head = normalize_pattern_key(s.left_head) if s.left_head else off_key
            s.right_head = normalize_pattern_key(s.right_head) if s.right_head else off_key
            s.left_tail = normalize_pattern_key(s.left_tail) if s.left_tail else off_key
            s.right_tail = normalize_pattern_key(s.right_tail) if s.right_tail else off_key

            for i, si in enumerate(s.sirens, start=1):
                si.index = i
                si.name = f"siren{i}"
                si.color_preset = normalize_color_key(si.color_preset)
                if getattr(si, "pattern_source", "LIBRARY") != "CUSTOM":
                    si.pattern_choice = normalize_pattern_key(si.pattern_choice or off_key)
                if si.siren_type == "ROTATOR":
                    update_rotator_settings(si, context)
                sync_siren_selector_controls(si)

            if not s.saved_config:
                s.saved_config = NO_SAVED_CFG
            clear_missing_associations(context.scene)
            try:
                current_id = int(s.vehicle_id)
            except Exception:
                current_id = 0
            if current_id <= 0:
                s.vehicle_id = generate_siren_id(s.vehicle_name)
        finally:
            resume_preview_updates()

        auto_detect_scene_sirens(context.scene, create_missing=False, sync_direction=False)
        apply_all_siren_directions(context.scene)
        clear_preview_keyframes(context.scene, list(s.sirens))
        s.preview_generated = False
        s.auto_timeline_pending = False
        stop_timeline_playback()
        s.preview_time_origin = _time.time()
        s.preview_last_step = -1
        s.preview_animating_until = 0.0
        s.preview_refresh_pending = False
        s.preview_dirty = True
        refresh_siren_preview_cache(context.scene)
        tag_all_ui_redraw()
        self.report({"INFO"}, f"Imported carcols: {fp}")
        return {"FINISHED"}

    def invoke(self, context, event):
        self.filepath = bpy.path.abspath("//")
        context.window_manager.fileselect_add(self)
        return {"RUNNING_MODAL"}


class NELS_MT_siren_actions(Menu):
    bl_label = "Siren Actions"
    bl_idname = "NELS_MT_siren_actions"

    def draw(self, context):
        l = self.layout
        s = getattr(context.scene, "nels", None)
        o = l.operator("nels.set_siren_count", text="Add 20 Sirens", icon="ADD")
        o.count = 20
        o = l.operator("nels.set_siren_count", text="Add 32 Sirens", icon="ADD")
        o.count = 32
        if s and len(s.sirens) == 20:
            o = l.operator("nels.set_siren_count", text="Add 12 Additional (21-32)", icon="ADD")
            o.count = 32
        if s and len(s.sirens) > 20:
            o = l.operator("nels.set_siren_count", text="Remove Sirens 21-32", icon="REMOVE")
            o.count = 20
        o = l.operator("nels.set_siren_count", text="Remove All Sirens", icon="TRASH")
        o.count = 0
        l.separator()
        l.operator("nels.duplicate_siren", text="Duplicate Siren", icon="DUPLICATE")
        l.operator("nels.swap_sirens", text="Swap Two Sirens", icon="FILE_REFRESH")

class NELS_MT_config_actions(Menu):
    bl_label = "Configuration Actions"
    bl_idname = "NELS_MT_config_actions"

    def draw(self, context):
        l = self.layout
        o = l.operator("nels.new_save_load", text="Save Configuration", icon="FILE_TICK")
        o.action = "SAVE"
        o = l.operator("nels.new_save_load", text="Reset Current to Default", icon="LOOP_BACK")
        o.action = "RESET"
        o = l.operator("nels.new_save_load", text="Delete Saved Configuration", icon="TRASH")
        o.action = "DELETE"
        l.operator("nels.export_config", text="Export Configuration", icon="EXPORT")
        l.operator("nels.import_config", text="Import Configuration", icon="IMPORT")
        l.operator("nels.import_carcols", text="Import carcols.meta", icon="FILEBROWSER")


class NELS_OT_choose_parent_skeleton(Operator):
    bl_idname = "nels.choose_parent_skeleton"
    bl_label = "Select Parent Skeleton"
    bl_options = {"REGISTER", "UNDO"}

    next_action: EnumProperty(items=[("BONE", "BONE", "")], default="BONE")
    skeleton_name: EnumProperty(items=scene_armature_items)

    def invoke(self, context, event):
        s = context.scene.nels
        arm = bpy.data.objects.get(s.armature_name) if s.armature_name else None
        if arm and arm.type == "ARMATURE":
            self.skeleton_name = arm.name
        else:
            arms = sorted({obj.name for obj in context.scene.objects if obj.type == "ARMATURE"}, key=str.lower)
            if not arms:
                msg = "Warning: Select or create a Parent Skeleton before placing a siren bone"
                s.status_message = msg
                self.report({"WARNING"}, msg)
                return {"CANCELLED"}
            self.skeleton_name = arms[0]
        return context.window_manager.invoke_props_dialog(self, width=360)

    def draw(self, context):
        l = self.layout
        l.label(text="Choose the armature that will receive the siren bone.")
        l.prop(self, "skeleton_name", text="Parent Skeleton")

    def execute(self, context):
        s = context.scene.nels
        if self.skeleton_name == "__NONE__":
            msg = "Warning: No armatures were found in the current scene"
            s.status_message = msg
            self.report({"WARNING"}, msg)
            return {"CANCELLED"}
        s.armature_name = self.skeleton_name
        s.status_message = f"Parent Skeleton set to {self.skeleton_name}"
        if self.next_action:
            return bpy.ops.nels.link_bone(action=self.next_action)
        return {"FINISHED"}


class NELS_OT_link_bone(Operator):
    bl_idname = "nels.link_bone"
    bl_label = "Link Object/Bone"
    bl_options = {"REGISTER", "UNDO"}
    action: EnumProperty(items=[("MARK", "MARK", ""), ("BONE", "BONE", ""), ("ORIGIN", "ORIGIN", "")])

    def execute(self, context):
        s = context.scene.nels
        if not s.sirens:
            return {"CANCELLED"}
        si = s.sirens[s.active_siren]
        obj = context.active_object

        if self.action == "MARK":
            if not obj:
                return {"CANCELLED"}
            old_index = infer_siren_index_from_hierarchy(obj, fallback=infer_siren_index_from_object(obj, s=s) or si.index) or si.index
            retarget_siren_hierarchy(obj, old_index, si.index, detach_root=True)
            nm = f"siren{si.index}"
            obj.name = nm
            si.object_name = nm
            si.bone_name = ""
            si.anchor_name = ""
            si.enabled = True
            _store_rest_loc(obj, force=True)
            s.status_message = f"Assigned {nm} and retargeted linked mesh data"
            return {"FINISHED"}

        if self.action == "ORIGIN":
            sobj = siren_obj(si)
            if not sobj:
                msg = f"Warning: Assign a siren object to siren{si.index} before copying its origin"
                s.status_message = msg
                self.report({"WARNING"}, msg)
                return {"CANCELLED"}

            reference = pick_reference_object(context, si)
            if not reference:
                msg = "Warning: Select a separate helper object to copy its origin to the active siren"
                s.status_message = msg
                self.report({"WARNING"}, msg)
                return {"CANCELLED"}

            ok, msg = set_object_origin_from_reference(sobj, reference)
            s.status_message = msg
            if ok:
                si.anchor_name = reference.name
                self.report({"INFO"}, msg)
                return {"FINISHED"}
            self.report({"ERROR"}, msg)
            return {"CANCELLED"}

        arm = bpy.data.objects.get(s.armature_name) if s.armature_name else None
        if not arm or arm.type != "ARMATURE":
            scene_arms = sorted({o.name for o in context.scene.objects if o.type == "ARMATURE"}, key=str.lower)
            if not scene_arms:
                msg = "Warning: Select or create a Parent Skeleton before placing a siren bone"
                s.status_message = msg
                self.report({"WARNING"}, msg)
                return {"CANCELLED"}
            if len(scene_arms) == 1:
                s.armature_name = scene_arms[0]
                arm = bpy.data.objects.get(s.armature_name)
                s.status_message = f"Parent Skeleton set to {s.armature_name}"
            else:
                bpy.ops.nels.choose_parent_skeleton('INVOKE_DEFAULT', next_action=self.action)
                return {"FINISHED"}

        sobj = siren_obj(si)
        if not sobj:
            msg = f"Warning: Assign a siren object to siren{si.index} before placing its bone"
            s.status_message = msg
            self.report({"WARNING"}, msg)
            return {"CANCELLED"}

        anchor = pick_anchor_object(context, arm, si)
        if not anchor:
            anchor = sobj

        active = context.view_layer.objects.active
        mode = context.mode
        try:
            if mode != "OBJECT":
                bpy.ops.object.mode_set(mode="OBJECT")
            bpy.ops.object.select_all(action="DESELECT")
            arm.select_set(True)
            context.view_layer.objects.active = arm
            bpy.ops.object.mode_set(mode="EDIT")
            bn = f"siren{si.index}"
            eb = arm.data.edit_bones.get(bn) or arm.data.edit_bones.new(bn)
            head = arm.matrix_world.inverted() @ anchor.matrix_world.translation
            eb.head = head
            eb.tail = head + Vector((0.0, 0.05, 0.0))
            bpy.ops.object.mode_set(mode="OBJECT")
            wm = sobj.matrix_world.copy()
            sobj.parent = arm
            sobj.parent_type = "BONE"
            sobj.parent_bone = bn
            sobj.matrix_world = wm
            si.bone_name = bn
            si.anchor_name = anchor.name
            _store_rest_loc(sobj, force=True)
            s.status_message = f"Placed bone {bn} on {arm.name}"
        finally:
            if active and active.name in bpy.data.objects:
                context.view_layer.objects.active = active
            if mode != "OBJECT" and context.mode == "OBJECT":
                try:
                    bpy.ops.object.mode_set(mode=mode)
                except Exception:
                    pass
        return {"FINISHED"}
        if not s.armature_name:
            return {"CANCELLED"}
        arm = bpy.data.objects.get(s.armature_name)
        sobj = siren_obj(si)
        anchor = pick_anchor_object(context, arm, si)
        if not arm or arm.type != "ARMATURE" or not sobj or not anchor:
            return {"CANCELLED"}

        active = context.view_layer.objects.active
        mode = context.mode
        try:
            if mode != "OBJECT":
                bpy.ops.object.mode_set(mode="OBJECT")
            bpy.ops.object.select_all(action="DESELECT")
            arm.select_set(True)
            context.view_layer.objects.active = arm
            bpy.ops.object.mode_set(mode="EDIT")
            bn = f"siren{si.index}"
            eb = arm.data.edit_bones.get(bn) or arm.data.edit_bones.new(bn)
            head = arm.matrix_world.inverted() @ anchor.matrix_world.translation
            eb.head = head
            eb.tail = head + Vector((0.0, 0.05, 0.0))
            bpy.ops.object.mode_set(mode="OBJECT")
            wm = sobj.matrix_world.copy()
            sobj.parent = arm
            sobj.parent_type = "BONE"
            sobj.parent_bone = bn
            sobj.matrix_world = wm
            si.bone_name = bn
            si.anchor_name = anchor.name
            _store_rest_loc(sobj, force=True)
        finally:
            if active and active.name in bpy.data.objects:
                context.view_layer.objects.active = active
            if mode != "OBJECT" and context.mode == "OBJECT":
                try:
                    bpy.ops.object.mode_set(mode=mode)
                except Exception:
                    pass
        return {"FINISHED"}


class NELS_OT_origin_to_selection(Operator):
    bl_idname = "nels.origin_to_selection"
    bl_label = "Set Origin to Selection"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        scene = getattr(context, "scene", None)
        s = getattr(scene, "nels", None) if scene else None
        obj = getattr(context, "active_object", None)
        if not obj or getattr(obj, "type", "") != "MESH":
            msg = "Select a mesh in Edit Mode first"
            if s:
                s.status_message = msg
            self.report({"WARNING"}, msg)
            return {"CANCELLED"}
        if getattr(context, "mode", "") != "EDIT_MESH" or getattr(obj, "mode", "") != "EDIT":
            msg = "Switch the active mesh to Edit Mode first"
            if s:
                s.status_message = msg
            self.report({"WARNING"}, msg)
            return {"CANCELLED"}

        center, msg = edit_selection_local_center(obj, context)
        if center is None:
            if s:
                s.status_message = msg
            self.report({"WARNING"}, msg)
            return {"CANCELLED"}

        active = getattr(context.view_layer, "objects", None).active if getattr(context, "view_layer", None) else obj
        try:
            bpy.ops.object.mode_set(mode="OBJECT")
            ok, msg = set_object_origin_to_local_point(obj, center)
        finally:
            try:
                if active and active.name in bpy.data.objects:
                    context.view_layer.objects.active = active
            except Exception:
                pass
            if getattr(context, "mode", "") == "OBJECT":
                try:
                    bpy.ops.object.mode_set(mode="EDIT")
                except Exception:
                    pass

        if s:
            s.status_message = msg
        if ok:
            self.report({"INFO"}, msg)
            return {"FINISHED"}
        self.report({"ERROR"}, msg)
        return {"CANCELLED"}


class NELS_OT_origins_to_bones(Operator):
    bl_idname = "nels.origins_to_bones"
    bl_label = "Set Selected Origins to Bones"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        scene = getattr(context, "scene", None)
        s = getattr(scene, "nels", None) if scene else None
        if getattr(context, "mode", "") != "OBJECT":
            msg = "Switch to Object Mode before moving selected origins to bones"
            if s:
                s.status_message = msg
            self.report({"WARNING"}, msg)
            return {"CANCELLED"}

        selected = [obj for obj in getattr(context, "selected_objects", []) if obj and getattr(obj, "type", "") == "MESH"]
        if not selected:
            msg = "Select one or more mesh objects first"
            if s:
                s.status_message = msg
            self.report({"WARNING"}, msg)
            return {"CANCELLED"}

        moved = 0
        skipped = []
        for obj in selected:
            world_point, msg = linked_bone_world_location(scene, obj, s=s)
            if world_point is None:
                skipped.append(msg or f"No linked bone was found for {obj.name}")
                continue
            ok, result = set_object_origin_to_world_point(obj, world_point)
            if ok:
                moved += 1
            else:
                skipped.append(result)

        if moved:
            msg = f"Set {moved} selected object origin{'s' if moved != 1 else ''} to linked bone locations"
            if skipped:
                msg += f" ({len(skipped)} skipped)"
            if s:
                s.status_message = msg
            self.report({"INFO"}, msg)
            return {"FINISHED"}

        msg = skipped[0] if skipped else "No selected mesh objects could be matched to linked bones"
        if s:
            s.status_message = msg
        self.report({"WARNING"}, msg)
        return {"CANCELLED"}



class NELS_OT_bones_to_origins(Operator):
    bl_idname = "nels.bones_to_origins"
    bl_label = "Move Linked Bones to Origins"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        scene = getattr(context, "scene", None)
        s = getattr(scene, "nels", None) if scene else None
        if getattr(context, "mode", "OBJECT") != "OBJECT":
            msg = "Switch to Object Mode before moving linked bones"
            if s:
                s.status_message = msg
            self.report({"WARNING"}, msg)
            return {"CANCELLED"}

        selected = [obj for obj in getattr(context, "selected_objects", []) if obj and getattr(obj, "type", "") == "MESH"]
        if not selected:
            msg = "Select one or more mesh objects first"
            if s:
                s.status_message = msg
            self.report({"WARNING"}, msg)
            return {"CANCELLED"}

        moved = 0
        skipped = []
        seen_bones = set()
        for obj in selected:
            arm, pb, msg = linked_bone_target(scene, obj, s=s)
            if not arm or not pb:
                skipped.append(msg or f"No linked bone was found for {obj.name}")
                continue
            key = (arm.name, pb.name)
            if key in seen_bones:
                continue
            seen_bones.add(key)
            ok, result = move_linked_bone_to_world_point(scene, obj, obj.matrix_world.translation, s=s, preserve_direction=True)
            if ok:
                moved += 1
            else:
                skipped.append(result)

        if moved:
            msg = f"Moved {moved} linked bone{'s' if moved != 1 else ''} to selected mesh origins"
            if skipped:
                msg += f" ({len(skipped)} skipped)"
            if s:
                s.status_message = msg
            self.report({"INFO"}, msg)
            return {"FINISHED"}

        msg = skipped[0] if skipped else "No linked bones were found for the selected mesh objects"
        if s:
            s.status_message = msg
        self.report({"WARNING"}, msg)
        return {"CANCELLED"}


class NELS_OT_transfer_selected_rig_to_parent_skeleton(Operator):
    bl_idname = "nels.transfer_selected_rig_to_parent_skeleton"
    bl_label = "Move Selected Rig to Parent Skeleton"
    bl_options = {"REGISTER", "UNDO"}

    replace_existing: BoolProperty(default=False, options={"SKIP_SAVE"})

    def execute(self, context):
        scene = getattr(context, "scene", None)
        s = getattr(scene, "nels", None) if scene else None
        if not scene or not s:
            self.report({"ERROR"}, "No scene settings are available")
            return {"CANCELLED"}

        target_name = str(getattr(s, "armature_name", "") or "").strip()
        if not target_name:
            msg = "Select a Parent Skeleton first"
            s.status_message = msg
            self.report({"WARNING"}, msg)
            return {"CANCELLED"}

        target = bpy.data.objects.get(target_name)
        if not target or getattr(target, "type", "") != "ARMATURE":
            msg = f"Parent Skeleton '{target_name}' was not found"
            s.status_message = msg
            self.report({"WARNING"}, msg)
            return {"CANCELLED"}
        if target.name not in getattr(scene, "objects", {}):
            msg = f"Parent Skeleton '{target.name}' is not in the current scene"
            s.status_message = msg
            self.report({"WARNING"}, msg)
            return {"CANCELLED"}

        source = source_rig_armature_from_context(context, scene=scene, s=s, exclude=target)
        if not source:
            msg = "Select a rigged lightbar mesh or its source armature first"
            s.status_message = msg
            self.report({"WARNING"}, msg)
            return {"CANCELLED"}
        if source == target:
            msg = "The selected rig is already using the current Parent Skeleton"
            s.status_message = msg
            self.report({"INFO"}, msg)
            return {"CANCELLED"}

        branch_root = rig_branch_root_from_context(context, source)
        linked_objects = collect_armature_linked_objects(scene, source, branch_root=branch_root)
        if not linked_objects:
            linked_objects = collect_armature_linked_objects(scene, source)

        target_mesh_container = armature_mesh_container_object(target)
        branch_root_is_container = bool(branch_root and branch_root.name in bpy.data.objects and is_armature_mesh_container(branch_root))
        transfer_objects = [obj for obj in linked_objects if obj and obj.name in bpy.data.objects]
        if branch_root_is_container and target_mesh_container is not None:
            non_container_objects = [obj for obj in transfer_objects if obj != branch_root]
            if non_container_objects:
                transfer_objects = non_container_objects

        bone_names = armature_transfer_bone_names(scene, source, linked_objects=linked_objects)
        if not bone_names:
            msg = "No linked rig bones were found on the selected lightbar. Make sure its meshes are parented or weighted to the source rig first."
            s.status_message = msg
            self.report({"WARNING"}, msg)
            return {"CANCELLED"}

        conflicts = armature_bone_name_conflicts(source, target, bone_names=bone_names)
        if conflicts and not self.replace_existing:
            preview = ", ".join(conflicts[:6])
            if len(conflicts) > 6:
                preview += ", ..."
            msg = f"Cannot move this rig because {len(conflicts)} target bone{'s' if len(conflicts) != 1 else ''} already exist on {target.name}: {preview}. Use Replace Existing Rig Bones to overwrite them."
            s.status_message = msg
            self.report({"ERROR"}, msg)
            return {"CANCELLED"}

        transfer_object_names = {obj.name for obj in transfer_objects if obj and obj.name in bpy.data.objects}
        world_mats = {obj: obj.matrix_world.copy() for obj in transfer_objects if obj and obj.name in bpy.data.objects}
        replacement_targets = {}
        replacement_target_states = {}
        replacement_target_sources = {}
        replaced_target_objects = []
        if self.replace_existing:
            for obj in transfer_objects:
                if not obj or obj.name not in bpy.data.objects:
                    continue
                base_name = strip_blender_duplicate_suffix(obj.name)
                if not base_name or base_name == obj.name:
                    continue
                existing = bpy.data.objects.get(base_name)
                if not existing or existing == obj:
                    continue
                if not object_related_to_armature(existing, target):
                    continue
                replacement_targets[obj.name] = existing
                replacement_target_states[obj.name] = {
                    "parent_name": getattr(getattr(existing, "parent", None), "name", "") if getattr(existing, "parent", None) else "",
                    "parent_type": str(getattr(existing, "parent_type", "OBJECT") or "OBJECT"),
                    "parent_bone": str(getattr(existing, "parent_bone", "") or ""),
                }
                replacement_target_sources[existing.name] = obj

            replacement_items = sorted(
                {obj for obj in replacement_targets.values() if obj and obj.name in bpy.data.objects},
                key=object_hierarchy_depth,
                reverse=True,
            )
            for existing in replacement_items:
                try:
                    replaced_target_objects.append(existing.name)
                    bpy.data.objects.remove(existing, do_unlink=True)
                except Exception:
                    pass

        source_bones = getattr(getattr(source, "data", None), "bones", None)
        source_name = source.name
        old_active = getattr(getattr(context, "view_layer", None), "objects", None)
        old_active = getattr(old_active, "active", None)
        old_mode = str(getattr(context, "mode", "OBJECT") or "OBJECT")

        def _depth(name):
            depth = 0
            bone = source_bones.get(name) if source_bones else None
            seen = set()
            while bone and getattr(bone, "parent", None) and bone.name not in seen:
                seen.add(bone.name)
                parent = bone.parent
                if parent.name not in bone_names:
                    break
                depth += 1
                bone = parent
            return depth

        ordered_bones = sorted(bone_names, key=lambda name: (_depth(name), str(name).lower()))
        removal_order = sorted(bone_names, key=lambda name: (_depth(name), str(name).lower()), reverse=True)

        try:
            if old_mode != "OBJECT":
                bpy.ops.object.mode_set(mode="OBJECT")
        except Exception:
            pass

        try:
            bpy.ops.object.select_all(action="DESELECT")
        except Exception:
            pass

        try:
            target.select_set(True)
            bpy.context.view_layer.objects.active = target
            bpy.ops.object.mode_set(mode="EDIT")
            target_edit = target.data.edit_bones
            target_inv = target.matrix_world.inverted()

            for bone_name in conflicts if self.replace_existing else []:
                existing = target_edit.get(bone_name)
                if existing is not None:
                    target_edit.remove(existing)

            for bone_name in ordered_bones:
                src_bone = source_bones.get(bone_name) if source_bones else None
                if src_bone is None:
                    continue
                edit_bone = target_edit.new(bone_name)
                head = target_inv @ (source.matrix_world @ src_bone.head_local)
                tail = target_inv @ (source.matrix_world @ src_bone.tail_local)
                if (tail - head).length < 0.000001:
                    tail = head + Vector((0.0, 0.05, 0.0))
                edit_bone.head = head
                edit_bone.tail = tail
                try:
                    roll_axis = (target_inv.to_3x3() @ source.matrix_world.to_3x3() @ src_bone.matrix_local.to_3x3() @ Vector((0.0, 0.0, 1.0)))
                    if roll_axis.length >= 0.000001:
                        edit_bone.align_roll(roll_axis.normalized())
                except Exception:
                    pass

            chassis_parent_name = target_chassis_bone_name(target)
            chassis_parent = target_edit.get(chassis_parent_name) if chassis_parent_name else None

            for bone_name in ordered_bones:
                src_bone = source_bones.get(bone_name) if source_bones else None
                dst_bone = target_edit.get(bone_name)
                if src_bone is None or dst_bone is None:
                    continue
                parent = getattr(src_bone, "parent", None)
                dst_parent = None
                if parent and parent.name in bone_names:
                    dst_parent = target_edit.get(parent.name)
                elif chassis_parent is not None and bone_name != getattr(chassis_parent, "name", ""):
                    dst_parent = chassis_parent
                if dst_parent is not None:
                    dst_bone.parent = dst_parent
                    try:
                        dst_bone.use_connect = False
                    except Exception:
                        pass

            bpy.ops.object.mode_set(mode="OBJECT")
        except Exception as ex:
            try:
                if getattr(bpy.context, "mode", "OBJECT") != "OBJECT":
                    bpy.ops.object.mode_set(mode="OBJECT")
            except Exception:
                pass
            msg = f"Could not move the selected rig: {ex}"
            s.status_message = msg
            self.report({"ERROR"}, msg)
            return {"CANCELLED"}

        for bone_name in ordered_bones:
            pose_bone = getattr(getattr(target, "pose", None), "bones", {}).get(bone_name) if hasattr(getattr(target, "pose", None), "bones") else None
            if pose_bone:
                _store_rest_pose_bone(target, pose_bone, force=True)

        retargeted_modifiers = 0
        relinked_objects = 0
        for obj in transfer_objects:
            stored_world = world_mats.get(obj)
            current_parent = getattr(obj, "parent", None)
            current_parent_name = getattr(current_parent, "name", "") if current_parent else ""
            parent_type = str(getattr(obj, "parent_type", "OBJECT") or "OBJECT")
            parent_bone = str(getattr(obj, "parent_bone", "") or "")

            replacement_state = replacement_target_states.get(obj.name)
            replacement_parent = None
            if replacement_state:
                replacement_parent_name = str(replacement_state.get("parent_name", "") or "")
                if replacement_parent_name == target.name:
                    replacement_parent = target
                elif replacement_parent_name:
                    replacement_parent = bpy.data.objects.get(replacement_parent_name)
                    if replacement_parent is None:
                        incoming_parent = replacement_target_sources.get(replacement_parent_name)
                        if incoming_parent and incoming_parent.name in bpy.data.objects:
                            replacement_parent = incoming_parent
                if replacement_parent == obj:
                    replacement_parent = None

            keep_existing_parent = bool(current_parent and current_parent_name in transfer_object_names and current_parent != source)
            if not keep_existing_parent:
                desired_parent = replacement_parent
                if desired_parent is None:
                    if branch_root_is_container and target_mesh_container is not None and current_parent == branch_root:
                        desired_parent = target_mesh_container
                    else:
                        desired_parent = target
                obj.parent = desired_parent
                replacement_parent_type = str(replacement_state.get("parent_type", "OBJECT") or "OBJECT") if replacement_state else "OBJECT"
                replacement_parent_bone = str(replacement_state.get("parent_bone", "") or "") if replacement_state else ""
                if getattr(desired_parent, "type", "") == "ARMATURE":
                    desired_bone = ""
                    if replacement_parent_type == "BONE" and replacement_parent_bone in bone_names:
                        desired_bone = replacement_parent_bone
                    elif parent_type == "BONE" and current_parent == source and parent_bone in bone_names:
                        desired_bone = parent_bone
                    if desired_bone:
                        obj.parent_type = "BONE"
                        obj.parent_bone = desired_bone
                    else:
                        obj.parent_type = "OBJECT"
                        obj.parent_bone = ""
                else:
                    obj.parent_type = "OBJECT"
                    obj.parent_bone = ""
                try:
                    obj.matrix_parent_inverse = Matrix.Identity(4)
                except Exception:
                    pass
                relinked_objects += 1

            for mod in getattr(obj, "modifiers", []) or []:
                if getattr(mod, "type", "") == "ARMATURE" and getattr(mod, "object", None) == source:
                    try:
                        mod.object = target
                        retargeted_modifiers += 1
                    except Exception:
                        pass
            if stored_world is not None:
                try:
                    obj.matrix_world = stored_world
                    _store_rest_loc(obj, force=True)
                except Exception:
                    pass

        renamed_objects = 0
        for obj in transfer_objects:
            if not obj or obj.name not in bpy.data.objects:
                continue
            base_name = strip_blender_duplicate_suffix(obj.name)
            if not base_name or base_name == obj.name:
                continue
            existing = bpy.data.objects.get(base_name)
            if existing and existing != obj:
                continue
            try:
                obj.name = base_name
                renamed_objects += 1
            except Exception:
                pass

        try:
            bpy.ops.object.select_all(action="DESELECT")
            source.select_set(True)
            bpy.context.view_layer.objects.active = source
            bpy.ops.object.mode_set(mode="EDIT")
            source_edit = source.data.edit_bones
            for bone_name in removal_order:
                edit_bone = source_edit.get(bone_name)
                if edit_bone is not None:
                    source_edit.remove(edit_bone)
            bpy.ops.object.mode_set(mode="OBJECT")
        except Exception:
            try:
                if getattr(bpy.context, "mode", "OBJECT") != "OBJECT":
                    bpy.ops.object.mode_set(mode="OBJECT")
            except Exception:
                pass

        s.armature_name = target.name
        try:
            bpy.ops.object.select_all(action="DESELECT")
            target.select_set(True)
            bpy.context.view_layer.objects.active = target
            bpy.context.view_layer.update()
        except Exception:
            pass
        try:
            if old_active and old_active.name in bpy.data.objects:
                bpy.context.view_layer.objects.active = old_active
        except Exception:
            pass
        try:
            if old_mode != "OBJECT" and getattr(bpy.context, "mode", "OBJECT") == "OBJECT":
                bpy.ops.object.mode_set(mode=old_mode)
        except Exception:
            pass

        moved_count = len(transfer_objects)
        msg = f"Moved {len(bone_names)} rig bone{'s' if len(bone_names) != 1 else ''} and {moved_count} linked object{'s' if moved_count != 1 else ''} from {source_name} to {target.name}"
        details = []
        if self.replace_existing and conflicts:
            details.append(f"{len(conflicts)} existing bone{'s' if len(conflicts) != 1 else ''} replaced")
        if replaced_target_objects:
            details.append(f"{len(replaced_target_objects)} matching object{'s' if len(replaced_target_objects) != 1 else ''} replaced")
        if renamed_objects:
            details.append(f"{renamed_objects} transferred object{'s' if renamed_objects != 1 else ''} renamed")
        if retargeted_modifiers:
            details.append(f"{retargeted_modifiers} armature modifier{'s' if retargeted_modifiers != 1 else ''} retargeted")
        if details:
            msg += " (" + ", ".join(details) + ")"
        s.status_message = msg
        self.report({"INFO"}, msg)
        return {"FINISHED"}


class NELS_OT_cleanup_mesh_duplicate_suffixes(Operator):
    bl_idname = "nels.cleanup_mesh_duplicate_suffixes"
    bl_label = "Clean Mesh Duplicate Names"
    bl_options = {"REGISTER", "UNDO"}

    selected_only: BoolProperty(default=False, options={"SKIP_SAVE"})

    def execute(self, context):
        scene = getattr(context, "scene", None)
        s = getattr(scene, "nels", None) if scene else None
        renamed = cleanup_duplicate_mesh_suffixes(scene, selected_only=bool(getattr(self, "selected_only", False)))
        if renamed:
            msg = f"Cleaned {len(renamed)} mesh duplicate suffix{'es' if len(renamed) != 1 else ''}"
        else:
            msg = "No mesh duplicate suffixes needed cleaning"
        if s:
            s.status_message = msg
        self.report({"INFO"}, msg)
        return {"FINISHED"}


class NELS_OT_rename_selected_vehicle_part(Operator):
    bl_idname = "nels.rename_selected_vehicle_part"
    bl_label = "Rename Selected Vehicle Part"
    bl_options = {"REGISTER", "UNDO"}

    group_name: EnumProperty(name="Group", items=mesh_rename_group_items)
    target_name: EnumProperty(name="Name", items=mesh_rename_name_items)

    @classmethod
    def poll(cls, context):
        active = getattr(context, "active_object", None)
        return bool(active and getattr(active, "type", "") != "ARMATURE")

    def invoke(self, context, event):
        active = getattr(context, "active_object", None)
        inferred_group = infer_mesh_list_group_for_name(getattr(active, "name", ""))
        group_items = [item[0] for item in mesh_rename_group_items(self, context) if item[0] != "__NONE__"]
        if not group_items:
            self.report({"WARNING"}, "No mesh rename groups were found in References\\mesh_list.txt")
            return {"CANCELLED"}
        if self.group_name not in group_items:
            self.group_name = inferred_group if inferred_group in group_items else group_items[0]

        current_base = strip_blender_duplicate_suffix(getattr(active, "name", ""))
        name_items = [item[0] for item in mesh_rename_name_items(self, context) if item[0] != "__NONE__"]
        if self.target_name not in name_items:
            self.target_name = current_base if current_base in name_items else (name_items[0] if name_items else "__NONE__")
        return context.window_manager.invoke_props_dialog(self, width=380)

    def draw(self, context):
        layout = self.layout
        active = getattr(context, "active_object", None)
        layout.label(text=f"Selected Object: {getattr(active, 'name', 'None')}")
        layout.prop(self, "group_name", text="Group")
        layout.prop(self, "target_name", text="Name")
        status_text, status_icon = mesh_rename_target_status(getattr(context, "scene", None), active, getattr(self, "target_name", ""))
        layout.label(text=status_text, icon=status_icon)

    def execute(self, context):
        scene = getattr(context, "scene", None)
        s = getattr(scene, "nels", None) if scene else None
        active = getattr(context, "active_object", None)
        if not scene or not s or active is None:
            self.report({"ERROR"}, "Select a vehicle object first")
            return {"CANCELLED"}
        ok, msg = rename_selected_vehicle_part(scene, s, active, getattr(self, "target_name", ""))
        s.status_message = msg
        if ok:
            mark_preview_dirty(context)
            self.report({"INFO"}, msg)
            return {"FINISHED"}
        self.report({"WARNING"}, msg)
        return {"CANCELLED"}


class NELS_OT_copy_siren_config(Operator):
    bl_idname = "nels.copy_siren_config"
    bl_label = "Copy Siren Config"
    bl_options = {"REGISTER", "UNDO"}

    target_index: IntProperty(default=0, options={"SKIP_SAVE"})

    def execute(self, context):
        scene = getattr(context, "scene", None)
        s = getattr(scene, "nels", None) if scene else None
        if not s or not getattr(s, "sirens", None):
            self.report({"ERROR"}, "Please add Sirens to configure them.")
            return {"CANCELLED"}

        target_idx = int(getattr(self, "target_index", 0) or 0)
        if not (1 <= target_idx <= len(s.sirens)):
            target_idx = siren_index_from_name(str(getattr(s, "tool_working_siren", "") or ""))
        if not (1 <= target_idx <= len(s.sirens)):
            target_idx = max(1, min(int(getattr(s, "active_siren", 0) or 0) + 1, len(s.sirens)))
        source_idx = siren_index_from_name(str(getattr(s, "tool_copy_siren_source", "") or ""))

        target = siren_slot_by_index(s, target_idx)
        source = siren_slot_by_index(s, source_idx)
        if not target or not source:
            msg = "Choose both the working siren and the source siren first"
            s.status_message = msg
            self.report({"WARNING"}, msg)
            return {"CANCELLED"}
        if int(getattr(target, "index", 0) or 0) == int(getattr(source, "index", 0) or 0):
            msg = "Choose a different source siren to copy from"
            s.status_message = msg
            self.report({"WARNING"}, msg)
            return {"CANCELLED"}

        snapshot = capture_siren_config_snapshot(source)
        apply_siren_config_snapshot(scene, s, target, snapshot)
        mark_preview_dirty(context, scene=scene, immediate=False)
        queue_preview_refresh_feedback(scene)
        msg = f"Copied siren{source.index} config to siren{target.index}"
        s.status_message = msg
        self.report({"INFO"}, msg)
        return {"FINISHED"}


class NELS_OT_match_origin_to_object(Operator):
    bl_idname = "nels.match_origin_to_object"
    bl_label = "Match Origin to Object"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        scene = getattr(context, "scene", None)
        s = getattr(scene, "nels", None) if scene else None
        if not s or not getattr(s, "sirens", None):
            self.report({"ERROR"}, "Please add Sirens to configure them.")
            return {"CANCELLED"}

        idx = max(0, min(int(getattr(s, "active_siren", 0) or 0), len(s.sirens) - 1))
        si = s.sirens[idx] if getattr(s, "sirens", None) else None
        if not si:
            self.report({"WARNING"}, "No siren could be resolved")
            return {"CANCELLED"}
            return {"CANCELLED"}

        sobj = siren_obj(si)
        if not sobj:
            msg = f"Warning: Assign a siren object to siren{si.index} before matching its origin"
            s.status_message = msg
            self.report({"WARNING"}, msg)
            return {"CANCELLED"}

        ref_name = str(getattr(s, "tool_origin_object", "") or "")
        reference = bpy.data.objects.get(ref_name) if ref_name else None
        if reference is None:
            reference = pick_reference_object(context, si)
        if reference is None:
            msg = "Select or pick an object to match the siren origin"
            s.status_message = msg
            self.report({"WARNING"}, msg)
            return {"CANCELLED"}
        if reference == sobj:
            msg = "Choose a separate helper object"
            s.status_message = msg
            self.report({"WARNING"}, msg)
            return {"CANCELLED"}

        ok, msg = set_object_origin_from_reference(sobj, reference)
        s.tool_origin_object = ""
        s.status_message = msg
        if ok:
            si.anchor_name = reference.name
            self.report({"INFO"}, msg)
            return {"FINISHED"}
        self.report({"ERROR"}, msg)
        return {"CANCELLED"}


class NELS_OT_select_linked_siren(Operator):
    bl_idname = "nels.select_linked_siren"
    bl_label = "Select Linked Siren"
    bl_options = {"REGISTER", "UNDO"}

    siren_index: IntProperty(default=0, min=0)

    def execute(self, context):
        scene = getattr(context, "scene", None)
        s = getattr(scene, "nels", None) if scene else None
        if not s:
            msg = "No scene settings are available"
            self.report({"WARNING"}, msg)
            return {"CANCELLED"}

        requested = int(getattr(self, "siren_index", 0) or 0)
        scene_pairs = scene_siren_mesh_pairs(scene, s=s)
        chosen_pair = None
        if requested > 0:
            chosen_pair = next((pair for pair in scene_pairs if int(pair[0] or 0) == requested), None)

        if not getattr(s, "sirens", None):
            if not scene_pairs:
                msg = "No siren meshes were found in the current scene"
                s.status_message = msg
                self.report({"WARNING"}, msg)
                return {"CANCELLED"}
            if chosen_pair is None:
                working_idx = siren_index_from_name(str(getattr(s, "tool_working_siren", "") or ""))
                if working_idx > 0:
                    chosen_pair = next((pair for pair in scene_pairs if int(pair[0] or 0) == working_idx), None)
            if chosen_pair is None:
                chosen_pair = scene_pairs[0]
            idx, obj, _si = chosen_pair
            try:
                if getattr(context, "mode", "OBJECT") != "OBJECT":
                    bpy.ops.object.mode_set(mode="OBJECT")
            except Exception:
                pass
            try:
                bpy.ops.object.select_all(action="DESELECT")
            except Exception:
                pass
            try:
                obj.select_set(True)
                context.view_layer.objects.active = obj
            except Exception:
                msg = f"Could not select linked data for siren {idx}"
                s.status_message = msg
                self.report({"WARNING"}, msg)
                return {"CANCELLED"}
            try:
                s.tool_working_siren = f"siren{int(idx or 1)}"
            except Exception:
                pass
            msg = f"Selected {obj.name}"
            s.status_message = msg
            self.report({"INFO"}, msg)
            return {"FINISHED"}

        si = None
        if 1 <= requested <= len(s.sirens):
            si = s.sirens[requested - 1]
        elif chosen_pair is not None:
            chosen_idx = int(chosen_pair[0] or 0)
            si = siren_slot_by_index(s, chosen_idx)
        if not si:
            si = resolve_context_siren(scene, s, require_linked=False)
        if not si:
            idx = max(0, min(int(getattr(s, "active_siren", 0) or 0), len(s.sirens) - 1))
            si = s.sirens[idx]

        s.active_siren = max(0, int(getattr(si, "index", 1) or 1) - 1)
        try:
            s.tool_working_siren = f"siren{int(getattr(si, 'index', 1) or 1)}"
        except Exception:
            pass

        obj = siren_obj(si)
        arm, pb = siren_pose_bone(scene, si)
        if not obj and not pb and chosen_pair is not None:
            obj = chosen_pair[1]
        if not obj and not pb:
            msg = f"Siren {si.index} has no linked mesh or bone to select"
            s.status_message = msg
            self.report({"WARNING"}, msg)
            return {"CANCELLED"}

        try:
            if getattr(context, "mode", "OBJECT") != "OBJECT":
                bpy.ops.object.mode_set(mode="OBJECT")
        except Exception:
            pass

        try:
            bpy.ops.object.select_all(action="DESELECT")
        except Exception:
            pass

        msg = ""
        if obj and obj.name in bpy.data.objects:
            try:
                obj.select_set(True)
                context.view_layer.objects.active = obj
                msg = f"Selected {obj.name}"
            except Exception:
                pass
        if (not msg) and arm and pb and arm.name in bpy.data.objects:
            try:
                arm.select_set(True)
                context.view_layer.objects.active = arm
                bone = arm.data.bones.get(pb.name)
                if bone is not None:
                    arm.data.bones.active = bone
                msg = f"Selected {pb.name} on {arm.name}"
            except Exception:
                pass

        if not msg:
            msg = f"Could not select linked data for siren {si.index}"
            s.status_message = msg
            self.report({"WARNING"}, msg)
            return {"CANCELLED"}

        s.status_message = msg
        self.report({"INFO"}, msg)
        return {"FINISHED"}

class NELS_OT_select_all_sirens(Operator):
    bl_idname = "nels.select_all_sirens"
    bl_label = "Select All Sirens"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        scene = getattr(context, "scene", None)
        s = getattr(scene, "nels", None) if scene else None
        if not scene or not s:
            msg = "No scene settings are available"
            self.report({"WARNING"}, msg)
            return {"CANCELLED"}

        siren_objects = scene_siren_mesh_pairs(scene, s=s)
        if not siren_objects:
            msg = "No siren meshes were found in the current scene"
            s.status_message = msg
            self.report({"WARNING"}, msg)
            return {"CANCELLED"}

        try:
            if getattr(context, "mode", "OBJECT") != "OBJECT":
                bpy.ops.object.mode_set(mode="OBJECT")
        except Exception:
            pass

        try:
            bpy.ops.object.select_all(action="DESELECT")
        except Exception:
            pass

        active_pair = None
        working_idx = siren_index_from_name(str(getattr(s, "tool_working_siren", "") or ""))
        for idx, obj, si in siren_objects:
            try:
                obj.select_set(True)
            except Exception:
                continue
            if active_pair is None:
                active_pair = (idx, obj, si)
            if int(idx or 0) == working_idx:
                active_pair = (idx, obj, si)

        if not active_pair:
            msg = "No siren meshes could be selected"
            s.status_message = msg
            self.report({"WARNING"}, msg)
            return {"CANCELLED"}

        try:
            context.view_layer.objects.active = active_pair[1]
        except Exception:
            pass
        try:
            idx = int(active_pair[0] or 0)
            if idx > 0:
                s.tool_working_siren = f"siren{idx}"
            si = active_pair[2]
            if si is not None:
                s.active_siren = max(0, int(getattr(si, "index", idx or 1) or 1) - 1)
        except Exception:
            pass

        msg = f"Selected {len(siren_objects)} siren mesh{'es' if len(siren_objects) != 1 else ''}"
        s.status_message = msg
        self.report({"INFO"}, msg)
        return {"FINISHED"}

class NELS_OT_move_bone_to_selected(Operator):
    bl_idname = "nels.move_bone_to_selected"
    bl_label = "Move Bone to Selected"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        scene = getattr(context, "scene", None)
        s = getattr(scene, "nels", None) if scene else None
        if not s or not getattr(s, "sirens", None):
            self.report({"ERROR"}, "Please add Sirens to configure them.")
            return {"CANCELLED"}

        si = resolve_context_siren(scene, s, require_linked=True)
        if not si:
            msg = "No linked siren could be resolved from the current selection"
            if s:
                s.status_message = msg
            self.report({"WARNING"}, msg)
            return {"CANCELLED"}

        reference = pick_any_reference_object(context)
        if not reference:
            msg = "Select a helper object first"
            if s:
                s.status_message = msg
            self.report({"WARNING"}, msg)
            return {"CANCELLED"}

        ok, msg = move_siren_bone_to_world_point(scene, si, reference.matrix_world.translation, preserve_direction=True)
        if s:
            s.status_message = msg
        if ok:
            si.anchor_name = reference.name
            self.report({"INFO"}, msg)
            return {"FINISHED"}
        self.report({"WARNING"}, msg)
        return {"CANCELLED"}


class NELS_OT_pick_selected_link_target(Operator):
    bl_idname = "nels.pick_selected_link_target"
    bl_label = "Use Selected Link Target"
    bl_options = {"REGISTER", "UNDO"}

    target: EnumProperty(items=[
        ("SIREN_MESH", "SIREN_MESH", ""),
        ("SIREN_BONE", "SIREN_BONE", ""),
        ("BODY_MESH", "BODY_MESH", ""),
        ("BODY_BONE", "BODY_BONE", ""),
        ("TOOL_ORIGIN_OBJECT", "TOOL_ORIGIN_OBJECT", ""),
    ])
    opening_key: StringProperty(default="")

    def execute(self, context):
        scene = getattr(context, "scene", None)
        s = getattr(scene, "nels", None) if scene else None
        if not s:
            self.report({"ERROR"}, "No scene settings available")
            return {"CANCELLED"}

        if self.target == "TOOL_ORIGIN_OBJECT":
            ref = pick_any_reference_object(context)
            if not ref:
                msg = "Select an object first"
                s.status_message = msg
                self.report({"WARNING"}, msg)
                return {"CANCELLED"}
            s.tool_origin_object = ref.name
            msg = f"Picked {ref.name} as the origin helper"
            s.status_message = msg
            self.report({"INFO"}, msg)
            return {"FINISHED"}

        is_siren = self.target.startswith("SIREN")
        wants_bone = self.target.endswith("BONE")

        if is_siren:
            if not getattr(s, "sirens", None):
                self.report({"ERROR"}, "Please add Sirens to configure them.")
                return {"CANCELLED"}
            target = resolve_context_siren(scene, s, require_linked=False)
            if not target:
                idx = max(0, min(int(getattr(s, "active_siren", 0) or 0), len(s.sirens) - 1))
                target = s.sirens[idx]
        else:
            target = body_opening_by_key(s, self.opening_key) if self.opening_key else active_body_opening(s)
            if not target:
                self.report({"ERROR"}, "No body openings are available to configure yet.")
                return {"CANCELLED"}

        if wants_bone:
            arm = selected_armature_from_context(context, scene=scene, s=s)
            bone_name = selected_bone_name_from_context(context, arm=arm)
            if not bone_name:
                msg = "Select a bone on the parent skeleton, or select a mesh already parented to the target bone"
                s.status_message = msg
                self.report({"WARNING"}, msg)
                return {"CANCELLED"}
            if arm:
                s.armature_name = arm.name
            target.bone_name = bone_name
            label = f"bone {bone_name}"
        else:
            mesh_name = selected_mesh_name_from_context(context)
            if not mesh_name:
                msg = "Select a mesh object first"
                s.status_message = msg
                self.report({"WARNING"}, msg)
                return {"CANCELLED"}
            target.object_name = mesh_name
            label = mesh_name

        owner = f"siren{target.index}" if is_siren else str(getattr(target, "name", "body opening") or "body opening")
        msg = f"Assigned {label} to {owner}"
        s.status_message = msg
        self.report({"INFO"}, msg)
        return {"FINISHED"}


class NELS_OT_body_opening_link(Operator):
    bl_idname = "nels.body_opening_link"
    bl_label = "Body Opening Link"
    bl_options = {"REGISTER", "UNDO"}

    action: EnumProperty(items=[("MARK", "MARK", ""), ("ORIGIN", "ORIGIN", ""), ("BONE", "BONE", "")])
    opening_key: StringProperty(default="")

    def execute(self, context):
        scene = context.scene
        s = getattr(scene, "nels", None)
        opening = body_opening_by_key(s, self.opening_key) if self.opening_key else active_body_opening(s)
        if not s or not opening:
            self.report({"ERROR"}, "No body openings are available to configure yet.")
            return {"CANCELLED"}

        if self.action == "MARK":
            obj = getattr(context, "active_object", None)
            if not obj or getattr(obj, "type", "") != "MESH":
                msg = "Select a mesh object first"
                s.status_message = msg
                self.report({"WARNING"}, msg)
                return {"CANCELLED"}
            opening.object_name = obj.name
            s.status_message = f"Assigned {obj.name} to {opening.name}"
            self.report({"INFO"}, s.status_message)
            return {"FINISHED"}

        if self.action == "ORIGIN":
            obj = body_opening_obj(opening)
            if not obj:
                msg = f"Assign a mesh to {opening.name} before moving its origin"
                s.status_message = msg
                self.report({"WARNING"}, msg)
                return {"CANCELLED"}
            reference = pick_body_opening_reference(context, opening)
            if not reference:
                msg = "Select a helper object to copy its origin"
                s.status_message = msg
                self.report({"WARNING"}, msg)
                return {"CANCELLED"}
            ok, msg = set_object_origin_from_reference(obj, reference)
            s.status_message = msg
            if ok:
                opening.anchor_name = reference.name
                self.report({"INFO"}, msg)
                return {"FINISHED"}
            self.report({"ERROR"}, msg)
            return {"CANCELLED"}

        arm = bpy.data.objects.get(s.armature_name) if getattr(s, "armature_name", "") else None
        if not arm or getattr(arm, "type", "") != "ARMATURE":
            scene_arms = sorted({obj.name for obj in scene.objects if getattr(obj, "type", "") == "ARMATURE"}, key=str.lower)
            if len(scene_arms) == 1:
                s.armature_name = scene_arms[0]
                arm = bpy.data.objects.get(s.armature_name)
            else:
                msg = "Select a Parent Skeleton before placing a body opening bone"
                s.status_message = msg
                self.report({"WARNING"}, msg)
                return {"CANCELLED"}

        obj = body_opening_obj(opening)
        if not obj:
            msg = f"Assign a mesh to {opening.name} before placing its bone"
            s.status_message = msg
            self.report({"WARNING"}, msg)
            return {"CANCELLED"}

        anchor = pick_body_opening_reference(context, opening) or obj
        active = context.view_layer.objects.active
        mode = context.mode
        bone_name = str(getattr(opening, "key", "") or getattr(opening, "bone_name", "") or "body_opening")
        try:
            if mode != "OBJECT":
                bpy.ops.object.mode_set(mode="OBJECT")
            bpy.ops.object.select_all(action="DESELECT")
            arm.select_set(True)
            context.view_layer.objects.active = arm
            bpy.ops.object.mode_set(mode="EDIT")
            eb = arm.data.edit_bones.get(bone_name) or arm.data.edit_bones.new(bone_name)
            head = arm.matrix_world.inverted() @ anchor.matrix_world.translation
            eb.head = head
            eb.tail = head + Vector((0.0, 0.05, 0.0))
            bpy.ops.object.mode_set(mode="OBJECT")
            world_matrix = obj.matrix_world.copy()
            obj.parent = arm
            obj.parent_type = "BONE"
            obj.parent_bone = bone_name
            obj.matrix_world = world_matrix
            opening.bone_name = bone_name
            opening.anchor_name = anchor.name
            _store_rest_loc(obj, force=True)
            s.status_message = f"Placed bone {bone_name} on {arm.name}"
            self.report({"INFO"}, s.status_message)
            return {"FINISHED"}
        finally:
            try:
                if active and active.name in bpy.data.objects:
                    context.view_layer.objects.active = active
            except Exception:
                pass
            if mode != "OBJECT" and context.mode == "OBJECT":
                try:
                    bpy.ops.object.mode_set(mode=mode)
                except Exception:
                    pass


class NELS_OT_select_body_opening(Operator):
    bl_idname = "nels.select_body_opening"
    bl_label = "Select Body Opening"
    bl_options = {"REGISTER", "UNDO"}

    opening_key: StringProperty(default="")

    def execute(self, context):
        scene = context.scene
        s = getattr(scene, "nels", None)
        opening = body_opening_by_key(s, self.opening_key) if self.opening_key else active_body_opening(s)
        if not s or not opening:
            self.report({"ERROR"}, "No body openings are available to configure yet.")
            return {"CANCELLED"}

        obj = body_opening_obj(opening)
        if obj is None:
            obj = find_body_opening_scene_object(scene, getattr(opening, "key", ""))
            if obj and not getattr(opening, "object_name", ""):
                opening.object_name = obj.name

        arm, pb = body_opening_pose_bone(scene, opening)
        if pb is None:
            found_arm, bone = find_body_opening_scene_bone(scene, s, getattr(opening, "key", ""))
            if found_arm and bone:
                if not getattr(s, "armature_name", ""):
                    s.armature_name = found_arm.name
                if not getattr(opening, "bone_name", ""):
                    opening.bone_name = bone.name
                arm = found_arm
                pb = found_arm.pose.bones.get(bone.name)

        if getattr(s, "body_openings", None):
            for idx, candidate in enumerate(s.body_openings):
                if candidate == opening:
                    s.active_body_opening = idx
                    break

        try:
            if getattr(context, "mode", "OBJECT") != "OBJECT":
                bpy.ops.object.mode_set(mode="OBJECT")
        except Exception:
            pass
        try:
            bpy.ops.object.select_all(action="DESELECT")
        except Exception:
            pass

        if obj and obj.name in bpy.data.objects:
            obj.select_set(True)
            context.view_layer.objects.active = obj
            msg = f"Selected {opening.name}"
            s.status_message = msg
            self.report({"INFO"}, msg)
            return {"FINISHED"}

        if arm and pb and arm.name in bpy.data.objects:
            arm.select_set(True)
            context.view_layer.objects.active = arm
            bone = arm.data.bones.get(pb.name)
            if bone is not None:
                arm.data.bones.active = bone
            msg = f"Selected {opening.name} bone"
            s.status_message = msg
            self.report({"INFO"}, msg)
            return {"FINISHED"}

        msg = f"No mesh or bone could be found for {opening.name}"
        s.status_message = msg
        self.report({"WARNING"}, msg)
        return {"CANCELLED"}


class NELS_OT_body_opening_state(Operator):
    bl_idname = "nels.body_opening_state"
    bl_label = "Body Opening State"
    bl_options = {"REGISTER", "UNDO"}

    action: EnumProperty(items=[("CAPTURE_CLOSED", "CAPTURE_CLOSED", ""), ("CAPTURE_OPEN", "CAPTURE_OPEN", ""), ("APPLY_CLOSED", "APPLY_CLOSED", ""), ("APPLY_OPEN", "APPLY_OPEN", "")])
    opening_key: StringProperty(default="")

    def execute(self, context):
        scene = context.scene
        s = getattr(scene, "nels", None)
        opening = body_opening_by_key(s, self.opening_key) if self.opening_key else active_body_opening(s)
        if not s or not opening:
            self.report({"ERROR"}, "No body openings are available to configure yet.")
            return {"CANCELLED"}

        if getattr(s, "body_openings", None):
            for idx, candidate in enumerate(s.body_openings):
                if candidate == opening:
                    s.active_body_opening = idx
                    break

        if not getattr(opening, "object_name", ""):
            obj = find_body_opening_scene_object(scene, getattr(opening, "key", ""))
            if obj:
                opening.object_name = obj.name
        if not getattr(opening, "bone_name", ""):
            arm, bone = find_body_opening_scene_bone(scene, s, getattr(opening, "key", ""))
            if arm and bone:
                if not getattr(s, "armature_name", ""):
                    s.armature_name = arm.name
                opening.bone_name = bone.name

        if self.action.startswith("CAPTURE_"):
            state = self.action.split("_", 1)[1]
            ok, msg = capture_body_opening_state(scene, opening, state)
        else:
            stop_timeline_playback()
            state = self.action.split("_", 1)[1]
            ok, msg = apply_body_opening_state(scene, opening, state)

        s.status_message = msg
        if ok:
            self.report({"INFO"}, msg)
            return {"FINISHED"}
        self.report({"WARNING"}, msg)
        return {"CANCELLED"}


class NELS_OT_sim(Operator):
    bl_idname = "nels.sim"
    bl_label = "Simulate"
    bl_options = {"REGISTER", "UNDO"}
    mode: EnumProperty(items=[("ON", "ON", ""), ("OFF", "OFF", "")])
    all: BoolProperty(default=False)

    def execute(self, context):
        scene = context.scene
        s = scene.nels
        sirens = list(s.sirens) if self.all else ([s.sirens[s.active_siren]] if s.sirens else [])
        if not sirens:
            return {"CANCELLED"}
        clear_preview_keyframes(scene, sirens)
        s.preview_generated = False
        s.preview_dirty = False
        s.auto_timeline_pending = False
        if self.mode == "OFF":
            stop_timeline_playback()
        for si in sirens:
            apply_sim_state(scene, s, si, self.mode)
        try:
            bpy.context.view_layer.update()
        except Exception:
            pass
        return {"FINISHED"}


class NELS_OT_set_siren_scale_state(Operator):
    bl_idname = "nels.set_siren_scale_state"
    bl_label = "Set Siren Scale"
    bl_options = {"REGISTER", "UNDO"}

    mode: EnumProperty(items=[("ON", "On", ""), ("OFF", "Off", "")], default="ON")

    def execute(self, context):
        scene = context.scene
        s = getattr(scene, "nels", None)
        if not s or not s.sirens:
            self.report({"ERROR"}, "Please add Sirens to configure them.")
            return {"CANCELLED"}

        target_sirens = selected_siren_slots(context, scene, s, require_linked=True)
        if not target_sirens:
            si = resolve_context_siren(scene, s, require_linked=True)
            if si:
                target_sirens = [si]

        if not target_sirens:
            msg = "No linked sirens could be resolved from the current selection"
            self.report({"ERROR"}, msg)
            return {"CANCELLED"}

        success = []
        failed = []
        for si in target_sirens:
            ok, msg = bake_siren_scale_state(scene, s, si, self.mode)
            if ok:
                success.append(si)
            else:
                failed.append((si, msg))

        if not success:
            first_error = failed[0][1] if failed else "No linked sirens could be updated"
            self.report({"ERROR"}, first_error)
            return {"CANCELLED"}

        msg = f"Set scale {self.mode.lower()} for {len(success)} siren{'s' if len(success) != 1 else ''}"
        if failed:
            msg += f" ({len(failed)} skipped)"
        try:
            s.status_message = msg
        except Exception:
            pass
        self.report({"INFO"}, msg)
        return {"FINISHED"}


class NELS_OT_reset_siren_default_state(Operator):
    bl_idname = "nels.reset_siren_default_state"
    bl_label = "Reset Siren to Default"
    bl_options = {"REGISTER", "UNDO"}

    all: BoolProperty(default=False)

    def execute(self, context):
        scene = context.scene
        s = getattr(scene, "nels", None)
        if not s or not s.sirens:
            self.report({"ERROR"}, "Please add Sirens to configure them.")
            return {"CANCELLED"}

        sirens = list(s.sirens) if self.all else []
        if not self.all:
            si = resolve_context_siren(scene, s, require_linked=False)
            if not si:
                self.report({"ERROR"}, "No siren could be resolved from the current selection")
                return {"CANCELLED"}
            sirens = [si]

        clear_preview_keyframes(scene, sirens)
        restored = 0
        for si in sirens:
            restored += restore_siren_default_state(scene, si)
        s.preview_generated = False
        s.preview_dirty = False
        if hasattr(scene, "view_layers"):
            try:
                bpy.context.view_layer.update()
            except Exception:
                pass
        self.report({"INFO"}, f"Reset {len(sirens)} siren(s) to default state")
        return {"FINISHED"}


def _clear_action_animation(action, path_predicate):
    if not action:
        return 0

    removed = 0
    for fc in _iter_action_fcurves(action):
        data_path = str(getattr(fc, "data_path", ""))
        if not path_predicate(data_path):
            continue

        try:
            points = getattr(fc, "keyframe_points", None)
            if points is not None:
                removed += len(points)
                points.clear()
        except Exception:
            try:
                points = getattr(fc, "keyframe_points", None)
                if points is not None:
                    for kp in list(points):
                        points.remove(kp)
                        removed += 1
            except Exception:
                pass

        try:
            for m in list(fc.modifiers):
                if m.type == "CYCLES":
                    fc.modifiers.remove(m)
        except Exception:
            pass

        try:
            fc.update()
        except Exception:
            pass

    return removed
def clear_preview_keyframes(scene, sirens, frame_start=None, frame_end=None):
    cleared = 0

    for si in sirens:
        o = siren_obj(si)
        if o:
            cleared += _clear_action_animation(
                getattr(getattr(o, "animation_data", None), "action", None),
                lambda p: p in {"location", "rotation_euler", "scale"},
            )

        if getattr(si, "siren_type", "FLASHER") == "ROTATOR":
            for target in rotator_preview_targets(si):
                if not target or target == o:
                    continue
                cleared += _clear_action_animation(
                    getattr(getattr(target, "animation_data", None), "action", None),
                    lambda p: p == "rotation_euler",
                )

        arm, pb = siren_pose_bone(scene, si)
        if arm and pb:
            target_bones = {pb.name}
            if getattr(si, "siren_type", "FLASHER") == "ROTATOR":
                target_bones.update(child.name for child in rotator_preview_pose_bones(scene, si))
            cleared += _clear_action_animation(
                getattr(getattr(arm, "animation_data", None), "action", None),
                lambda p, target_bones=target_bones: any(
                    p.startswith(f'pose.bones["{bone}"].') and (p.endswith(".location") or p.endswith(".rotation_euler") or p.endswith(".scale"))
                    for bone in target_bones
                ),
            )

    return cleared


def generate_timeline_preview(scene, s, sirens):
    st = int(scene.frame_start)
    fps = max(1.0, scene.render.fps / max(scene.render.fps_base, 0.0001))
    step = preview_step_frames(s.bpm, fps)
    used = 0
    cycle_end = float(st)

    for si in sirens:
        if not siren_is_active(si):
            continue

        delay_frames = start_delay_frames(s.bpm, fps, si)

        if getattr(si, "siren_type", "FLASHER") == "ROTATOR":
            cycle_frames = rotator_cycle_frames(s.bpm, fps, si)
            cycle_end = max(cycle_end, st + delay_frames + cycle_frames)

            # Keep rotators statically shown and animate only their rotation channels.
            # This avoids scale/location keyframe churn on the full siren hierarchy.
            apply_sim_state(scene, s, si, "ON", turns=0.0, keyframe_frame=None)
            apply_rotator_preview_targets(si, turns=0.0, keyframe_frame=st)
            apply_rotator_preview_pose_targets(scene, si, turns=0.0, keyframe_frame=st)
            if delay_frames > 0.0:
                apply_rotator_preview_targets(si, turns=0.0, keyframe_frame=st + delay_frames)
                apply_rotator_preview_pose_targets(scene, si, turns=0.0, keyframe_frame=st + delay_frames)
            apply_rotator_preview_targets(si, turns=1.0, keyframe_frame=st + delay_frames + cycle_frames)
            apply_rotator_preview_pose_targets(scene, si, turns=1.0, keyframe_frame=st + delay_frames + cycle_frames)
        else:
            bits, _, _ = pattern_triplet(s, si)
            bit_count = max(1, len(bits))
            cycle_end = max(cycle_end, st + delay_frames + (bit_count * step))
            if delay_frames > 0.0:
                apply_sim_state(scene, s, si, "OFF", turns=0.0, keyframe_frame=st)
            first_mode = "ON" if bits[0] == "1" else "OFF"
            apply_sim_state(scene, s, si, first_mode, turns=0.0, keyframe_frame=st + delay_frames)
            for i in range(1, bit_count):
                if bits[i] == bits[i - 1]:
                    continue
                fr = st + delay_frames + (i * step)
                mode = "ON" if bits[i] == "1" else "OFF"
                apply_sim_state(scene, s, si, mode, turns=0.0, keyframe_frame=fr)
            apply_sim_state(scene, s, si, first_mode, turns=0.0, keyframe_frame=st + delay_frames + (bit_count * step))

        _set_preview_key_interpolation(scene, si)
        used += 1

    if used:
        scene.frame_end = max(int(scene.frame_start), int(math.ceil(cycle_end)))
    return used, cycle_end


class NELS_OT_preview_clear(Operator):
    bl_idname = "nels.preview_clear"
    bl_label = "Clear Timeline"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        s = context.scene.nels
        scene = context.scene
        cleared = clear_preview_keyframes(scene, list(s.sirens))
        s.preview_generated = False
        s.preview_dirty = False
        self.report({"INFO"}, f"Cleared {cleared} keyframes")
        return {"FINISHED"}


class NELS_OT_sollumz_enable(Operator):
    bl_idname = "nels.sollumz_enable"
    bl_label = "Enable Sollumz"
    bl_options = {"REGISTER"}

    def execute(self, context):
        module_name = find_sollumz_module_name()
        if not module_name:
            self.report({"ERROR"}, "Sollumz is not installed")
            return {"CANCELLED"}
        try:
            bpy.ops.preferences.addon_enable(module=module_name)
            scene = getattr(context, "scene", None)
            s = getattr(scene, "nels", None) if scene else None
            if s:
                s.status_message = f"Enabled Sollumz ({module_name})"
            self.report({"INFO"}, f"Enabled Sollumz ({module_name})")
            return {"FINISHED"}
        except Exception as ex:
            self.report({"ERROR"}, f"Could not enable Sollumz: {ex}")
            return {"CANCELLED"}


class NELS_OT_sollumz_install(Operator):
    bl_idname = "nels.sollumz_install"
    bl_label = "Install Sollumz"
    bl_options = {"REGISTER"}

    def execute(self, context):
        scene = getattr(context, "scene", None)
        s = getattr(scene, "nels", None) if scene else None
        try:
            asset = fetch_sollumz_release_asset_info()
            data = download_url_bytes(asset["url"])
            enabled_module = install_addon_from_zip_bytes(data, name_hint="sollumz")
            status = sollumz_status()
            if s:
                version = str(asset.get("tag", "") or asset.get("name", "") or "latest release")
                if status["enabled"]:
                    s.status_message = f"Installed Sollumz {version}"
                else:
                    s.status_message = f"Installed Sollumz {version}. Enable it in Blender Preferences if needed."
            if status["enabled"]:
                self.report({"INFO"}, f"Installed Sollumz {asset.get('tag', '') or enabled_module or ''}".strip())
                return {"FINISHED"}
            self.report({"WARNING"}, "Sollumz downloaded and installed, but Blender did not auto-enable it")
            return {"FINISHED"}
        except Exception as ex:
            if s:
                s.status_message = f"Sollumz install failed: {ex}"
            self.report({"ERROR"}, f"Sollumz install failed: {ex}")
            return {"CANCELLED"}


class NELS_OT_update_check(Operator):
    bl_idname = "nels.update_check"
    bl_label = "Check for Updates"
    bl_options = {"REGISTER"}

    def execute(self, context):
        if begin_update_operation("CHECK", automatic=False):
            self.report({"INFO"}, "Checking GitHub for updates")
            return {"FINISHED"}
        self.report({"WARNING"}, "An update task is already running")
        return {"CANCELLED"}


class NELS_OT_update_install(Operator):
    bl_idname = "nels.update_install"
    bl_label = "Install Update"
    bl_options = {"REGISTER"}

    def execute(self, context):
        s = getattr(context.scene, "nels", None)
        if not s:
            self.report({"ERROR"}, "No scene settings available")
            return {"CANCELLED"}
        if getattr(s, "update_install_in_progress", False) or getattr(s, "update_check_in_progress", False):
            self.report({"WARNING"}, "An update task is already running")
            return {"CANCELLED"}
        if not getattr(s, "update_available", False):
            self.report({"WARNING"}, "No newer update is currently available")
            return {"CANCELLED"}
        if begin_update_operation("INSTALL", automatic=False):
            self.report({"INFO"}, "Installing update from GitHub")
            return {"FINISHED"}
        self.report({"WARNING"}, "An update task is already running")
        return {"CANCELLED"}



class NELS_OT_siren_preview_control(Operator):
    bl_idname = "nels.siren_preview_control"
    bl_label = "Siren Preview Control"
    bl_options = {"REGISTER", "UNDO"}

    action: EnumProperty(items=[("START", "Start", ""), ("STOP", "Stop", "")], default="START")

    def execute(self, context):
        scene = getattr(context, "scene", None)
        s = getattr(scene, "nels", None) if scene else None
        if not s:
            self.report({"ERROR"}, "No scene settings available")
            return {"CANCELLED"}
        running = (self.action == "START")
        s.siren_preview_running = running
        if running:
            s.preview_time_origin = _time.time()
            s.preview_last_step = -1
            queue_preview_refresh_feedback(scene, message="Siren preview started")
            mark_preview_dirty(context, scene=scene, immediate=False)
            refresh_preview_visibility_state(scene, restart_clock=True)
            self.report({"INFO"}, "Siren preview started")
        else:
            s.preview_refresh_pending = False
            s.preview_animating_until = 0.0
            mark_preview_dirty(context, scene=scene)
            refresh_preview_visibility_state(scene, restart_clock=False)
            self.report({"INFO"}, "Siren preview stopped")
        return {"FINISHED"}

class NELS_OT_refresh_pattern_previews(Operator):
    bl_idname = "nels.refresh_pattern_previews"
    bl_label = "Refresh Pattern Previews"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        scene = getattr(context, "scene", None)
        s = getattr(scene, "nels", None) if scene else None
        if not s:
            self.report({"ERROR"}, "No scene settings available")
            return {"CANCELLED"}

        queue_preview_refresh_feedback(scene)
        mark_preview_dirty(context, scene=scene, immediate=False)
        refresh_preview_visibility_state(scene, restart_clock=True)
        self.report({"INFO"}, "Preview refresh started")
        return {"FINISHED"}


class NELS_OT_preview(Operator):
    bl_idname = "nels.preview"
    bl_label = "Generate Siren Preview"
    bl_options = {"REGISTER", "UNDO"}

    scope: EnumProperty(items=[("ACTIVE", "ACTIVE", ""), ("ALL", "ALL", "")], default="ALL")

    def execute(self, context):
        s = context.scene.nels
        scene = context.scene

        if self.scope == "ACTIVE":
            if not s.sirens:
                return {"CANCELLED"}
            idx = max(0, min(s.active_siren, len(s.sirens) - 1))
            siren_list = [s.sirens[idx]]
        else:
            siren_list = list(s.sirens)

        clear_preview_keyframes(scene, siren_list)

        used, _cycle_end = generate_timeline_preview(scene, s, siren_list)
        if used:
            s.preview_generated = True
            s.preview_dirty = False
            return {"FINISHED"}
        return {"CANCELLED"}

_VEHSHARE_TEXTURE_NAMES_CACHE = None


def write_carcols_export_file(s, filepath):
    fp = bpy.path.abspath(str(filepath or "").strip())
    if not fp.lower().endswith(".meta"):
        fp += ".meta"
    out_dir = os.path.dirname(fp)
    if out_dir:
        os.makedirs(out_dir, exist_ok=True)
    with open(fp, "w", encoding="utf-8") as h:
        h.write(build_xml(s))
    return fp


def vehicle_export_directory_path(s):
    raw = str(getattr(s, "vehicle_export_directory", "") or "").strip()
    if not raw:
        raw = os.path.join(os.path.expanduser("~"), "Downloads")
    fp = bpy.path.abspath(raw)
    os.makedirs(fp, exist_ok=True)
    return fp


def vehicle_export_model_name(scene, s, armature=None):
    raw = str(getattr(s, "vehicle_export_model_name", "") or "").strip()
    if not raw:
        if armature is not None:
            raw = strip_blender_duplicate_suffix(str(getattr(armature, "name", "") or ""))
        elif scene is not None:
            raw = strip_blender_duplicate_suffix(str(getattr(scene, "name", "") or ""))
    raw = raw or "vehicle"
    return re.sub(r'[<>:"/\\|?*]+', "_", raw)


def resolve_vehicle_export_armature(context, scene, s):
    scene_objects = list(getattr(scene, "objects", [])) if scene else []
    scene_names = {obj.name for obj in scene_objects}
    candidates = []
    seen = set()

    def add_candidate(obj):
        if not obj or getattr(obj, "type", "") != "ARMATURE":
            return
        if scene and obj.name not in scene_names:
            return
        if obj.name in seen:
            return
        seen.add(obj.name)
        candidates.append(obj)

    arm_name = str(getattr(s, "armature_name", "") or "").strip() if s else ""
    if arm_name:
        add_candidate(bpy.data.objects.get(arm_name))

    active = getattr(context, "active_object", None)
    if active:
        if getattr(active, "type", "") == "ARMATURE":
            add_candidate(active)
        try:
            add_candidate(active.find_armature() if hasattr(active, "find_armature") else None)
        except Exception:
            pass
        current = getattr(active, "parent", None)
        visited = set()
        while current and current.name not in visited:
            visited.add(current.name)
            if getattr(current, "type", "") == "ARMATURE":
                add_candidate(current)
                break
            current = getattr(current, "parent", None)

    if scene and not candidates:
        for obj in scene_objects:
            if getattr(obj, "type", "") == "ARMATURE":
                add_candidate(obj)
                break

    arm = candidates[0] if candidates else None
    if arm and s and getattr(s, "armature_name", "") != arm.name:
        s.armature_name = arm.name
    return arm


def vehicle_related_objects(scene, armature):
    if not scene or not armature:
        return []
    related = []
    for obj in scene.objects:
        if obj == armature:
            continue
        if object_related_to_armature(obj, armature):
            related.append(obj)
    return related


def vehicle_related_mesh_objects(scene, armature):
    return [obj for obj in vehicle_related_objects(scene, armature) if getattr(obj, "type", "") == "MESH"]


def image_texture_name(image):
    path = ""
    try:
        path = bpy.path.abspath(str(getattr(image, "filepath_raw", "") or getattr(image, "filepath", "") or ""))
    except Exception:
        path = ""
    if path:
        base = os.path.splitext(os.path.basename(path))[0]
    else:
        base = os.path.splitext(str(getattr(image, "name", "") or "texture"))[0]
    return strip_blender_duplicate_suffix(base)


def image_source_identifier(image):
    path = ""
    try:
        path = bpy.path.abspath(str(getattr(image, "filepath_raw", "") or getattr(image, "filepath", "") or ""))
    except Exception:
        path = ""
    packed = getattr(image, "packed_file", None)
    if packed is not None:
        return f"PACKED:{getattr(image, 'name', '')}"
    if path:
        return os.path.normcase(path)
    return f"IMAGE:{getattr(image, 'name', '')}"


def build_transparent_dds_bytes(width=1, height=1):
    width = max(1, int(width or 1))
    height = max(1, int(height or 1))
    pitch = width * 4
    header = bytearray()
    header.extend(b"DDS ")
    header.extend((124).to_bytes(4, "little"))
    header.extend((0x0000100F).to_bytes(4, "little"))
    header.extend(height.to_bytes(4, "little"))
    header.extend(width.to_bytes(4, "little"))
    header.extend(pitch.to_bytes(4, "little"))
    header.extend((0).to_bytes(4, "little"))
    header.extend((1).to_bytes(4, "little"))
    header.extend((0).to_bytes(4 * 11, "little"))
    header.extend((32).to_bytes(4, "little"))
    header.extend((0x00000041).to_bytes(4, "little"))
    header.extend((0).to_bytes(4, "little"))
    header.extend((32).to_bytes(4, "little"))
    header.extend((0x00FF0000).to_bytes(4, "little"))
    header.extend((0x0000FF00).to_bytes(4, "little"))
    header.extend((0x000000FF).to_bytes(4, "little"))
    header.extend((0xFF000000).to_bytes(4, "little"))
    header.extend((0x00001000).to_bytes(4, "little"))
    header.extend((0).to_bytes(4 * 4, "little"))
    pixel_data = bytes(width * height * 4)
    return bytes(header) + pixel_data


def missing_texture_placeholder_dds(image, texture_name=None):
    name = str(texture_name or image_texture_name(image) or getattr(image, "name", "texture") or "texture")
    return build_transparent_dds_bytes(1, 1), f"generated transparent placeholder DDS for missing texture {name}"


def image_dds_bytes(image):
    packed = getattr(image, "packed_file", None)
    if packed is not None:
        try:
            data = bytes(packed.data)
            if data[:4] == b"DDS ":
                return data, f"packed DDS in {image.name}"
        except Exception:
            pass

    path = ""
    try:
        path = bpy.path.abspath(str(getattr(image, "filepath_raw", "") or getattr(image, "filepath", "") or ""))
    except Exception:
        path = ""
    if not path:
        return missing_texture_placeholder_dds(image)
    if not path.lower().endswith(".dds"):
        return None, f"{image.name} is not backed by a DDS file"
    if not os.path.isfile(path):
        return missing_texture_placeholder_dds(image, texture_name=image_texture_name(image))
    try:
        with open(path, "rb") as fh:
            data = fh.read()
    except Exception as ex:
        return None, f"Could not read DDS file for {image.name}: {ex}"
    if data[:4] != b"DDS ":
        return None, f"{os.path.basename(path)} is not a valid DDS file"
    return data, path


def dds_format_name(data):
    fourcc = bytes(data[84:88])
    flags = int.from_bytes(data[80:84], "little")
    rgb_bits = int.from_bytes(data[88:92], "little")
    r_mask = int.from_bytes(data[92:96], "little")
    g_mask = int.from_bytes(data[96:100], "little")
    b_mask = int.from_bytes(data[100:104], "little")
    a_mask = int.from_bytes(data[104:108], "little")

    if fourcc == b"DX10":
        if len(data) < 148:
            raise RuntimeError("DDS file is missing the DX10 header")
        dxgi = int.from_bytes(data[128:132], "little")
        return {
            71: "D3DFMT_DXT1",
            72: "D3DFMT_DXT1",
            74: "D3DFMT_DXT3",
            75: "D3DFMT_DXT3",
            77: "D3DFMT_DXT5",
            78: "D3DFMT_DXT5",
            80: "DXGI_FORMAT_BC4_UNORM",
            81: "DXGI_FORMAT_BC4_SNORM",
            83: "DXGI_FORMAT_BC5_UNORM",
            84: "DXGI_FORMAT_BC5_SNORM",
            95: "DXGI_FORMAT_BC6H_UF16",
            96: "DXGI_FORMAT_BC6H_SF16",
            98: "D3DFMT_BC7",
            99: "D3DFMT_BC7",
        }.get(dxgi, "")

    key = fourcc.decode("ascii", errors="ignore").rstrip("\x00").upper()
    if key:
        return {
            "DXT1": "D3DFMT_DXT1",
            "DXT3": "D3DFMT_DXT3",
            "DXT5": "D3DFMT_DXT5",
            "ATI1": "DXGI_FORMAT_BC4_UNORM",
            "BC4U": "DXGI_FORMAT_BC4_UNORM",
            "BC4S": "DXGI_FORMAT_BC4_SNORM",
            "ATI2": "DXGI_FORMAT_BC5_UNORM",
            "BC5U": "DXGI_FORMAT_BC5_UNORM",
            "BC5S": "DXGI_FORMAT_BC5_SNORM",
        }.get(key, "")

    if (flags & 0x40) and rgb_bits == 32 and r_mask == 0x00FF0000 and g_mask == 0x0000FF00 and b_mask == 0x000000FF:
        if a_mask == 0xFF000000:
            return "D3DFMT_A8R8G8B8"
        if a_mask == 0x00000000:
            return "D3DFMT_X8R8G8B8"

    return ""


def parse_dds_metadata(data, texture_name="texture"):
    if len(data) < 128 or bytes(data[:4]) != b"DDS ":
        raise RuntimeError(f"{texture_name} is not a valid DDS file")
    header_size = int.from_bytes(data[4:8], "little")
    if header_size != 124:
        raise RuntimeError(f"{texture_name} has an unsupported DDS header")
    height = int.from_bytes(data[12:16], "little")
    width = int.from_bytes(data[16:20], "little")
    mip_levels = max(1, int.from_bytes(data[28:32], "little") or 1)
    format_name = dds_format_name(data)
    if not format_name:
        raise RuntimeError(f"{texture_name} uses an unsupported DDS compression format")
    if width <= 0 or height <= 0:
        raise RuntimeError(f"{texture_name} has an invalid DDS size")
    return {
        "width": width,
        "height": height,
        "mip_levels": mip_levels,
        "format": format_name,
    }


def dds_usage_flags(width, height):
    flags = []
    seen = set()
    for prefix, value in (("X", int(width)), ("Y", int(height))):
        for size in (32, 64, 128, 256, 512, 1024, 2048, 4096):
            if value >= size:
                token = f"{prefix}{size}"
                if token not in seen:
                    seen.add(token)
                    flags.append(token)
    flags.append("UNK24")
    return ", ".join(flags)


def vehshare_texture_names():
    global _VEHSHARE_TEXTURE_NAMES_CACHE
    if _VEHSHARE_TEXTURE_NAMES_CACHE is not None:
        return set(_VEHSHARE_TEXTURE_NAMES_CACHE)

    names = set()
    addon_root = os.path.dirname(__file__)
    manifest_path = os.path.join(addon_root, "vehshare_texture_names.txt")
    if os.path.isfile(manifest_path):
        try:
            with open(manifest_path, "r", encoding="utf-8") as fh:
                for line in fh:
                    text = str(line or "").strip().lower()
                    if text:
                        names.add(text)
        except Exception:
            names.clear()

    if not names:
        fallback_dir = os.path.abspath(os.path.join(addon_root, "..", "Samples", "VehShare Files"))
        if os.path.isdir(fallback_dir):
            for root, _dirs, files in os.walk(fallback_dir):
                for filename in files:
                    stem = os.path.splitext(filename)[0].strip().lower()
                    if stem:
                        names.add(stem)

    _VEHSHARE_TEXTURE_NAMES_CACHE = set(names)
    return set(names)


def iter_material_images(obj):
    yielded = set()
    for slot in getattr(obj, "material_slots", []) or []:
        mat = getattr(slot, "material", None)
        if not mat or not getattr(mat, "use_nodes", False):
            continue
        tree = getattr(mat, "node_tree", None)
        for node in getattr(tree, "nodes", []) or []:
            if getattr(node, "type", "") != "TEX_IMAGE":
                continue
            image = getattr(node, "image", None)
            if not image:
                continue
            key = int(image.as_pointer()) if hasattr(image, "as_pointer") else id(image)
            if key in yielded:
                continue
            yielded.add(key)
            yield image


def collect_vehicle_texture_exports(scene, armature):
    excluded_names = vehshare_texture_names()
    exported = {}
    excluded = set()
    failed = set()
    errors = []

    for obj in vehicle_related_mesh_objects(scene, armature):
        for image in iter_material_images(obj):
            tex_name = image_texture_name(image)
            if not tex_name:
                continue
            tex_name_lower = tex_name.lower()
            if tex_name_lower in excluded_names:
                excluded.add(tex_name_lower)
                continue
            if tex_name_lower in failed:
                continue

            source_id = image_source_identifier(image)
            existing = exported.get(tex_name_lower)
            if existing is not None:
                if existing.get("source_id") != source_id:
                    errors.append(f"Texture name conflict for {tex_name}: multiple different source images use the same output name")
                    failed.add(tex_name_lower)
                continue

            data, source_info = image_dds_bytes(image)
            if data is None:
                errors.append(source_info)
                failed.add(tex_name_lower)
                continue

            try:
                meta = parse_dds_metadata(data, texture_name=tex_name)
            except Exception as ex:
                errors.append(str(ex))
                failed.add(tex_name_lower)
                continue

            exported[tex_name_lower] = {
                "name": tex_name,
                "file_name": f"{tex_name}.dds",
                "data": data,
                "source": source_info,
                "source_id": source_id,
                "width": meta["width"],
                "height": meta["height"],
                "mip_levels": meta["mip_levels"],
                "format": meta["format"],
                "usage_flags": dds_usage_flags(meta["width"], meta["height"]),
                "placeholder": str(source_info).startswith("generated transparent placeholder DDS"),
            }

    return list(exported.values()), sorted(excluded), errors


def build_texture_dictionary_xml(texture_infos):
    root = ET.Element("TextureDictionary")
    for info in sorted(texture_infos, key=lambda item: str(item.get("name", "")).lower()):
        item = ET.SubElement(root, "Item")
        ET.SubElement(item, "Name").text = str(info.get("name", "") or "texture")
        e(item, "Unk32", 128)
        ET.SubElement(item, "Usage").text = "DEFAULT"
        ET.SubElement(item, "UsageFlags").text = str(info.get("usage_flags", "UNK24") or "UNK24")
        e(item, "ExtraFlags", 0)
        e(item, "Width", int(info.get("width", 0) or 0))
        e(item, "Height", int(info.get("height", 0) or 0))
        e(item, "MipLevels", int(info.get("mip_levels", 1) or 1))
        ET.SubElement(item, "Format").text = str(info.get("format", "") or "D3DFMT_DXT5")
        ET.SubElement(item, "FileName").text = str(info.get("file_name", "") or "")
    return xml.dom.minidom.parseString(ET.tostring(root, encoding="utf-8")).toprettyxml(indent=" ")


def export_vehicle_texture_dictionary(scene, s, armature, output_dir, model_name):
    textures, excluded, errors = collect_vehicle_texture_exports(scene, armature)
    if errors:
        preview = "; ".join(errors[:4])
        if len(errors) > 4:
            preview += f"; and {len(errors) - 4} more"
        return False, preview, {}
    if not textures:
        return False, "No DDS-backed vehicle textures were found after VehShare exclusions", {}

    texture_dir = os.path.join(output_dir, model_name)
    os.makedirs(texture_dir, exist_ok=True)
    for info in textures:
        with open(os.path.join(texture_dir, info["file_name"]), "wb") as fh:
            fh.write(info["data"])

    xml_path = os.path.join(output_dir, f"{model_name}.ytd.xml")
    with open(xml_path, "w", encoding="utf-8") as fh:
        fh.write(build_texture_dictionary_xml(textures))

    return True, "", {
        "xml_path": xml_path,
        "texture_dir": texture_dir,
        "texture_count": len(textures),
        "excluded_count": len(excluded),
        "placeholder_count": sum(1 for info in textures if info.get("placeholder")),
    }


def sollumz_native_export_available(version_id):
    if not sollumz_enabled():
        return False, "Enable Sollumz first to export native YFT files"
    try:
        gta5 = __import__("szio.gta5", fromlist=["AssetFormat", "AssetVersion", "AssetTarget", "is_provider_available"])
        target = gta5.AssetTarget(gta5.AssetFormat["NATIVE"], gta5.AssetVersion[str(version_id or "GEN8")])
        if not gta5.is_provider_available(target):
            return False, f"Sollumz native export is not available for {version_id}"
    except Exception as ex:
        return False, f"Could not load Sollumz native export support: {ex}"
    return True, ""


def restore_object_selection_state(context, selected_names, active_name, mode_name):
    try:
        bpy.ops.object.select_all(action="DESELECT")
    except Exception:
        pass
    for name in selected_names:
        obj = bpy.data.objects.get(name)
        if obj:
            try:
                obj.select_set(True)
            except Exception:
                pass
    try:
        active_obj = bpy.data.objects.get(active_name) if active_name else None
        if active_obj:
            context.view_layer.objects.active = active_obj
    except Exception:
        pass
    target_mode = "OBJECT"
    text = str(mode_name or "OBJECT").upper()
    if text.startswith("POSE"):
        target_mode = "POSE"
    elif text.startswith("EDIT"):
        target_mode = "EDIT"
    elif text.startswith("SCULPT"):
        target_mode = "SCULPT"
    if target_mode != "OBJECT":
        try:
            bpy.ops.object.mode_set(mode=target_mode)
        except Exception:
            pass


def export_vehicle_yfts_via_sollumz(context, scene, s, armature, output_dir, model_name):
    ok, error_message = sollumz_native_export_available(getattr(s, "vehicle_export_game_version", "GEN8"))
    if not ok:
        return False, error_message, {}

    temp_dir = tempfile.mkdtemp(prefix="gta000tools_yft_")
    selected_names = [obj.name for obj in getattr(context, "selected_objects", []) or [] if obj and obj.name in bpy.data.objects]
    active_obj = getattr(getattr(context, "view_layer", None), "objects", None)
    active_obj = getattr(active_obj, "active", None)
    active_name = getattr(active_obj, "name", "")
    old_mode = str(getattr(context, "mode", "OBJECT") or "OBJECT")
    try:
        try:
            if old_mode != "OBJECT":
                bpy.ops.object.mode_set(mode="OBJECT")
        except Exception:
            pass
        try:
            bpy.ops.object.select_all(action="DESELECT")
        except Exception:
            pass
        armature.select_set(True)
        context.view_layer.objects.active = armature
        result = bpy.ops.sollumz.export_assets(
            directory=temp_dir,
            direct_export=True,
            use_custom_settings=True,
            target_formats={"NATIVE"},
            target_versions={str(getattr(s, "vehicle_export_game_version", "GEN8") or "GEN8")},
            limit_to_selected=True,
            exclude_skeleton=False,
            apply_transforms=False,
            mesh_domain="FACE_CORNER",
        )
        if "FINISHED" not in set(result):
            return False, "Sollumz did not finish the native YFT export", {}

        found = []
        for root, _dirs, files in os.walk(temp_dir):
            for filename in files:
                if filename.lower().endswith(".yft"):
                    found.append(os.path.join(root, filename))
        if not found:
            return False, "Sollumz export finished but no native .yft files were created", {}

        base_src = None
        hi_src = None
        for path in sorted(found):
            stem = os.path.splitext(os.path.basename(path))[0].lower()
            if stem.endswith("_hi"):
                hi_src = hi_src or path
            else:
                base_src = base_src or path
        if not base_src and hi_src:
            base_src = hi_src
            hi_src = None
        if not base_src:
            return False, "Sollumz did not create a base .yft file", {}

        base_path = os.path.join(output_dir, f"{model_name}.yft")
        shutil.copy2(base_src, base_path)
        result_info = {"base_path": base_path, "hi_path": ""}
        if hi_src:
            hi_path = os.path.join(output_dir, f"{model_name}_hi.yft")
            shutil.copy2(hi_src, hi_path)
            result_info["hi_path"] = hi_path
        return True, "", result_info
    finally:
        restore_object_selection_state(context, selected_names, active_name, old_mode)
        shutil.rmtree(temp_dir, ignore_errors=True)


class NELS_OT_export_vehicle(Operator):
    bl_idname = "nels.export_vehicle"
    bl_label = "Export Vehicle"
    bl_options = {"REGISTER"}

    mode: EnumProperty(
        items=[
            ("YFT", "YFT", "Export native YFT files through Sollumz"),
            ("TEXTURES", "Textures", "Export DDS-backed textures and a CodeWalker-ready texture dictionary XML"),
            ("ALL", "All", "Export the native YFT files and the DDS-backed texture package"),
        ],
        default="ALL",
        options={"SKIP_SAVE"},
    )

    def execute(self, context):
        scene = getattr(context, "scene", None)
        s = getattr(scene, "nels", None) if scene else None
        if not scene or not s:
            self.report({"ERROR"}, "No scene settings are available")
            return {"CANCELLED"}

        armature = resolve_vehicle_export_armature(context, scene, s)
        if not armature:
            msg = "Select or choose a Parent Skeleton before exporting the vehicle"
            s.status_message = msg
            self.report({"WARNING"}, msg)
            return {"CANCELLED"}

        output_dir = vehicle_export_directory_path(s)
        model_name = vehicle_export_model_name(scene, s, armature=armature)

        messages = []
        if self.mode in {"YFT", "ALL"}:
            ok, error_message, info = export_vehicle_yfts_via_sollumz(context, scene, s, armature, output_dir, model_name)
            if not ok:
                s.status_message = error_message
                self.report({"ERROR"}, error_message)
                return {"CANCELLED"}
            messages.append(f"YFT: {os.path.basename(info['base_path'])}")
            if info.get("hi_path"):
                messages.append(f"YFT HI: {os.path.basename(info['hi_path'])}")
            else:
                messages.append("YFT HI: not generated (Very High LOD was not exported)")

        if self.mode in {"TEXTURES", "ALL"}:
            ok, error_message, info = export_vehicle_texture_dictionary(scene, s, armature, output_dir, model_name)
            if not ok:
                s.status_message = error_message
                self.report({"ERROR"}, error_message)
                return {"CANCELLED"}
            messages.append(f"Textures: {info.get('texture_count', 0)} DDS")
            messages.append(f"YTD XML: {os.path.basename(info.get('xml_path', ''))}")
            excluded_count = int(info.get("excluded_count", 0) or 0)
            if excluded_count:
                messages.append(f"VehShare excluded: {excluded_count}")
            placeholder_count = int(info.get("placeholder_count", 0) or 0)
            if placeholder_count:
                messages.append(f"Missing placeholders: {placeholder_count}")

        msg = f"Vehicle export complete for {model_name}: " + ", ".join(messages)
        s.status_message = msg
        self.report({"INFO"}, msg)
        return {"FINISHED"}


def e(parent, tag, value=None):
    n = ET.SubElement(parent, tag)
    if value is not None:
        n.set("value", str(value))
    return n


def build_xml(s):
    root = ET.Element("CVehicleModelInfoVarGlobal")
    ss = ET.SubElement(root, "Sirens")
    top = ET.SubElement(ss, "Item")
    e(top, "id", s.vehicle_id)
    ET.SubElement(top, "name").text = s.vehicle_name
    e(top, "timeMultiplier", f8(s.time_multiplier))
    e(top, "lightFalloffMax", f8(s.light_falloff_max))
    e(top, "lightFalloffExponent", f8(s.light_falloff_exp))
    e(top, "lightInnerConeAngle", f8(s.light_inner_angle))
    e(top, "lightOuterConeAngle", f8(s.light_outer_angle))
    e(top, "lightOffset", f8(s.light_offset))
    ET.SubElement(top, "textureName").text = s.texture_name
    e(top, "sequencerBpm", int(s.bpm))

    for tn, key in [("leftHeadLight", s.left_head), ("rightHeadLight", s.right_head), ("leftTailLight", s.left_tail), ("rightTailLight", s.right_tail)]:
        x = ET.SubElement(top, tn)
        p = get_pattern(s, key)
        e(x, "sequencer", bits_to_int(p.bits) if p else 0)

    e(top, "leftHeadLightMultiples", s.left_head_mult)
    e(top, "rightHeadLightMultiples", s.right_head_mult)
    e(top, "leftTailLightMultiples", s.left_tail_mult)
    e(top, "rightTailLightMultiples", s.right_tail_mult)
    e(top, "useRealLights", b(s.use_real_lights))

    sir = ET.SubElement(top, "sirens")
    slots = s.siren_count if s.siren_count > 0 else 20
    for i in range(1, slots + 1):
        si = s.sirens[i - 1] if i - 1 < len(s.sirens) else None
        active = siren_has_output(s, si)
        sir.append(ET.Comment(f"siren{i}" if active else f"inactive siren{i}"))
        it = ET.SubElement(sir, "Item")
        if not active:
            for tag in ["rotation", "flashiness"]:
                sec = ET.SubElement(it, tag)
                e(sec, "delta", f8(0))
                e(sec, "start", f8(0))
                e(sec, "speed", f8(0))
                e(sec, "sequencer", 0)
                e(sec, "multiples", 0)
                e(sec, "direction", b(True))
                e(sec, "syncToBpm", b(True))
            c = ET.SubElement(it, "corona")
            e(c, "intensity", f8(0)); e(c, "size", f8(0)); e(c, "pull", f8(0.00000001)); e(c, "faceCamera", b(False))
            e(it, "color", "0xFFFF0000")
            e(it, "intensity", f8(0))
            e(it, "lightGroup", 0)
            e(it, "rotate", b(False)); e(it, "scale", b(True)); e(it, "scaleFactor", 0)
            e(it, "flash", b(True)); e(it, "light", b(True)); e(it, "spotLight", b(True)); e(it, "castShadows", b(False))
            continue

        _, seq, vis = pattern_triplet(s, si)
        d = dir_val(si)
        is_rot = si.siren_type == "ROTATOR"
        rot_speed_val = rot_speed(s.bpm, si) if is_rot else 0.0
        rot_seq = seq if is_rot and vis in {"BOTH", "ROTATOR"} else 0
        rot_mult = si.light_multiples if is_rot else 0
        rot_dir = bool(getattr(si, "rotator_clockwise", True)) if is_rot else True
        rot_delta = d if is_rot else 0.0

        rot = ET.SubElement(it, "rotation")
        e(rot, "delta", f8(rot_delta))
        e(rot, "start", f8(si.start_delay))
        e(rot, "speed", f8(rot_speed_val))
        e(rot, "sequencer", rot_seq)
        e(rot, "multiples", rot_mult)
        e(rot, "direction", b(rot_dir)); e(rot, "syncToBpm", b(si.sync_to_bpm))

        fl = ET.SubElement(it, "flashiness")
        if is_rot:
            e(fl, "delta", f8(rot_delta)); e(fl, "start", f8(si.start_delay)); e(fl, "speed", f8(rot_speed_val))
            e(fl, "sequencer", rot_seq)
            e(fl, "multiples", rot_mult); e(fl, "direction", b(rot_dir)); e(fl, "syncToBpm", b(si.sync_to_bpm))
        else:
            e(fl, "delta", f8(d)); e(fl, "start", f8(si.start_delay)); e(fl, "speed", f8(si.light_speed))
            e(fl, "sequencer", seq if vis in {"BOTH", "FLASHER"} else 0)
            e(fl, "multiples", si.light_multiples); e(fl, "direction", b(True)); e(fl, "syncToBpm", b(si.sync_to_bpm))

        c = ET.SubElement(it, "corona")
        e(c, "intensity", f8(si.corona_intensity)); e(c, "size", f8(si.corona_size)); e(c, "pull", f8(si.corona_pull)); e(c, "faceCamera", b(si.corona_face_camera))
        e(it, "color", color_hex(s, si)); e(it, "intensity", f8(si.light_intensity)); e(it, "lightGroup", si.light_group)
        e(it, "rotate", b(is_rot)); e(it, "scale", b(True)); e(it, "scaleFactor", f8(scale_val(si)))
        e(it, "flash", b(si.flash)); e(it, "light", b(si.light)); e(it, "spotLight", b(si.spot_light)); e(it, "castShadows", b(si.cast_shadows))
    return xml.dom.minidom.parseString(ET.tostring(root, encoding="utf-8")).toprettyxml(indent="\t")







