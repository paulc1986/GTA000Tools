class NELS_OT_initialize_defaults(Operator):
    bl_idname = "nels.initialize_defaults"
    bl_label = "Initialize Defaults"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        ensure_scene_defaults(context.scene)
        return {"FINISHED"}

class NELS_OT_pattern_tools(Operator):
    bl_idname = "nels.pattern_tools"
    bl_label = "Pattern Tools"
    bl_options = {"REGISTER", "UNDO"}

    action: EnumProperty(items=[("ADD", "ADD", ""), ("DUPLICATE", "DUPLICATE", ""), ("REMOVE", "REMOVE", ""), ("REPEAT", "REPEAT", ""), ("INVERT", "INVERT", "")])
    scope: EnumProperty(items=[("LIB", "LIB", ""), ("SIREN", "SIREN", "")], default="LIB")

    def execute(self, context):
        s = context.scene.nels
        if self.action == "ADD":
            p = s.patterns.add()
            p.name = f"Pattern {len(s.patterns)}"
            p.allow_duplicate = False
            p.visibility = "BOTH"
            p.bits = "00001111000011110000111100001111"
            p.value = str(bits_to_int(p.bits))
            s.active_pattern = len(s.patterns) - 1
            save_global_library(s)
            return {"FINISHED"}
        if self.action == "DUPLICATE":
            if not s.patterns:
                return {"CANCELLED"}
            i = max(0, min(s.active_pattern, len(s.patterns) - 1))
            src = s.patterns[i]
            p = s.patterns.add()
            p.name = f"{(src.name or f'Pattern {i + 1}')} Copy"
            p.allow_duplicate = False
            p.visibility = src.visibility
            p.bits = src.bits
            p.value = src.value
            s.active_pattern = len(s.patterns) - 1
            save_global_library(s)
            return {"FINISHED"}
        if self.action == "REMOVE":
            if s.patterns:
                i = max(0, min(s.active_pattern, len(s.patterns) - 1))
                s.patterns.remove(i)
                s.active_pattern = min(i, max(0, len(s.patterns) - 1))
            save_global_library(s)
            return {"FINISHED"}

        si = s.sirens[s.active_siren] if s.sirens and 0 <= s.active_siren < len(s.sirens) else None
        if self.scope == "LIB":
            p = s.patterns[s.active_pattern] if s.patterns and 0 <= s.active_pattern < len(s.patterns) else None
            if not p:
                return {"CANCELLED"}
            if self.action == "REPEAT":
                p.bits = repeat_32(p.bits)
            elif self.action == "INVERT":
                p.bits = invert_bits(p.bits)
            save_global_library(s)
            return {"FINISHED"}

        if not si:
            return {"CANCELLED"}
        if self.action == "REPEAT":
            si.custom_bits = repeat_32(si.custom_bits)
        elif self.action == "INVERT":
            si.custom_bits = invert_bits(si.custom_bits)
        return {"FINISHED"}


class NELS_OT_save_siren_pattern(Operator):
    bl_idname = "nels.save_siren_pattern"
    bl_label = "Save Pattern to Library"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        scene = getattr(context, "scene", None)
        s = getattr(scene, "nels", None) if scene else None
        if not s or not s.sirens:
            self.report({"ERROR"}, "No siren selected")
            return {"CANCELLED"}

        idx = max(0, min(getattr(s, "active_siren", 0), len(s.sirens) - 1))
        si = s.sirens[idx]
        bits = repeat_32(getattr(si, "custom_bits", "0"))
        value = str(bits_to_int(bits))
        visibility = getattr(si, "custom_visibility", "BOTH")

        existing_key = find_pattern_key_by_bits(s, bits, visibility)
        if existing_key:
            si.pattern_source = "LIBRARY"
            si.pattern_choice = existing_key
            sync_siren_selector_controls(si)
            mark_preview_dirty(context)
            self.report({"INFO"}, "Matched existing library pattern")
            return {"FINISHED"}

        p = s.patterns.add()
        p.name = next_pattern_name(s, "Unsaved Pattern")
        p.allow_duplicate = False
        p.visibility = normalize_pattern_visibility(visibility)
        p.bits = bits
        p.value = value
        s.active_pattern = len(s.patterns) - 1

        save_global_library(s)

        si.pattern_source = "LIBRARY"
        si.pattern_choice = f"PAT_{s.active_pattern}"
        si.custom_bits = bits
        si.custom_value = value
        sync_siren_selector_controls(si)
        mark_preview_dirty(context)
        self.report({"INFO"}, f"Saved pattern as {p.name}")
        return {"FINISHED"}


class NELS_OT_pattern_duplicate_resolution(Operator):
    bl_idname = "nels.pattern_duplicate_resolution"
    bl_label = "Resolve Pattern Duplicate"
    bl_options = {"REGISTER", "UNDO"}

    action: EnumProperty(items=[("ALLOW", "Allow Duplicate", ""), ("KEEP_SELECTED", "Keep Selected Only", ""), ("WARN", "Warn Again", "")], default="ALLOW")
    index: IntProperty(default=-1)

    def execute(self, context):
        s = context.scene.nels
        idx = max(0, min(self.index, len(s.patterns) - 1)) if s.patterns else -1
        matches = pattern_duplicate_indices(s, idx)
        if idx < 0 or not matches:
            self.report({"INFO"}, "No duplicate pattern name detected")
            return {"CANCELLED"}

        if self.action == "ALLOW":
            count = set_pattern_duplicate_allowed(s, idx, True)
            save_global_library(s)
            self.report({"INFO"}, f"Duplicate allowed for {count} patterns")
            return {"FINISHED"}

        if self.action == "WARN":
            count = set_pattern_duplicate_allowed(s, idx, False)
            save_global_library(s)
            self.report({"INFO"}, f"Duplicate warning restored for {count} patterns")
            return {"FINISHED"}

        removed, keep_idx = remove_pattern_duplicates_keep_selected(s, idx)
        s.active_pattern = min(max(0, keep_idx), max(0, len(s.patterns) - 1))
        save_global_library(s)
        self.report({"INFO"}, f"Removed {removed} duplicate patterns")
        return {"FINISHED"}



class NELS_OT_siren_filter_bulk(Operator):
    bl_idname = "nels.siren_filter_bulk"
    bl_label = "Filter Sirens"
    bl_options = {"REGISTER", "UNDO"}

    action: EnumProperty(items=[("SHOW_ALL", "Show All", ""), ("HIDE_ALL", "Hide All", ""), ("BY_DIRECTION", "By Direction", "")], default="SHOW_ALL")
    direction: EnumProperty(items=DIRECTION_ITEMS, default="FRONT")

    def execute(self, context):
        s = getattr(getattr(context, "scene", None), "nels", None)
        if not s or not getattr(s, "sirens", None):
            self.report({"WARNING"}, "Please add Sirens to configure them.")
            return {"CANCELLED"}

        changed = 0
        visible = []
        target_direction = str(getattr(self, "direction", "") or getattr(s, "siren_filter_direction", "FRONT") or "FRONT")
        s.siren_filter_direction = target_direction

        for si in s.sirens:
            if self.action == "SHOW_ALL":
                new_state = True
            elif self.action == "HIDE_ALL":
                new_state = False
            else:
                preset = str(getattr(si, "direction_select", "") or "")
                if preset == "__CUSTOM__" or not preset:
                    preset = direction_preset_from_value(dir_val(si)) or "FRONT"
                new_state = (preset == target_direction)
            if bool(getattr(si, "filter_selected", False)) != bool(new_state):
                si.filter_selected = bool(new_state)
                changed += 1
            if bool(new_state):
                visible.append(si)

        if visible and not any(bool(getattr(si, "expanded", False)) for si in visible):
            try:
                visible[0].expanded = True
            except Exception:
                pass

        mark_preview_dirty(context)
        if self.action == "SHOW_ALL":
            self.report({"INFO"}, f"Showing all {len(s.sirens)} sirens")
        elif self.action == "HIDE_ALL":
            self.report({"INFO"}, "Hid all sirens from the filter")
        else:
            self.report({"INFO"}, f"Showing {len(visible)} sirens facing {target_direction.replace('_', ' ').title()}")
        return {"FINISHED"}

class NELS_OT_pattern_library_io(Operator):
    bl_idname = "nels.pattern_library_io"
    bl_label = "Pattern Library Import/Export"
    bl_options = {"REGISTER", "UNDO"}

    action: EnumProperty(items=[("EXPORT", "EXPORT", ""), ("IMPORT", "IMPORT", "")], default="EXPORT")

    def execute(self, context):
        s = context.scene.nels
        fp = bpy.path.abspath(getattr(s, "pattern_library_path", "") or "").strip()
        if not fp:
            self.report({"ERROR"}, "Pattern library path is empty")
            return {"CANCELLED"}
        if not fp.lower().endswith(".json"):
            fp += ".json"

        try:
            if self.action == "EXPORT":
                out_dir = os.path.dirname(fp)
                if out_dir:
                    os.makedirs(out_dir, exist_ok=True)

                data = {
                    "patterns": [
                        {
                            "name": p.name,
                            "visibility": "FLASHER" if p.visibility == "FLASHER" else "BOTH",
                            "bits": repeat_32(p.bits),
                            "value": parse_u32(p.value),
                            "allow_duplicate": bool(getattr(p, "allow_duplicate", False)),
                        }
                        for p in s.patterns
                    ]
                }
                with open(fp, "w", encoding="utf-8") as h:
                    json.dump(data, h, indent=2)
                s.pattern_library_path = fp
                s.status_message = f"Pattern library exported: {fp}"
                self.report({"INFO"}, s.status_message)
                return {"FINISHED"}

            if not os.path.exists(fp):
                self.report({"ERROR"}, f"Pattern library not found: {fp}")
                return {"CANCELLED"}

            with open(fp, "r", encoding="utf-8") as h:
                data = json.load(h)

            if isinstance(data, dict):
                pats = data.get("patterns", [])
            elif isinstance(data, list):
                pats = data
            else:
                self.report({"ERROR"}, "Invalid pattern library format")
                return {"CANCELLED"}

            if not isinstance(pats, list):
                self.report({"ERROR"}, "Pattern library must contain a list of patterns")
                return {"CANCELLED"}

            s.patterns.clear()
            for pd in pats:
                if not isinstance(pd, dict):
                    continue
                p = s.patterns.add()
                p.name = str(pd.get("name", "Pattern") or "Pattern")
                p.allow_duplicate = bool(pd.get("allow_duplicate", False))
                p.visibility = "FLASHER" if pd.get("visibility", "BOTH") == "FLASHER" else "BOTH"
                bits = clean_bits(pd.get("bits", int_to_bits(pd.get("value", 0)))) or "0"
                p.bits = bits
                p.value = str(parse_u32(pd.get("value", bits_to_int(bits))))

            ensure_off_pattern(s)
            s.active_pattern = min(max(0, s.active_pattern), max(0, len(s.patterns) - 1))
            save_global_library(s)
            s.pattern_library_path = fp
            s.status_message = f"Pattern library imported: {fp}"
            self.report({"INFO"}, s.status_message)
            return {"FINISHED"}
        except Exception as ex:
            self.report({"ERROR"}, f"Pattern library {self.action.lower()} failed: {ex}")
            return {"CANCELLED"}
class NELS_OT_color_tools(Operator):
    bl_idname = "nels.color_tools"
    bl_label = "Color Tools"
    bl_options = {"REGISTER", "UNDO"}

    action: EnumProperty(items=[("ADD", "ADD", ""), ("REMOVE", "REMOVE", "")])

    def execute(self, context):
        s = context.scene.nels
        ensure_color_defaults(s)

        if self.action == "ADD":
            c = s.colors.add()
            c.name = f"Custom Colour {len(s.colors)}"
            c.rgb = (1.0, 0.0, 0.0)
            c.value = rgb_to_color(c.rgb)
            s.active_color = len(s.colors) - 1
            save_global_library(s)
            return {"FINISHED"}

        if not s.colors:
            return {"CANCELLED"}
        i = max(0, min(s.active_color, len(s.colors) - 1))
        s.colors.remove(i)
        if not s.colors:
            ensure_color_defaults(s)
        s.active_color = min(i, max(0, len(s.colors) - 1))
        for si in s.sirens:
            si.color_preset = normalize_color_key(si.color_preset)
        save_global_library(s)
        return {"FINISHED"}


class NELS_OT_other_attr_tools(Operator):
    bl_idname = "nels.other_attr_tools"
    bl_label = "Other Attribute Tools"
    bl_options = {"REGISTER", "UNDO"}

    action: EnumProperty(items=[("ADD", "ADD", ""), ("REMOVE", "REMOVE", "")], default="ADD")

    def execute(self, context):
        s = context.scene.nels
        ensure_other_attributes_defaults(s)

        if self.action == "ADD":
            a = s.other_attributes.add()
            a.display_value = f"Attribute {len(s.other_attributes)}"
            a.return_value = ""
            s.active_other_attribute = len(s.other_attributes) - 1
            return {"FINISHED"}

        if not s.other_attributes:
            return {"CANCELLED"}
        i = max(0, min(s.active_other_attribute, len(s.other_attributes) - 1))
        s.other_attributes.remove(i)
        if not s.other_attributes:
            ensure_other_attributes_defaults(s)
        s.active_other_attribute = min(i, max(0, len(s.other_attributes) - 1))
        return {"FINISHED"}


class NELS_OT_light_id_faces(Operator):
    bl_idname = "nels.light_id_faces"
    bl_label = "Light IDs"
    bl_options = {"REGISTER", "UNDO"}

    action: EnumProperty(items=[("SET", "Set", "Assign the selected Light ID to the selected faces"), ("SELECT", "Select", "Select faces that already use the chosen Light ID")], default="SET")

    def execute(self, context):
        scene = getattr(context, "scene", None)
        s = getattr(scene, "nels", None) if scene else None
        if not s:
            self.report({"WARNING"}, "No scene settings available")
            return {"CANCELLED"}
        if not light_id_face_select_ready(context):
            self.report({"WARNING"}, "Must be in Edit Mode > Face Select")
            return {"CANCELLED"}

        obj = getattr(context, "active_object", None)
        if not obj or getattr(obj, "type", "") != "MESH":
            self.report({"WARNING"}, "Select a mesh in Edit Mode")
            return {"CANCELLED"}

        bm = bmesh.from_edit_mesh(obj.data)
        bm.faces.ensure_lookup_table()
        value = current_light_id_value(s)
        label = next((item[1] for item in SOLLUMZ_LIGHT_ID_UI_ITEMS if item[0] == getattr(s, "car_light_id_target", "always_on")), "Custom")

        if self.action == "SET":
            selected_indices = [face.index for face in bm.faces if face.select]
            if not selected_indices:
                self.report({"WARNING"}, "Select one or more faces first")
                return {"CANCELLED"}
            layer = editable_light_id_face_layer(bm, create=True)
            if layer is None:
                self.report({"ERROR"}, "Could not access a face integer layer for Light IDs")
                return {"CANCELLED"}
            bm.faces.ensure_lookup_table()
            for face_index in selected_indices:
                if 0 <= face_index < len(bm.faces):
                    bm.faces[face_index][layer] = int(value)
            bmesh.update_edit_mesh(obj.data, loop_triangles=False, destructive=False)
            s.car_light_id_signature = ""
            s.car_light_id_checked_at = 0.0
            apply_car_light_simulation(scene, s, blink_indicators=True, now=playback_seconds(scene=scene))
            self.report({"INFO"}, f"Assigned {label} to {len(selected_indices)} face(s)")
            return {"FINISHED"}

        layer = editable_light_id_face_layer(bm, create=False)
        if layer is None:
            self.report({"WARNING"}, "No editable Light ID layer was found on this mesh")
            return {"CANCELLED"}

        match_count = 0
        for face in bm.faces:
            is_match = int(face[layer]) == int(value)
            face.select_set(is_match)
            if is_match:
                match_count += 1
        bmesh.update_edit_mesh(obj.data, loop_triangles=False, destructive=False)
        if match_count <= 0:
            self.report({"WARNING"}, f"No faces use {label}")
            return {"CANCELLED"}
        self.report({"INFO"}, f"Selected {match_count} face(s) using {label}")
        return {"FINISHED"}

class NELS_OT_car_lights_sim(Operator):
    bl_idname = "nels.car_lights_sim"
    bl_label = "Apply Car Light Simulation"
    bl_options = {"REGISTER", "UNDO"}

    action: EnumProperty(items=[("APPLY", "APPLY", ""), ("RESET", "RESET", "")], default="APPLY")

    def execute(self, context):
        s = context.scene.nels
        scene = context.scene

        if self.action == "RESET":
            s.car_headlights_on = False
            s.car_taillights_on = False
            s.car_left_indicator_on = False
            s.car_right_indicator_on = False
            s.car_extra_lights_on = False

        touched = apply_car_light_simulation(scene, s, blink_indicators=True, now=playback_seconds(scene=scene))
        msg = f"Applied car light simulation to {touched} objects"
        s.status_message = msg
        self.report({"INFO"}, msg)
        return {"FINISHED"}


class NELS_OT_wheel_simulation(Operator):
    bl_idname = "nels.wheel_simulation"
    bl_label = "Wheel Preview"
    bl_options = {"REGISTER", "UNDO"}

    action: EnumProperty(items=[("APPLY", "APPLY", ""), ("RESET", "RESET", "")], default="APPLY")

    @classmethod
    def poll(cls, context):
        return bool(sollumz_enabled())

    def execute(self, context):
        s = context.scene.nels
        scene = context.scene

        if self.action == "RESET":
            removed = clear_sollumz_wheel_preview_objects(scene) + clear_wheel_preview_objects(scene)
            msg = f"Cleared {removed} wheel preview objects"
            s.status_message = msg
            self.report({"INFO"}, msg)
            return {"FINISHED"}

        ok, used_name, error_message = run_sollumz_wheel_preview(context, scene)
        if not ok:
            msg = error_message or "Could not run Sollumz wheel preview. Select an object inside the Sollumz fragment and try again."
            s.status_message = msg
            self.report({"WARNING"}, msg)
            return {"CANCELLED"}

        msg = f"Generated Sollumz wheel preview using {used_name}" if used_name else "Generated Sollumz wheel preview"
        s.status_message = msg
        self.report({"INFO"}, msg)
        return {"FINISHED"}


def clear_sollumz_wheel_preview_objects(scene):
    scene_names = {obj.name for obj in getattr(scene, "objects", [])} if scene else set()
    roots = []
    for obj in bpy.data.objects:
        name = str(getattr(obj, "name", "") or "")
        if scene_names and name not in scene_names:
            continue
        if name.endswith(".wheel_previews"):
            roots.append(obj)

    seen = set()
    ordered = []

    def collect(obj):
        if not obj:
            return
        name = str(getattr(obj, "name", "") or "")
        if name in seen:
            return
        seen.add(name)
        for child in list(getattr(obj, "children", [])):
            collect(child)
        ordered.append(obj)

    for root in roots:
        collect(root)

    removed = 0
    for obj in ordered:
        try:
            bpy.data.objects.remove(obj, do_unlink=True)
            removed += 1
        except Exception:
            pass
    return removed


def run_sollumz_wheel_preview(context, scene):
    op_group = getattr(bpy.ops, "sollumz", None)
    op = getattr(op_group, "generate_wheel_instances", None) if op_group else None
    if op is None:
        return False, "", "Sollumz wheel preview is not available. Enable Sollumz first."

    candidates = []
    seen = set()

    def add_candidate(obj):
        if not obj:
            return
        try:
            name = str(obj.name)
        except Exception:
            return
        if name in seen:
            return
        seen.add(name)
        candidates.append(obj)

    add_candidate(getattr(context, "active_object", None))
    for obj in getattr(context, "selected_objects", []) or []:
        add_candidate(obj)

    arm, bones = wheel_pose_bones(scene)
    if arm and bones:
        add_candidate(find_source_wheel_object(context, arm, bones))
        add_candidate(arm)

    for obj in getattr(scene, "objects", []):
        name = str(getattr(obj, "name", "") or "").lower()
        if name.startswith("wheel_") or "wheel" in name:
            add_candidate(obj)

    last_error = ""
    for obj in candidates:
        try:
            with context.temp_override(
                active_object=obj,
                object=obj,
                selected_objects=[obj],
                selected_editable_objects=[obj],
            ):
                if not bpy.ops.sollumz.generate_wheel_instances.poll():
                    continue
                bpy.ops.sollumz.generate_wheel_instances()
                return True, str(getattr(obj, "name", "") or ""), ""
        except Exception as ex:
            last_error = str(ex)

    if not candidates:
        return False, "", "Select an object inside the Sollumz fragment before generating wheel preview."
    return False, "", last_error or "Select an object inside the Sollumz fragment before generating wheel preview."


class NELS_OT_environment_lights(Operator):
    bl_idname = "nels.environment_lights"
    bl_label = "Environmental Lights"
    bl_options = {"REGISTER", "UNDO"}

    action: EnumProperty(
        items=[
            ("GENERATE", "Generate", "Create or update environment preview lights for active sirens"),
            ("CLEAR", "Clear", "Remove previously generated environment preview lights"),
        ],
        default="GENERATE",
    )

    def execute(self, context):
        scene = getattr(context, "scene", None)
        s = getattr(scene, "nels", None) if scene else None
        if not scene or not s:
            self.report({"WARNING"}, "No scene settings available")
            return {"CANCELLED"}

        if self.action == "CLEAR":
            removed = clear_environment_lights(scene)
            self.report({"INFO"}, f"Removed {removed} generated environment light(s)")
            return {"FINISHED"}

        created, updated = generate_environment_lights(scene, s)
        self.report({"INFO"}, f"Environment lights updated: {created} created, {updated} updated")
        return {"FINISHED"}


class NELS_OT_extra_visibility(Operator):
    bl_idname = "nels.extra_visibility"
    bl_label = "Set Extra Visibility"
    bl_options = {"REGISTER", "UNDO"}

    object_name: StringProperty(default="")
    show: BoolProperty(default=True)

    def execute(self, context):
        obj = bpy.data.objects.get(self.object_name)
        if not obj:
            return {"CANCELLED"}
        set_object_visible(obj, self.show)
        return {"FINISHED"}


class NELS_OT_extras_visibility_all(Operator):
    bl_idname = "nels.extras_visibility_all"
    bl_label = "Set All Extras Visibility"
    bl_options = {"REGISTER", "UNDO"}

    show: BoolProperty(default=True)

    def execute(self, context):
        objs = scene_extra_objects(context.scene)
        for obj in objs:
            set_object_visible(obj, self.show)
        self.report({"INFO"}, f"Updated {len(objs)} extras")
        return {"FINISHED"}
class NELS_OT_set_siren_count(Operator):
    bl_idname = "nels.set_siren_count"
    bl_label = "Set Siren Count"
    bl_options = {"REGISTER", "UNDO"}
    count: IntProperty(default=20)

    def execute(self, context):
        ensure_sirens(context.scene.nels, self.count)
        return {"FINISHED"}



class NELS_OT_swap_sirens(Operator):
    bl_idname = "nels.swap_sirens"
    bl_label = "Swap Sirens"
    bl_options = {"REGISTER", "UNDO"}

    siren_a: EnumProperty(name="First Siren", items=swappable_siren_items)
    siren_b: EnumProperty(name="Second Siren", items=swappable_siren_items)

    def invoke(self, context, event):
        items = [item[0] for item in swappable_siren_items(self, context) if item[0] != "__NONE__"]
        if len(items) < 2:
            msg = "Warning: Link mesh and bone for at least two sirens before swapping"
            context.scene.nels.status_message = msg
            self.report({"WARNING"}, msg)
            return {"CANCELLED"}
        if self.siren_a not in items:
            self.siren_a = items[0]
        if self.siren_b not in items or self.siren_b == self.siren_a:
            self.siren_b = next((item for item in items if item != self.siren_a), items[0])
        return context.window_manager.invoke_props_dialog(self, width=360)

    def draw(self, context):
        l = self.layout
        l.label(text="Swap the scene mesh and bone names for two configured sirens.")
        l.prop(self, "siren_a", text="First Siren")
        l.prop(self, "siren_b", text="Second Siren")

    def execute(self, context):
        scene = context.scene
        s = scene.nels
        if self.siren_a == "__NONE__" or self.siren_b == "__NONE__":
            msg = "Warning: Link mesh and bone for at least two sirens before swapping"
            s.status_message = msg
            self.report({"WARNING"}, msg)
            return {"CANCELLED"}
        if self.siren_a == self.siren_b:
            msg = "Warning: Choose two different sirens to swap"
            s.status_message = msg
            self.report({"WARNING"}, msg)
            return {"CANCELLED"}

        si_a = siren_slot_by_index(s, self.siren_a)
        si_b = siren_slot_by_index(s, self.siren_b)
        if not si_a or not si_b:
            msg = "Warning: Could not resolve the selected sirens"
            s.status_message = msg
            self.report({"WARNING"}, msg)
            return {"CANCELLED"}

        obj_a = siren_obj(si_a)
        obj_b = siren_obj(si_b)
        arm_a, pb_a = siren_pose_bone(scene, si_a)
        arm_b, pb_b = siren_pose_bone(scene, si_b)
        if not obj_a or obj_a.type != "MESH" or not obj_b or obj_b.type != "MESH":
            msg = "Warning: Both selected sirens must have linked mesh objects before swapping"
            s.status_message = msg
            self.report({"WARNING"}, msg)
            return {"CANCELLED"}
        if not arm_a or not pb_a or not arm_b or not pb_b:
            msg = "Warning: Both selected sirens must have linked bones before swapping"
            s.status_message = msg
            self.report({"WARNING"}, msg)
            return {"CANCELLED"}

        old_obj_a_name = obj_a.name
        old_obj_b_name = obj_b.name
        old_bone_a_name = pb_a.name
        old_bone_b_name = pb_b.name
        new_obj_a_name = f"siren{si_b.index}"
        new_obj_b_name = f"siren{si_a.index}"
        new_bone_a_name = f"siren{si_b.index}"
        new_bone_b_name = f"siren{si_a.index}"

        def object_name_conflict(target_name):
            other = bpy.data.objects.get(target_name)
            return other is not None and other not in (obj_a, obj_b)

        def bone_name_conflict(arm, target_name, allowed_names):
            bone = arm.data.bones.get(target_name) if arm and getattr(arm, "data", None) else None
            return bone is not None and bone.name not in allowed_names

        if object_name_conflict(new_obj_a_name) or object_name_conflict(new_obj_b_name):
            msg = "Warning: A different scene object is already using one of the target siren names"
            s.status_message = msg
            self.report({"WARNING"}, msg)
            return {"CANCELLED"}

        allowed_a = {old_bone_a_name}
        allowed_b = {old_bone_b_name}
        if arm_a == arm_b:
            allowed_a.add(old_bone_b_name)
            allowed_b.add(old_bone_a_name)
        if bone_name_conflict(arm_a, new_bone_a_name, allowed_a) or bone_name_conflict(arm_b, new_bone_b_name, allowed_b):
            msg = "Warning: A different siren bone is already using one of the target siren names"
            s.status_message = msg
            self.report({"WARNING"}, msg)
            return {"CANCELLED"}

        def capture_children(arm, bone_name):
            links = []
            for child in scene.objects:
                try:
                    if child.parent == arm and child.parent_type == "BONE" and child.parent_bone == bone_name:
                        links.append((child, child.matrix_world.copy()))
                except Exception:
                    continue
            return links

        def restore_children(links, arm, bone_name):
            for child, matrix_world in links:
                try:
                    child.parent = arm
                    child.parent_type = "BONE"
                    child.parent_bone = bone_name
                    child.matrix_world = matrix_world
                except Exception:
                    continue

        child_links_a = capture_children(arm_a, old_bone_a_name)
        child_links_b = capture_children(arm_b, old_bone_b_name)
        temp_tag = _time.time_ns()
        temp_obj_a_name = f"__nels_swap_obj_{si_a.index}_{temp_tag}_a"
        temp_obj_b_name = f"__nels_swap_obj_{si_b.index}_{temp_tag}_b"
        temp_bone_a_name = f"__nels_swap_bone_{si_a.index}_{temp_tag}_a"
        temp_bone_b_name = f"__nels_swap_bone_{si_b.index}_{temp_tag}_b"

        old_active = getattr(context.view_layer.objects, "active", None)
        old_mode = getattr(context, "mode", "OBJECT")
        try:
            obj_a.name = temp_obj_a_name
            obj_b.name = temp_obj_b_name
            obj_a.name = new_obj_a_name
            obj_b.name = new_obj_b_name

            plans = []
            if arm_a == arm_b:
                plans.append((arm_a, [(old_bone_a_name, temp_bone_a_name), (old_bone_b_name, temp_bone_b_name)], [(temp_bone_a_name, new_bone_a_name), (temp_bone_b_name, new_bone_b_name)]))
            else:
                plans.append((arm_a, [(old_bone_a_name, temp_bone_a_name)], [(temp_bone_a_name, new_bone_a_name)]))
                plans.append((arm_b, [(old_bone_b_name, temp_bone_b_name)], [(temp_bone_b_name, new_bone_b_name)]))

            if old_mode != "OBJECT":
                bpy.ops.object.mode_set(mode="OBJECT")
            for arm, temp_pairs, final_pairs in plans:
                bpy.ops.object.select_all(action="DESELECT")
                arm.select_set(True)
                context.view_layer.objects.active = arm
                bpy.ops.object.mode_set(mode="EDIT")
                for old_name, temp_name in temp_pairs:
                    eb = arm.data.edit_bones.get(old_name)
                    if not eb:
                        raise RuntimeError(f"Missing editable bone {old_name}")
                    eb.name = temp_name
                for temp_name, final_name in final_pairs:
                    eb = arm.data.edit_bones.get(temp_name)
                    if not eb:
                        raise RuntimeError(f"Missing temporary bone {temp_name}")
                    eb.name = final_name
                bpy.ops.object.mode_set(mode="OBJECT")
        except Exception as exc:
            msg = f"Warning: Failed to swap sirens: {exc}"
            s.status_message = msg
            self.report({"WARNING"}, msg)
            return {"CANCELLED"}
        finally:
            try:
                if getattr(context, "mode", "OBJECT") != "OBJECT":
                    bpy.ops.object.mode_set(mode="OBJECT")
            except Exception:
                pass
            try:
                if old_active and old_active.name in bpy.data.objects:
                    context.view_layer.objects.active = old_active
            except Exception:
                pass
            try:
                if old_mode != "OBJECT" and getattr(context, "mode", "OBJECT") == "OBJECT":
                    bpy.ops.object.mode_set(mode=old_mode)
            except Exception:
                pass

        restore_children(child_links_a, arm_a, new_bone_a_name)
        restore_children(child_links_b, arm_b, new_bone_b_name)

        object_map = {old_obj_a_name: new_obj_a_name, old_obj_b_name: new_obj_b_name}
        bone_map = {old_bone_a_name: new_bone_a_name, old_bone_b_name: new_bone_b_name}
        for si in s.sirens:
            if si.object_name in object_map:
                si.object_name = object_map[si.object_name]
            if si.bone_name in bone_map:
                si.bone_name = bone_map[si.bone_name]
            si.enabled = bool(si.object_name or si.bone_name)

        anchor_a = si_a.anchor_name
        anchor_b = si_b.anchor_name
        si_a.object_name = f"siren{si_a.index}"
        si_b.object_name = f"siren{si_b.index}"
        si_a.bone_name = f"siren{si_a.index}"
        si_b.bone_name = f"siren{si_b.index}"
        si_a.anchor_name = anchor_b
        si_b.anchor_name = anchor_a
        si_a.enabled = True
        si_b.enabled = True

        apply_all_siren_directions(scene)
        refresh_direction_warning(scene)
        mark_preview_dirty(context)
        tag_all_ui_redraw()

        msg = f"Swapped Siren {si_a.index} and Siren {si_b.index}"
        s.status_message = msg
        self.report({"INFO"}, msg)
        return {"FINISHED"}


class NELS_OT_renumber_siren(Operator):
    bl_idname = "nels.renumber_siren"
    bl_label = "Renumber Siren"
    bl_options = {"REGISTER", "UNDO"}

    target_index: EnumProperty(name="New Siren Number", items=renumber_target_items)

    def invoke(self, context, event):
        scene = context.scene
        s = getattr(scene, "nels", None)
        if not s or not s.sirens:
            self.report({"WARNING"}, "No sirens are configured")
            return {"CANCELLED"}
        clear_missing_associations(scene)
        items = [item[0] for item in renumber_target_items(self, context) if item[0] != "__NONE__"]
        if not items:
            self.report({"WARNING"}, "No available siren numbers exist in the current configuration")
            return {"CANCELLED"}
        if self.target_index not in items:
            self.target_index = items[0]
        return context.window_manager.invoke_props_dialog(self, width=340)

    def draw(self, context):
        self.layout.label(text="Rename the selected siren hierarchy to an unused configured siren number.")
        self.layout.prop(self, "target_index", text="Target")

    def execute(self, context):
        scene = context.scene
        s = getattr(scene, "nels", None)
        if not s or not s.sirens:
            self.report({"ERROR"}, "No sirens are configured")
            return {"CANCELLED"}

        clear_missing_associations(scene)
        if self.target_index == "__NONE__":
            self.report({"ERROR"}, "No target siren number is available")
            return {"CANCELLED"}

        try:
            target_index = int(self.target_index)
        except Exception:
            self.report({"ERROR"}, "Invalid target siren number")
            return {"CANCELLED"}

        limit = max(0, min(int(getattr(s, "siren_count", len(s.sirens)) or len(s.sirens)), len(s.sirens)))
        if target_index < 1 or target_index > limit:
            self.report({"ERROR"}, f"Target siren must be between 1 and {limit}")
            return {"CANCELLED"}

        target_slot = siren_slot_by_index(s, target_index)
        if not target_slot:
            self.report({"ERROR"}, f"Could not resolve Siren {target_index}")
            return {"CANCELLED"}
        if (siren_obj(target_slot) or siren_pose_bone(scene, target_slot)[1]):
            self.report({"ERROR"}, f"Siren {target_index} already exists in the scene")
            return {"CANCELLED"}

        source_slot = resolve_context_siren(scene, s, require_linked=False)
        active = selected_siren_root_object(context, fallback=siren_obj(source_slot) if source_slot else None)
        if not active:
            self.report({"ERROR"}, "Select a siren mesh or sub-mesh first")
            return {"CANCELLED"}

        source_obj = active
        old_index = infer_siren_index_from_hierarchy(source_obj, fallback=int(getattr(source_slot, "index", 0) or 0))
        if old_index <= 0:
            self.report({"ERROR"}, "Could not determine the siren number from the selected hierarchy")
            return {"CANCELLED"}
        if old_index == target_index:
            self.report({"ERROR"}, "Choose a different siren number")
            return {"CANCELLED"}

        source_slot = siren_slot_by_index(s, old_index) or source_slot
        source_snapshot = capture_siren_slot_snapshot(source_slot) if source_slot else None
        old_object_name = getattr(source_obj, "name", "")
        old_anchor_name = getattr(source_slot, "anchor_name", "") if source_slot else ""
        old_bone_name = str(getattr(source_slot, "bone_name", "") or f"siren{old_index}")

        try:
            arm, pb = siren_pose_bone(scene, source_slot) if source_slot else (None, None)
            renamed_bones = {}
            new_root_bone_name = ""
            if arm and pb:
                renamed_bones, new_root_bone_name = rename_siren_bone_hierarchy(scene, arm, pb.name, old_index, target_index)
            hierarchy = retarget_siren_hierarchy(source_obj, old_index, target_index, detach_root=False)
            renamed_objects = set(hierarchy or [])
            if arm and renamed_bones:
                subtree_bones = set(renamed_bones.values())
                extra_roots = []
                for obj in scene.objects:
                    try:
                        if obj in renamed_objects:
                            continue
                        if obj.parent == arm and obj.parent_type == "BONE" and obj.parent_bone in subtree_bones:
                            extra_roots.append(obj)
                    except Exception:
                        continue
                for obj in extra_roots:
                    renamed_objects.update(retarget_siren_hierarchy(obj, old_index, target_index, detach_root=False, force_root_name=False) or [])
            new_object_name = getattr(source_obj, "name", f"siren{target_index}")
        except Exception as exc:
            self.report({"ERROR"}, f"Failed to renumber siren: {exc}")
            return {"CANCELLED"}

        if source_snapshot:
            apply_siren_slot_snapshot(s, target_slot, target_index, source_snapshot)
        else:
            add_siren(s, target_slot, target_index)

        target_slot.object_name = new_object_name
        if new_root_bone_name:
            target_slot.bone_name = new_root_bone_name
        elif renamed_bones:
            target_slot.bone_name = renamed_bones.get(old_bone_name, f"siren{target_index}")
        target_slot.anchor_name = old_anchor_name
        target_slot.enabled = True

        if source_slot:
            add_siren(s, source_slot, old_index)
        s.active_siren = max(0, target_index - 1)

        refresh_direction_warning(scene)
        apply_all_siren_directions(scene)
        clear_preview_keyframes(scene, list(s.sirens))
        s.preview_generated = False
        mark_preview_dirty(context)
        tag_all_ui_redraw()

        msg = f"Renumbered siren{old_index} to siren{target_index}"
        s.status_message = msg
        self.report({"INFO"}, msg)
        return {"FINISHED"}


class NELS_OT_duplicate_siren(Operator):
    bl_idname = "nels.duplicate_siren"
    bl_label = "Duplicate Siren"
    bl_options = {"REGISTER", "UNDO"}

    target_index: EnumProperty(name="Target Siren", items=renumber_target_items)

    def invoke(self, context, event):
        scene = context.scene
        s = getattr(scene, "nels", None)
        if not s or not s.sirens:
            return {"CANCELLED"}
        source = resolve_context_siren(scene, s, require_linked=True)
        if not source:
            return {"CANCELLED"}
        items = [item[0] for item in renumber_target_items(self, context) if item[0] != "__NONE__"]
        if not items:
            self.report({"WARNING"}, "No available siren numbers exist in the current configuration")
            return {"CANCELLED"}
        suggested = str(suggest_duplicate_target_index(s, source.index))
        self.target_index = suggested if suggested in items else items[0]
        return context.window_manager.invoke_props_dialog(self, width=340)

    def draw(self, context):
        self.layout.label(text="Duplicate the selected siren hierarchy to an unused configured siren number.")
        self.layout.prop(self, "target_index", text="Target")

    def execute(self, context):
        scene = context.scene
        s = getattr(scene, "nels", None)
        if not s or not s.sirens:
            self.report({"ERROR"}, "Please add Sirens to configure them.")
            return {"CANCELLED"}

        source = resolve_context_siren(scene, s, require_linked=True)
        if not source:
            self.report({"ERROR"}, "No linked siren could be resolved from the current selection")
            return {"CANCELLED"}

        if self.target_index == "__NONE__":
            self.report({"ERROR"}, "No target siren number is available")
            return {"CANCELLED"}
        target_index = int(self.target_index or 0)
        limit = max(0, min(int(getattr(s, "siren_count", len(s.sirens)) or len(s.sirens)), len(s.sirens)))
        if target_index < 1 or target_index > limit:
            self.report({"ERROR"}, f"Target siren must be between 1 and {limit}")
            return {"CANCELLED"}
        if target_index == int(source.index):
            self.report({"ERROR"}, "Choose a different siren number for the duplicate")
            return {"CANCELLED"}

        ensure_sirens(s, max(len(s.sirens), target_index))
        target = siren_slot_by_index(s, target_index)
        if not target:
            self.report({"ERROR"}, f"Could not resolve Siren {target_index}")
            return {"CANCELLED"}
        if target.object_name or target.bone_name:
            self.report({"ERROR"}, f"Siren {target_index} is already configured")
            return {"CANCELLED"}
        if bpy.data.objects.get(f"siren{target_index}") is not None:
            self.report({"ERROR"}, f"An object named siren{target_index} already exists")
            return {"CANCELLED"}

        source_obj = siren_obj(source)
        if not source_obj:
            self.report({"ERROR"}, "The active siren has no linked mesh to duplicate")
            return {"CANCELLED"}

        arm, pb = siren_pose_bone(scene, source)
        extra_sources = siren_bone_subtree_objects(scene, arm, pb.name, exclude={source_obj}) if arm and pb else []
        dup_root, duplicates = duplicate_siren_hierarchy(scene, source_obj, source.index, target_index, extra_sources=extra_sources)
        if not dup_root:
            self.report({"ERROR"}, "Could not duplicate the selected siren hierarchy")
            return {"CANCELLED"}

        source_snapshot = capture_siren_slot_snapshot(source)
        apply_siren_slot_snapshot(s, target, target_index, source_snapshot)
        target.object_name = dup_root.name
        target.bone_name = ""
        target.anchor_name = ""
        target.enabled = True
        s.active_siren = max(0, target_index - 1)
        clear_preview_keyframes(scene, [target])
        refresh_direction_warning(scene)
        mark_preview_dirty(context)

        try:
            bpy.ops.object.select_all(action='DESELECT')
            for obj in duplicates:
                obj.select_set(True)
            context.view_layer.objects.active = dup_root
        except Exception:
            pass

        msg = f"Duplicated Siren {source.index} to Siren {target_index}"
        s.status_message = msg
        self.report({"INFO"}, msg)
        return {"FINISHED"}


class NELS_OT_auto_detect(Operator):
    bl_idname = "nels.auto_detect"
    bl_label = "Auto-Detect Sirens/Bones"
    bl_options = {"REGISTER", "UNDO"}

    create_missing: BoolProperty(default=True)

    def execute(self, context):
        obj_count, bone_count, linked = auto_detect_scene_sirens(context.scene, create_missing=self.create_missing, sync_direction=True)
        self.report({"INFO"}, f"Detected objects: {obj_count}, bones: {bone_count}, linked: {linked}")
        return {"FINISHED"}


class NELS_OT_generate_siren_id(Operator):
    bl_idname = "nels.generate_siren_id"
    bl_label = "Generate Siren ID"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        s = context.scene.nels
        s.vehicle_id = generate_siren_id(s.vehicle_name)
        return {"FINISHED"}


def reset_scene_config_defaults(s, keep_name=False):
    cfg_name = s.config_name if keep_name and str(s.config_name).strip() else "new_lightbar"
    s.config_name = cfg_name
    s.vehicle_name = "police"
    s.vehicle_id = generate_siren_id(s.vehicle_name)
    s.bpm = 800
    s.scale_factor = 0.5
    s.scale_factor_choice = "SF_2"
    s.scale_factor_custom = 0.5
    s.patterns.clear()
    ensure_defaults(s)
    s.colors.clear()
    ensure_color_defaults(s)
    s.other_attributes.clear()
    ensure_other_attributes_defaults(s)
    s.sirens.clear()
    s.siren_count = 0
    off_key = off_pattern_key(s)
    s.left_head = off_key
    s.right_head = off_key
    s.left_tail = off_key
    s.right_tail = off_key
    s.saved_config = NO_SAVED_CFG
    s.car_headlights_on = False
    s.car_taillights_on = False
    s.car_left_indicator_on = False
    s.car_right_indicator_on = False
    s.car_extra_lights_on = False
    sync_scale_factor_controls(s)


class NELS_OT_new_save_load(Operator):
    bl_idname = "nels.new_save_load"
    bl_label = "Config IO"
    bl_options = {"REGISTER", "UNDO"}
    action: EnumProperty(items=[("NEW", "NEW", ""), ("SAVE", "SAVE", ""), ("LOAD", "LOAD", ""), ("DELETE", "DELETE", ""), ("RESET", "RESET", "")])

    def execute(self, context):
        s = context.scene.nels
        if self.action == "NEW":
            reset_scene_config_defaults(s, keep_name=False)
            auto_detect_scene_sirens(context.scene, create_missing=True, sync_direction=True)
            return {"FINISHED"}

        if self.action == "SAVE":
            fp = os.path.join(cfg_dir(), safe_name(s.config_name) + ".json")
            with open(fp, "w", encoding="utf-8") as h:
                json.dump(settings_to_dict(s), h, indent=2)
            s.saved_config = os.path.basename(fp)
            return {"FINISHED"}

        if self.action == "RESET":
            if s.saved_config and s.saved_config != NO_SAVED_CFG:
                fp = os.path.join(cfg_dir(), s.saved_config)
                if os.path.exists(fp):
                    with open(fp, "r", encoding="utf-8") as h:
                        data = json.load(h)
                    apply_settings_dict(s, data)
                    ensure_scene_defaults(context.scene)
                    return {"FINISHED"}
            reset_scene_config_defaults(s, keep_name=True)
            auto_detect_scene_sirens(context.scene, create_missing=True, sync_direction=True)
            return {"FINISHED"}

        if self.action == "DELETE":
            if not s.saved_config or s.saved_config == NO_SAVED_CFG:
                return {"CANCELLED"}
            fp = os.path.join(cfg_dir(), s.saved_config)
            if os.path.exists(fp):
                os.remove(fp)
            choices = config_json_files()
            s.saved_config = choices[0] if choices else NO_SAVED_CFG
            return {"FINISHED"}

        if not s.saved_config or s.saved_config == NO_SAVED_CFG:
            return {"CANCELLED"}
        fp = os.path.join(cfg_dir(), s.saved_config)
        if not os.path.exists(fp):
            return {"CANCELLED"}
        with open(fp, "r", encoding="utf-8") as h:
            data = json.load(h)
        apply_settings_dict(s, data)
        ensure_scene_defaults(context.scene)
        return {"FINISHED"}


class NELS_OT_export_config(Operator):
    bl_idname = "nels.export_config"
    bl_label = "Export Configuration"

    filepath: StringProperty(subtype="FILE_PATH")
    filter_glob: StringProperty(default="*.json", options={"HIDDEN"})

    def execute(self, context):
        s = context.scene.nels
        fp = self.filepath or bpy.path.abspath(f"//{safe_name(s.config_name)}.json")
        if not fp.lower().endswith(".json"):
            fp += ".json"
        out_dir = os.path.dirname(fp)
        if out_dir:
            os.makedirs(out_dir, exist_ok=True)
        with open(fp, "w", encoding="utf-8") as h:
            json.dump(settings_to_dict(s), h, indent=2)
        self.report({"INFO"}, f"Exported configuration: {fp}")
        return {"FINISHED"}

    def invoke(self, context, event):
        s = context.scene.nels
        if not self.filepath:
            self.filepath = bpy.path.abspath(f"//{safe_name(s.config_name)}.json")
        context.window_manager.fileselect_add(self)
        return {"RUNNING_MODAL"}


class NELS_OT_import_config(Operator):
    bl_idname = "nels.import_config"
    bl_label = "Import Configuration"

    filepath: StringProperty(subtype="FILE_PATH")
    filter_glob: StringProperty(default="*.json", options={"HIDDEN"})

    def execute(self, context):
        s = context.scene.nels
        fp = self.filepath
        if not fp or not os.path.exists(fp):
            self.report({"ERROR"}, "Configuration file not found")
            return {"CANCELLED"}

        with open(fp, "r", encoding="utf-8") as h:
            data = json.load(h)
        apply_settings_dict(s, data)
        ensure_scene_defaults(context.scene)
        self.report({"INFO"}, f"Imported configuration: {fp}")
        return {"FINISHED"}

    def invoke(self, context, event):
        self.filepath = bpy.path.abspath("//")
        context.window_manager.fileselect_add(self)
        return {"RUNNING_MODAL"}



def _read_xml_value(node, tag, default=None):
    if node is None:
        return default
    child = node.find(tag)
    if child is None:
        return default
    return child.attrib.get("value", default)


def _read_bool(value, default=False):
    txt = str(value).strip().lower()
    if txt in {"true", "1", "yes"}:
        return True
    if txt in {"false", "0", "no"}:
        return False
    return bool(default)


class NELS_OT_import_carcols(Operator):
    bl_idname = "nels.import_carcols"
    bl_label = "Import carcols.meta"

    filepath: StringProperty(subtype="FILE_PATH")
    filter_glob: StringProperty(default="*.meta;*.xml", options={"HIDDEN"})

    def execute(self, context):
        s = context.scene.nels
        fp = self.filepath
        if not fp or not os.path.exists(fp):
            self.report({"ERROR"}, "carcols.meta file not found")
            return {"CANCELLED"}

        suspend_preview_updates()
        try:
            try:
                tree = ET.parse(fp)
                root = tree.getroot()
            except Exception as ex:
                self.report({"ERROR"}, f"Invalid XML: {ex}")
                return {"CANCELLED"}

            top = root.find("./Sirens/Item")
            if top is None:
                self.report({"ERROR"}, "Invalid carcols format: missing Sirens/Item")
                return {"CANCELLED"}

            if not s.patterns:
                ensure_defaults(s)
            migrate_legacy_default_patterns(s)
            ensure_off_pattern(s)
            ensure_color_defaults(s)
            ensure_other_attributes_defaults(s)
            sync_scale_factor_controls(s)

            try:
                s.vehicle_id = int(_read_xml_value(top, "id", s.vehicle_id))
            except Exception:
                pass
            nm = top.find("name")
            if nm is not None and nm.text:
                s.vehicle_name = nm.text.strip() or s.vehicle_name

            try:
                s.bpm = int(_read_xml_value(top, "sequencerBpm", s.bpm))
            except Exception:
                pass

            off_key = off_pattern_key(s)
            s.left_head = off_key
            s.right_head = off_key
            s.left_tail = off_key
            s.right_tail = off_key
            s.head_tail_initialized = True

            for tag, prop in [("leftHeadLight", "left_head"), ("rightHeadLight", "right_head"), ("leftTailLight", "left_tail"), ("rightTailLight", "right_tail")]:
                sec = top.find(tag)
                if sec is None:
                    continue
                seq = parse_u32(_read_xml_value(sec, "sequencer", 0))
                bits = int_to_bits(seq)
                setattr(s, prop, off_key if seq == 0 else normalize_pattern_key(get_or_add_pattern(s, f"Imported {tag}", "BOTH", bits)))

            sirens_node = top.find("sirens")
            if sirens_node is None:
                self.report({"ERROR"}, "Invalid carcols format: missing sirens block")
                return {"CANCELLED"}

            items = [n for n in sirens_node.findall("Item")]
            ensure_sirens(s, len(items))
            imported_scale_factor = None

            for i, it in enumerate(items):
                if i >= len(s.sirens):
                    break
                si = s.sirens[i]
                rot = it.find("rotation")
                fl = it.find("flashiness")
                rotate_flag = _read_bool(_read_xml_value(it, "rotate", "false"), False)
                si.siren_type = "ROTATOR" if rotate_flag else "FLASHER"

                seq_val = 0
                vis = "BOTH"
                if si.siren_type == "ROTATOR" and rot is not None:
                    seq_val = parse_u32(_read_xml_value(rot, "sequencer", 0))
                    vis = "ROTATOR"
                elif fl is not None:
                    seq_val = parse_u32(_read_xml_value(fl, "sequencer", 0))
                    vis = "FLASHER"

                if seq_val == 0:
                    si.pattern_source = "LIBRARY"
                    si.pattern_choice = off_key
                else:
                    matched_pattern = find_pattern_key_by_bits(s, int_to_bits(seq_val), vis)
                    if matched_pattern:
                        si.pattern_source = "LIBRARY"
                        si.pattern_choice = matched_pattern
                    else:
                        si.pattern_source = "CUSTOM"
                        si.custom_visibility = normalize_pattern_visibility(vis)
                        si.custom_value = str(seq_val)
                        si.custom_bits = int_to_bits(seq_val)

                col_hex = clean_color_value(_read_xml_value(it, "color", COLORS["GENERAL_WHITE"]))
                preset = find_color_key_by_value(s, col_hex)
                if preset != "COL_0" or col_hex == clean_color_value(COLORS["GENERAL_WHITE"]):
                    si.color_mode = "PRESET"
                    si.color_preset = preset
                else:
                    si.color_mode = "CUSTOM"
                    si.custom_color = color_to_rgb(col_hex)

                scale_factor = _read_xml_value(it, "scaleFactor", None)
                if imported_scale_factor is None and scale_factor is not None:
                    imported_scale_factor = normalize_import_scale_factor(scale_factor)
                apply_scale_to_siren(si, scale_factor)

                dir_val_txt = _read_xml_value(rot if rotate_flag and rot is not None else fl, "delta", 0.0)
                try:
                    imported_dir = float(dir_val_txt)
                except Exception:
                    imported_dir = 0.0
                preset_dir = direction_preset_from_value(imported_dir)
                if preset_dir:
                    si.direction_mode = "PRESET"
                    si.direction_preset = preset_dir
                    si.custom_direction = float(DIRECTIONS.get(preset_dir, 0.0))
                else:
                    si.direction_mode = "CUSTOM"
                    si.custom_direction = imported_dir
                si.sync_to_bpm = _read_bool(_read_xml_value(rot if rotate_flag and rot is not None else fl, "syncToBpm", "true"), True)
                si.start_delay = float(_read_xml_value(fl if fl is not None else rot, "start", 0.0) or 0.0)
                si.light_speed = float(_read_xml_value(fl if fl is not None else rot, "speed", 0.0) or 0.0)
                si.light_multiples = int(float(_read_xml_value(fl if fl is not None else rot, "multiples", 0) or 0))
                si.rotator_clockwise = _read_bool(_read_xml_value(rot, "direction", "true"), True) if rot is not None else True

                si.flash = _read_bool(_read_xml_value(it, "flash", "true"), True)
                si.light = _read_bool(_read_xml_value(it, "light", "false"), False)
                si.spot_light = _read_bool(_read_xml_value(it, "spotLight", "false"), False)
                si.cast_shadows = _read_bool(_read_xml_value(it, "castShadows", "false"), False)
                si.light_group = int(float(_read_xml_value(it, "lightGroup", 1) or 1))

                cor = it.find("corona")
                if cor is not None:
                    si.corona_intensity = float(_read_xml_value(cor, "intensity", si.corona_intensity) or si.corona_intensity)
                    si.corona_size = float(_read_xml_value(cor, "size", si.corona_size) or si.corona_size)
                    si.corona_pull = float(_read_xml_value(cor, "pull", si.corona_pull) or si.corona_pull)
                    si.corona_face_camera = _read_bool(_read_xml_value(cor, "faceCamera", si.corona_face_camera), si.corona_face_camera)

                update_rotator_settings(si, context)

            if imported_scale_factor is not None:
                apply_scale_to_settings(s, imported_scale_factor)

            off_key = off_pattern_key(s)
            s.left_head = normalize_pattern_key(s.left_head) if s.left_head else off_key
            s.right_head = normalize_pattern_key(s.right_head) if s.right_head else off_key
            s.left_tail = normalize_pattern_key(s.left_tail) if s.left_tail else off_key
            s.right_tail = normalize_pattern_key(s.right_tail) if s.right_tail else off_key

            for i, si in enumerate(s.sirens, start=1):
                si.index = i
                si.name = f"siren{i}"
                si.color_preset = normalize_color_key(si.color_preset)
                if getattr(si, "pattern_source", "LIBRARY") != "CUSTOM":
                    si.pattern_choice = normalize_pattern_key(si.pattern_choice or off_key)
                if si.siren_type == "ROTATOR":
                    update_rotator_settings(si, context)
                sync_siren_selector_controls(si)

            if not s.saved_config:
                s.saved_config = NO_SAVED_CFG
            clear_missing_associations(context.scene)
            try:
                current_id = int(s.vehicle_id)
            except Exception:
                current_id = 0
            if current_id <= 0:
                s.vehicle_id = generate_siren_id(s.vehicle_name)
        finally:
            resume_preview_updates()

        auto_detect_scene_sirens(context.scene, create_missing=False, sync_direction=False)
        apply_all_siren_directions(context.scene)
        clear_preview_keyframes(context.scene, list(s.sirens))
        s.preview_generated = False
        s.auto_timeline_pending = False
        stop_timeline_playback()
        s.preview_time_origin = _time.time()
        s.preview_last_step = -1
        s.preview_animating_until = 0.0
        s.preview_refresh_pending = False
        s.preview_dirty = True
        refresh_siren_preview_cache(context.scene)
        tag_all_ui_redraw()
        self.report({"INFO"}, f"Imported carcols: {fp}")
        return {"FINISHED"}

    def invoke(self, context, event):
        self.filepath = bpy.path.abspath("//")
        context.window_manager.fileselect_add(self)
        return {"RUNNING_MODAL"}


class NELS_MT_siren_actions(Menu):
    bl_label = "Siren Actions"
    bl_idname = "NELS_MT_siren_actions"

    def draw(self, context):
        l = self.layout
        s = getattr(context.scene, "nels", None)
        o = l.operator("nels.set_siren_count", text="Add 20 Sirens", icon="ADD")
        o.count = 20
        o = l.operator("nels.set_siren_count", text="Add 32 Sirens", icon="ADD")
        o.count = 32
        if s and len(s.sirens) == 20:
            o = l.operator("nels.set_siren_count", text="Add 12 Additional (21-32)", icon="ADD")
            o.count = 32
        if s and len(s.sirens) > 20:
            o = l.operator("nels.set_siren_count", text="Remove Sirens 21-32", icon="REMOVE")
            o.count = 20
        o = l.operator("nels.set_siren_count", text="Remove All Sirens", icon="TRASH")
        o.count = 0
        l.separator()
        l.operator("nels.duplicate_siren", text="Duplicate Siren", icon="DUPLICATE")
        l.operator("nels.swap_sirens", text="Swap Two Sirens", icon="FILE_REFRESH")

class NELS_MT_config_actions(Menu):
    bl_label = "Configuration Actions"
    bl_idname = "NELS_MT_config_actions"

    def draw(self, context):
        l = self.layout
        o = l.operator("nels.new_save_load", text="Save Configuration", icon="FILE_TICK")
        o.action = "SAVE"
        o = l.operator("nels.new_save_load", text="Reset Current to Default", icon="LOOP_BACK")
        o.action = "RESET"
        o = l.operator("nels.new_save_load", text="Delete Saved Configuration", icon="TRASH")
        o.action = "DELETE"
        l.operator("nels.export_config", text="Export Configuration", icon="EXPORT")
        l.operator("nels.import_config", text="Import Configuration", icon="IMPORT")
        l.operator("nels.import_carcols", text="Import carcols.meta", icon="FILEBROWSER")


class NELS_OT_choose_parent_skeleton(Operator):
    bl_idname = "nels.choose_parent_skeleton"
    bl_label = "Select Parent Skeleton"
    bl_options = {"REGISTER", "UNDO"}

    next_action: EnumProperty(items=[("BONE", "BONE", "")], default="BONE")
    skeleton_name: EnumProperty(items=scene_armature_items)

    def invoke(self, context, event):
        s = context.scene.nels
        arm = bpy.data.objects.get(s.armature_name) if s.armature_name else None
        if arm and arm.type == "ARMATURE":
            self.skeleton_name = arm.name
        else:
            arms = sorted({obj.name for obj in context.scene.objects if obj.type == "ARMATURE"}, key=str.lower)
            if not arms:
                msg = "Warning: Select or create a Parent Skeleton before placing a siren bone"
                s.status_message = msg
                self.report({"WARNING"}, msg)
                return {"CANCELLED"}
            self.skeleton_name = arms[0]
        return context.window_manager.invoke_props_dialog(self, width=360)

    def draw(self, context):
        l = self.layout
        l.label(text="Choose the armature that will receive the siren bone.")
        l.prop(self, "skeleton_name", text="Parent Skeleton")

    def execute(self, context):
        s = context.scene.nels
        if self.skeleton_name == "__NONE__":
            msg = "Warning: No armatures were found in the current scene"
            s.status_message = msg
            self.report({"WARNING"}, msg)
            return {"CANCELLED"}
        s.armature_name = self.skeleton_name
        s.status_message = f"Parent Skeleton set to {self.skeleton_name}"
        if self.next_action:
            return bpy.ops.nels.link_bone(action=self.next_action)
        return {"FINISHED"}


class NELS_OT_link_bone(Operator):
    bl_idname = "nels.link_bone"
    bl_label = "Link Object/Bone"
    bl_options = {"REGISTER", "UNDO"}
    action: EnumProperty(items=[("MARK", "MARK", ""), ("BONE", "BONE", ""), ("ORIGIN", "ORIGIN", "")])

    def execute(self, context):
        s = context.scene.nels
        if not s.sirens:
            return {"CANCELLED"}
        si = s.sirens[s.active_siren]
        obj = context.active_object

        if self.action == "MARK":
            if not obj:
                return {"CANCELLED"}
            old_index = infer_siren_index_from_hierarchy(obj, fallback=infer_siren_index_from_object(obj, s=s) or si.index) or si.index
            retarget_siren_hierarchy(obj, old_index, si.index, detach_root=True)
            nm = f"siren{si.index}"
            obj.name = nm
            si.object_name = nm
            si.bone_name = ""
            si.anchor_name = ""
            si.enabled = True
            _store_rest_loc(obj, force=True)
            s.status_message = f"Assigned {nm} and retargeted linked mesh data"
            return {"FINISHED"}

        if self.action == "ORIGIN":
            sobj = siren_obj(si)
            if not sobj:
                msg = f"Warning: Assign a siren object to siren{si.index} before copying its origin"
                s.status_message = msg
                self.report({"WARNING"}, msg)
                return {"CANCELLED"}

            reference = pick_reference_object(context, si)
            if not reference:
                msg = "Warning: Select a separate helper object to copy its origin to the active siren"
                s.status_message = msg
                self.report({"WARNING"}, msg)
                return {"CANCELLED"}

            ok, msg = set_object_origin_from_reference(sobj, reference)
            s.status_message = msg
            if ok:
                si.anchor_name = reference.name
                self.report({"INFO"}, msg)
                return {"FINISHED"}
            self.report({"ERROR"}, msg)
            return {"CANCELLED"}

        arm = bpy.data.objects.get(s.armature_name) if s.armature_name else None
        if not arm or arm.type != "ARMATURE":
            scene_arms = sorted({o.name for o in context.scene.objects if o.type == "ARMATURE"}, key=str.lower)
            if not scene_arms:
                msg = "Warning: Select or create a Parent Skeleton before placing a siren bone"
                s.status_message = msg
                self.report({"WARNING"}, msg)
                return {"CANCELLED"}
            if len(scene_arms) == 1:
                s.armature_name = scene_arms[0]
                arm = bpy.data.objects.get(s.armature_name)
                s.status_message = f"Parent Skeleton set to {s.armature_name}"
            else:
                bpy.ops.nels.choose_parent_skeleton('INVOKE_DEFAULT', next_action=self.action)
                return {"FINISHED"}

        sobj = siren_obj(si)
        if not sobj:
            msg = f"Warning: Assign a siren object to siren{si.index} before placing its bone"
            s.status_message = msg
            self.report({"WARNING"}, msg)
            return {"CANCELLED"}

        anchor = pick_anchor_object(context, arm, si)
        if not anchor:
            anchor = sobj

        active = context.view_layer.objects.active
        mode = context.mode
        try:
            if mode != "OBJECT":
                bpy.ops.object.mode_set(mode="OBJECT")
            bpy.ops.object.select_all(action="DESELECT")
            arm.select_set(True)
            context.view_layer.objects.active = arm
            bpy.ops.object.mode_set(mode="EDIT")
            bn = f"siren{si.index}"
            eb = arm.data.edit_bones.get(bn) or arm.data.edit_bones.new(bn)
            head = arm.matrix_world.inverted() @ anchor.matrix_world.translation
            eb.head = head
            eb.tail = head + Vector((0.0, 0.05, 0.0))
            bpy.ops.object.mode_set(mode="OBJECT")
            wm = sobj.matrix_world.copy()
            sobj.parent = arm
            sobj.parent_type = "BONE"
            sobj.parent_bone = bn
            sobj.matrix_world = wm
            si.bone_name = bn
            si.anchor_name = anchor.name
            _store_rest_loc(sobj, force=True)
            s.status_message = f"Placed bone {bn} on {arm.name}"
        finally:
            if active and active.name in bpy.data.objects:
                context.view_layer.objects.active = active
            if mode != "OBJECT" and context.mode == "OBJECT":
                try:
                    bpy.ops.object.mode_set(mode=mode)
                except Exception:
                    pass
        return {"FINISHED"}
        if not s.armature_name:
            return {"CANCELLED"}
        arm = bpy.data.objects.get(s.armature_name)
        sobj = siren_obj(si)
        anchor = pick_anchor_object(context, arm, si)
        if not arm or arm.type != "ARMATURE" or not sobj or not anchor:
            return {"CANCELLED"}

        active = context.view_layer.objects.active
        mode = context.mode
        try:
            if mode != "OBJECT":
                bpy.ops.object.mode_set(mode="OBJECT")
            bpy.ops.object.select_all(action="DESELECT")
            arm.select_set(True)
            context.view_layer.objects.active = arm
            bpy.ops.object.mode_set(mode="EDIT")
            bn = f"siren{si.index}"
            eb = arm.data.edit_bones.get(bn) or arm.data.edit_bones.new(bn)
            head = arm.matrix_world.inverted() @ anchor.matrix_world.translation
            eb.head = head
            eb.tail = head + Vector((0.0, 0.05, 0.0))
            bpy.ops.object.mode_set(mode="OBJECT")
            wm = sobj.matrix_world.copy()
            sobj.parent = arm
            sobj.parent_type = "BONE"
            sobj.parent_bone = bn
            sobj.matrix_world = wm
            si.bone_name = bn
            si.anchor_name = anchor.name
            _store_rest_loc(sobj, force=True)
        finally:
            if active and active.name in bpy.data.objects:
                context.view_layer.objects.active = active
            if mode != "OBJECT" and context.mode == "OBJECT":
                try:
                    bpy.ops.object.mode_set(mode=mode)
                except Exception:
                    pass
        return {"FINISHED"}


class NELS_OT_origin_to_selection(Operator):
    bl_idname = "nels.origin_to_selection"
    bl_label = "Set Origin to Selection"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        scene = getattr(context, "scene", None)
        s = getattr(scene, "nels", None) if scene else None
        obj = getattr(context, "active_object", None)
        if not obj or getattr(obj, "type", "") != "MESH":
            msg = "Select a mesh in Edit Mode first"
            if s:
                s.status_message = msg
            self.report({"WARNING"}, msg)
            return {"CANCELLED"}
        if getattr(context, "mode", "") != "EDIT_MESH" or getattr(obj, "mode", "") != "EDIT":
            msg = "Switch the active mesh to Edit Mode first"
            if s:
                s.status_message = msg
            self.report({"WARNING"}, msg)
            return {"CANCELLED"}

        center, msg = edit_selection_local_center(obj, context)
        if center is None:
            if s:
                s.status_message = msg
            self.report({"WARNING"}, msg)
            return {"CANCELLED"}

        active = getattr(context.view_layer, "objects", None).active if getattr(context, "view_layer", None) else obj
        try:
            bpy.ops.object.mode_set(mode="OBJECT")
            ok, msg = set_object_origin_to_local_point(obj, center)
        finally:
            try:
                if active and active.name in bpy.data.objects:
                    context.view_layer.objects.active = active
            except Exception:
                pass
            if getattr(context, "mode", "") == "OBJECT":
                try:
                    bpy.ops.object.mode_set(mode="EDIT")
                except Exception:
                    pass

        if s:
            s.status_message = msg
        if ok:
            self.report({"INFO"}, msg)
            return {"FINISHED"}
        self.report({"ERROR"}, msg)
        return {"CANCELLED"}


class NELS_OT_origins_to_bones(Operator):
    bl_idname = "nels.origins_to_bones"
    bl_label = "Set Selected Origins to Bones"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        scene = getattr(context, "scene", None)
        s = getattr(scene, "nels", None) if scene else None
        if getattr(context, "mode", "") != "OBJECT":
            msg = "Switch to Object Mode before moving selected origins to bones"
            if s:
                s.status_message = msg
            self.report({"WARNING"}, msg)
            return {"CANCELLED"}

        selected = [obj for obj in getattr(context, "selected_objects", []) if obj and getattr(obj, "type", "") == "MESH"]
        if not selected:
            msg = "Select one or more mesh objects first"
            if s:
                s.status_message = msg
            self.report({"WARNING"}, msg)
            return {"CANCELLED"}

        moved = 0
        skipped = []
        for obj in selected:
            world_point, msg = linked_bone_world_location(scene, obj, s=s)
            if world_point is None:
                skipped.append(msg or f"No linked bone was found for {obj.name}")
                continue
            ok, result = set_object_origin_to_world_point(obj, world_point)
            if ok:
                moved += 1
            else:
                skipped.append(result)

        if moved:
            msg = f"Set {moved} selected object origin{'s' if moved != 1 else ''} to linked bone locations"
            if skipped:
                msg += f" ({len(skipped)} skipped)"
            if s:
                s.status_message = msg
            self.report({"INFO"}, msg)
            return {"FINISHED"}

        msg = skipped[0] if skipped else "No selected mesh objects could be matched to linked bones"
        if s:
            s.status_message = msg
        self.report({"WARNING"}, msg)
        return {"CANCELLED"}



class NELS_OT_bones_to_origins(Operator):
    bl_idname = "nels.bones_to_origins"
    bl_label = "Move Linked Bones to Origins"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        scene = getattr(context, "scene", None)
        s = getattr(scene, "nels", None) if scene else None
        if getattr(context, "mode", "OBJECT") != "OBJECT":
            msg = "Switch to Object Mode before moving linked bones"
            if s:
                s.status_message = msg
            self.report({"WARNING"}, msg)
            return {"CANCELLED"}

        selected = [obj for obj in getattr(context, "selected_objects", []) if obj and getattr(obj, "type", "") == "MESH"]
        if not selected:
            msg = "Select one or more mesh objects first"
            if s:
                s.status_message = msg
            self.report({"WARNING"}, msg)
            return {"CANCELLED"}

        moved = 0
        skipped = []
        seen_bones = set()
        for obj in selected:
            arm, pb, msg = linked_bone_target(scene, obj, s=s)
            if not arm or not pb:
                skipped.append(msg or f"No linked bone was found for {obj.name}")
                continue
            key = (arm.name, pb.name)
            if key in seen_bones:
                continue
            seen_bones.add(key)
            ok, result = move_linked_bone_to_world_point(scene, obj, obj.matrix_world.translation, s=s, preserve_direction=True)
            if ok:
                moved += 1
            else:
                skipped.append(result)

        if moved:
            msg = f"Moved {moved} linked bone{'s' if moved != 1 else ''} to selected mesh origins"
            if skipped:
                msg += f" ({len(skipped)} skipped)"
            if s:
                s.status_message = msg
            self.report({"INFO"}, msg)
            return {"FINISHED"}

        msg = skipped[0] if skipped else "No linked bones were found for the selected mesh objects"
        if s:
            s.status_message = msg
        self.report({"WARNING"}, msg)
        return {"CANCELLED"}


class NELS_OT_match_origin_to_object(Operator):
    bl_idname = "nels.match_origin_to_object"
    bl_label = "Match Origin to Object"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        scene = getattr(context, "scene", None)
        s = getattr(scene, "nels", None) if scene else None
        if not s or not getattr(s, "sirens", None):
            self.report({"ERROR"}, "Please add Sirens to configure them.")
            return {"CANCELLED"}

        idx = max(0, min(int(getattr(s, "active_siren", 0) or 0), len(s.sirens) - 1))
        si = s.sirens[idx] if getattr(s, "sirens", None) else None
        if not si:
            self.report({"WARNING"}, "No siren could be resolved")
            return {"CANCELLED"}
            return {"CANCELLED"}

        sobj = siren_obj(si)
        if not sobj:
            msg = f"Warning: Assign a siren object to siren{si.index} before matching its origin"
            s.status_message = msg
            self.report({"WARNING"}, msg)
            return {"CANCELLED"}

        ref_name = str(getattr(s, "tool_origin_object", "") or "")
        reference = bpy.data.objects.get(ref_name) if ref_name else None
        if reference is None:
            reference = pick_reference_object(context, si)
        if reference is None:
            msg = "Select or pick an object to match the siren origin"
            s.status_message = msg
            self.report({"WARNING"}, msg)
            return {"CANCELLED"}
        if reference == sobj:
            msg = "Choose a separate helper object"
            s.status_message = msg
            self.report({"WARNING"}, msg)
            return {"CANCELLED"}

        ok, msg = set_object_origin_from_reference(sobj, reference)
        s.tool_origin_object = ""
        s.status_message = msg
        if ok:
            si.anchor_name = reference.name
            self.report({"INFO"}, msg)
            return {"FINISHED"}
        self.report({"ERROR"}, msg)
        return {"CANCELLED"}


class NELS_OT_select_linked_siren(Operator):
    bl_idname = "nels.select_linked_siren"
    bl_label = "Select Linked Siren"
    bl_options = {"REGISTER", "UNDO"}

    siren_index: IntProperty(default=0, min=0)

    def execute(self, context):
        scene = getattr(context, "scene", None)
        s = getattr(scene, "nels", None) if scene else None
        if not s or not getattr(s, "sirens", None):
            msg = "Please add Sirens to configure them."
            self.report({"WARNING"}, msg)
            return {"CANCELLED"}

        requested = int(getattr(self, "siren_index", 0) or 0)
        if 1 <= requested <= len(s.sirens):
            si = s.sirens[requested - 1]
        else:
            si = resolve_context_siren(scene, s, require_linked=False)
            if not si:
                idx = max(0, min(int(getattr(s, "active_siren", 0) or 0), len(s.sirens) - 1))
                si = s.sirens[idx]

        s.active_siren = max(0, int(getattr(si, "index", 1) or 1) - 1)
        try:
            s.tool_working_siren = f"siren{int(getattr(si, 'index', 1) or 1)}"
        except Exception:
            pass

        obj = siren_obj(si)
        arm, pb = siren_pose_bone(scene, si)
        if not obj and not pb:
            msg = f"Siren {si.index} has no linked mesh or bone to select"
            s.status_message = msg
            self.report({"WARNING"}, msg)
            return {"CANCELLED"}

        try:
            if getattr(context, "mode", "OBJECT") != "OBJECT":
                bpy.ops.object.mode_set(mode="OBJECT")
        except Exception:
            pass

        try:
            bpy.ops.object.select_all(action="DESELECT")
        except Exception:
            pass

        msg = ""
        if obj and obj.name in bpy.data.objects:
            try:
                obj.select_set(True)
                context.view_layer.objects.active = obj
                msg = f"Selected {obj.name}"
            except Exception:
                pass
        if (not msg) and arm and pb and arm.name in bpy.data.objects:
            try:
                arm.select_set(True)
                context.view_layer.objects.active = arm
                bone = arm.data.bones.get(pb.name)
                if bone is not None:
                    arm.data.bones.active = bone
                msg = f"Selected {pb.name} on {arm.name}"
            except Exception:
                pass

        if not msg:
            msg = f"Could not select linked data for siren {si.index}"
            s.status_message = msg
            self.report({"WARNING"}, msg)
            return {"CANCELLED"}

        s.status_message = msg
        self.report({"INFO"}, msg)
        return {"FINISHED"}

class NELS_OT_move_bone_to_selected(Operator):
    bl_idname = "nels.move_bone_to_selected"
    bl_label = "Move Bone to Selected"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        scene = getattr(context, "scene", None)
        s = getattr(scene, "nels", None) if scene else None
        if not s or not getattr(s, "sirens", None):
            self.report({"ERROR"}, "Please add Sirens to configure them.")
            return {"CANCELLED"}

        si = resolve_context_siren(scene, s, require_linked=True)
        if not si:
            msg = "No linked siren could be resolved from the current selection"
            if s:
                s.status_message = msg
            self.report({"WARNING"}, msg)
            return {"CANCELLED"}

        reference = pick_any_reference_object(context)
        if not reference:
            msg = "Select a helper object first"
            if s:
                s.status_message = msg
            self.report({"WARNING"}, msg)
            return {"CANCELLED"}

        ok, msg = move_siren_bone_to_world_point(scene, si, reference.matrix_world.translation, preserve_direction=True)
        if s:
            s.status_message = msg
        if ok:
            si.anchor_name = reference.name
            self.report({"INFO"}, msg)
            return {"FINISHED"}
        self.report({"WARNING"}, msg)
        return {"CANCELLED"}


class NELS_OT_pick_selected_link_target(Operator):
    bl_idname = "nels.pick_selected_link_target"
    bl_label = "Use Selected Link Target"
    bl_options = {"REGISTER", "UNDO"}

    target: EnumProperty(items=[
        ("SIREN_MESH", "SIREN_MESH", ""),
        ("SIREN_BONE", "SIREN_BONE", ""),
        ("BODY_MESH", "BODY_MESH", ""),
        ("BODY_BONE", "BODY_BONE", ""),
        ("TOOL_ORIGIN_OBJECT", "TOOL_ORIGIN_OBJECT", ""),
    ])
    opening_key: StringProperty(default="")

    def execute(self, context):
        scene = getattr(context, "scene", None)
        s = getattr(scene, "nels", None) if scene else None
        if not s:
            self.report({"ERROR"}, "No scene settings available")
            return {"CANCELLED"}

        if self.target == "TOOL_ORIGIN_OBJECT":
            ref = pick_any_reference_object(context)
            if not ref:
                msg = "Select an object first"
                s.status_message = msg
                self.report({"WARNING"}, msg)
                return {"CANCELLED"}
            s.tool_origin_object = ref.name
            msg = f"Picked {ref.name} as the origin helper"
            s.status_message = msg
            self.report({"INFO"}, msg)
            return {"FINISHED"}

        is_siren = self.target.startswith("SIREN")
        wants_bone = self.target.endswith("BONE")

        if is_siren:
            if not getattr(s, "sirens", None):
                self.report({"ERROR"}, "Please add Sirens to configure them.")
                return {"CANCELLED"}
            target = resolve_context_siren(scene, s, require_linked=False)
            if not target:
                idx = max(0, min(int(getattr(s, "active_siren", 0) or 0), len(s.sirens) - 1))
                target = s.sirens[idx]
        else:
            target = body_opening_by_key(s, self.opening_key) if self.opening_key else active_body_opening(s)
            if not target:
                self.report({"ERROR"}, "No body openings are available to configure yet.")
                return {"CANCELLED"}

        if wants_bone:
            arm = selected_armature_from_context(context, scene=scene, s=s)
            bone_name = selected_bone_name_from_context(context, arm=arm)
            if not bone_name:
                msg = "Select a bone on the parent skeleton, or select a mesh already parented to the target bone"
                s.status_message = msg
                self.report({"WARNING"}, msg)
                return {"CANCELLED"}
            if arm:
                s.armature_name = arm.name
            target.bone_name = bone_name
            label = f"bone {bone_name}"
        else:
            mesh_name = selected_mesh_name_from_context(context)
            if not mesh_name:
                msg = "Select a mesh object first"
                s.status_message = msg
                self.report({"WARNING"}, msg)
                return {"CANCELLED"}
            target.object_name = mesh_name
            label = mesh_name

        owner = f"siren{target.index}" if is_siren else str(getattr(target, "name", "body opening") or "body opening")
        msg = f"Assigned {label} to {owner}"
        s.status_message = msg
        self.report({"INFO"}, msg)
        return {"FINISHED"}


class NELS_OT_body_opening_link(Operator):
    bl_idname = "nels.body_opening_link"
    bl_label = "Body Opening Link"
    bl_options = {"REGISTER", "UNDO"}

    action: EnumProperty(items=[("MARK", "MARK", ""), ("ORIGIN", "ORIGIN", ""), ("BONE", "BONE", "")])
    opening_key: StringProperty(default="")

    def execute(self, context):
        scene = context.scene
        s = getattr(scene, "nels", None)
        opening = body_opening_by_key(s, self.opening_key) if self.opening_key else active_body_opening(s)
        if not s or not opening:
            self.report({"ERROR"}, "No body openings are available to configure yet.")
            return {"CANCELLED"}

        if self.action == "MARK":
            obj = getattr(context, "active_object", None)
            if not obj or getattr(obj, "type", "") != "MESH":
                msg = "Select a mesh object first"
                s.status_message = msg
                self.report({"WARNING"}, msg)
                return {"CANCELLED"}
            opening.object_name = obj.name
            s.status_message = f"Assigned {obj.name} to {opening.name}"
            self.report({"INFO"}, s.status_message)
            return {"FINISHED"}

        if self.action == "ORIGIN":
            obj = body_opening_obj(opening)
            if not obj:
                msg = f"Assign a mesh to {opening.name} before moving its origin"
                s.status_message = msg
                self.report({"WARNING"}, msg)
                return {"CANCELLED"}
            reference = pick_body_opening_reference(context, opening)
            if not reference:
                msg = "Select a helper object to copy its origin"
                s.status_message = msg
                self.report({"WARNING"}, msg)
                return {"CANCELLED"}
            ok, msg = set_object_origin_from_reference(obj, reference)
            s.status_message = msg
            if ok:
                opening.anchor_name = reference.name
                self.report({"INFO"}, msg)
                return {"FINISHED"}
            self.report({"ERROR"}, msg)
            return {"CANCELLED"}

        arm = bpy.data.objects.get(s.armature_name) if getattr(s, "armature_name", "") else None
        if not arm or getattr(arm, "type", "") != "ARMATURE":
            scene_arms = sorted({obj.name for obj in scene.objects if getattr(obj, "type", "") == "ARMATURE"}, key=str.lower)
            if len(scene_arms) == 1:
                s.armature_name = scene_arms[0]
                arm = bpy.data.objects.get(s.armature_name)
            else:
                msg = "Select a Parent Skeleton before placing a body opening bone"
                s.status_message = msg
                self.report({"WARNING"}, msg)
                return {"CANCELLED"}

        obj = body_opening_obj(opening)
        if not obj:
            msg = f"Assign a mesh to {opening.name} before placing its bone"
            s.status_message = msg
            self.report({"WARNING"}, msg)
            return {"CANCELLED"}

        anchor = pick_body_opening_reference(context, opening) or obj
        active = context.view_layer.objects.active
        mode = context.mode
        bone_name = str(getattr(opening, "key", "") or getattr(opening, "bone_name", "") or "body_opening")
        try:
            if mode != "OBJECT":
                bpy.ops.object.mode_set(mode="OBJECT")
            bpy.ops.object.select_all(action="DESELECT")
            arm.select_set(True)
            context.view_layer.objects.active = arm
            bpy.ops.object.mode_set(mode="EDIT")
            eb = arm.data.edit_bones.get(bone_name) or arm.data.edit_bones.new(bone_name)
            head = arm.matrix_world.inverted() @ anchor.matrix_world.translation
            eb.head = head
            eb.tail = head + Vector((0.0, 0.05, 0.0))
            bpy.ops.object.mode_set(mode="OBJECT")
            world_matrix = obj.matrix_world.copy()
            obj.parent = arm
            obj.parent_type = "BONE"
            obj.parent_bone = bone_name
            obj.matrix_world = world_matrix
            opening.bone_name = bone_name
            opening.anchor_name = anchor.name
            _store_rest_loc(obj, force=True)
            s.status_message = f"Placed bone {bone_name} on {arm.name}"
            self.report({"INFO"}, s.status_message)
            return {"FINISHED"}
        finally:
            try:
                if active and active.name in bpy.data.objects:
                    context.view_layer.objects.active = active
            except Exception:
                pass
            if mode != "OBJECT" and context.mode == "OBJECT":
                try:
                    bpy.ops.object.mode_set(mode=mode)
                except Exception:
                    pass


class NELS_OT_body_opening_state(Operator):
    bl_idname = "nels.body_opening_state"
    bl_label = "Body Opening State"
    bl_options = {"REGISTER", "UNDO"}

    action: EnumProperty(items=[("CAPTURE_CLOSED", "CAPTURE_CLOSED", ""), ("CAPTURE_OPEN", "CAPTURE_OPEN", ""), ("APPLY_CLOSED", "APPLY_CLOSED", ""), ("APPLY_OPEN", "APPLY_OPEN", "")])
    opening_key: StringProperty(default="")

    def execute(self, context):
        scene = context.scene
        s = getattr(scene, "nels", None)
        opening = body_opening_by_key(s, self.opening_key) if self.opening_key else active_body_opening(s)
        if not s or not opening:
            self.report({"ERROR"}, "No body openings are available to configure yet.")
            return {"CANCELLED"}

        if self.action.startswith("CAPTURE_"):
            state = self.action.split("_", 1)[1]
            ok, msg = capture_body_opening_state(scene, opening, state)
        else:
            stop_timeline_playback()
            state = self.action.split("_", 1)[1]
            ok, msg = apply_body_opening_state(scene, opening, state)

        s.status_message = msg
        if ok:
            self.report({"INFO"}, msg)
            return {"FINISHED"}
        self.report({"WARNING"}, msg)
        return {"CANCELLED"}


class NELS_OT_sim(Operator):
    bl_idname = "nels.sim"
    bl_label = "Simulate"
    bl_options = {"REGISTER", "UNDO"}
    mode: EnumProperty(items=[("ON", "ON", ""), ("OFF", "OFF", "")])
    all: BoolProperty(default=False)

    def execute(self, context):
        scene = context.scene
        s = scene.nels
        sirens = list(s.sirens) if self.all else ([s.sirens[s.active_siren]] if s.sirens else [])
        if not sirens:
            return {"CANCELLED"}
        clear_preview_keyframes(scene, sirens)
        s.preview_generated = False
        s.preview_dirty = False
        s.auto_timeline_pending = False
        if self.mode == "OFF":
            stop_timeline_playback()
        for si in sirens:
            apply_sim_state(scene, s, si, self.mode)
        try:
            bpy.context.view_layer.update()
        except Exception:
            pass
        return {"FINISHED"}


class NELS_OT_set_siren_scale_state(Operator):
    bl_idname = "nels.set_siren_scale_state"
    bl_label = "Set Siren Scale"
    bl_options = {"REGISTER", "UNDO"}

    mode: EnumProperty(items=[("ON", "On", ""), ("OFF", "Off", "")], default="ON")

    def execute(self, context):
        scene = context.scene
        s = getattr(scene, "nels", None)
        if not s or not s.sirens:
            self.report({"ERROR"}, "Please add Sirens to configure them.")
            return {"CANCELLED"}

        si = resolve_context_siren(scene, s, require_linked=True)
        if not si:
            self.report({"ERROR"}, "No linked siren could be resolved from the current selection")
            return {"CANCELLED"}

        ok, msg = bake_siren_scale_state(scene, s, si, self.mode)
        if not ok:
            self.report({"ERROR"}, msg)
            return {"CANCELLED"}
        self.report({"INFO"}, msg)
        return {"FINISHED"}


class NELS_OT_reset_siren_default_state(Operator):
    bl_idname = "nels.reset_siren_default_state"
    bl_label = "Reset Siren to Default"
    bl_options = {"REGISTER", "UNDO"}

    all: BoolProperty(default=False)

    def execute(self, context):
        scene = context.scene
        s = getattr(scene, "nels", None)
        if not s or not s.sirens:
            self.report({"ERROR"}, "Please add Sirens to configure them.")
            return {"CANCELLED"}

        sirens = list(s.sirens) if self.all else []
        if not self.all:
            si = resolve_context_siren(scene, s, require_linked=False)
            if not si:
                self.report({"ERROR"}, "No siren could be resolved from the current selection")
                return {"CANCELLED"}
            sirens = [si]

        clear_preview_keyframes(scene, sirens)
        restored = 0
        for si in sirens:
            restored += restore_siren_default_state(scene, si)
        s.preview_generated = False
        s.preview_dirty = False
        if hasattr(scene, "view_layers"):
            try:
                bpy.context.view_layer.update()
            except Exception:
                pass
        self.report({"INFO"}, f"Reset {len(sirens)} siren(s) to default state")
        return {"FINISHED"}


def _clear_action_animation(action, path_predicate):
    if not action:
        return 0

    removed = 0
    for fc in _iter_action_fcurves(action):
        data_path = str(getattr(fc, "data_path", ""))
        if not path_predicate(data_path):
            continue

        try:
            points = getattr(fc, "keyframe_points", None)
            if points is not None:
                removed += len(points)
                points.clear()
        except Exception:
            try:
                points = getattr(fc, "keyframe_points", None)
                if points is not None:
                    for kp in list(points):
                        points.remove(kp)
                        removed += 1
            except Exception:
                pass

        try:
            for m in list(fc.modifiers):
                if m.type == "CYCLES":
                    fc.modifiers.remove(m)
        except Exception:
            pass

        try:
            fc.update()
        except Exception:
            pass

    return removed
def clear_preview_keyframes(scene, sirens, frame_start=None, frame_end=None):
    cleared = 0

    for si in sirens:
        o = siren_obj(si)
        if o:
            cleared += _clear_action_animation(
                getattr(getattr(o, "animation_data", None), "action", None),
                lambda p: p in {"location", "rotation_euler", "scale"},
            )

        if getattr(si, "siren_type", "FLASHER") == "ROTATOR":
            for target in rotator_preview_targets(si):
                if not target or target == o:
                    continue
                cleared += _clear_action_animation(
                    getattr(getattr(target, "animation_data", None), "action", None),
                    lambda p: p == "rotation_euler",
                )

        arm, pb = siren_pose_bone(scene, si)
        if arm and pb:
            target_bones = {pb.name}
            if getattr(si, "siren_type", "FLASHER") == "ROTATOR":
                target_bones.update(child.name for child in rotator_preview_pose_bones(scene, si))
            cleared += _clear_action_animation(
                getattr(getattr(arm, "animation_data", None), "action", None),
                lambda p, target_bones=target_bones: any(
                    p.startswith(f'pose.bones["{bone}"].') and (p.endswith(".location") or p.endswith(".rotation_euler") or p.endswith(".scale"))
                    for bone in target_bones
                ),
            )

    return cleared


def generate_timeline_preview(scene, s, sirens):
    st = int(scene.frame_start)
    fps = max(1.0, scene.render.fps / max(scene.render.fps_base, 0.0001))
    step = preview_step_frames(s.bpm, fps)
    used = 0
    cycle_end = float(st)

    for si in sirens:
        if not siren_is_active(si):
            continue

        delay_frames = start_delay_frames(s.bpm, fps, si)

        if getattr(si, "siren_type", "FLASHER") == "ROTATOR":
            cycle_frames = rotator_cycle_frames(s.bpm, fps, si)
            cycle_end = max(cycle_end, st + delay_frames + cycle_frames)

            # Keep rotators statically shown and animate only their rotation channels.
            # This avoids scale/location keyframe churn on the full siren hierarchy.
            apply_sim_state(scene, s, si, "ON", turns=0.0, keyframe_frame=None)
            apply_rotator_preview_targets(si, turns=0.0, keyframe_frame=st)
            apply_rotator_preview_pose_targets(scene, si, turns=0.0, keyframe_frame=st)
            if delay_frames > 0.0:
                apply_rotator_preview_targets(si, turns=0.0, keyframe_frame=st + delay_frames)
                apply_rotator_preview_pose_targets(scene, si, turns=0.0, keyframe_frame=st + delay_frames)
            apply_rotator_preview_targets(si, turns=1.0, keyframe_frame=st + delay_frames + cycle_frames)
            apply_rotator_preview_pose_targets(scene, si, turns=1.0, keyframe_frame=st + delay_frames + cycle_frames)
        else:
            bits, _, _ = pattern_triplet(s, si)
            bit_count = max(1, len(bits))
            cycle_end = max(cycle_end, st + delay_frames + (bit_count * step))
            if delay_frames > 0.0:
                apply_sim_state(scene, s, si, "OFF", turns=0.0, keyframe_frame=st)
            first_mode = "ON" if bits[0] == "1" else "OFF"
            apply_sim_state(scene, s, si, first_mode, turns=0.0, keyframe_frame=st + delay_frames)
            for i in range(1, bit_count):
                if bits[i] == bits[i - 1]:
                    continue
                fr = st + delay_frames + (i * step)
                mode = "ON" if bits[i] == "1" else "OFF"
                apply_sim_state(scene, s, si, mode, turns=0.0, keyframe_frame=fr)
            apply_sim_state(scene, s, si, first_mode, turns=0.0, keyframe_frame=st + delay_frames + (bit_count * step))

        _set_preview_key_interpolation(scene, si)
        used += 1

    if used:
        scene.frame_end = max(int(scene.frame_start), int(math.ceil(cycle_end)))
    return used, cycle_end


class NELS_OT_preview_clear(Operator):
    bl_idname = "nels.preview_clear"
    bl_label = "Clear Timeline"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        s = context.scene.nels
        scene = context.scene
        cleared = clear_preview_keyframes(scene, list(s.sirens))
        s.preview_generated = False
        s.preview_dirty = False
        self.report({"INFO"}, f"Cleared {cleared} keyframes")
        return {"FINISHED"}


class NELS_OT_sollumz_enable(Operator):
    bl_idname = "nels.sollumz_enable"
    bl_label = "Enable Sollumz"
    bl_options = {"REGISTER"}

    def execute(self, context):
        module_name = find_sollumz_module_name()
        if not module_name:
            self.report({"ERROR"}, "Sollumz is not installed")
            return {"CANCELLED"}
        try:
            bpy.ops.preferences.addon_enable(module=module_name)
            scene = getattr(context, "scene", None)
            s = getattr(scene, "nels", None) if scene else None
            if s:
                s.status_message = f"Enabled Sollumz ({module_name})"
            self.report({"INFO"}, f"Enabled Sollumz ({module_name})")
            return {"FINISHED"}
        except Exception as ex:
            self.report({"ERROR"}, f"Could not enable Sollumz: {ex}")
            return {"CANCELLED"}


class NELS_OT_sollumz_install(Operator):
    bl_idname = "nels.sollumz_install"
    bl_label = "Install Sollumz"
    bl_options = {"REGISTER"}

    def execute(self, context):
        scene = getattr(context, "scene", None)
        s = getattr(scene, "nels", None) if scene else None
        try:
            asset = fetch_sollumz_release_asset_info()
            data = download_url_bytes(asset["url"])
            enabled_module = install_addon_from_zip_bytes(data, name_hint="sollumz")
            status = sollumz_status()
            if s:
                version = str(asset.get("tag", "") or asset.get("name", "") or "latest release")
                if status["enabled"]:
                    s.status_message = f"Installed Sollumz {version}"
                else:
                    s.status_message = f"Installed Sollumz {version}. Enable it in Blender Preferences if needed."
            if status["enabled"]:
                self.report({"INFO"}, f"Installed Sollumz {asset.get('tag', '') or enabled_module or ''}".strip())
                return {"FINISHED"}
            self.report({"WARNING"}, "Sollumz downloaded and installed, but Blender did not auto-enable it")
            return {"FINISHED"}
        except Exception as ex:
            if s:
                s.status_message = f"Sollumz install failed: {ex}"
            self.report({"ERROR"}, f"Sollumz install failed: {ex}")
            return {"CANCELLED"}


class NELS_OT_update_check(Operator):
    bl_idname = "nels.update_check"
    bl_label = "Check for Updates"
    bl_options = {"REGISTER"}

    def execute(self, context):
        if begin_update_operation("CHECK", automatic=False):
            self.report({"INFO"}, "Checking GitHub for updates")
            return {"FINISHED"}
        self.report({"WARNING"}, "An update task is already running")
        return {"CANCELLED"}


class NELS_OT_update_install(Operator):
    bl_idname = "nels.update_install"
    bl_label = "Install Update"
    bl_options = {"REGISTER"}

    def execute(self, context):
        s = getattr(context.scene, "nels", None)
        if not s:
            self.report({"ERROR"}, "No scene settings available")
            return {"CANCELLED"}
        if getattr(s, "update_install_in_progress", False) or getattr(s, "update_check_in_progress", False):
            self.report({"WARNING"}, "An update task is already running")
            return {"CANCELLED"}
        if not getattr(s, "update_available", False):
            self.report({"WARNING"}, "No newer update is currently available")
            return {"CANCELLED"}
        if begin_update_operation("INSTALL", automatic=False):
            self.report({"INFO"}, "Installing update from GitHub")
            return {"FINISHED"}
        self.report({"WARNING"}, "An update task is already running")
        return {"CANCELLED"}



class NELS_OT_siren_preview_control(Operator):
    bl_idname = "nels.siren_preview_control"
    bl_label = "Siren Preview Control"
    bl_options = {"REGISTER", "UNDO"}

    action: EnumProperty(items=[("START", "Start", ""), ("STOP", "Stop", "")], default="START")

    def execute(self, context):
        scene = getattr(context, "scene", None)
        s = getattr(scene, "nels", None) if scene else None
        if not s:
            self.report({"ERROR"}, "No scene settings available")
            return {"CANCELLED"}
        running = (self.action == "START")
        s.siren_preview_running = running
        if running:
            s.preview_time_origin = _time.time()
            s.preview_last_step = -1
            queue_preview_refresh_feedback(scene, message="Siren preview started")
            mark_preview_dirty(context, scene=scene, immediate=False)
            refresh_preview_visibility_state(scene, restart_clock=True)
            self.report({"INFO"}, "Siren preview started")
        else:
            s.preview_refresh_pending = False
            s.preview_animating_until = 0.0
            mark_preview_dirty(context, scene=scene)
            refresh_preview_visibility_state(scene, restart_clock=False)
            self.report({"INFO"}, "Siren preview stopped")
        return {"FINISHED"}

class NELS_OT_refresh_pattern_previews(Operator):
    bl_idname = "nels.refresh_pattern_previews"
    bl_label = "Refresh Pattern Previews"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        scene = getattr(context, "scene", None)
        s = getattr(scene, "nels", None) if scene else None
        if not s:
            self.report({"ERROR"}, "No scene settings available")
            return {"CANCELLED"}

        queue_preview_refresh_feedback(scene)
        mark_preview_dirty(context, scene=scene, immediate=False)
        refresh_preview_visibility_state(scene, restart_clock=True)
        self.report({"INFO"}, "Preview refresh started")
        return {"FINISHED"}


class NELS_OT_preview(Operator):
    bl_idname = "nels.preview"
    bl_label = "Generate Siren Preview"
    bl_options = {"REGISTER", "UNDO"}

    scope: EnumProperty(items=[("ACTIVE", "ACTIVE", ""), ("ALL", "ALL", "")], default="ALL")

    def execute(self, context):
        s = context.scene.nels
        scene = context.scene

        if self.scope == "ACTIVE":
            if not s.sirens:
                return {"CANCELLED"}
            idx = max(0, min(s.active_siren, len(s.sirens) - 1))
            siren_list = [s.sirens[idx]]
        else:
            siren_list = list(s.sirens)

        clear_preview_keyframes(scene, siren_list)

        used, _cycle_end = generate_timeline_preview(scene, s, siren_list)
        if used:
            s.preview_generated = True
            s.preview_dirty = False
            return {"FINISHED"}
        return {"CANCELLED"}

def e(parent, tag, value=None):
    n = ET.SubElement(parent, tag)
    if value is not None:
        n.set("value", str(value))
    return n


def build_xml(s):
    root = ET.Element("CVehicleModelInfoVarGlobal")
    ss = ET.SubElement(root, "Sirens")
    top = ET.SubElement(ss, "Item")
    e(top, "id", s.vehicle_id)
    ET.SubElement(top, "name").text = s.vehicle_name
    e(top, "timeMultiplier", f8(s.time_multiplier))
    e(top, "lightFalloffMax", f8(s.light_falloff_max))
    e(top, "lightFalloffExponent", f8(s.light_falloff_exp))
    e(top, "lightInnerConeAngle", f8(s.light_inner_angle))
    e(top, "lightOuterConeAngle", f8(s.light_outer_angle))
    e(top, "lightOffset", f8(s.light_offset))
    ET.SubElement(top, "textureName").text = s.texture_name
    e(top, "sequencerBpm", int(s.bpm))

    for tn, key in [("leftHeadLight", s.left_head), ("rightHeadLight", s.right_head), ("leftTailLight", s.left_tail), ("rightTailLight", s.right_tail)]:
        x = ET.SubElement(top, tn)
        p = get_pattern(s, key)
        e(x, "sequencer", bits_to_int(p.bits) if p else 0)

    e(top, "leftHeadLightMultiples", s.left_head_mult)
    e(top, "rightHeadLightMultiples", s.right_head_mult)
    e(top, "leftTailLightMultiples", s.left_tail_mult)
    e(top, "rightTailLightMultiples", s.right_tail_mult)
    e(top, "useRealLights", b(s.use_real_lights))

    sir = ET.SubElement(top, "sirens")
    slots = s.siren_count if s.siren_count > 0 else 20
    for i in range(1, slots + 1):
        si = s.sirens[i - 1] if i - 1 < len(s.sirens) else None
        active = siren_has_output(s, si)
        sir.append(ET.Comment(f"siren{i}" if active else f"inactive siren{i}"))
        it = ET.SubElement(sir, "Item")
        if not active:
            for tag in ["rotation", "flashiness"]:
                sec = ET.SubElement(it, tag)
                e(sec, "delta", f8(0))
                e(sec, "start", f8(0))
                e(sec, "speed", f8(0))
                e(sec, "sequencer", 0)
                e(sec, "multiples", 0)
                e(sec, "direction", b(True))
                e(sec, "syncToBpm", b(True))
            c = ET.SubElement(it, "corona")
            e(c, "intensity", f8(0)); e(c, "size", f8(0)); e(c, "pull", f8(0.00000001)); e(c, "faceCamera", b(False))
            e(it, "color", "0xFFFF0000")
            e(it, "intensity", f8(0))
            e(it, "lightGroup", 0)
            e(it, "rotate", b(False)); e(it, "scale", b(True)); e(it, "scaleFactor", 0)
            e(it, "flash", b(True)); e(it, "light", b(True)); e(it, "spotLight", b(True)); e(it, "castShadows", b(False))
            continue

        _, seq, vis = pattern_triplet(s, si)
        d = dir_val(si)
        is_rot = si.siren_type == "ROTATOR"
        rot_speed_val = rot_speed(s.bpm, si) if is_rot else 0.0
        rot_seq = seq if is_rot and vis in {"BOTH", "ROTATOR"} else 0
        rot_mult = si.light_multiples if is_rot else 0
        rot_dir = bool(getattr(si, "rotator_clockwise", True)) if is_rot else True
        rot_delta = d if is_rot else 0.0

        rot = ET.SubElement(it, "rotation")
        e(rot, "delta", f8(rot_delta))
        e(rot, "start", f8(si.start_delay))
        e(rot, "speed", f8(rot_speed_val))
        e(rot, "sequencer", rot_seq)
        e(rot, "multiples", rot_mult)
        e(rot, "direction", b(rot_dir)); e(rot, "syncToBpm", b(si.sync_to_bpm))

        fl = ET.SubElement(it, "flashiness")
        if is_rot:
            e(fl, "delta", f8(rot_delta)); e(fl, "start", f8(si.start_delay)); e(fl, "speed", f8(rot_speed_val))
            e(fl, "sequencer", rot_seq)
            e(fl, "multiples", rot_mult); e(fl, "direction", b(rot_dir)); e(fl, "syncToBpm", b(si.sync_to_bpm))
        else:
            e(fl, "delta", f8(d)); e(fl, "start", f8(si.start_delay)); e(fl, "speed", f8(si.light_speed))
            e(fl, "sequencer", seq if vis in {"BOTH", "FLASHER"} else 0)
            e(fl, "multiples", si.light_multiples); e(fl, "direction", b(True)); e(fl, "syncToBpm", b(si.sync_to_bpm))

        c = ET.SubElement(it, "corona")
        e(c, "intensity", f8(si.corona_intensity)); e(c, "size", f8(si.corona_size)); e(c, "pull", f8(si.corona_pull)); e(c, "faceCamera", b(si.corona_face_camera))
        e(it, "color", color_hex(s, si)); e(it, "intensity", f8(si.light_intensity)); e(it, "lightGroup", si.light_group)
        e(it, "rotate", b(is_rot)); e(it, "scale", b(True)); e(it, "scaleFactor", f8(scale_val(si)))
        e(it, "flash", b(si.flash)); e(it, "light", b(si.light)); e(it, "spotLight", b(si.spot_light)); e(it, "castShadows", b(si.cast_shadows))
    return xml.dom.minidom.parseString(ET.tostring(root, encoding="utf-8")).toprettyxml(indent="\t")





