class NELS_OT_export(Operator):
    bl_idname = "nels.export"
    bl_label = "Export carcols.meta"

    def execute(self, context):
        s = context.scene.nels
        fp = bpy.path.abspath(s.export_path)
        if not fp.lower().endswith(".meta"):
            fp += ".meta"
        out_dir = os.path.dirname(fp)
        if out_dir:
            os.makedirs(out_dir, exist_ok=True)
        with open(fp, "w", encoding="utf-8") as h:
            h.write(build_xml(s))
        s.status_message = f"Export complete: {fp}"
        self.report({"INFO"}, s.status_message)
        return {"FINISHED"}

class VIEW3D_MT_nels(Menu):
    bl_label = "GTA 000 Tools"
    bl_idname = "VIEW3D_MT_nels"

    def draw(self, context):
        l = self.layout
        l.menu("NELS_MT_siren_actions", icon="DOWNARROW_HLT")
        l.separator()
        o = l.operator("nels.sim", text="Simulate All Off"); o.all = True; o.mode = "OFF"
        o = l.operator("nels.sim", text="Simulate All On"); o.all = True; o.mode = "ON"
        l.operator("nels.export")


class VIEW3D_MT_nels_context_object(Menu):
    bl_label = "GTA 000 Tools"
    bl_idname = "VIEW3D_MT_nels_context_object"

    def draw(self, context):
        l = self.layout
        o = l.operator("nels.link_bone", text="Assign Selected Mesh", icon="OUTLINER_OB_MESH"); o.action = "MARK"
        o = l.operator("nels.link_bone", text="Match Origin to Selected", icon="OBJECT_ORIGIN"); o.action = "ORIGIN"
        l.operator("nels.move_bone_to_selected", text="Move Bone to Selected", icon="BONE_DATA")
        o = l.operator("nels.link_bone", text="Place Bone at Selected Origin", icon="BONE_DATA"); o.action = "BONE"
        l.separator()
        l.operator("nels.origins_to_bones", text="Set Selected Origins to Bones", icon="CON_TRACKTO")
        l.operator("nels.bones_to_origins", text="Move Linked Bones to Origins", icon="BONE_DATA")
        l.operator("nels.auto_detect", text="Auto-Detect Sirens/Bones", icon="VIEWZOOM")


class VIEW3D_MT_nels_context_edit(Menu):
    bl_label = "GTA 000 Tools"
    bl_idname = "VIEW3D_MT_nels_context_edit"

    def draw(self, context):
        l = self.layout
        l.operator("nels.origin_to_selection", text="Set Origin to Selection", icon="PIVOT_CURSOR")
        if light_id_face_select_ready(context):
            l.separator()
            o = l.operator("nels.light_id_faces", text="Set Light ID", icon="MESH_DATA")
            o.action = "SET"
            o = l.operator("nels.light_id_faces", text="Select Light ID", icon="RESTRICT_SELECT_OFF")
            o.action = "SELECT"


def draw_obj_menu(self, context):
    self.layout.separator()
    self.layout.menu(VIEW3D_MT_nels.bl_idname, icon="LIGHT")


def draw_object_context_menu(self, context):
    layout = self.layout
    layout.menu(VIEW3D_MT_nels_context_object.bl_idname, icon="LIGHT")
    layout.separator()


def draw_edit_mesh_context_menu(self, context):
    layout = self.layout
    layout.menu(VIEW3D_MT_nels_context_edit.bl_idname, icon="LIGHT")
    layout.separator()


def register_panel_icons():
    unregister_panel_icons()
    icons_dir = os.path.join(os.path.dirname(__file__), "icons")
    if not os.path.isdir(icons_dir):
        return

    pcoll = bpy.utils.previews.new()
    loaded_any = False
    for key, stem in PANEL_ICON_FILES.items():
        for variant in ("dark", "light"):
            for ext in PANEL_ICON_EXTENSIONS:
                fp = os.path.join(icons_dir, f"{stem}_{variant}{ext}")
                if not os.path.isfile(fp):
                    continue
                try:
                    pcoll.load(f"{key}_{variant}", fp, "IMAGE")
                    loaded_any = True
                    break
                except Exception:
                    continue
        for ext in PANEL_ICON_EXTENSIONS:
            fp = os.path.join(icons_dir, stem + ext)
            if not os.path.isfile(fp):
                continue
            try:
                pcoll.load(key, fp, "IMAGE")
                loaded_any = True
                break
            except Exception:
                continue

    if not loaded_any:
        bpy.utils.previews.remove(pcoll)
        return

    _PREVIEW_COLLECTIONS["panel_icons"] = pcoll


def unregister_panel_icons():
    pcoll = _PREVIEW_COLLECTIONS.pop("panel_icons", None)
    if not pcoll:
        return
    try:
        bpy.utils.previews.remove(pcoll)
    except Exception:
        pass


def preferred_icon_variant(context=None):
    mode = icon_color_mode(context)
    if mode == "LIGHT":
        return "light"
    if mode == "DARK":
        return "dark"
    return "dark" if theme_uses_dark_panels(context) else "light"


def get_panel_icon_value(key, context=None):
    pcoll = _PREVIEW_COLLECTIONS.get("panel_icons")
    if not pcoll:
        return 0
    try:
        variant_key = f"{key}_{preferred_icon_variant(context)}"
        if variant_key in pcoll:
            return pcoll[variant_key].icon_id
        if key in pcoll:
            return pcoll[key].icon_id
    except Exception:
        pass
    return 0


def theme_uses_dark_panels(context=None):
    ctx = context if context is not None else bpy.context
    try:
        themes = getattr(getattr(ctx, "preferences", None), "themes", None)
        theme = themes[0] if themes else None
        ui = getattr(theme, "user_interface", None) if theme else None
        panel = getattr(ui, "wcol_panel", None) if ui else None
        inner = getattr(panel, "inner", None) if panel else None
        if inner is None:
            return True
        avg = (float(inner[0]) + float(inner[1]) + float(inner[2])) / 3.0
        return avg < 0.5
    except Exception:
        return True


def panel_icon_draw_kwargs(key, context=None, fallback_icon=None):
    icon_value = get_panel_icon_value(key, context)
    if icon_value:
        return {"icon_value": icon_value}
    return {"icon": fallback_icon or PANEL_FALLBACK_ICONS.get(key, "NONE")}


def draw_panel_header_icon(layout, key, context=None):
    layout.label(text="", **panel_icon_draw_kwargs(key, context))

def siren_row_shows_status_icon(scene, si):
    s = getattr(scene, "nels", None) if scene else None
    if not s or not si:
        return True
    if getattr(si, "siren_type", "FLASHER") == "ROTATOR":
        return True
    bits, seq, vis = pattern_triplet(s, si)
    return bool(seq and vis in {"BOTH", "FLASHER"})


def siren_status_details(scene, si):
    if not si:
        return "ERROR", "Missing siren data"

    issues = []
    expected_name = f"siren{getattr(si, 'index', 0)}"
    scene_objects = list(getattr(scene, "objects", [])) if scene else []
    scene_object_names = {obj.name for obj in scene_objects}
    settings = getattr(scene, "nels", None) if scene else None

    mesh_name = str(getattr(si, "object_name", "") or "").strip()
    if mesh_name:
        mesh_obj = bpy.data.objects.get(mesh_name)
        if mesh_obj is None:
            issues.append(f"Missing mesh: linked object '{mesh_name}' was not found")
        elif mesh_obj.type != "MESH":
            issues.append(f"Invalid mesh link: '{mesh_name}' is not a mesh")
        elif scene and mesh_obj.name not in scene_object_names:
            issues.append(f"Missing mesh: linked object '{mesh_name}' is not in the current scene")
    else:
        fallback = bpy.data.objects.get(expected_name)
        if fallback is None or fallback.type != "MESH" or (scene and fallback.name not in scene_object_names):
            issues.append(f"Missing mesh: assign a mesh or rename it to '{expected_name}'")

    armature_name = str(getattr(settings, "armature_name", "") or "").strip() if settings else ""
    bone_name = str(getattr(si, "bone_name", "") or "").strip()
    armatures = [obj for obj in scene_objects if obj.type == "ARMATURE"]

    def bone_exists(name):
        if not name:
            return False
        for arm in armatures:
            if name in arm.data.bones:
                return True
        return False

    if armature_name:
        arm_obj = bpy.data.objects.get(armature_name)
        if arm_obj is None:
            issues.append(f"Missing parent skeleton: '{armature_name}' was not found")
        elif arm_obj.type != "ARMATURE":
            issues.append(f"Invalid parent skeleton: '{armature_name}' is not an armature")
        elif scene and arm_obj.name not in scene_object_names:
            issues.append(f"Missing parent skeleton: '{armature_name}' is not in the current scene")

    if bone_name:
        if not bone_exists(bone_name):
            issues.append(f"Missing bone: linked bone '{bone_name}' was not found")
    else:
        if not bone_exists(expected_name):
            issues.append(f"Missing bone: place or link bone '{expected_name}'")

    if issues:
        return "ERROR", "; ".join(dict.fromkeys(issues))
    return "LIGHT", "Configured: mesh and bone are linked"



def friendly_ui_error_message(ex, section="general"):
    text = str(ex or "").strip()
    lower = text.lower()
    section_key = str(section or "").lower()
    if "bpy_prop_collection[index]" in text and "size 0" in text:
        if "siren" in section_key:
            return "Please add Sirens to configure them."
        if "pattern" in section_key:
            return "Please add Flash Patterns to configure them."
        if "colour" in section_key or "color" in section_key:
            return "Please add Colours to configure them."
        if "body" in section_key or "opening" in section_key:
            return "No body openings are available to configure yet."
        return "Nothing is available to configure yet."
    if "'nonetype' object has no attribute 'action'" in lower:
        return "Blender is still using stale UI state from an older add-on build. Restart Blender and reopen this panel."
    if lower.startswith("error") or lower.startswith("warning"):
        return text
    if not text:
        return "Something went wrong in this panel."
    return f"Something went wrong in the {section or 'current'} panel: {text}"

def draw_ui_exception(layout, context, ex, section="general"):
    box = layout.box()
    box.alert = True
    draw_wrapped_text(box, context, friendly_ui_error_message(ex, section), icon="ERROR")

def filtered_sirens(s):
    if not s:
        return []
    return [si for si in getattr(s, "sirens", []) if bool(getattr(si, "filter_selected", True))]

def siren_is_off_for_summary(s, si):
    if not s or not si:
        return True
    if getattr(si, "siren_type", "FLASHER") == "ROTATOR":
        return False
    _bits, seq, vis = pattern_triplet(s, si)
    return (not seq) or (vis not in {"BOTH", "FLASHER"})

def draw_siren_setup_summary(layout, scene, s, si):
    if siren_is_off_for_summary(s, si):
        layout.label(text="Off")
        return
    icon_name, _tooltip = siren_status_details(scene, si)
    if icon_name == "ERROR":
        layout.label(text="Setup Incomplete")
        return
    sw = layout.row(align=True)
    sw.enabled = False
    sw.prop(si, "configured_color", text="")

def draw_siren_filter_group(layout, s):
    filter_box = layout.box()
    header = filter_box.row(align=True)
    header.prop(s, "show_siren_filters", text="Filter Sirens", icon="TRIA_DOWN" if s.show_siren_filters else "TRIA_RIGHT", emboss=False)
    if not getattr(s, "show_siren_filters", True):
        return
    actions = filter_box.row(align=True)
    o = actions.operator("nels.siren_filter_bulk", text="Show All", icon="CHECKBOX_HLT")
    o.action = "SHOW_ALL"
    o = actions.operator("nels.siren_filter_bulk", text="Hide All", icon="CHECKBOX_DEHLT")
    o.action = "HIDE_ALL"
    dir_row = filter_box.row(align=True)
    dir_row.prop(s, "siren_filter_direction", text="Facing")
    o = dir_row.operator("nels.siren_filter_bulk", text="Show", icon="VIEWZOOM")
    o.action = "BY_DIRECTION"
    o.direction = getattr(s, "siren_filter_direction", "FRONT")
    grid = filter_box.grid_flow(row_major=True, columns=4, even_columns=True, even_rows=True, align=True)
    for si in getattr(s, "sirens", []):
        cell = grid.row(align=True)
        cell.prop(si, "filter_selected", text=f"Siren {si.index}")

def draw_siren_preview_grid(layout, context, s, sirens):
    preview_box = layout.box()
    header = preview_box.row(align=True)
    header.prop(s, "show_siren_preview_panel", text="Siren Previews", icon="TRIA_DOWN" if s.show_siren_preview_panel else "TRIA_RIGHT", emboss=False)
    controls = header.row(align=True)
    controls.enabled = getattr(s, "show_siren_preview_panel", False)
    controls.operator("nels.siren_preview_control", text="Start Preview", icon="PLAY").action = "START"
    controls.operator("nels.siren_preview_control", text="Stop Preview", icon="PAUSE").action = "STOP"
    if not getattr(s, "show_siren_preview_panel", False):
        return
    if not getattr(s, "all_flash_previews", True):
        draw_wrapped_text(preview_box, context, "Turn on Show All Flash Previews to show siren previews here.", icon="INFO")
        return
    if not sirens:
        draw_wrapped_text(preview_box, context, "Select one or more Sirens to preview.", icon="INFO")
        return
    if not getattr(s, "siren_preview_running", True):
        preview_box.label(text="Preview stopped", icon="PAUSE")
    grid = preview_box.grid_flow(row_major=True, columns=5, even_columns=True, even_rows=False, align=True)
    for si in sirens:
        tile = grid.column(align=True)
        sw = tile.row(align=True)
        sw.enabled = False
        sw.prop(si, "preview_color_cache", text="")
        label = tile.row()
        label.alignment = "CENTER"
        label.label(text=f"Siren {si.index}")

def draw_siren_configuration_fields(layout, context, s, si):
    show_rotators = alpha_rotators_enabled(context)
    if show_rotators:
        layout.prop(si, "siren_type")

    if show_rotators and si.siren_type == "ROTATOR":
        layout.prop(si, "rotator_speed_mode")
        if si.rotator_speed_mode == "CUSTOM":
            layout.prop(si, "rotator_custom_percent")
        layout.prop(si, "rotator_clockwise", text="Clockwise Rotation")
        speed_row = layout.row()
        speed_row.enabled = False
        speed_row.prop(si, "light_speed", text="Light Speed")
    elif (not show_rotators) and si.siren_type == "ROTATOR":
        warn_box = layout.box()
        warn_box.alert = True
        warn_box.label(text="Rotator controls are hidden in Add-on Preferences", icon="INFO")
    else:
        layout.prop(si, "pattern_select", text="Pattern")
        if si.pattern_select in {UNSAVED_PATTERN_KEY, "__CUSTOM__"}:
            save_row = layout.row(align=True)
            save_row.label(text="Unsaved Pattern", icon="BOOKMARKS")
            save_row.operator("nels.save_siren_pattern", text="Save to Library", icon="ADD")
            layout.prop(si, "custom_bits")
            tools_row = layout.row(align=True)
            o = tools_row.operator("nels.pattern_tools", text="Repeat to 32")
            o.action = "REPEAT"
            o.scope = "SIREN"
            o = tools_row.operator("nels.pattern_tools", text="Generate Opposite")
            o.action = "INVERT"
            o.scope = "SIREN"
            layout.prop(si, "custom_value", text="Sequencer")

    layout.prop(si, "color_select", text="Colour")
    if si.color_select == "__CUSTOM__":
        layout.prop(si, "custom_color", text="Custom Colour")
        layout.label(text=f"Output: {color_hex(s, si)}")

    layout.prop(si, "direction_select", text="Direction")
    if si.direction_select == "__CUSTOM__":
        layout.prop(si, "custom_direction", text="Custom Direction")
    layout.prop(si, "sync_to_bpm")

    link_box = layout.box()
    link_header = link_box.row(align=True)
    link_header.prop(si, "show_linking", text="Object/Bone Linking", icon="TRIA_DOWN" if si.show_linking else "TRIA_RIGHT", emboss=False)
    select_op = link_header.operator("nels.select_linked_siren", text="", icon="RESTRICT_SELECT_OFF")
    select_op.siren_index = si.index
    if si.show_linking:
        link_box.prop_search(s, "armature_name", context.scene, "objects", text="Parent Skeleton")
        link_box.operator("nels.select_linked_siren", text="Select Linked Siren", icon="RESTRICT_SELECT_OFF").siren_index = si.index
        link_box.operator("nels.auto_detect", text="Auto-Detect Sirens/Bones", icon="VIEWZOOM")
        o = link_box.operator("nels.link_bone", text="Assign Selected Mesh", icon="OUTLINER_OB_MESH")
        o.action = "MARK"
        o = link_box.operator("nels.link_bone", text="Place Bone at Selected Origin", icon="BONE_DATA")
        o.action = "BONE"

        mesh_row = link_box.row(align=True)
        mesh_row.prop_search(si, "object_name", context.scene, "objects", text="Mesh")
        o = mesh_row.operator("nels.pick_selected_link_target", text="", icon="EYEDROPPER")
        if o is not None:
            o.target = "SIREN_MESH"

        arm = bpy.data.objects.get(getattr(s, "armature_name", "")) if getattr(s, "armature_name", "") else None
        bone_row = link_box.row(align=True)
        if arm and getattr(arm, "type", "") == "ARMATURE":
            bone_row.prop_search(si, "bone_name", arm.data, "bones", text="Bone")
        else:
            bone_field = bone_row.row(align=True)
            bone_field.enabled = False
            bone_field.prop(si, "bone_name", text="Bone")
        o = bone_row.operator("nels.pick_selected_link_target", text="", icon="EYEDROPPER")
        if o is not None:
            o.target = "SIREN_BONE"

        if not arm or getattr(arm, "type", "") != "ARMATURE":
            link_box.label(text="Select a Parent Skeleton to search scene bones", icon="INFO")
        direction_warning = siren_direction_warning(context.scene, si)
        if direction_warning:
            warn_box = link_box.box()
            warn_box.alert = True
            draw_wrapped_text(warn_box, context, direction_warning, icon="ERROR")
    adv_row = layout.row(align=True)
    adv_row.prop(si, "show_advanced", text="Other Configurations", icon="TRIA_DOWN" if si.show_advanced else "TRIA_RIGHT", emboss=False)
    if si.show_advanced:
        for k in ["flash", "light", "spot_light", "cast_shadows", "light_group", "start_delay", "light_speed", "light_multiples", "corona_intensity", "corona_size", "corona_pull", "light_intensity", "corona_face_camera"]:
            layout.prop(si, k)

class NELS_OT_siren_status_info(Operator):
    bl_idname = "nels.siren_status_info"
    bl_label = "Siren Status"
    bl_options = {"INTERNAL"}

    message: StringProperty(default="")

    @classmethod
    def description(cls, _context, properties):
        return str(getattr(properties, "message", "") or "Siren status")

    def execute(self, context):
        msg = str(getattr(self, "message", "") or "Siren status")
        self.report({"INFO"}, msg)
        return {"FINISHED"}


class NELS_UL_sirens(UIList):
    def draw_item(self, context, layout, data, item, icon, active_data, active_propname, index=0, flt_flag=0):
        if self.layout_type in {"DEFAULT", "COMPACT"}:
            row = layout.row(align=True)
            split = row.split(factor=0.85, align=True)
            left = split.row(align=True)
            scene = getattr(context, "scene", None)
            if siren_row_shows_status_icon(scene, item):
                icon_name, tooltip = siren_status_details(scene, item)
                op = left.operator("nels.siren_status_info", text="", icon=icon_name, emboss=False)
                op.message = tooltip
            else:
                left.label(text="", icon="BLANK1")
            left.label(text=f"siren{item.index}")
            right = split.row(align=True)
            if getattr(data, "all_flash_previews", True) and getattr(data, "list_flash_preview", True):
                right.prop(item, "preview_color_cache", text="")
            else:
                right.label(text="")
        else:
            layout.alignment = "CENTER"
            layout.label(text=str(item.index))


class NELS_UL_patterns(UIList):
    def draw_item(self, context, layout, data, item, icon, active_data, active_propname, index=0, flt_flag=0):
        if self.layout_type in {"DEFAULT", "COMPACT"}:
            row = layout.row(align=True)
            split = row.split(factor=0.82, align=True)
            left = split.row(align=True)
            if pattern_duplicate_indices(data, index):
                icon_name = "INFO" if pattern_duplicate_is_allowed(data, index) else "ERROR"
            else:
                icon_name = "FILE_TEXT"
            left.label(text=pattern_display_name(data, index), icon=icon_name)
        else:
            layout.alignment = "CENTER"
            layout.label(text=str(index + 1))


class NELS_UL_body_openings(UIList):
    def draw_item(self, context, layout, data, item, icon, active_data, active_propname, index=0, flt_flag=0):
        if self.layout_type in {"DEFAULT", "COMPACT"}:
            row = layout.row(align=True)
            icon_name = "CON_ROTLIKE" if getattr(item, "opening_type", "HINGED") == "HINGED" else "EMPTY_ARROWS"
            row.label(text=str(getattr(item, "name", body_opening_display_name(getattr(item, "key", ""))) or "Body Opening"), **panel_icon_draw_kwargs(body_opening_icon_key(getattr(item, "key", "")), context, fallback_icon=icon_name))
        else:
            layout.alignment = "CENTER"
            layout.label(text=str(index + 1))


class VIEW3D_PT_nels_body_openings(Panel):
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "Tool"
    bl_label = "Body Openings"
    bl_options = {"DEFAULT_CLOSED"}

    def draw_header(self, context):
        draw_panel_header_icon(self.layout, "body_openings")

    def draw(self, context):
        l = self.layout
        try:
            s = getattr(context.scene, "nels", None)
            if not s:
                l.label(text="No scene settings available")
                return

            ensure_body_opening_defaults(s)
            row = l.row()
            row.template_list("NELS_UL_body_openings", "nels_body_openings", s, "body_openings", s, "active_body_opening", rows=6)
            opening = active_body_opening(s)
            if not opening:
                l.label(text="No body openings available")
                return

            box = l.box()
            box.label(text=str(getattr(opening, "name", "Body Opening") or "Body Opening"))
            box.prop(opening, "opening_type", text="Type")

            motion = box.box()
            if body_opening_supports_rotation(opening):
                rot_box = motion.box() if body_opening_supports_translation(opening) else motion
                rot_box.label(text="Rotation Axes")
                rr = rot_box.row(align=True)
                rr.prop(opening, "rot_x", text="X", toggle=True)
                rr.prop(opening, "rot_y", text="Y", toggle=True)
                rr.prop(opening, "rot_z", text="Z", toggle=True)
                rot_box.prop(opening, "limit_rotation")
            if body_opening_supports_translation(opening):
                slide_box = motion.box() if body_opening_supports_rotation(opening) else motion
                slide_box.label(text="Movement Axes")
                sr = slide_box.row(align=True)
                sr.prop(opening, "slide_x", text="X", toggle=True)
                sr.prop(opening, "slide_y", text="Y", toggle=True)
                sr.prop(opening, "slide_z", text="Z", toggle=True)
                slide_box.prop(opening, "limit_translation")

            link_box = box.box()
            link_box.label(text="Object/Bone Linking")
            link_box.prop_search(s, "armature_name", bpy.data, "objects", text="Parent Skeleton")
            op = link_box.operator("nels.body_opening_link", text="Assign Selected Mesh", icon="OUTLINER_OB_MESH")
            op.action = "MARK"
            op = link_box.operator("nels.body_opening_link", text="Match Origin to Selected", icon="OBJECT_ORIGIN")
            op.action = "ORIGIN"
            op = link_box.operator("nels.body_opening_link", text="Place Bone at Selected Origin", icon="BONE_DATA")
            op.action = "BONE"
            link_box.prop(opening, "object_name", text="Mesh")
            link_box.prop(opening, "bone_name", text="Bone")
            link_box.label(text="Placed bones always point to vehicle front (Y+)", icon="INFO")

            state_box = box.box()
            state_box.label(text="Capture and Preview")
            state_box.label(text="Move the linked mesh or pose bone manually, then set Closed and Open positions.", icon="INFO")
            capture_row = state_box.row(align=True)
            op = capture_row.operator("nels.body_opening_state", text="Set Closed Position", icon="IMPORT")
            op.action = "CAPTURE_CLOSED"
            op = capture_row.operator("nels.body_opening_state", text="Set Open Position", icon="EXPORT")
            op.action = "CAPTURE_OPEN"
            apply_row = state_box.row(align=True)
            op = apply_row.operator("nels.body_opening_state", text="Preview Closed", icon="LOOP_BACK")
            op.action = "APPLY_CLOSED"
            op = apply_row.operator("nels.body_opening_state", text="Preview Open", icon="PLAY")
            op.action = "APPLY_OPEN"

            closed_loc = Vector(getattr(opening, "closed_location", (0.0, 0.0, 0.0)))
            open_loc = Vector(getattr(opening, "open_location", (0.0, 0.0, 0.0)))
            closed_rot = Vector(getattr(opening, "closed_rotation", (0.0, 0.0, 0.0)))
            open_rot = Vector(getattr(opening, "open_rotation", (0.0, 0.0, 0.0)))
            slide_delta = open_loc - closed_loc
            rot_delta = open_rot - closed_rot

            display = state_box.column(align=True)
            display.enabled = False
            display.prop(opening, "closed_location", text="Closed Position")
            display.prop(opening, "open_location", text="Open Position")
            display.prop(opening, "closed_rotation", text="Closed Rotation")
            display.prop(opening, "open_rotation", text="Open Rotation")
            state_box.label(text=f"Slide Delta: X {slide_delta[0]:.4f}  Y {slide_delta[1]:.4f}  Z {slide_delta[2]:.4f}")
            state_box.label(text=f"Rotation Delta: X {rot_delta[0]:.4f}  Y {rot_delta[1]:.4f}  Z {rot_delta[2]:.4f}")
        except Exception as ex:
            draw_ui_exception(l, context, ex, getattr(self, "bl_label", "general"))


class VIEW3D_PT_nels(Panel):
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "Tool"
    bl_label = "Lightbar Configuration"
    bl_options = {"DEFAULT_CLOSED"}

    def draw_header(self, context):
        draw_panel_header_icon(self.layout, "lightbar")

    def draw(self, context):
        mark_panel_drawn(getattr(context, "scene", None), "lightbar")
        l = self.layout
        try:
            s = getattr(context.scene, "nels", None)
            if not s:
                l.label(text="No scene settings available")
                return

            soll_status = sollumz_status()
            if not soll_status["enabled"]:
                warn = l.box()
                warn.alert = True
                if soll_status["installed"]:
                    draw_wrapped_text(warn, context, "Sollumz is installed but not enabled. Some functions may not work as expected until it is enabled.", icon="ERROR")
                    row = warn.row(align=True)
                    row.operator("nels.sollumz_enable", text="Enable Sollumz", icon="CHECKMARK")
                    row.operator("wm.url_open", text="Open GitHub", icon="URL").url = SOLLUMZ_REPO_URL
                else:
                    draw_wrapped_text(warn, context, "You do not have Sollumz installed, some functions may not work as expected. Please install Sollumz from GitHub.", icon="ERROR")
                    row = warn.row(align=True)
                    row.operator("nels.sollumz_install", text="Install Sollumz", icon="IMPORT")
                    row.operator("wm.url_open", text="Open GitHub", icon="URL").url = SOLLUMZ_REPO_URL

            b0 = l.box(); b0.label(text="Lightbar Setup")
            r = b0.row(align=True)
            r.prop(s, "saved_config", text="Saved")
            o = r.operator("nels.new_save_load", text="", icon="FILE_REFRESH"); o.action = "LOAD"
            r.menu("NELS_MT_config_actions", text="", icon="DOWNARROW_HLT")
            b0.prop(s, "config_name")
            b0.prop(s, "vehicle_name", text="vehicle_name")
            id_row = b0.row(align=True)
            id_row.prop(s, "vehicle_id", text="siren_id")
            id_row.operator("nels.generate_siren_id", text="", icon="FILE_REFRESH")
            b0.prop(s, "bpm")
            b0.prop(s, "scale_factor_choice", text="Scale Factor")
            if s.scale_factor_choice == "CUSTOM":
                b0.prop(s, "scale_factor_custom", text="Custom Scale Factor")
            b0.prop(s, "all_flash_previews", text="Show All Flash Previews")
            preview_row = b0.row(align=True)
            preview_row.prop(s, "head_tail_preview", text="Head/Tail Preview")
            preview_row.operator("nels.refresh_pattern_previews", text="Refresh", icon="FILE_REFRESH")

            b0.label(text="Headlight Flash Patterns")
            hr = b0.row(align=True)
            hsplit = hr.split(factor=0.85, align=True)
            hleft = hsplit.row(align=True)
            hleft.prop(s, "left_head", text="Left")
            hsw = hsplit.row(align=True)
            if getattr(s, "all_flash_previews", True) and getattr(s, "head_tail_preview", True):
                hsw.enabled = False
                hsw.prop(s, "left_head_preview_cache", text="")
            else:
                hsw.label(text="")

            hr2 = b0.row(align=True)
            hsplit2 = hr2.split(factor=0.85, align=True)
            hleft2 = hsplit2.row(align=True)
            hleft2.prop(s, "right_head", text="Right")
            hsw2 = hsplit2.row(align=True)
            if getattr(s, "all_flash_previews", True) and getattr(s, "head_tail_preview", True):
                hsw2.enabled = False
                hsw2.prop(s, "right_head_preview_cache", text="")
            else:
                hsw2.label(text="")

            b0.label(text="Taillight Flash Patterns")
            tr = b0.row(align=True)
            tsplit = tr.split(factor=0.85, align=True)
            tleft = tsplit.row(align=True)
            tleft.prop(s, "left_tail", text="Left")
            tsw = tsplit.row(align=True)
            if getattr(s, "all_flash_previews", True) and getattr(s, "head_tail_preview", True):
                tsw.enabled = False
                tsw.prop(s, "left_tail_preview_cache", text="")
            else:
                tsw.label(text="")

            tr2 = b0.row(align=True)
            tsplit2 = tr2.split(factor=0.85, align=True)
            tleft2 = tsplit2.row(align=True)
            tleft2.prop(s, "right_tail", text="Right")
            tsw2 = tsplit2.row(align=True)
            if getattr(s, "all_flash_previews", True) and getattr(s, "head_tail_preview", True):
                tsw2.enabled = False
                tsw2.prop(s, "right_tail_preview_cache", text="")
            else:
                tsw2.label(text="")

            r = b0.row(align=True)
            r.prop(s, "show_adv_main", text="Advanced Configurations", icon="TRIA_DOWN" if s.show_adv_main else "TRIA_RIGHT", emboss=False)
            if s.show_adv_main:
                for k in ["use_real_lights", "time_multiplier", "light_falloff_max", "light_falloff_exp", "light_inner_angle", "light_outer_angle", "light_offset", "texture_name", "left_head_mult", "right_head_mult", "left_tail_mult", "right_tail_mult"]:
                    b0.prop(s, k)

            b2 = l.box()
            sh = b2.row(align=True)
            sh.prop(s, "show_sirens_section", text=f"Non-ELS Sirens ({len(s.sirens)})", icon="TRIA_DOWN" if s.show_sirens_section else "TRIA_RIGHT", emboss=False)
            if s.show_sirens_section:
                actions = b2.row(align=True)
                actions.menu("NELS_MT_siren_actions", text="Siren Actions", icon="DOWNARROW_HLT")
                actions.operator("nels.refresh_pattern_previews", text="", icon="FILE_REFRESH")
                actions.label(text=f"Count: {len(s.sirens)}")
                if not s.sirens:
                    info = b2.box()
                    draw_wrapped_text(info, context, "Please add Sirens to configure them.", icon="INFO")
                else:
                    draw_siren_filter_group(b2, s)
                    visible_sirens = filtered_sirens(s)
                    draw_siren_preview_grid(b2, context, s, visible_sirens)
                    if not visible_sirens:
                        info = b2.box()
                        draw_wrapped_text(info, context, "Select one or more Sirens to show their setup panels.", icon="INFO")
                    else:
                        for si in visible_sirens:
                            sec = b2.box()
                            hdr = sec.row(align=True)
                            split = hdr.split(factor=0.80, align=True)
                            left = split.row(align=True)
                            left.prop(si, "expanded", text=f"Siren {si.index} Setup", icon="TRIA_DOWN" if si.expanded else "TRIA_RIGHT", emboss=False)
                            right = split.row(align=True)
                            right.alignment = "RIGHT"
                            draw_siren_setup_summary(right, context.scene, s, si)
                            if si.expanded:
                                draw_siren_configuration_fields(sec, context, s, si)
            b4 = l.box(); b4.label(text="Export")
            b4.prop(s, "export_path")
            b4.operator("nels.export", icon="EXPORT")

            if getattr(s, "status_message", ""):
                wb = l.box()
                msg = str(s.status_message)
                warn = msg.lower().startswith("warning") or msg.lower().startswith("error")
                wb.alert = warn
                draw_wrapped_text(wb, context, msg, icon="ERROR" if warn else "INFO")
        except Exception as ex:
            draw_ui_exception(l, context, ex, getattr(self, "bl_label", "general"))

class VIEW3D_PT_nels_patterns(Panel):
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "Tool"
    bl_label = "Flash Patterns Library"
    bl_options = {"DEFAULT_CLOSED"}

    def draw_header(self, context):
        draw_panel_header_icon(self.layout, "patterns")

    def draw(self, context):
        l = self.layout
        try:
            s = getattr(context.scene, "nels", None)
            if not s:
                l.label(text="No scene settings available")
                return

            row = l.row()
            row.template_list("NELS_UL_patterns", "nels_patterns", s, "patterns", s, "active_pattern", rows=5)
            col = row.column(align=True)
            o = col.operator("nels.pattern_tools", text="", icon="ADD"); o.action = "ADD"; o.scope = "LIB"
            o = col.operator("nels.pattern_tools", text="", icon="DUPLICATE"); o.action = "DUPLICATE"; o.scope = "LIB"
            o = col.operator("nels.pattern_tools", text="", icon="REMOVE"); o.action = "REMOVE"; o.scope = "LIB"

            lib = l.box(); lib.label(text="Pattern Library File")
            lib.prop(s, "pattern_library_path", text="")
            lr = lib.row(align=True)
            o = lr.operator("nels.pattern_library_io", text="Export Library", icon="EXPORT"); o.action = "EXPORT"
            o = lr.operator("nels.pattern_library_io", text="Import Library", icon="IMPORT"); o.action = "IMPORT"

            if not s.patterns:
                l.label(text="No patterns yet. Click + or initialize defaults.")
                l.operator("nels.initialize_defaults", icon="FILE_REFRESH")
                return

            p = s.patterns[s.active_pattern] if 0 <= s.active_pattern < len(s.patterns) else s.patterns[0]
            dup_matches = pattern_duplicate_indices(s, s.active_pattern)
            if dup_matches:
                dup_box = l.box()
                dup_allowed = pattern_duplicate_is_allowed(s, s.active_pattern)
                dup_box.alert = not dup_allowed
                dup_box.label(text=f"Duplicate pattern name: {p.name} ({len(dup_matches)} entries)", icon="INFO" if dup_allowed else "ERROR")
                dup_row = dup_box.row(align=True)
                if dup_allowed:
                    o = dup_row.operator("nels.pattern_duplicate_resolution", text="Warn Again")
                    o.action = "WARN"
                    o.index = s.active_pattern
                else:
                    o = dup_row.operator("nels.pattern_duplicate_resolution", text="Keep Both")
                    o.action = "ALLOW"
                    o.index = s.active_pattern
                o = dup_row.operator("nels.pattern_duplicate_resolution", text="Keep Selected Only")
                o.action = "KEEP_SELECTED"
                o.index = s.active_pattern
            l.prop(p, "name")
            l.prop(p, "bits")
            r = l.row(align=True)
            o = r.operator("nels.pattern_tools", text="Repeat to 32"); o.action = "REPEAT"; o.scope = "LIB"
            o = r.operator("nels.pattern_tools", text="Opposite Pattern"); o.action = "INVERT"; o.scope = "LIB"
            vrow = l.row()
            vrow.prop(p, "value", text="Sequencer")
        except Exception as ex:
            draw_ui_exception(l, context, ex, getattr(self, "bl_label", "general"))

class VIEW3D_PT_nels_colors(Panel):
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "Tool"
    bl_label = "Colours"
    bl_options = {"DEFAULT_CLOSED"}

    def draw_header(self, context):
        draw_panel_header_icon(self.layout, "colors")

    def draw(self, context):
        l = self.layout
        try:
            s = getattr(context.scene, "nels", None)
            if not s:
                l.label(text="No scene settings available")
                return

            row = l.row()
            row.template_list("UI_UL_list", "nels_colors", s, "colors", s, "active_color", rows=6)
            col = row.column(align=True)
            o = col.operator("nels.color_tools", text="", icon="ADD"); o.action = "ADD"
            o = col.operator("nels.color_tools", text="", icon="REMOVE"); o.action = "REMOVE"

            if not s.colors:
                l.label(text="No colours found. Initialize defaults.")
                l.operator("nels.initialize_defaults", icon="FILE_REFRESH")
                return

            idx = max(0, min(s.active_color, len(s.colors) - 1))
            c = s.colors[idx]
            l.prop(c, "name")
            l.prop(c, "rgb", text="Colour")
            vrow = l.row()
            vrow.enabled = False
            vrow.prop(c, "value", text="Output")
        except Exception as ex:
            draw_ui_exception(l, context, ex, getattr(self, "bl_label", "general"))

def draw_vehicle_lighting_section(layout, context, s):
    layout.prop(s, "car_headlights_on", text="Headlights")
    layout.prop(s, "car_taillights_on", text="Taillights")
    layout.prop(s, "car_left_indicator_on", text="Left Indicator")
    layout.prop(s, "car_right_indicator_on", text="Right Indicator")
    layout.prop(s, "car_extra_lights_on", text="Extra Lights")
    row = layout.row(align=True)
    o = row.operator("nels.car_lights_sim", text="Apply Light Simulation", icon="LIGHT")
    if o is not None:
        o.action = "APPLY"
    o = row.operator("nels.car_lights_sim", text="Reset Light Simulation", icon="LOOP_BACK")
    if o is not None:
        o.action = "RESET"


def draw_vehicle_wheel_preview_section(layout, context, s):
    layout.label(text="Uses Sollumz Preview Wheel Instances", icon="INFO")
    row = layout.row(align=True)
    o = row.operator("nels.wheel_simulation", text="Preview Wheel Instances", icon="MESH_TORUS")
    if o is not None:
        o.action = "APPLY"
    o = row.operator("nels.wheel_simulation", text="Clear Wheel Preview", icon="TRASH")
    if o is not None:
        o.action = "RESET"


def draw_vehicle_light_ids_section(layout, context, s):
    layout.label(text="Uses Sollumz-style polygon Light IDs", icon="LIGHT")
    ready = light_id_face_select_ready(context)
    detected_light = selected_face_light_id_label(context) if ready else ""
    if detected_light:
        layout.label(text=f"Selected Faces: {detected_light}", icon="INFO")

    set_row = layout.row(align=True)
    set_row.enabled = ready
    set_row.prop(s, "car_light_id_target", text="")
    o = set_row.operator("nels.light_id_faces", text="Set Light ID", icon="MESH_DATA")
    if o is not None:
        o.action = "SET"

    select_row = layout.row(align=True)
    select_row.enabled = ready
    if s.car_light_id_target == "CUSTOM":
        select_row.prop(s, "car_light_id_custom_value", text="Custom Light ID")
    else:
        select_row.label(text="Select faces using the chosen ID")
    o = select_row.operator("nels.light_id_faces", text="Select Light ID", icon="RESTRICT_SELECT_OFF")
    if o is not None:
        o.action = "SELECT"

    if not ready:
        warn = layout.row()
        warn.alert = True
        warn.label(text="Must be in Edit Mode > Face Select", icon="ERROR")


def draw_vehicle_extras_section(layout, context):
    extras = scene_extra_objects(context.scene)
    if not extras:
        layout.label(text="No extras found on scene objects")
        return

    top = layout.row(align=True)
    o = top.operator("nels.extras_visibility_all", text="Show All", icon="HIDE_OFF")
    o.show = True
    o = top.operator("nels.extras_visibility_all", text="Hide All", icon="HIDE_ON")
    o.show = False

    for obj in extras:
        visible = is_object_visible(obj)
        row = layout.row(align=True)
        row.label(text=extra_display_name(obj))
        o = row.operator("nels.extra_visibility", text="Hide" if visible else "Show")
        o.object_name = obj.name
        o.show = not visible


def draw_vehicle_body_openings_section(layout, context, s):
    if not getattr(s, "body_openings", None):
        layout.label(text="No body openings available")
        return

    for opening in s.body_openings:
        sub = layout.box()
        draw_body_opening_controls(sub, context, s, opening)


class VIEW3D_PT_nels_vehicle_lighting(Panel):
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "Tool"
    bl_label = "Lighting"
    bl_options = {"DEFAULT_CLOSED"}

    def draw_header(self, context):
        self.layout.label(text="", icon="LIGHT")

    def draw(self, context):
        layout = self.layout
        try:
            s = getattr(context.scene, "nels", None)
            if not s:
                layout.label(text="No scene settings available")
                return
            draw_vehicle_lighting_section(layout, context, s)
        except Exception as ex:
            draw_ui_exception(layout, context, ex, getattr(self, "bl_label", "general"))


class VIEW3D_PT_nels_vehicle_wheel_preview(Panel):
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "Tool"
    bl_label = "Wheel Preview"
    bl_options = {"DEFAULT_CLOSED"}

    def draw_header(self, context):
        self.layout.label(text="", icon="MESH_TORUS")

    def draw(self, context):
        layout = self.layout
        try:
            s = getattr(context.scene, "nels", None)
            if not s:
                layout.label(text="No scene settings available")
                return
            draw_vehicle_wheel_preview_section(layout, context, s)
        except Exception as ex:
            draw_ui_exception(layout, context, ex, getattr(self, "bl_label", "general"))


class VIEW3D_PT_nels_vehicle_light_ids(Panel):
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "Tool"
    bl_label = "Light ID's"
    bl_options = {"DEFAULT_CLOSED"}

    def draw_header(self, context):
        self.layout.label(text="", icon="MESH_DATA")

    def draw(self, context):
        layout = self.layout
        try:
            s = getattr(context.scene, "nels", None)
            if not s:
                layout.label(text="No scene settings available")
                return
            draw_vehicle_light_ids_section(layout, context, s)
        except Exception as ex:
            draw_ui_exception(layout, context, ex, getattr(self, "bl_label", "general"))


class VIEW3D_PT_nels_vehicle_extras(Panel):
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "Tool"
    bl_label = "Extra's"
    bl_options = {"DEFAULT_CLOSED"}

    def draw_header(self, context):
        self.layout.label(text="", icon="OUTLINER_OB_GROUP_INSTANCE")

    def draw(self, context):
        layout = self.layout
        try:
            draw_vehicle_extras_section(layout, context)
        except Exception as ex:
            draw_ui_exception(layout, context, ex, getattr(self, "bl_label", "general"))


class VIEW3D_PT_nels_vehicle_body_openings(Panel):
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "Tool"
    bl_label = "Body Openings"
    bl_options = {"DEFAULT_CLOSED"}

    def draw_header(self, context):
        draw_panel_header_icon(self.layout, "body_openings")

    def draw(self, context):
        layout = self.layout
        try:
            s = getattr(context.scene, "nels", None)
            if not s:
                layout.label(text="No scene settings available")
                return
            draw_vehicle_body_openings_section(layout, context, s)
        except Exception as ex:
            draw_ui_exception(layout, context, ex, getattr(self, "bl_label", "general"))


class VIEW3D_PT_nels_simulation(Panel):
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "Tool"
    bl_label = "Simulation Preview"
    bl_options = {"DEFAULT_CLOSED"}

    def draw_header(self, context):
        draw_panel_header_icon(self.layout, "simulation")

    def draw(self, context):
        l = self.layout
        try:
            s = getattr(context.scene, "nels", None)
            if not s:
                l.label(text="No scene settings available")
                return

            if s.show_sirens_section and s.sirens:
                selector = l.box()
                selector.label(text="Active Siren")
                selector.prop(s, "tool_working_siren", text="")
                idx = siren_index_from_name(str(getattr(s, "tool_working_siren", "") or ""))
                if not (1 <= idx <= len(s.sirens)):
                    idx = max(0, min(int(getattr(s, "active_siren", 0) or 0), len(s.sirens) - 1)) + 1
                si = s.sirens[max(0, min(idx - 1, len(s.sirens) - 1))]
                l.label(text=f"Scale Factor (from config): {format_scale_factor(scale_factor_from_siren(si, scene=context.scene))}")
                r = l.row(align=True)
                o = r.operator("nels.sim", text="Simulate Siren Off"); o.mode = "OFF"; o.all = False
                o = r.operator("nels.sim", text="Simulate Siren On"); o.mode = "ON"; o.all = False
            else:
                sf = max(0.0, float(getattr(s, "scale_factor", 0.5)))
                l.label(text=f"Scale Factor (from config): {format_scale_factor((1.0 / sf) if sf > 0.0 else 0.0)}")

            r = l.row(align=True)
            o = r.operator("nels.sim", text="Simulate All Sirens Off"); o.mode = "OFF"; o.all = True
            o = r.operator("nels.sim", text="Simulate All Sirens On"); o.mode = "ON"; o.all = True

            l.prop(s, "auto_timeline_preview", text="Auto Rebuild")
            l.operator("nels.preview_clear", text="Clear Timeline", icon="TRASH")
            o = l.operator("nels.preview", text="Preview Active", icon="ANIM_DATA")
            o.scope = "ACTIVE"
            o = l.operator("nels.preview", text="Preview All", icon="ANIM")
            o.scope = "ALL"
        except Exception as ex:
            draw_ui_exception(l, context, ex, getattr(self, "bl_label", "general"))


class VIEW3D_PT_nels_useful_tools(Panel):
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "Tool"
    bl_label = "Useful Tools"
    bl_options = {"DEFAULT_CLOSED"}

    def draw_header(self, context):
        draw_panel_header_icon(self.layout, "useful_tools")

    def draw(self, context):
        l = self.layout
        try:
            s = getattr(context.scene, "nels", None)
            if not s or not s.sirens:
                draw_wrapped_text(l, context, "Please add Sirens to configure them.", icon="INFO")
                return

            selector_box = l.box()
            selector_box.label(text="Working Siren")
            selector_box.prop(s, "tool_working_siren", text="")
            selector_box.label(text="Defaults to the selected scene siren when available", icon="INFO")

            scale_box = l.box()
            scale_box.label(text="Set Siren Scale Position")
            o = scale_box.operator("nels.set_siren_scale_state", text="Set Scale Off", icon="FULLSCREEN_EXIT")
            o.mode = "OFF"
            o = scale_box.operator("nels.set_siren_scale_state", text="Set Scale On", icon="FULLSCREEN_ENTER")
            o.mode = "ON"

            numbering_box = l.box()
            numbering_box.label(text="Siren Numbering")
            numbering_box.operator("nels.duplicate_siren", text="Duplicate Siren", icon="DUPLICATE")
            numbering_box.operator("nels.renumber_siren", text="Renumber Siren", icon="SORTALPHA")

            linking_box = l.box()
            linking_box.label(text="Linking Tools")
            origin_pick = linking_box.row(align=True)
            origin_pick.prop_search(s, "tool_origin_object", context.scene, "objects", text="Match Origin to Object")
            pick = origin_pick.operator("nels.pick_selected_link_target", text="", icon="EYEDROPPER")
            if pick is not None:
                pick.target = "TOOL_ORIGIN_OBJECT"
            linking_box.operator("nels.match_origin_to_object", text="Match Origin", icon="OBJECT_ORIGIN")
            linking_box.operator("nels.move_bone_to_selected", text="Move Bone to Selected", icon="BONE_DATA")
            linking_box.operator("nels.origin_to_selection", text="Set Origin to Selection", icon="PIVOT_CURSOR")
            linking_box.operator("nels.origins_to_bones", text="Set Selected Origins to Bones", icon="CON_TRACKTO")
            linking_box.operator("nels.bones_to_origins", text="Move Linked Bones to Origins", icon="BONE_DATA")


            reset_box = l.box()
            reset_box.label(text="Reset Siren")
            o = reset_box.operator("nels.reset_siren_default_state", text="Reset Active", icon="LOOP_BACK")
            o.all = False
            o = reset_box.operator("nels.reset_siren_default_state", text="Reset All", icon="FILE_REFRESH")
            o.all = True
        except Exception as ex:
            draw_ui_exception(l, context, ex, getattr(self, "bl_label", "general"))


class VIEW3D_PT_nels_updates(Panel):
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "Tool"
    bl_label = "Updates"
    bl_options = {"DEFAULT_CLOSED"}

    def draw_header(self, context):
        draw_panel_header_icon(self.layout, "updates")

    def draw(self, context):
        l = self.layout
        try:
            s = getattr(context.scene, "nels", None)
            if not s:
                l.label(text="No scene settings available")
                return

            current_version = version_to_str(addon_version_tuple())
            l.label(text=f"Current Version: {current_version}")
            l.label(text=f"Latest Version: {displayed_update_version(s) or 'Not checked yet'}")
            if getattr(s, "update_last_checked", ""):
                l.label(text=f"Last Checked: {s.update_last_checked}")
            l.prop(s, "update_check_on_startup", text="Check on Startup")
            l.label(text="Checks GitHub and installs the latest zip", icon="INFO")

            status = str(getattr(s, "update_status", "") or "")
            if getattr(s, "update_restart_required", False):
                box = l.box()
                box.alert = True
                draw_wrapped_text(box, context, status or "Update installed. Restart Blender.", icon="ERROR")
            elif getattr(s, "update_available", False):
                box = l.box()
                box.alert = True
                draw_wrapped_text(box, context, status or "Update available", icon="IMPORT")
            elif status:
                icon = "TIME" if (getattr(s, "update_check_in_progress", False) or getattr(s, "update_install_in_progress", False)) else "INFO"
                draw_wrapped_text(l, context, status, icon=icon)

            row = l.row(align=True)
            row.enabled = not (getattr(s, "update_check_in_progress", False) or getattr(s, "update_install_in_progress", False))
            row.operator("nels.update_check", text="Check Updates", icon="FILE_REFRESH")
            sub = row.row(align=True)
            sub.enabled = bool(getattr(s, "update_available", False))
            sub.operator("nels.update_install", text="Install Update", icon="IMPORT")

            open_row = l.row(align=True)
            open_row.operator("wm.url_open", text="Open GitHub", icon="URL").url = UPDATE_REPO_URL
        except Exception as ex:
            draw_ui_exception(l, context, ex, getattr(self, "bl_label", "general"))


def init_all_scenes_defaults():
    scenes = getattr(bpy.data, "scenes", None)
    if scenes is None:
        return 0.25

    for sc in scenes:
        try:
            ensure_scene_defaults(sc)
        except Exception:
            pass
    return None


def update_auto_timeline_preview(self, context):
    if getattr(self, "auto_timeline_preview", False):
        self.auto_timeline_pending = True
        self.auto_timeline_requested_at = _time.time()
        mark_preview_dirty(context, immediate=False)
    else:
        self.auto_timeline_pending = False


def rebuild_auto_timeline_preview(scene):
    global _LIVE_PREVIEW_GUARD
    s = getattr(scene, "nels", None) if scene else None
    if not s or not getattr(s, "auto_timeline_preview", False):
        return False
    if preview_updates_suspended() or _LIVE_PREVIEW_GUARD:
        return False

    _LIVE_PREVIEW_GUARD = True
    try:
        sirens = list(getattr(s, "sirens", []))
        clear_preview_keyframes(scene, sirens)
        used, _cycle_end = generate_timeline_preview(scene, s, sirens)
        s.preview_generated = bool(used)
        s.preview_dirty = False
        s.auto_timeline_pending = False
        return bool(used)
    finally:
        _LIVE_PREVIEW_GUARD = False


def refresh_live_preview(scene):
    global _LIVE_PREVIEW_GUARD
    s = getattr(scene, "nels", None) if scene else None
    if not s or (not s.preview_generated) or (not s.preview_dirty):
        return False
    if not timeline_playing():
        return False
    if _LIVE_PREVIEW_GUARD:
        return False

    _LIVE_PREVIEW_GUARD = True
    try:
        clear_preview_keyframes(scene, list(s.sirens))
        used, _cycle_end = generate_timeline_preview(scene, s, list(s.sirens))
        if used:
            s.preview_dirty = False
            return True
        return False
    finally:
        _LIVE_PREVIEW_GUARD = False


def car_light_tick_required(s):
    if not s:
        return False
    return bool(
        getattr(s, "car_headlights_on", False)
        or getattr(s, "car_taillights_on", False)
        or getattr(s, "car_left_indicator_on", False)
        or getattr(s, "car_right_indicator_on", False)
        or getattr(s, "car_extra_lights_on", False)
    )


def preview_cache_required(scene, s=None):
    s = s if s is not None else (getattr(scene, "nels", None) if scene else None)
    if not s:
        return False
    if not getattr(s, "all_flash_previews", True):
        return False
    if scene and getattr(s, "preview_generated", False) and timeline_playing():
        return False

    if not panel_drawn_recently(scene, "lightbar"):
        return False
    if getattr(s, "preview_refresh_pending", False):
        return True
    if getattr(s, "head_tail_preview", True):
        return True
    if getattr(s, "show_sirens_section", True) and getattr(s, "show_siren_preview_panel", False) and getattr(s, "siren_preview_running", True):
        return any(bool(getattr(si, "filter_selected", True)) for si in getattr(s, "sirens", []))
    now = _time.time()
    return now < float(getattr(s, "preview_animating_until", 0.0) or 0.0)

def preview_timer_interval(scenes=None):
    interval = 0.50
    scene_iter = scenes if scenes is not None else getattr(bpy.data, "scenes", None)
    if not scene_iter:
        return interval

    for sc in scene_iter:
        s = getattr(sc, "nels", None) if sc else None
        if not s:
            continue
        playing_preview = bool(sc and getattr(s, "preview_generated", False) and timeline_playing())
        if playing_preview and not car_light_tick_required(s) and not getattr(s, "preview_refresh_pending", False):
            continue
        if not (preview_cache_required(sc, s) or car_light_tick_required(s)):
            continue
        bpm = max(1.0, float(getattr(s, "bpm", 800) or 800))
        step_seconds = 60.0 / bpm
        # When the timeline preview itself is playing, keep timer work coarse to avoid fighting viewport FPS.
        if playing_preview:
            target = 0.20 if car_light_tick_required(s) else 0.35
        else:
            target = max(0.08, min(0.15, step_seconds))
        interval = min(interval, target)
    return interval


def nels_preview_tick():
    scenes = getattr(bpy.data, "scenes", None)
    interval = preview_timer_interval(scenes)
    needs_redraw = False
    if scenes:
        now = _time.time()
        needs_redraw = apply_update_job_result() or needs_redraw
        for sc in scenes:
            try:
                s = getattr(sc, "nels", None)
                if not s:
                    continue
                playing_preview = bool(getattr(s, "preview_generated", False) and timeline_playing())
                refresh_direction_warning(sc)
                if not playing_preview:
                    last_detect = float(getattr(s, "body_opening_autodetect_at", 0.0) or 0.0)
                    if (now - last_detect) >= 2.5:
                        needs_redraw = auto_detect_body_opening_links(sc, s) or needs_redraw
                        s.body_opening_autodetect_at = now
                    needs_redraw = sync_tool_working_siren(sc, s) or needs_redraw
                if getattr(s, "auto_timeline_preview", False) and getattr(s, "auto_timeline_pending", False):
                    requested = float(getattr(s, "auto_timeline_requested_at", 0.0) or 0.0)
                    if (now - requested) >= 0.15:
                        needs_redraw = rebuild_auto_timeline_preview(sc) or needs_redraw
                if car_light_tick_required(s):
                    apply_car_light_simulation(sc, s, blink_indicators=True)
                if preview_cache_required(sc, s):
                    needs_redraw = refresh_siren_preview_cache(sc) or needs_redraw
                needs_redraw = update_preview_refresh_feedback(sc) or needs_redraw
            except Exception:
                pass

    wm = getattr(bpy.context, "window_manager", None)
    if not wm:
        return interval

    if needs_redraw:
        tag_preview_ui_redraw()
    return interval


class NELS_ToolPanelMixin:
    panel_location_target = "TOOL"

    @classmethod
    def poll(cls, context):
        return panel_location_visible(cls.panel_location_target, context)


class NELS_ViewportPanelMixin:
    panel_location_target = "VIEWPORT"

    @classmethod
    def poll(cls, context):
        return panel_location_visible(cls.panel_location_target, context)


class VIEW3D_PT_nels_group_general(Panel):
    bl_label = "General"
    bl_options = {"DEFAULT_CLOSED"}

    def draw_header(self, context):
        draw_panel_header_icon(self.layout, "gta000", context)

    def draw(self, context):
        pass


class VIEW3D_PT_nels_group_vehicle(Panel):
    bl_label = "Vehicle"
    bl_options = {"DEFAULT_CLOSED"}

    def draw_header(self, context):
        self.layout.label(text="", icon="SCENE_DATA")

    def draw(self, context):
        pass


class VIEW3D_PT_nels_group_asset_library(Panel):
    bl_label = "Asset Library"
    bl_options = {"DEFAULT_CLOSED"}

    def draw_header(self, context):
        self.layout.label(text="", icon="FILEBROWSER")

    def draw(self, context):
        pass


class VIEW3D_PT_nels_group_libraries(Panel):
    bl_label = "Config Libraries"
    bl_options = {"DEFAULT_CLOSED"}

    def draw_header(self, context):
        self.layout.label(text="", icon="FILE_FOLDER")

    def draw(self, context):
        pass


class VIEW3D_PT_nels_group_lightbars(Panel):
    bl_label = "Lightbars"
    bl_options = {"DEFAULT_CLOSED"}

    def draw_header(self, context):
        draw_panel_header_icon(self.layout, "lightbar", context)

    def draw(self, context):
        pass


class VIEW3D_PT_nels_group_assets_config(Panel):
    bl_label = "Assets"
    bl_options = {"DEFAULT_CLOSED"}

    def draw_header(self, context):
        self.layout.label(text="", icon="ASSET_MANAGER")

    def draw(self, context):
        pass


class VIEW3D_PT_nels_group_updates_information(Panel):
    bl_label = "Updates and Information"
    bl_options = {"DEFAULT_CLOSED"}

    def draw_header(self, context):
        self.layout.label(text="", icon="INFO")

    def draw(self, context):
        pass


class VIEW3D_PT_nels_group_general_tool(NELS_ToolPanelMixin, VIEW3D_PT_nels_group_general, Panel):
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "Tool"
    bl_label = "General"
    bl_options = {"DEFAULT_CLOSED"}


class VIEW3D_PT_nels_group_vehicle_tool(NELS_ToolPanelMixin, VIEW3D_PT_nels_group_vehicle, Panel):
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "Tool"
    bl_label = "Vehicle"
    bl_options = {"DEFAULT_CLOSED"}


class VIEW3D_PT_nels_group_asset_library_tool(NELS_ToolPanelMixin, VIEW3D_PT_nels_group_asset_library, Panel):
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "Tool"
    bl_label = "Asset Library"
    bl_options = {"DEFAULT_CLOSED"}


class VIEW3D_PT_nels_group_libraries_tool(NELS_ToolPanelMixin, VIEW3D_PT_nels_group_libraries, Panel):
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "Tool"
    bl_label = "Config Libraries"
    bl_options = {"DEFAULT_CLOSED"}


class VIEW3D_PT_nels_group_lightbars_tool(NELS_ToolPanelMixin, VIEW3D_PT_nels_group_lightbars, Panel):
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "Tool"
    bl_label = "Lightbars"
    bl_parent_id = "VIEW3D_PT_nels_group_libraries_tool"
    bl_options = {"DEFAULT_CLOSED"}


class VIEW3D_PT_nels_group_assets_config_tool(NELS_ToolPanelMixin, VIEW3D_PT_nels_group_assets_config, Panel):
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "Tool"
    bl_label = "Assets"
    bl_parent_id = "VIEW3D_PT_nels_group_libraries_tool"
    bl_options = {"DEFAULT_CLOSED"}


class VIEW3D_PT_nels_group_updates_information_tool(NELS_ToolPanelMixin, VIEW3D_PT_nels_group_updates_information, Panel):
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "Tool"
    bl_label = "Updates and Information"
    bl_options = {"DEFAULT_CLOSED"}


class VIEW3D_PT_nels_tool(NELS_ToolPanelMixin, VIEW3D_PT_nels, Panel):
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "Tool"
    bl_label = "Lightbar Setup"
    bl_parent_id = "VIEW3D_PT_nels_group_general_tool"
    bl_options = {"DEFAULT_CLOSED"}


class VIEW3D_PT_nels_patterns_tool(NELS_ToolPanelMixin, VIEW3D_PT_nels_patterns, Panel):
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "Tool"
    bl_label = "Flash Patterns"
    bl_parent_id = "VIEW3D_PT_nels_group_lightbars_tool"
    bl_options = {"DEFAULT_CLOSED"}


class VIEW3D_PT_nels_colors_tool(NELS_ToolPanelMixin, VIEW3D_PT_nels_colors, Panel):
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "Tool"
    bl_label = "Colours"
    bl_parent_id = "VIEW3D_PT_nels_group_lightbars_tool"
    bl_options = {"DEFAULT_CLOSED"}


class VIEW3D_PT_nels_vehicle_lighting_tool(NELS_ToolPanelMixin, VIEW3D_PT_nels_vehicle_lighting, Panel):
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "Tool"
    bl_label = "Lighting"
    bl_parent_id = "VIEW3D_PT_nels_group_vehicle_tool"
    bl_options = {"DEFAULT_CLOSED"}


class VIEW3D_PT_nels_vehicle_wheel_preview_tool(NELS_ToolPanelMixin, VIEW3D_PT_nels_vehicle_wheel_preview, Panel):
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "Tool"
    bl_label = "Wheel Preview"
    bl_parent_id = "VIEW3D_PT_nels_group_vehicle_tool"
    bl_options = {"DEFAULT_CLOSED"}

    @classmethod
    def poll(cls, context):
        return super().poll(context) and bool(sollumz_enabled())


class VIEW3D_PT_nels_vehicle_light_ids_tool(NELS_ToolPanelMixin, VIEW3D_PT_nels_vehicle_light_ids, Panel):
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "Tool"
    bl_label = "Light ID's"
    bl_parent_id = "VIEW3D_PT_nels_group_vehicle_tool"
    bl_options = {"DEFAULT_CLOSED"}


class VIEW3D_PT_nels_vehicle_extras_tool(NELS_ToolPanelMixin, VIEW3D_PT_nels_vehicle_extras, Panel):
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "Tool"
    bl_label = "Extra's"
    bl_parent_id = "VIEW3D_PT_nels_group_vehicle_tool"
    bl_options = {"DEFAULT_CLOSED"}


class VIEW3D_PT_nels_vehicle_body_openings_tool(NELS_ToolPanelMixin, VIEW3D_PT_nels_vehicle_body_openings, Panel):
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "Tool"
    bl_label = "Body Openings"
    bl_parent_id = "VIEW3D_PT_nels_group_vehicle_tool"
    bl_options = {"DEFAULT_CLOSED"}


class VIEW3D_PT_nels_simulation_tool(NELS_ToolPanelMixin, VIEW3D_PT_nels_simulation, Panel):
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "Tool"
    bl_label = "Simulation"
    bl_parent_id = "VIEW3D_PT_nels_tool"
    bl_options = {"DEFAULT_CLOSED"}


class VIEW3D_PT_nels_useful_tools_tool(NELS_ToolPanelMixin, VIEW3D_PT_nels_useful_tools, Panel):
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "Tool"
    bl_label = "Useful Tools"
    bl_parent_id = "VIEW3D_PT_nels_group_general_tool"
    bl_options = {"DEFAULT_CLOSED"}


class VIEW3D_PT_nels_updates_tool(NELS_ToolPanelMixin, VIEW3D_PT_nels_updates, Panel):
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "Tool"
    bl_label = "Updates"
    bl_parent_id = "VIEW3D_PT_nels_group_updates_information_tool"
    bl_options = {"DEFAULT_CLOSED"}


class VIEW3D_PT_nels_asset_library_assets(Panel):
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "Tool"
    bl_label = "Asset's"
    bl_options = {"DEFAULT_CLOSED"}

    def draw_header(self, context):
        self.layout.label(text="", icon="FILEBROWSER")

    def draw(self, context):
        layout = self.layout
        try:
            draw_asset_library_assets(self, context)
        except Exception as ex:
            draw_ui_exception(layout, context, ex, getattr(self, "bl_label", "general"))


class VIEW3D_PT_nels_asset_library_details(Panel):
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "Tool"
    bl_label = "Asset Details"
    bl_options = {"DEFAULT_CLOSED"}

    def draw_header(self, context):
        self.layout.label(text="", icon="INFO")

    def draw(self, context):
        layout = self.layout
        try:
            draw_asset_library_details(self, context)
        except Exception as ex:
            draw_ui_exception(layout, context, ex, getattr(self, "bl_label", "general"))


class VIEW3D_PT_nels_asset_library_paths(Panel):
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "Tool"
    bl_label = "Asset Library Path"
    bl_options = {"DEFAULT_CLOSED"}

    def draw_header(self, context):
        self.layout.label(text="", icon="FILE_FOLDER")

    def draw(self, context):
        layout = self.layout
        try:
            draw_asset_library_paths(self, context)
        except Exception as ex:
            draw_ui_exception(layout, context, ex, getattr(self, "bl_label", "general"))


class VIEW3D_PT_nels_asset_library_information(Panel):
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "Tool"
    bl_label = "Information"
    bl_options = {"DEFAULT_CLOSED"}

    def draw_header(self, context):
        self.layout.label(text="", icon="INFO")

    def draw(self, context):
        layout = self.layout
        try:
            draw_asset_library_information(self, context)
        except Exception as ex:
            draw_ui_exception(layout, context, ex, getattr(self, "bl_label", "general"))


class VIEW3D_PT_nels_asset_categories(Panel):
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "Tool"
    bl_label = "Categories"
    bl_options = {"DEFAULT_CLOSED"}

    def draw_header(self, context):
        self.layout.label(text="", icon="FILE_FOLDER")

    def draw(self, context):
        layout = self.layout
        try:
            draw_asset_library_categories(self, context)
        except Exception as ex:
            draw_ui_exception(layout, context, ex, getattr(self, "bl_label", "general"))


class VIEW3D_PT_nels_asset_subcategories(Panel):
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "Tool"
    bl_label = "Sub-Categories"
    bl_options = {"DEFAULT_CLOSED"}

    def draw_header(self, context):
        self.layout.label(text="", icon="TRIA_RIGHT")

    def draw(self, context):
        layout = self.layout
        try:
            draw_asset_library_subcategories(self, context)
        except Exception as ex:
            draw_ui_exception(layout, context, ex, getattr(self, "bl_label", "general"))


class VIEW3D_PT_nels_asset_tags(Panel):
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "Tool"
    bl_label = "Tags"
    bl_options = {"DEFAULT_CLOSED"}

    def draw_header(self, context):
        self.layout.label(text="", icon="BOOKMARKS")

    def draw(self, context):
        layout = self.layout
        try:
            draw_asset_library_tags(self, context)
        except Exception as ex:
            draw_ui_exception(layout, context, ex, getattr(self, "bl_label", "general"))


class VIEW3D_PT_nels_group_general_tab(NELS_ViewportPanelMixin, VIEW3D_PT_nels_group_general, Panel):
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "GTA 000"
    bl_label = "General"
    bl_options = {"DEFAULT_CLOSED"}


class VIEW3D_PT_nels_group_vehicle_tab(NELS_ViewportPanelMixin, VIEW3D_PT_nels_group_vehicle, Panel):
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "GTA 000"
    bl_label = "Vehicle"
    bl_options = {"DEFAULT_CLOSED"}


class VIEW3D_PT_nels_group_asset_library_tab(NELS_ViewportPanelMixin, VIEW3D_PT_nels_group_asset_library, Panel):
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "GTA 000"
    bl_label = "Asset Library"
    bl_options = {"DEFAULT_CLOSED"}


class VIEW3D_PT_nels_group_libraries_tab(NELS_ViewportPanelMixin, VIEW3D_PT_nels_group_libraries, Panel):
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "GTA 000"
    bl_label = "Config Libraries"
    bl_options = {"DEFAULT_CLOSED"}


class VIEW3D_PT_nels_group_lightbars_tab(NELS_ViewportPanelMixin, VIEW3D_PT_nels_group_lightbars, Panel):
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "GTA 000"
    bl_label = "Lightbars"
    bl_parent_id = "VIEW3D_PT_nels_group_libraries_tab"
    bl_options = {"DEFAULT_CLOSED"}


class VIEW3D_PT_nels_group_assets_config_tab(NELS_ViewportPanelMixin, VIEW3D_PT_nels_group_assets_config, Panel):
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "GTA 000"
    bl_label = "Assets"
    bl_parent_id = "VIEW3D_PT_nels_group_libraries_tab"
    bl_options = {"DEFAULT_CLOSED"}


class VIEW3D_PT_nels_group_updates_information_tab(NELS_ViewportPanelMixin, VIEW3D_PT_nels_group_updates_information, Panel):
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "GTA 000"
    bl_label = "Updates and Information"
    bl_options = {"DEFAULT_CLOSED"}


class VIEW3D_PT_nels_tab(NELS_ViewportPanelMixin, VIEW3D_PT_nels, Panel):
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "GTA 000"
    bl_label = "Lightbar Setup"
    bl_parent_id = "VIEW3D_PT_nels_group_general_tab"
    bl_options = {"DEFAULT_CLOSED"}


class VIEW3D_PT_nels_patterns_tab(NELS_ViewportPanelMixin, VIEW3D_PT_nels_patterns, Panel):
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "GTA 000"
    bl_label = "Flash Patterns"
    bl_parent_id = "VIEW3D_PT_nels_group_lightbars_tab"
    bl_options = {"DEFAULT_CLOSED"}


class VIEW3D_PT_nels_colors_tab(NELS_ViewportPanelMixin, VIEW3D_PT_nels_colors, Panel):
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "GTA 000"
    bl_label = "Colours"
    bl_parent_id = "VIEW3D_PT_nels_group_lightbars_tab"
    bl_options = {"DEFAULT_CLOSED"}


class VIEW3D_PT_nels_vehicle_lighting_tab(NELS_ViewportPanelMixin, VIEW3D_PT_nels_vehicle_lighting, Panel):
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "GTA 000"
    bl_label = "Lighting"
    bl_parent_id = "VIEW3D_PT_nels_group_vehicle_tab"
    bl_options = {"DEFAULT_CLOSED"}


class VIEW3D_PT_nels_vehicle_wheel_preview_tab(NELS_ViewportPanelMixin, VIEW3D_PT_nels_vehicle_wheel_preview, Panel):
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "GTA 000"
    bl_label = "Wheel Preview"
    bl_parent_id = "VIEW3D_PT_nels_group_vehicle_tab"
    bl_options = {"DEFAULT_CLOSED"}

    @classmethod
    def poll(cls, context):
        return super().poll(context) and bool(sollumz_enabled())


class VIEW3D_PT_nels_vehicle_light_ids_tab(NELS_ViewportPanelMixin, VIEW3D_PT_nels_vehicle_light_ids, Panel):
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "GTA 000"
    bl_label = "Light ID's"
    bl_parent_id = "VIEW3D_PT_nels_group_vehicle_tab"
    bl_options = {"DEFAULT_CLOSED"}


class VIEW3D_PT_nels_vehicle_extras_tab(NELS_ViewportPanelMixin, VIEW3D_PT_nels_vehicle_extras, Panel):
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "GTA 000"
    bl_label = "Extra's"
    bl_parent_id = "VIEW3D_PT_nels_group_vehicle_tab"
    bl_options = {"DEFAULT_CLOSED"}


class VIEW3D_PT_nels_vehicle_body_openings_tab(NELS_ViewportPanelMixin, VIEW3D_PT_nels_vehicle_body_openings, Panel):
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "GTA 000"
    bl_label = "Body Openings"
    bl_parent_id = "VIEW3D_PT_nels_group_vehicle_tab"
    bl_options = {"DEFAULT_CLOSED"}


class VIEW3D_PT_nels_simulation_tab(NELS_ViewportPanelMixin, VIEW3D_PT_nels_simulation, Panel):
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "GTA 000"
    bl_label = "Simulation"
    bl_parent_id = "VIEW3D_PT_nels_tab"
    bl_options = {"DEFAULT_CLOSED"}


class VIEW3D_PT_nels_useful_tools_tab(NELS_ViewportPanelMixin, VIEW3D_PT_nels_useful_tools, Panel):
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "GTA 000"
    bl_label = "Useful Tools"
    bl_parent_id = "VIEW3D_PT_nels_group_general_tab"
    bl_options = {"DEFAULT_CLOSED"}


class VIEW3D_PT_nels_updates_tab(NELS_ViewportPanelMixin, VIEW3D_PT_nels_updates, Panel):
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "GTA 000"
    bl_label = "Updates"
    bl_parent_id = "VIEW3D_PT_nels_group_updates_information_tab"
    bl_options = {"DEFAULT_CLOSED"}


class VIEW3D_PT_nels_asset_library_assets_tool(NELS_ToolPanelMixin, VIEW3D_PT_nels_asset_library_assets, Panel):
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "Tool"
    bl_label = "Asset's"
    bl_parent_id = "VIEW3D_PT_nels_group_asset_library_tool"
    bl_options = {"DEFAULT_CLOSED"}


class VIEW3D_PT_nels_asset_library_details_tool(NELS_ToolPanelMixin, VIEW3D_PT_nels_asset_library_details, Panel):
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "Tool"
    bl_label = "Asset Details"
    bl_parent_id = "VIEW3D_PT_nels_group_asset_library_tool"
    bl_options = {"DEFAULT_CLOSED"}


class VIEW3D_PT_nels_asset_library_paths_tool(NELS_ToolPanelMixin, VIEW3D_PT_nels_asset_library_paths, Panel):
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "Tool"
    bl_label = "Asset Library Path"
    bl_parent_id = "VIEW3D_PT_nels_group_updates_information_tool"
    bl_options = {"DEFAULT_CLOSED"}


class VIEW3D_PT_nels_asset_library_information_tool(NELS_ToolPanelMixin, VIEW3D_PT_nels_asset_library_information, Panel):
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "Tool"
    bl_label = "Information"
    bl_parent_id = "VIEW3D_PT_nels_group_updates_information_tool"
    bl_options = {"DEFAULT_CLOSED"}


class VIEW3D_PT_nels_asset_categories_tool(NELS_ToolPanelMixin, VIEW3D_PT_nels_asset_categories, Panel):
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "Tool"
    bl_label = "Categories"
    bl_parent_id = "VIEW3D_PT_nels_group_assets_config_tool"
    bl_options = {"DEFAULT_CLOSED"}


class VIEW3D_PT_nels_asset_subcategories_tool(NELS_ToolPanelMixin, VIEW3D_PT_nels_asset_subcategories, Panel):
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "Tool"
    bl_label = "Sub-Categories"
    bl_parent_id = "VIEW3D_PT_nels_group_assets_config_tool"
    bl_options = {"DEFAULT_CLOSED"}


class VIEW3D_PT_nels_asset_tags_tool(NELS_ToolPanelMixin, VIEW3D_PT_nels_asset_tags, Panel):
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "Tool"
    bl_label = "Tags"
    bl_parent_id = "VIEW3D_PT_nels_group_assets_config_tool"
    bl_options = {"DEFAULT_CLOSED"}


class VIEW3D_PT_nels_asset_library_assets_tab(NELS_ViewportPanelMixin, VIEW3D_PT_nels_asset_library_assets, Panel):
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "GTA 000"
    bl_label = "Asset's"
    bl_parent_id = "VIEW3D_PT_nels_group_asset_library_tab"
    bl_options = {"DEFAULT_CLOSED"}


class VIEW3D_PT_nels_asset_library_details_tab(NELS_ViewportPanelMixin, VIEW3D_PT_nels_asset_library_details, Panel):
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "GTA 000"
    bl_label = "Asset Details"
    bl_parent_id = "VIEW3D_PT_nels_group_asset_library_tab"
    bl_options = {"DEFAULT_CLOSED"}


class VIEW3D_PT_nels_asset_library_paths_tab(NELS_ViewportPanelMixin, VIEW3D_PT_nels_asset_library_paths, Panel):
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "GTA 000"
    bl_label = "Asset Library Path"
    bl_parent_id = "VIEW3D_PT_nels_group_updates_information_tab"
    bl_options = {"DEFAULT_CLOSED"}


class VIEW3D_PT_nels_asset_library_information_tab(NELS_ViewportPanelMixin, VIEW3D_PT_nels_asset_library_information, Panel):
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "GTA 000"
    bl_label = "Information"
    bl_parent_id = "VIEW3D_PT_nels_group_updates_information_tab"
    bl_options = {"DEFAULT_CLOSED"}


class VIEW3D_PT_nels_asset_categories_tab(NELS_ViewportPanelMixin, VIEW3D_PT_nels_asset_categories, Panel):
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "GTA 000"
    bl_label = "Categories"
    bl_parent_id = "VIEW3D_PT_nels_group_assets_config_tab"
    bl_options = {"DEFAULT_CLOSED"}


class VIEW3D_PT_nels_asset_subcategories_tab(NELS_ViewportPanelMixin, VIEW3D_PT_nels_asset_subcategories, Panel):
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "GTA 000"
    bl_label = "Sub-Categories"
    bl_parent_id = "VIEW3D_PT_nels_group_assets_config_tab"
    bl_options = {"DEFAULT_CLOSED"}


class VIEW3D_PT_nels_asset_tags_tab(NELS_ViewportPanelMixin, VIEW3D_PT_nels_asset_tags, Panel):
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "GTA 000"
    bl_label = "Tags"
    bl_parent_id = "VIEW3D_PT_nels_group_assets_config_tab"
    bl_options = {"DEFAULT_CLOSED"}
@persistent
def nels_load_post(_dummy):
    init_all_scenes_defaults()


OPERATOR_DESCRIPTIONS = {
    "nels.initialize_defaults": "Initialize GTA 000 Tools defaults for the current scene.",
    "nels.pattern_tools": "Add, duplicate, remove, repeat, or invert flash patterns.",
    "nels.save_siren_pattern": "Save the active siren's unsaved pattern to the flash pattern library.",
    "nels.pattern_duplicate_resolution": "Resolve duplicate flash pattern names in the pattern library.",
    "nels.pattern_library_io": "Import or export the flash pattern library as JSON.",
    "nels.color_tools": "Add or remove colour library entries.",
    "nels.other_attr_tools": "Add or remove entries in the Other Attributes list.",
    "nels.light_id_faces": "Assign the chosen Sollumz-style Light ID to selected faces or select faces that already use that Light ID.",
    "nels.car_lights_sim": "Apply or reset the current car light simulation state in the scene.",
    "nels.wheel_simulation": "Use Sollumz Preview Wheel Instances for the active vehicle fragment, or clear generated wheel preview objects.",
    "nels.extra_visibility": "Show or hide the selected extra object.",
    "nels.environment_lights": "Create or remove generated environment preview lights aligned to the linked siren mesh or bone direction.",
    "nels.extras_visibility_all": "Show or hide all detected extras in the current scene.",
    "nels.set_siren_count": "Set how many non-ELS sirens are present in the current configuration.",
    "nels.duplicate_siren": "Duplicate the active siren mesh hierarchy to a new siren number and retarget its names, weights, and linked references.",
    "nels.swap_sirens": "Swap two linked siren meshes and bones in the scene while keeping the siren configuration rows unchanged.",
    "nels.auto_detect": "Auto-detect siren meshes and bones from scene names and existing links.",
    "nels.generate_siren_id": "Generate a siren ID value for the current vehicle configuration.",
    "nels.new_save_load": "Create, save, load, delete, or reset Blender-side lightbar configurations.",
    "nels.export_config": "Export the current Blender-side lightbar configuration to a JSON file.",
    "nels.import_config": "Import a Blender-side lightbar configuration from a JSON file.",
    "nels.import_carcols": "Import a GTA V carcols.meta file into the current Blender scene.",
    "nels.choose_parent_skeleton": "Choose which armature should be used as the parent skeleton.",
    "nels.sollumz_enable": "Enable an installed Sollumz addon so GTA 000 Tools features that depend on Sollumz can work.",
    "nels.sollumz_install": "Download the latest official Sollumz release zip from GitHub, install it into Blender, and try to enable it automatically.",
    "nels.link_bone": "Assign the selected object to the siren, place a siren bone at the selected origin, or copy a helper object origin onto the active siren mesh.",
    "nels.pick_selected_link_target": "Assign the active selected mesh or selected bone to the current siren or body opening from the current scene.",
    "nels.match_origin_to_object": "Move the working siren origin to the chosen helper object and then clear the helper selection field.",
    "nels.select_linked_siren": "Select the linked siren mesh when available, or fall back to the linked siren bone on its parent skeleton.",
    "nels.origin_to_selection": "In Edit Mode, move the active mesh origin to the midpoint of the selected vertices, edges, or faces without moving the mesh in world space.",
    "nels.origins_to_bones": "In Object Mode, move each selected mesh origin to its linked siren bone location without moving the mesh in world space.",
    "nels.bones_to_origins": "In Object Mode, move each linked siren or body-opening bone to the origin of its selected mesh while preserving the current bone direction.",
    "nels.move_bone_to_selected": "Move the resolved active siren bone to the selected object origin while preserving its current direction.",
    "nels.sim": "Simulate active or all sirens in their shown or hidden state.",
    "nels.set_siren_scale_state": "Bake the resolved siren mesh so the current visible size becomes the correct shown or hidden state without moving its origin.",
    "nels.reset_siren_default_state": "Clear preview transforms and restore the resolved siren or all sirens to their stored default pose.",
    "nels.renumber_siren": "Rename the selected siren mesh, linked sub-meshes, and linked bone hierarchy to an unused siren number in the current configuration.",
    "nels.preview_clear": "Clear generated siren preview keyframes from the timeline.",
    "nels.update_check": "Check the GTA000Tools GitHub repository for a newer addon version.",
    "nels.update_install": "Download the latest addon zip from GitHub, replace the installed addon files, and prompt for a Blender restart.",
    "nels.refresh_pattern_previews": "Force-refresh all siren, headlight, and taillight preview swatches.",
    "nels.siren_preview_control": "Start or stop the animated siren preview swatches in the siren preview panel.",
    "nels.siren_filter_bulk": "Show all sirens, hide all sirens, or filter the siren list by a specific direction.",
    "nels.preview": "Generate a timeline preview for the active siren or for all sirens.",
    "nels.export": "Export the current setup as a carcols.meta file.",
    "nels.siren_status_info": "Show the current siren link status and any missing mesh or bone requirements.",
    "nels.body_opening_link": "Assign the selected mesh to the active body opening, match its origin to a helper object, or place its linked bone on the parent skeleton.",
    "nels.body_opening_state": "Capture or apply the open and closed preview state for the active body opening.",
}


def apply_operator_descriptions():
    for cls in classes:
        try:
            if not issubclass(cls, Operator):
                continue
        except Exception:
            continue
        if "description" in cls.__dict__:
            continue
        if "bl_description" in cls.__dict__ and str(getattr(cls, "bl_description", "") or "").strip():
            continue
        desc = str(OPERATOR_DESCRIPTIONS.get(getattr(cls, "bl_idname", ""), "") or "").strip()
        if desc:
            cls.bl_description = desc


classes = (
    GTA000TOOLS_Preferences,
    NELSPattern,
    NELSColor,
    NELSOtherAttribute,
    NELSBodyOpening,
    NELSSiren,
    NELSSettings,
    NELS_OT_pattern_tools,
    NELS_OT_save_siren_pattern,
    NELS_OT_pattern_library_io,
    NELS_OT_pattern_duplicate_resolution,
    NELS_OT_color_tools,
    NELS_OT_other_attr_tools,
    NELS_OT_light_id_faces,
    NELS_OT_car_lights_sim,
    NELS_OT_wheel_simulation,
    NELS_OT_extra_visibility,
    NELS_OT_environment_lights,
    NELS_OT_extras_visibility_all,
    NELS_OT_initialize_defaults,
    NELS_OT_set_siren_count,
    NELS_OT_duplicate_siren,
    NELS_OT_swap_sirens,
    NELS_OT_auto_detect,
    NELS_OT_generate_siren_id,
    NELS_OT_new_save_load,
    NELS_OT_export_config,
    NELS_OT_import_config,
    NELS_OT_import_carcols,
    NELS_MT_siren_actions,
    NELS_MT_config_actions,
    NELS_OT_choose_parent_skeleton,
    NELS_OT_sollumz_enable,
    NELS_OT_sollumz_install,
    NELS_OT_link_bone,
    NELS_OT_pick_selected_link_target,
    NELS_OT_match_origin_to_object,
    NELS_OT_select_linked_siren,
    NELS_OT_origin_to_selection,
    NELS_OT_origins_to_bones,
    NELS_OT_bones_to_origins,
    NELS_OT_move_bone_to_selected,
    NELS_OT_body_opening_link,
    NELS_OT_body_opening_state,
    NELS_OT_sim,
    NELS_OT_set_siren_scale_state,
    NELS_OT_reset_siren_default_state,
    NELS_OT_renumber_siren,
    NELS_OT_preview_clear,
    NELS_OT_update_check,
    NELS_OT_update_install,
    NELS_OT_siren_preview_control,
    NELS_OT_refresh_pattern_previews,
    NELS_OT_siren_filter_bulk,
    NELS_OT_preview,
    NELS_OT_export,
    NELS_OT_siren_status_info,
    VIEW3D_MT_nels,
    VIEW3D_MT_nels_context_object,
    VIEW3D_MT_nels_context_edit,
    NELS_UL_sirens,
    NELS_UL_patterns,
    VIEW3D_PT_nels_group_general_tool,
    VIEW3D_PT_nels_group_vehicle_tool,
    VIEW3D_PT_nels_group_asset_library_tool,
    VIEW3D_PT_nels_group_libraries_tool,
    VIEW3D_PT_nels_group_lightbars_tool,
    VIEW3D_PT_nels_group_assets_config_tool,
    VIEW3D_PT_nels_group_updates_information_tool,
    VIEW3D_PT_nels_tool,
    VIEW3D_PT_nels_useful_tools_tool,
    VIEW3D_PT_nels_vehicle_body_openings_tool,
    VIEW3D_PT_nels_vehicle_extras_tool,
    VIEW3D_PT_nels_vehicle_lighting_tool,
    VIEW3D_PT_nels_vehicle_light_ids_tool,
    VIEW3D_PT_nels_vehicle_wheel_preview_tool,
    VIEW3D_PT_nels_asset_library_assets_tool,
    VIEW3D_PT_nels_asset_library_details_tool,
    VIEW3D_PT_nels_patterns_tool,
    VIEW3D_PT_nels_colors_tool,
    VIEW3D_PT_nels_asset_categories_tool,
    VIEW3D_PT_nels_asset_subcategories_tool,
    VIEW3D_PT_nels_asset_tags_tool,
    VIEW3D_PT_nels_updates_tool,
    VIEW3D_PT_nels_asset_library_paths_tool,
    VIEW3D_PT_nels_asset_library_information_tool,
    VIEW3D_PT_nels_simulation_tool,
    VIEW3D_PT_nels_group_general_tab,
    VIEW3D_PT_nels_group_vehicle_tab,
    VIEW3D_PT_nels_group_asset_library_tab,
    VIEW3D_PT_nels_group_libraries_tab,
    VIEW3D_PT_nels_group_lightbars_tab,
    VIEW3D_PT_nels_group_assets_config_tab,
    VIEW3D_PT_nels_group_updates_information_tab,
    VIEW3D_PT_nels_tab,
    VIEW3D_PT_nels_useful_tools_tab,
    VIEW3D_PT_nels_vehicle_body_openings_tab,
    VIEW3D_PT_nels_vehicle_extras_tab,
    VIEW3D_PT_nels_vehicle_lighting_tab,
    VIEW3D_PT_nels_vehicle_light_ids_tab,
    VIEW3D_PT_nels_vehicle_wheel_preview_tab,
    VIEW3D_PT_nels_asset_library_assets_tab,
    VIEW3D_PT_nels_asset_library_details_tab,
    VIEW3D_PT_nels_patterns_tab,
    VIEW3D_PT_nels_colors_tab,
    VIEW3D_PT_nels_asset_categories_tab,
    VIEW3D_PT_nels_asset_subcategories_tab,
    VIEW3D_PT_nels_asset_tags_tab,
    VIEW3D_PT_nels_updates_tab,
    VIEW3D_PT_nels_asset_library_paths_tab,
    VIEW3D_PT_nels_asset_library_information_tab,
    VIEW3D_PT_nels_simulation_tab,
)
apply_operator_descriptions()

LEGACY_CLASS_NAMES = (
    "NELS_UL_body_openings",
    "VIEW3D_PT_nels_body_openings",
    "VIEW3D_PT_nels_body_openings_tool",
    "VIEW3D_PT_nels_body_openings_tab",
    "VIEW3D_PT_nels_car_functions",
    "VIEW3D_PT_nels_car_functions_tool",
    "VIEW3D_PT_nels_car_functions_tab",
)


def cleanup_legacy_classes():
    for name in LEGACY_CLASS_NAMES:
        cls = getattr(bpy.types, name, None)
        if cls is None:
            continue
        try:
            bpy.utils.unregister_class(cls)
        except Exception:
            pass


def register():
    global _UPDATE_STARTUP_SCHEDULED
    _UPDATE_STARTUP_SCHEDULED = False
    cleanup_legacy_classes()
    cleanup_stale_external_addon_preferences()
    register_panel_icons()
    remove_custom_preview_draw_handler()
    register_asset_library_integration()
    apply_operator_descriptions()
    for c in classes:
        bpy.utils.register_class(c)
    bpy.types.Scene.nels = PointerProperty(type=NELSSettings)
    bpy.types.VIEW3D_MT_object.append(draw_obj_menu)
    bpy.types.VIEW3D_MT_object_context_menu.prepend(draw_object_context_menu)
    bpy.types.VIEW3D_MT_edit_mesh_context_menu.prepend(draw_edit_mesh_context_menu)

    if nels_load_post not in bpy.app.handlers.load_post:
        bpy.app.handlers.load_post.append(nels_load_post)

    try:
        if not bpy.app.timers.is_registered(init_all_scenes_defaults):
            bpy.app.timers.register(init_all_scenes_defaults, first_interval=0.1)
        if not bpy.app.timers.is_registered(nels_preview_tick):
            bpy.app.timers.register(nels_preview_tick, first_interval=0.2)
    except Exception:
        pass


def unregister():
    global _UPDATE_STARTUP_SCHEDULED
    _UPDATE_STARTUP_SCHEDULED = False
    try:
        bpy.types.VIEW3D_MT_object.remove(draw_obj_menu)
    except Exception:
        pass
    try:
        bpy.types.VIEW3D_MT_object_context_menu.remove(draw_object_context_menu)
    except Exception:
        pass
    try:
        bpy.types.VIEW3D_MT_edit_mesh_context_menu.remove(draw_edit_mesh_context_menu)
    except Exception:
        pass

    if hasattr(bpy.types.Scene, "nels"):
        del bpy.types.Scene.nels

    try:
        if bpy.app.timers.is_registered(init_all_scenes_defaults):
            bpy.app.timers.unregister(init_all_scenes_defaults)
        if bpy.app.timers.is_registered(nels_preview_tick):
            bpy.app.timers.unregister(nels_preview_tick)
    except Exception:
        pass

    if nels_load_post in bpy.app.handlers.load_post:
        bpy.app.handlers.load_post.remove(nels_load_post)

    for c in reversed(classes):
        bpy.utils.unregister_class(c)

    unregister_asset_library_integration()
    cleanup_legacy_classes()
    remove_custom_preview_draw_handler()
    unregister_panel_icons()
if __name__ == "__main__":
    register()














































































































































































































































