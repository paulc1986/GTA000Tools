def auto_detect_scene_sirens(scene, create_missing=True, sync_direction=False):
    s = getattr(scene, "nels", None)
    if not s:
        return (0, 0, 0)

    scene_objects = list(getattr(scene, "objects", [])) if scene else list(bpy.data.objects)

    arm = None
    if s.armature_name:
        arm = next((obj for obj in scene_objects if obj.name == s.armature_name and obj.type == "ARMATURE"), None)

    best_arm = arm
    best_bones = {}
    best_count = 0
    for obj in scene_objects:
        if obj.type != "ARMATURE":
            continue
        bone_map = {}
        for b in obj.data.bones:
            idx = siren_index_from_name(b.name)
            if idx and idx not in bone_map:
                bone_map[idx] = b.name
        if len(bone_map) > best_count:
            best_count = len(bone_map)
            best_arm = obj
            best_bones = bone_map

    if best_arm and s.armature_name != best_arm.name:
        s.armature_name = best_arm.name
    if not best_bones and best_arm and best_arm.type == "ARMATURE":
        for b in best_arm.data.bones:
            idx = siren_index_from_name(b.name)
            if idx and idx not in best_bones:
                best_bones[idx] = b.name

    obj_map = {}
    for obj in scene_objects:
        idx = siren_index_from_name(obj.name)
        if idx and idx not in obj_map:
            obj_map[idx] = obj.name
        if best_arm and obj.parent == best_arm and obj.parent_type == "BONE":
            bidx = siren_index_from_name(obj.parent_bone)
            if bidx and bidx not in obj_map:
                obj_map[bidx] = obj.name

    max_idx = max([0, len(s.sirens)] + list(obj_map.keys()) + list(best_bones.keys()))
    if create_missing and max_idx > len(s.sirens):
        ensure_sirens(s, max_idx)

    linked = 0
    for i, si in enumerate(s.sirens, start=1):
        if (not si.bone_name) and i in best_bones:
            si.bone_name = best_bones[i]
            linked += 1

        if (not si.object_name) and i in obj_map:
            si.object_name = obj_map[i]
            o = bpy.data.objects.get(si.object_name)
            if o:
                _store_rest_loc(o)
            linked += 1

        if si.object_name and (not si.bone_name) and best_arm:
            o = bpy.data.objects.get(si.object_name)
            if o and o.parent == best_arm and o.parent_type == "BONE":
                bidx = siren_index_from_name(o.parent_bone)
                if bidx == i:
                    si.bone_name = o.parent_bone

        si.enabled = bool(si.object_name or si.bone_name)

    ensure_body_opening_defaults(s)
    for op in s.body_openings:
        if op.object_name and op.object_name not in bpy.data.objects:
            op.object_name = ""
        if op.anchor_name and op.anchor_name not in bpy.data.objects:
            op.anchor_name = ""
        if op.bone_name:
            has_bone = bool(arm and op.bone_name in arm.data.bones)
            if not has_bone:
                for obj in bpy.data.objects:
                    if obj.type != "ARMATURE":
                        continue
                    if op.bone_name in obj.data.bones:
                        has_bone = True
                        if not arm:
                            arm = obj
                            s.armature_name = obj.name
                        break
            if not has_bone:
                op.bone_name = ""

    if sync_direction:
        apply_all_siren_directions(scene)

    return (len(obj_map), len(best_bones), linked)

def siren_obj(si):
    if si.object_name and si.object_name in bpy.data.objects:
        return bpy.data.objects[si.object_name]
    n = f"siren{si.index}"
    return bpy.data.objects.get(n)



def siren_pose_bone(scene, si):
    s = getattr(scene, "nels", None) if scene else None
    candidates = []
    if s and s.armature_name:
        arm = bpy.data.objects.get(s.armature_name)
        if arm and arm.type == "ARMATURE":
            candidates.append(arm)
    for obj in bpy.data.objects:
        if obj.type == "ARMATURE" and obj not in candidates:
            candidates.append(obj)

    names = []
    if si and si.bone_name:
        names.append(si.bone_name)
    if si:
        names.append(f"siren{si.index}")

    for arm in candidates:
        for bn in names:
            if not bn:
                continue
            pb = arm.pose.bones.get(bn)
            if pb:
                if si and not si.bone_name:
                    si.bone_name = pb.name
                if s and not s.armature_name:
                    s.armature_name = arm.name
                return arm, pb
    return None, None


def swappable_siren_items(self, context):
    scene = getattr(context, "scene", None) if context else getattr(bpy.context, "scene", None)
    s = getattr(scene, "nels", None) if scene else None
    items = []
    if s:
        for si in s.sirens:
            obj = siren_obj(si)
            arm, pb = siren_pose_bone(scene, si)
            if obj and obj.type == "MESH" and arm and pb:
                items.append((str(si.index), f"Siren {si.index}", f"{obj.name} on {arm.name}:{pb.name}"))
    if items:
        return items
    return [("__NONE__", "(No complete sirens found)", "Link mesh and bone for at least two sirens first")]


def siren_slot_by_index(s, idx):
    if not s:
        return None
    try:
        needle = int(idx)
    except Exception:
        return None
    for si in s.sirens:
        if int(getattr(si, "index", 0)) == needle:
            return si
    return None


SIREN_SNAPSHOT_FIELDS = [
    "enabled", "siren_type", "rotator_speed_mode", "rotator_custom_percent", "rotator_clockwise",
    "pattern_source", "pattern_choice", "custom_visibility", "custom_bits", "custom_value",
    "color_mode", "color_preset", "direction_mode", "direction_preset", "custom_direction",
    "scale_mode", "scale_preset", "custom_scale", "sync_to_bpm", "flash_preview",
    "flash", "light", "spot_light", "cast_shadows", "light_group", "start_delay",
    "light_speed", "light_multiples", "corona_intensity", "corona_size", "corona_pull",
    "light_intensity", "corona_face_camera", "object_name", "anchor_name", "bone_name",
]


def capture_siren_slot_snapshot(si):
    data = {}
    for key in SIREN_SNAPSHOT_FIELDS:
        try:
            value = getattr(si, key)
            if isinstance(value, (list, tuple)):
                value = tuple(value)
            data[key] = value
        except Exception:
            pass
    try:
        data["custom_color"] = tuple(si.custom_color)
    except Exception:
        data["custom_color"] = (1.0, 1.0, 1.0)
    return data


def apply_siren_slot_snapshot(s, si, idx, data):
    add_siren(s, si, idx)
    for key, value in dict(data or {}).items():
        if key in {"index", "name"}:
            continue
        try:
            setattr(si, key, value)
        except Exception:
            pass
    si.index = idx
    si.name = f"siren{idx}"
    sync_siren_selector_controls(si)


def scene_present_siren_indices(scene, s=None):
    used = set()
    if scene:
        for obj in scene.objects:
            try:
                idx = siren_index_from_name(getattr(obj, "name", ""))
                if idx > 0:
                    used.add(idx)
                if getattr(obj, "parent_type", "") == "BONE":
                    idx = siren_index_from_name(getattr(obj, "parent_bone", ""))
                    if idx > 0:
                        used.add(idx)
                if getattr(obj, "type", "") == "ARMATURE":
                    for bone in getattr(getattr(obj, "data", None), "bones", []):
                        idx = siren_index_from_name(getattr(bone, "name", ""))
                        if idx > 0:
                            used.add(idx)
            except Exception:
                continue
    if s:
        for si in getattr(s, "sirens", []):
            try:
                if siren_obj(si) or siren_pose_bone(scene, si)[1]:
                    used.add(int(getattr(si, "index", 0) or 0))
            except Exception:
                pass
    return used


def renumber_target_items(self, context):
    scene = getattr(context, "scene", None) if context else getattr(bpy.context, "scene", None)
    s = getattr(scene, "nels", None) if scene else None
    if not s or not s.sirens:
        return [("__NONE__", "(No sirens configured)", "")]
    source = resolve_context_siren(scene, s, require_linked=False, update_active=False)
    used = scene_present_siren_indices(scene, s=s)
    limit = max(0, min(int(getattr(s, "siren_count", len(s.sirens)) or len(s.sirens)), len(s.sirens)))
    items = [(str(idx), f"Siren {idx}", f"Rename the selected siren hierarchy to siren{idx}") for idx in range(1, limit + 1) if idx not in used]
    return items if items else [("__NONE__", "(No available siren numbers)", "All configured siren numbers already exist in the scene")]


def selected_siren_root_object(context, fallback=None):
    obj = getattr(getattr(context, "view_layer", None), "objects", None)
    active = getattr(obj, "active", None) if obj else getattr(bpy.context, "active_object", None)
    cur = active or fallback
    while cur and getattr(cur, "parent", None) and getattr(cur.parent, "type", "") != "ARMATURE" and getattr(cur, "parent_type", "") != "BONE":
        cur = cur.parent
    return cur or fallback


def bone_tree_names(arm, root_name):
    if not arm or getattr(arm, "type", "") != "ARMATURE" or not root_name:
        return []
    root = getattr(getattr(arm, "data", None), "bones", {}).get(root_name) if hasattr(getattr(arm, "data", None), "bones") else None
    if not root:
        return []
    found = []
    stack = [root]
    while stack:
        cur = stack.pop(0)
        if not cur or cur.name in found:
            continue
        found.append(cur.name)
        stack.extend(list(getattr(cur, "children", [])))
    return found


def rename_pose_rest_keys(arm, name_map):
    if not arm:
        return
    for old_name, new_name in dict(name_map or {}).items():
        old_key = _pose_rest_key(old_name)
        new_key = _pose_rest_key(new_name)
        if old_key == new_key:
            continue
        try:
            if old_key in arm:
                arm[new_key] = list(arm[old_key])
                del arm[old_key]
        except Exception:
            pass


def capture_bone_parent_links(scene, arm, bone_names):
    links = []
    if not scene or not arm:
        return links
    names = set(bone_names or [])
    for obj in scene.objects:
        try:
            if obj.parent == arm and obj.parent_type == "BONE" and obj.parent_bone in names:
                _store_rest_loc(obj)
                links.append((obj, arm, obj.parent_bone, obj.matrix_world.copy()))
        except Exception:
            continue
    return links


def restore_bone_parent_links(links, name_map):
    for obj, arm, old_bone, matrix_world in list(links or []):
        try:
            obj.parent = arm
            obj.parent_type = "BONE"
            obj.parent_bone = name_map.get(old_bone, old_bone)
            obj.matrix_world = matrix_world
            _store_rest_loc(obj, force=True)
        except Exception:
            continue


def siren_bone_subtree_objects(scene, arm, root_bone_name, exclude=None):
    names = set(bone_tree_names(arm, root_bone_name))
    found = []
    exclude = set(exclude or [])
    if not scene or not arm or not names:
        return found
    for obj in scene.objects:
        try:
            if obj in exclude:
                continue
            if obj.parent == arm and obj.parent_type == "BONE" and obj.parent_bone in names:
                found.append(obj)
        except Exception:
            continue
    return found


def rename_siren_bone_hierarchy(scene, arm, root_bone_name, old_index, new_index):
    bone_names = bone_tree_names(arm, root_bone_name)
    if not bone_names:
        return {}, ""

    desired_map = {}
    for old_name in bone_names:
        desired = retarget_siren_name_token(old_name, old_index, new_index)
        desired = re.sub(r'\.\d{3}$', '', desired)
        if old_name == root_bone_name:
            desired = f"siren{int(new_index)}"
        desired_map[old_name] = desired

    conflicts = []
    existing = getattr(getattr(arm, "data", None), "bones", None)
    for old_name, new_name in desired_map.items():
        if not new_name:
            continue
        bone = existing.get(new_name) if existing else None
        if bone and bone.name not in desired_map:
            conflicts.append(new_name)
    if conflicts:
        raise RuntimeError(f"Target bone name already exists: {conflicts[0]}")

    child_links = capture_bone_parent_links(scene, arm, bone_names)
    old_active = getattr(bpy.context.view_layer.objects, "active", None)
    old_mode = getattr(bpy.context, "mode", "OBJECT")
    stamp = _time.time_ns()
    temp_map = {old_name: f"__nels_ren_{stamp}_{i}" for i, old_name in enumerate(bone_names, start=1)}

    try:
        if old_mode != "OBJECT":
            bpy.ops.object.mode_set(mode="OBJECT")
        bpy.ops.object.select_all(action="DESELECT")
        arm.select_set(True)
        bpy.context.view_layer.objects.active = arm
        bpy.ops.object.mode_set(mode="EDIT")
        for old_name in bone_names:
            eb = arm.data.edit_bones.get(old_name)
            if eb:
                eb.name = temp_map[old_name]
        for old_name in bone_names:
            eb = arm.data.edit_bones.get(temp_map[old_name])
            if eb:
                eb.name = desired_map[old_name]
        bpy.ops.object.mode_set(mode="OBJECT")
    finally:
        try:
            if getattr(bpy.context, "mode", "OBJECT") != "OBJECT":
                bpy.ops.object.mode_set(mode="OBJECT")
        except Exception:
            pass
        try:
            if old_active and old_active.name in bpy.data.objects:
                bpy.context.view_layer.objects.active = old_active
        except Exception:
            pass
        try:
            if old_mode != "OBJECT" and getattr(bpy.context, "mode", "OBJECT") == "OBJECT":
                bpy.ops.object.mode_set(mode=old_mode)
        except Exception:
            pass

    restore_bone_parent_links(child_links, desired_map)
    rename_pose_rest_keys(arm, desired_map)
    for new_name in desired_map.values():
        try:
            pb = arm.pose.bones.get(new_name)
            if pb:
                _store_rest_pose_bone(arm, pb, force=True)
        except Exception:
            pass
    return desired_map, desired_map.get(root_bone_name, "")


def pick_anchor_object(context, arm, si):
    active = getattr(context.view_layer.objects, "active", None)
    selected = [o for o in context.selected_objects if o and o.type != "ARMATURE"]

    if si and si.object_name:
        non_siren = [o for o in selected if o.name != si.object_name]
        if non_siren:
            selected = non_siren

    if active and active in selected:
        return active
    if selected:
        return selected[0]
    if active and active.type != "ARMATURE":
        if not si or active.name != si.object_name:
            return active

    if si and si.anchor_name and si.anchor_name in bpy.data.objects:
        anchor = bpy.data.objects[si.anchor_name]
        if anchor.type != "ARMATURE":
            return anchor
    return None


def pick_reference_object(context, si):
    active = getattr(context.view_layer.objects, "active", None)
    selected = [o for o in context.selected_objects if o and o.type != "ARMATURE"]

    if si and si.object_name:
        selected = [o for o in selected if o.name != si.object_name]

    if active and active in selected:
        return active
    if selected:
        return selected[0]
    if active and active.type != "ARMATURE":
        if not si or active.name != si.object_name:
            return active
    return None


def pick_any_reference_object(context):
    active = getattr(getattr(context, "view_layer", None), "objects", None)
    active = getattr(active, "active", None)
    selected = [o for o in getattr(context, "selected_objects", []) if o and getattr(o, "type", "") != "ARMATURE"]

    if active and active in selected:
        return active
    if selected:
        return selected[0]
    if active and getattr(active, "type", "") != "ARMATURE":
        return active
    return None


def set_object_origin_from_reference(obj, reference):
    if not obj or not reference:
        return False, "Missing source or reference object"
    if getattr(obj, "type", "") != "MESH":
        return False, "The linked siren object must be a mesh"
    if getattr(obj, "data", None) is None or not hasattr(obj.data, "transform"):
        return False, "The linked siren object has no editable mesh data"

    old_world = obj.matrix_world.copy()
    new_world = old_world.copy()
    new_world.translation = reference.matrix_world.translation.copy()

    try:
        transform = new_world.inverted() @ old_world
    except Exception:
        return False, "Could not calculate the new siren origin transform"

    try:
        if getattr(obj.data, "users", 1) > 1:
            obj.data = obj.data.copy()
        obj.data.transform(transform)
        if hasattr(obj.data, "update"):
            obj.data.update()
        obj.matrix_world = new_world
        _store_rest_loc(obj, force=True)
        return True, f"Set {obj.name} origin to {reference.name}"
    except Exception as ex:
        return False, f"Could not set siren origin: {ex}"

def set_object_origin_to_local_point(obj, local_point):
    if not obj:
        return False, "Missing object"
    if getattr(obj, "type", "") != "MESH":
        return False, "The active object must be a mesh"
    if getattr(obj, "data", None) is None or not hasattr(obj.data, "transform"):
        return False, "The active mesh has no editable geometry data"

    try:
        point = Vector(local_point)
    except Exception:
        return False, "Could not read the selected midpoint"

    old_world = obj.matrix_world.copy()
    new_world = old_world @ Matrix.Translation(point)

    try:
        if getattr(obj.data, "users", 1) > 1:
            obj.data = obj.data.copy()
        obj.data.transform(Matrix.Translation(-point))
        if hasattr(obj.data, "update"):
            obj.data.update()
        obj.matrix_world = new_world
        _store_rest_loc(obj, force=True)
        return True, f"Set {obj.name} origin to the current selection"
    except Exception as ex:
        return False, f"Could not set the object origin: {ex}"


def set_object_origin_to_world_point(obj, world_point):
    if not obj:
        return False, "Missing object"
    if getattr(obj, "type", "") != "MESH":
        return False, "The selected object must be a mesh"
    if getattr(obj, "data", None) is None or not hasattr(obj.data, "transform"):
        return False, "The selected mesh has no editable geometry data"

    try:
        point = Vector(world_point)
    except Exception:
        return False, "Could not read the target bone location"

    old_world = obj.matrix_world.copy()
    new_world = old_world.copy()
    new_world.translation = point

    try:
        transform = new_world.inverted() @ old_world
    except Exception:
        return False, "Could not calculate the new origin transform"

    try:
        if getattr(obj.data, "users", 1) > 1:
            obj.data = obj.data.copy()
        obj.data.transform(transform)
        if hasattr(obj.data, "update"):
            obj.data.update()
        obj.matrix_world = new_world
        _store_rest_loc(obj, force=True)
        return True, f"Set {obj.name} origin to its linked bone"
    except Exception as ex:
        return False, f"Could not set the object origin: {ex}"


def edit_selection_local_center(obj, context):
    if not obj or getattr(obj, "type", "") != "MESH":
        return None, "The active object must be a mesh"
    if getattr(obj, "mode", "") != "EDIT":
        return None, "Switch the active mesh to Edit Mode first"

    try:
        bm = bmesh.from_edit_mesh(obj.data)
    except Exception as ex:
        return None, f"Could not read the edit selection: {ex}"

    mesh_mode = tuple(getattr(getattr(context, "tool_settings", None), "mesh_select_mode", (True, False, False)) or (True, False, False))
    face_points = [f.calc_center_median().copy() for f in bm.faces if getattr(f, "select", False)]
    edge_points = [((e.verts[0].co.copy() + e.verts[1].co.copy()) * 0.5) for e in bm.edges if getattr(e, "select", False)]
    vert_points = [v.co.copy() for v in bm.verts if getattr(v, "select", False)]

    points = []
    if len(mesh_mode) > 2 and mesh_mode[2] and face_points:
        points = face_points
    elif len(mesh_mode) > 1 and mesh_mode[1] and edge_points:
        points = edge_points
    elif len(mesh_mode) > 0 and mesh_mode[0] and vert_points:
        points = vert_points
    elif face_points:
        points = face_points
    elif edge_points:
        points = edge_points
    else:
        points = vert_points

    if not points:
        return None, "Select at least one vertex, edge, or face first"

    center = Vector((0.0, 0.0, 0.0))
    for point in points:
        center += point
    center /= float(len(points))
    return center, ""


def move_siren_bone_to_world_point(scene, si, world_point, preserve_direction=True):
    if not scene or not si:
        return False, "No siren was resolved"

    arm, pb = siren_pose_bone(scene, si)
    if not arm or not pb:
        return False, f"No linked bone was found for siren {getattr(si, 'index', '?')}"

    try:
        point_world = Vector(world_point)
    except Exception:
        return False, "Could not read the selected object origin"

    old_active = getattr(bpy.context.view_layer.objects, "active", None)
    old_mode = getattr(bpy.context, "mode", "OBJECT")

    try:
        if old_mode != "OBJECT":
            bpy.ops.object.mode_set(mode="OBJECT")
        bpy.ops.object.select_all(action="DESELECT")
        arm.select_set(True)
        bpy.context.view_layer.objects.active = arm
        bpy.ops.object.mode_set(mode="EDIT")

        eb = arm.data.edit_bones.get(pb.name) or arm.data.edit_bones.get(getattr(si, "bone_name", ""))
        if not eb:
            bpy.ops.object.mode_set(mode="OBJECT")
            return False, f"Could not find linked bone for siren {getattr(si, 'index', '?')}"

        current_vec = (eb.tail - eb.head)
        length = current_vec.length
        if length < 0.000001:
            length = 0.05
        if preserve_direction and current_vec.length >= 0.000001:
            direction_vec = current_vec.normalized()
        else:
            ang = dir_val(si)
            direction_vec = Vector((math.sin(ang), math.cos(ang), 0.0))
            if direction_vec.length < 0.000001:
                direction_vec = Vector((0.0, 1.0, 0.0))
            direction_vec.normalize()

        head = arm.matrix_world.inverted() @ point_world
        eb.head = head
        eb.tail = head + (direction_vec * length)

        bpy.ops.object.mode_set(mode="OBJECT")
        pose_bone = arm.pose.bones.get(eb.name)
        if pose_bone:
            _store_rest_pose_bone(arm, pose_bone, force=True)
        try:
            bpy.context.view_layer.update()
        except Exception:
            pass
        return True, f"Moved bone {eb.name} to the selected object origin"
    except Exception as ex:
        return False, f"Could not move the linked bone: {ex}"
    finally:
        try:
            if old_active and old_active.name in bpy.data.objects:
                bpy.context.view_layer.objects.active = old_active
        except Exception:
            pass
        try:
            if old_mode != "OBJECT" and getattr(bpy.context, "mode", "OBJECT") == "OBJECT":
                bpy.ops.object.mode_set(mode=old_mode)
        except Exception:
            pass


def linked_bone_target(scene, obj, s=None):
    if not obj:
        return None, None, ""

    try:
        if obj.parent and obj.parent.type == "ARMATURE" and obj.parent_type == "BONE" and obj.parent_bone:
            arm = obj.parent
            pb = getattr(getattr(arm, "pose", None), "bones", {}).get(obj.parent_bone) if hasattr(getattr(arm, "pose", None), "bones") else None
            if pb:
                return arm, pb, ""
    except Exception:
        pass

    si_index = infer_siren_index_from_hierarchy(obj, fallback=infer_siren_index_from_object(obj, s=s))
    if si_index and scene:
        try:
            arm, pb = siren_pose_bone(scene, int(si_index))
            if arm and pb:
                return arm, pb, ""
        except Exception:
            pass

    try:
        if scene and s and getattr(s, "body_openings", None):
            obj_name = str(getattr(obj, "name", "") or "")
            for opening in s.body_openings:
                linked_name = str(getattr(opening, "object_name", "") or "")
                key_name = str(getattr(opening, "key", "") or "")
                if linked_name and linked_name == obj_name:
                    arm, pb = body_opening_pose_bone(scene, opening)
                    if arm and pb:
                        return arm, pb, ""
                elif key_name and _body_opening_name_matches(obj_name, key_name):
                    arm, pb = body_opening_pose_bone(scene, opening)
                    if arm and pb:
                        if not linked_name:
                            opening.object_name = obj_name
                        return arm, pb, ""
    except Exception:
        pass

    return None, None, f"No linked bone was found for {getattr(obj, 'name', 'the selected object')}"


def move_linked_bone_to_world_point(scene, obj, world_point, s=None, preserve_direction=True):
    arm, pb, msg = linked_bone_target(scene, obj, s=s)
    if not arm or not pb:
        return False, msg or f"No linked bone was found for {getattr(obj, 'name', 'the selected object')}"

    try:
        point_world = Vector(world_point)
    except Exception:
        return False, "Could not read the selected object origin"

    old_active = getattr(bpy.context.view_layer.objects, "active", None)
    old_mode = getattr(bpy.context, "mode", "OBJECT")

    try:
        if old_mode != "OBJECT":
            bpy.ops.object.mode_set(mode="OBJECT")
        bpy.ops.object.select_all(action="DESELECT")
        arm.select_set(True)
        bpy.context.view_layer.objects.active = arm
        bpy.ops.object.mode_set(mode="EDIT")

        eb = arm.data.edit_bones.get(pb.name)
        if not eb:
            bpy.ops.object.mode_set(mode="OBJECT")
            return False, f"Could not find linked bone for {getattr(obj, 'name', 'the selected object')}"

        current_vec = (eb.tail - eb.head)
        length = current_vec.length
        if length < 0.000001:
            length = 0.05
        if preserve_direction and current_vec.length >= 0.000001:
            direction_vec = current_vec.normalized()
        else:
            direction_vec = Vector((0.0, 1.0, 0.0))

        head = arm.matrix_world.inverted() @ point_world
        eb.head = head
        eb.tail = head + (direction_vec * length)

        bpy.ops.object.mode_set(mode="OBJECT")
        pose_bone = arm.pose.bones.get(eb.name)
        if pose_bone:
            _store_rest_pose_bone(arm, pose_bone, force=True)
        try:
            bpy.context.view_layer.update()
        except Exception:
            pass
        return True, f"Moved bone {eb.name} to {getattr(obj, 'name', 'the selected object')} origin"
    except Exception as ex:
        return False, f"Could not move the linked bone: {ex}"
    finally:
        try:
            if old_active and old_active.name in bpy.data.objects:
                bpy.context.view_layer.objects.active = old_active
        except Exception:
            pass
        try:
            if old_mode != "OBJECT" and getattr(bpy.context, "mode", "OBJECT") == "OBJECT":
                bpy.ops.object.mode_set(mode=old_mode)
        except Exception:
            pass


def linked_bone_world_location(scene, obj, s=None):
    arm, pb, msg = linked_bone_target(scene, obj, s=s)
    if arm and pb:
        return arm.matrix_world @ Vector(pb.head), ""
    return None, msg or f"No linked bone was found for {getattr(obj, 'name', 'the selected object')}"


def body_opening_icon_key(key):
    text = str(key or "").strip().lower()
    if text.startswith("bonnet"):
        return "bonnet"
    if text.startswith("boot"):
        return "boot"
    if text.startswith("door_") or text.startswith("door"):
        return "door"
    return "body_openings"


def body_opening_display_name(key):
    lookup = {k: label for k, label, _opening_type in DEFAULT_BODY_OPENINGS}
    text = str(key or "").strip()
    if text in lookup:
        return lookup[text]
    if not text:
        return "Body Opening"
    return text.replace("_", " ").title()


def body_opening_supports_rotation(opening):
    return str(getattr(opening, "opening_type", "HINGED") or "HINGED") in {"HINGED", "HINGED_SLIDING"}


def body_opening_supports_translation(opening):
    return str(getattr(opening, "opening_type", "HINGED") or "HINGED") in {"SLIDING", "HINGED_SLIDING"}


def update_body_opening_type(self, context):
    opening_type = str(getattr(self, "opening_type", "HINGED") or "HINGED")
    if opening_type in {"SLIDING", "HINGED_SLIDING"}:
        if not any(bool(getattr(self, attr, False)) for attr in ("slide_x", "slide_y", "slide_z")):
            self.slide_y = True
        self.limit_translation = True
    if opening_type in {"HINGED", "HINGED_SLIDING"}:
        if not any(bool(getattr(self, attr, False)) for attr in ("rot_x", "rot_y", "rot_z")):
            self.rot_z = True
        self.limit_rotation = True


def ensure_body_opening_defaults(s):
    if not s or not hasattr(s, "body_openings"):
        return
    existing = {str(getattr(op, "key", "") or "") for op in getattr(s, "body_openings", [])}
    for key, label, opening_type in DEFAULT_BODY_OPENINGS:
        if key in existing:
            continue
        op = s.body_openings.add()
        op.key = key
        op.name = label
        op.opening_type = opening_type
        op.rot_x = True
        op.rot_y = True
        op.rot_z = True
        op.slide_x = False
        op.slide_y = opening_type == "SLIDING"
        op.slide_z = False
        op.limit_rotation = True
        op.limit_translation = opening_type == "SLIDING"
        existing.add(key)
    if getattr(s, "body_openings", None):
        s.active_body_opening = min(max(0, int(getattr(s, "active_body_opening", 0) or 0)), len(s.body_openings) - 1)


def body_opening_by_key(s, key=""):
    if not s or not getattr(s, "body_openings", None):
        return None
    wanted = str(key or "").strip()
    if wanted:
        for op in s.body_openings:
            if str(getattr(op, "key", "") or "") == wanted:
                return op
    idx = min(max(0, int(getattr(s, "active_body_opening", 0) or 0)), len(s.body_openings) - 1)
    return s.body_openings[idx]


def active_body_opening(s):
    return body_opening_by_key(s, "")


def _body_opening_name_matches(name, key):
    lhs = str(name or "").strip().lower()
    rhs = str(key or "").strip().lower()
    if not lhs or not rhs:
        return False
    return lhs == rhs or lhs.startswith(rhs + "_") or lhs.startswith(rhs + ".")


def find_body_opening_scene_object(scene, key):
    if not scene:
        return None
    exact = None
    fallback = None
    for obj in scene.objects:
        if getattr(obj, "type", "") != "MESH":
            continue
        name = str(getattr(obj, "name", "") or "")
        if name.lower() == str(key or "").lower():
            exact = obj
            break
        if fallback is None and _body_opening_name_matches(name, key):
            fallback = obj
    return exact or fallback


def find_body_opening_scene_bone(scene, settings, key):
    if not scene:
        return None, None
    candidates = []
    arm_name = str(getattr(settings, "armature_name", "") or "") if settings else ""
    if arm_name:
        arm = bpy.data.objects.get(arm_name)
        if arm and getattr(arm, "type", "") == "ARMATURE" and arm.name in scene.objects:
            candidates.append(arm)
    for obj in scene.objects:
        if getattr(obj, "type", "") == "ARMATURE" and obj not in candidates:
            candidates.append(obj)
    for arm in candidates:
        exact = arm.data.bones.get(str(key or ""))
        if exact:
            return arm, exact
        for bone in arm.data.bones:
            if _body_opening_name_matches(getattr(bone, "name", ""), key):
                return arm, bone
    return None, None


def _vector_has_motion(vec, eps=0.00001):
    try:
        return any(abs(float(v)) > eps for v in vec)
    except Exception:
        return False


def body_opening_state_configured(opening):
    if not opening:
        return False
    return any(
        _vector_has_motion(getattr(opening, attr, (0.0, 0.0, 0.0)))
        for attr in ("closed_location", "closed_rotation", "open_location", "open_rotation")
    )


def read_body_opening_current_transform(scene, opening):
    arm, pb = body_opening_pose_bone(scene, opening)
    if pb:
        pb.rotation_mode = "XYZ"
        return Vector(pb.location), Vector(pb.rotation_euler), "BONE"
    obj = body_opening_obj(opening)
    if obj:
        obj.rotation_mode = "XYZ"
        return Vector(obj.location), Vector(obj.rotation_euler), "MESH"
    return None, None, ""


def auto_detect_body_opening_links(scene, settings):
    if not scene or not settings or not getattr(settings, "body_openings", None):
        return False

    changed = False
    scene_names = {obj.name for obj in scene.objects}
    armatures = [obj for obj in scene.objects if getattr(obj, "type", "") == "ARMATURE"]
    arm_name = str(getattr(settings, "armature_name", "") or "")
    if (not arm_name or arm_name not in scene_names) and len(armatures) == 1:
        settings.armature_name = armatures[0].name
        changed = True

    for opening in settings.body_openings:
        mesh_name = str(getattr(opening, "object_name", "") or "")
        mesh_obj = bpy.data.objects.get(mesh_name) if mesh_name else None
        if mesh_obj is None or mesh_obj.name not in scene_names:
            found_obj = find_body_opening_scene_object(scene, getattr(opening, "key", ""))
            if found_obj and mesh_name != found_obj.name:
                opening.object_name = found_obj.name
                changed = True

        arm, bone = body_opening_pose_bone(scene, opening)
        if bone is not None and not str(getattr(opening, "bone_name", "") or ""):
            opening.bone_name = bone.name
            changed = True
            if arm and (not getattr(settings, "armature_name", "") or getattr(settings, "armature_name", "") not in scene_names):
                settings.armature_name = arm.name
                changed = True
        elif bone is None:
            found_arm, found_bone = find_body_opening_scene_bone(scene, settings, getattr(opening, "key", ""))
            if found_bone is not None:
                if str(getattr(opening, "bone_name", "") or "") != found_bone.name:
                    opening.bone_name = found_bone.name
                    changed = True
                if found_arm and (not getattr(settings, "armature_name", "") or getattr(settings, "armature_name", "") not in scene_names):
                    settings.armature_name = found_arm.name
                    changed = True

        if not body_opening_state_configured(opening):
            loc, rot, _source = read_body_opening_current_transform(scene, opening)
            if loc is None or rot is None:
                continue
            if _vector_has_motion(loc) or _vector_has_motion(rot):
                opening.open_location = (float(loc[0]), float(loc[1]), float(loc[2]))
                opening.open_rotation = (float(rot[0]), float(rot[1]), float(rot[2]))
                opening.open_source = str(_source or "")
                changed = True
            else:
                opening.closed_location = (float(loc[0]), float(loc[1]), float(loc[2]))
                opening.closed_rotation = (float(rot[0]), float(rot[1]), float(rot[2]))
                opening.closed_source = str(_source or "")
                changed = True
    return changed


def draw_body_opening_controls(layout, context, s, opening):
    if not opening:
        layout.label(text="No body opening available")
        return

    icon_name = "CON_ROTLIKE" if getattr(opening, "opening_type", "HINGED") == "HINGED" else "EMPTY_ARROWS"
    header = layout.row(align=True)
    header.prop(opening, "expanded", text="", emboss=False, icon="TRIA_DOWN" if opening.expanded else "TRIA_RIGHT")
    header.label(text=str(getattr(opening, "name", "Body Opening") or "Body Opening"), **panel_icon_draw_kwargs(body_opening_icon_key(getattr(opening, "key", "")), context, fallback_icon=icon_name))
    summary = []
    obj_name = str(getattr(opening, "object_name", "") or "")
    bone_name = str(getattr(opening, "bone_name", "") or "")
    if obj_name:
        summary.append(obj_name)
    elif bone_name:
        summary.append(bone_name)
    if summary:
        header.label(text=" | ".join(summary))
    if not getattr(opening, "expanded", False):
        return

    layout.prop(opening, "opening_type", text="Type")

    motion = layout.box()
    if body_opening_supports_rotation(opening):
        rot_box = motion.box() if body_opening_supports_translation(opening) else motion
        rot_box.label(text="Rotation Axes")
        rr = rot_box.row(align=True)
        rr.prop(opening, "rot_x", text="X", toggle=True)
        rr.prop(opening, "rot_y", text="Y", toggle=True)
        rr.prop(opening, "rot_z", text="Z", toggle=True)
        rot_box.prop(opening, "limit_rotation")
    if body_opening_supports_translation(opening):
        slide_box = motion.box() if body_opening_supports_rotation(opening) else motion
        slide_box.label(text="Movement Axes")
        sr = slide_box.row(align=True)
        sr.prop(opening, "slide_x", text="X", toggle=True)
        sr.prop(opening, "slide_y", text="Y", toggle=True)
        sr.prop(opening, "slide_z", text="Z", toggle=True)
        slide_box.prop(opening, "limit_translation")

    link_box = layout.box()
    link_box.label(text="Object/Bone Linking")
    link_box.prop_search(s, "armature_name", context.scene, "objects", text="Parent Skeleton")
    op = link_box.operator("nels.body_opening_link", text="Assign Selected Mesh", icon="OUTLINER_OB_MESH")
    if op is not None:
        op.action = "MARK"
        op.opening_key = opening.key
    op = link_box.operator("nels.body_opening_link", text="Match Origin to Selected", icon="OBJECT_ORIGIN")
    if op is not None:
        op.action = "ORIGIN"
        op.opening_key = opening.key
    op = link_box.operator("nels.body_opening_link", text="Place Bone at Selected Origin", icon="BONE_DATA")
    if op is not None:
        op.action = "BONE"
        op.opening_key = opening.key

    mesh_row = link_box.row(align=True)
    mesh_row.prop_search(opening, "object_name", context.scene, "objects", text="Mesh")
    op = mesh_row.operator("nels.pick_selected_link_target", text="", icon="EYEDROPPER")
    if op is not None:
        op.target = "BODY_MESH"
        op.opening_key = opening.key

    arm = bpy.data.objects.get(getattr(s, "armature_name", "")) if getattr(s, "armature_name", "") else None
    bone_row = link_box.row(align=True)
    if arm and getattr(arm, "type", "") == "ARMATURE":
        bone_row.prop_search(opening, "bone_name", arm.data, "bones", text="Bone")
    else:
        bone_field = bone_row.row(align=True)
        bone_field.enabled = False
        bone_field.prop(opening, "bone_name", text="Bone")
    op = bone_row.operator("nels.pick_selected_link_target", text="", icon="EYEDROPPER")
    if op is not None:
        op.target = "BODY_BONE"
        op.opening_key = opening.key

    link_box.label(text="Mesh and bone links auto-detect from the current scene", icon="INFO")
    if not arm or getattr(arm, "type", "") != "ARMATURE":
        link_box.label(text="Select a Parent Skeleton to search scene bones", icon="INFO")
    link_box.label(text="Placed bones always point to vehicle front (Y+)", icon="INFO")

    state_box = layout.box()
    state_box.label(text="Capture and Preview")
    state_box.label(text="Set values directly or move the linked pose bone manually, then capture Closed and Open positions.", icon="INFO")
    capture_row = state_box.row(align=True)
    op = capture_row.operator("nels.body_opening_state", text="Set Closed Position", icon="IMPORT")
    if op is not None:
        op.action = "CAPTURE_CLOSED"
        op.opening_key = opening.key
    op = capture_row.operator("nels.body_opening_state", text="Set Open Position", icon="EXPORT")
    if op is not None:
        op.action = "CAPTURE_OPEN"
        op.opening_key = opening.key
    apply_row = state_box.row(align=True)
    op = apply_row.operator("nels.body_opening_state", text="Preview Closed", icon="LOOP_BACK")
    if op is not None:
        op.action = "APPLY_CLOSED"
        op.opening_key = opening.key
    op = apply_row.operator("nels.body_opening_state", text="Preview Open", icon="PLAY")
    if op is not None:
        op.action = "APPLY_OPEN"
        op.opening_key = opening.key


    closed_loc = Vector(getattr(opening, "closed_location", (0.0, 0.0, 0.0)))
    open_loc = Vector(getattr(opening, "open_location", (0.0, 0.0, 0.0)))
    closed_rot = Vector(getattr(opening, "closed_rotation", (0.0, 0.0, 0.0)))
    open_rot = Vector(getattr(opening, "open_rotation", (0.0, 0.0, 0.0)))
    slide_delta = open_loc - closed_loc
    rot_delta = open_rot - closed_rot

    def draw_axis_group(box, title, prop_name):
        grp = state_box.box()
        grp.label(text=title)
        for axis, idx in (("X", 0), ("Y", 1), ("Z", 2)):
            grp.prop(opening, prop_name, index=idx, text=axis, slider=True)
        return grp

    if body_opening_supports_translation(opening):
        draw_axis_group(state_box, "Closed Position", "closed_location")
        draw_axis_group(state_box, "Open Position", "open_location")
        state_box.label(text=f"Position Delta: X {slide_delta[0]:.4f}  Y {slide_delta[1]:.4f}  Z {slide_delta[2]:.4f}")

    if body_opening_supports_rotation(opening):
        draw_axis_group(state_box, "Closed Rotation", "closed_rotation")
        draw_axis_group(state_box, "Open Rotation", "open_rotation")
        state_box.label(text=f"Rotation Delta: X {rot_delta[0]:.4f}  Y {rot_delta[1]:.4f}  Z {rot_delta[2]:.4f}")


def body_opening_obj(opening):
    if not opening:
        return None
    name = str(getattr(opening, "object_name", "") or "")
    return bpy.data.objects.get(name) if name else None


def body_opening_pose_bone(scene, opening):
    if not scene or not opening:
        return None, None
    s = getattr(scene, "nels", None)
    bone_name = str(getattr(opening, "bone_name", "") or getattr(opening, "key", "") or "")
    if not bone_name:
        return None, None

    candidates = []
    arm_name = str(getattr(s, "armature_name", "") or "") if s else ""
    if arm_name:
        arm = bpy.data.objects.get(arm_name)
        if arm and getattr(arm, "type", "") == "ARMATURE":
            candidates.append(arm)
    if scene:
        for obj in scene.objects:
            if getattr(obj, "type", "") == "ARMATURE" and obj not in candidates:
                candidates.append(obj)

    for arm in candidates:
        try:
            pb = getattr(getattr(arm, "pose", None), "bones", {}).get(bone_name) if hasattr(getattr(arm, "pose", None), "bones") else None
            if pb:
                return arm, pb
        except Exception:
            continue
    return None, None


def pick_body_opening_reference(context, opening):
    opening_obj = body_opening_obj(opening)
    selected = [obj for obj in getattr(context, "selected_objects", []) if obj and getattr(obj, "type", "") != "ARMATURE"]
    if opening_obj:
        selected = [obj for obj in selected if obj != opening_obj]
    active = getattr(getattr(context, "view_layer", None), "objects", None)
    active = getattr(active, "active", None)
    if active and active in selected:
        return active
    if selected:
        return selected[0]
    if active and getattr(active, "type", "") != "ARMATURE" and active != opening_obj:
        return active
    return None


def body_opening_capture_target(scene, opening):
    ctx = bpy.context
    arm, pb = body_opening_pose_bone(scene, opening)
    obj = body_opening_obj(opening)
    active_obj = getattr(getattr(getattr(ctx, "view_layer", None), "objects", None), "active", None)
    active_pose_bone = getattr(ctx, "active_pose_bone", None)
    mode = str(getattr(ctx, "mode", "") or "")

    if arm and pb and mode == "POSE" and active_obj == arm and active_pose_bone and getattr(active_pose_bone, "name", "") == pb.name:
        return "BONE", pb
    if obj and active_obj == obj:
        return "MESH", obj
    if obj:
        return "MESH", obj
    if pb:
        return "BONE", pb
    return "", None


def capture_body_opening_state(scene, opening, state):
    prefix = "closed" if str(state or "CLOSED").upper() == "CLOSED" else "open"
    source, target = body_opening_capture_target(scene, opening)

    if source == "BONE" and target is not None:
        target.rotation_mode = "XYZ"
        setattr(opening, f"{prefix}_location", (float(target.location[0]), float(target.location[1]), float(target.location[2])))
        setattr(opening, f"{prefix}_rotation", (float(target.rotation_euler[0]), float(target.rotation_euler[1]), float(target.rotation_euler[2])))
        setattr(opening, f"{prefix}_source", "BONE")
        return True, f"Captured {prefix} state from bone {target.name}"

    if source == "MESH" and target is not None:
        target.rotation_mode = "XYZ"
        setattr(opening, f"{prefix}_location", (float(target.location[0]), float(target.location[1]), float(target.location[2])))
        setattr(opening, f"{prefix}_rotation", (float(target.rotation_euler[0]), float(target.rotation_euler[1]), float(target.rotation_euler[2])))
        setattr(opening, f"{prefix}_source", "MESH")
        return True, f"Captured {prefix} state from mesh {target.name}"

    return False, f"Assign a mesh or place bone {getattr(opening, 'key', 'opening')} first"


def apply_body_opening_state(scene, opening, state):
    prefix = "closed" if str(state or "CLOSED").upper() == "CLOSED" else "open"
    loc = Vector(getattr(opening, f"{prefix}_location", (0.0, 0.0, 0.0)))
    rot = Vector(getattr(opening, f"{prefix}_rotation", (0.0, 0.0, 0.0)))
    source = str(getattr(opening, f"{prefix}_source", "") or "").upper()

    obj = body_opening_obj(opening)
    arm, pb = body_opening_pose_bone(scene, opening)

    if source == "MESH" and obj:
        obj.rotation_mode = "XYZ"
        obj.location = loc
        obj.rotation_euler = rot
        try:
            bpy.context.view_layer.update()
        except Exception:
            pass
        return True, f"Applied {prefix} state to mesh {obj.name}"

    if source == "BONE" and pb:
        pb.rotation_mode = "XYZ"
        pb.location = loc
        pb.rotation_euler = rot
        try:
            bpy.context.view_layer.update()
        except Exception:
            pass
        return True, f"Applied {prefix} state to bone {pb.name}"

    if obj:
        obj.rotation_mode = "XYZ"
        obj.location = loc
        obj.rotation_euler = rot
        try:
            bpy.context.view_layer.update()
        except Exception:
            pass
        return True, f"Applied {prefix} state to mesh {obj.name}"

    if pb:
        pb.rotation_mode = "XYZ"
        pb.location = loc
        pb.rotation_euler = rot
        try:
            bpy.context.view_layer.update()
        except Exception:
            pass
        return True, f"Applied {prefix} state to bone {pb.name}"

    return False, f"Assign a mesh or place bone {getattr(opening, 'key', 'opening')} first"


def infer_siren_index_from_object(obj, s=None):
    seen = set()
    cur = obj
    while cur and cur not in seen:
        seen.add(cur)
        idx = siren_index_from_name(getattr(cur, "name", ""))
        if idx:
            return idx
        idx = siren_index_from_name(getattr(cur, "parent_bone", ""))
        if idx:
            return idx
        if s:
            for si in getattr(s, "sirens", []):
                if getattr(si, "object_name", "") == getattr(cur, "name", ""):
                    return int(getattr(si, "index", 0) or 0)
        cur = getattr(cur, "parent", None)
    return 0


def retarget_siren_name_token(value, old_index, new_index, extra_name_map=None):
    text = str(value or "")
    if extra_name_map:
        for old_name, new_name in sorted(extra_name_map.items(), key=lambda item: len(str(item[0])), reverse=True):
            old_name = str(old_name or "")
            new_name = str(new_name or "")
            if old_name:
                text = text.replace(old_name, new_name)

    patterns = (
        (r'(?i)siren\s*0*%d(?=[^0-9]|$)' % int(old_index), f"siren{int(new_index)}"),
        (r'(?i)misc_rotator_?\s*0*%d(?=[^0-9]|$)' % int(old_index), lambda m: ("misc_rotator_" if m.group(0).lower().startswith("misc_rotator_") else "misc_rotator") + str(int(new_index))),
    )
    for pattern, repl in patterns:
        text = re.sub(pattern, repl, text)
    return text


def _localize_object_data(obj):
    if not obj:
        return
    data = getattr(obj, "data", None)
    try:
        if data is not None and getattr(data, "users", 1) > 1:
            obj.data = data.copy()
    except Exception:
        pass
    try:
        obj.animation_data_clear()
    except Exception:
        pass


def _retarget_vertex_groups(obj, old_index, new_index, extra_name_map=None):
    for vg in getattr(obj, "vertex_groups", []):
        new_name = retarget_siren_name_token(vg.name, old_index, new_index, extra_name_map=extra_name_map)
        if new_name != vg.name:
            vg.name = new_name


def _retarget_modifier_settings(obj, old_index, new_index, extra_name_map=None):
    for mod in getattr(obj, "modifiers", []):
        try:
            if hasattr(mod, "vertex_group"):
                value = str(getattr(mod, "vertex_group", "") or "")
                new_value = retarget_siren_name_token(value, old_index, new_index, extra_name_map=extra_name_map)
                if new_value != value:
                    setattr(mod, "vertex_group", new_value)
        except Exception:
            pass


def _retarget_id_properties(container, old_index, new_index, extra_name_map=None):
    if not hasattr(container, "keys"):
        return
    try:
        for key in list(container.keys()):
            try:
                value = container[key]
            except Exception:
                continue
            if isinstance(value, str):
                new_value = retarget_siren_name_token(value, old_index, new_index, extra_name_map=extra_name_map)
                if new_value != value:
                    container[key] = new_value
    except Exception:
        pass


def _retarget_pointer_properties(container, old_index, new_index, object_map=None, extra_name_map=None, depth=0, seen=None):
    if container is None or depth > 4:
        return
    if seen is None:
        seen = set()
    marker = id(container)
    if marker in seen:
        return
    seen.add(marker)

    _retarget_id_properties(container, old_index, new_index, extra_name_map=extra_name_map)
    bl_rna = getattr(container, "bl_rna", None)
    if bl_rna is None:
        return

    skip = {
        "rna_type", "name", "data", "parent", "users_collection", "modifiers", "constraints",
        "material_slots", "particle_systems", "vertex_groups", "pose", "children", "matrix_world",
        "matrix_local", "matrix_parent_inverse",
    }
    for prop in bl_rna.properties:
        ident = getattr(prop, "identifier", "")
        if not ident or ident in skip or getattr(prop, "is_readonly", False):
            continue
        try:
            value = getattr(container, ident)
        except Exception:
            continue

        ptype = getattr(prop, "type", "")
        if ptype == 'STRING' and isinstance(value, str):
            new_value = retarget_siren_name_token(value, old_index, new_index, extra_name_map=extra_name_map)
            if new_value != value:
                try:
                    setattr(container, ident, new_value)
                except Exception:
                    pass
        elif ptype == 'POINTER':
            if object_map and isinstance(value, bpy.types.Object) and value in object_map:
                try:
                    setattr(container, ident, object_map[value])
                except Exception:
                    pass
            elif value is not None and hasattr(value, 'bl_rna') and not isinstance(value, bpy.types.ID):
                _retarget_pointer_properties(value, old_index, new_index, object_map=object_map, extra_name_map=extra_name_map, depth=depth + 1, seen=seen)
        elif ptype == 'COLLECTION':
            try:
                for item in value:
                    if item is not None and hasattr(item, 'bl_rna'):
                        _retarget_pointer_properties(item, old_index, new_index, object_map=object_map, extra_name_map=extra_name_map, depth=depth + 1, seen=seen)
            except Exception:
                pass


def retarget_siren_hierarchy(root, old_index, new_index, object_map=None, detach_root=False, force_root_name=True):
    if not root or old_index <= 0 or new_index <= 0:
        return []

    hierarchy = [root] + iter_siren_object_hierarchy(root)
    if object_map is None:
        object_map = {obj: obj for obj in hierarchy}

    name_map = {}
    desired_names = {}
    for obj in hierarchy:
        desired = retarget_siren_name_token(obj.name, old_index, new_index)
        desired = re.sub(r'\.\d{3}$', '', desired)
        if force_root_name and obj == root:
            desired = f"siren{int(new_index)}"
        desired_names[obj] = desired
        name_map[obj.name] = desired

    for obj in hierarchy:
        _localize_object_data(obj)

    for obj in hierarchy:
        desired = desired_names.get(obj, obj.name)
        if desired and obj.name != desired:
            obj.name = desired
        data = getattr(obj, 'data', None)
        if data is not None and hasattr(data, 'name'):
            try:
                data.name = retarget_siren_name_token(data.name, old_index, new_index, extra_name_map=name_map)
            except Exception:
                pass
        if getattr(obj, 'parent_type', '') == 'BONE':
            try:
                obj.parent_bone = retarget_siren_name_token(obj.parent_bone, old_index, new_index, extra_name_map=name_map)
            except Exception:
                pass
        _retarget_vertex_groups(obj, old_index, new_index, extra_name_map=name_map)
        _retarget_modifier_settings(obj, old_index, new_index, extra_name_map=name_map)
        _retarget_pointer_properties(obj, old_index, new_index, object_map=object_map, extra_name_map=name_map)
        data = getattr(obj, 'data', None)
        if data is not None and hasattr(data, 'bl_rna'):
            _retarget_pointer_properties(data, old_index, new_index, object_map=object_map, extra_name_map=name_map)
        _store_rest_loc(obj, force=True)

    if detach_root:
        try:
            world = root.matrix_world.copy()
            root.parent = None
            root.parent_type = 'OBJECT'
            root.parent_bone = ''
            root.matrix_parent_inverse = Matrix.Identity(4)
            root.matrix_world = world
            _store_rest_loc(root, force=True)
        except Exception:
            pass
    return hierarchy


def infer_siren_index_from_hierarchy(root, fallback=0):
    counts = {}
    for obj in [root] + iter_siren_object_hierarchy(root):
        for candidate in (
            infer_siren_index_from_object(obj),
            siren_index_from_name(getattr(obj, "name", "")),
            siren_index_from_name(getattr(obj, "parent_bone", "")),
        ):
            if candidate > 0:
                counts[candidate] = counts.get(candidate, 0) + 1
        for vg in getattr(obj, "vertex_groups", []):
            candidate = siren_index_from_name(getattr(vg, "name", ""))
            if candidate > 0:
                counts[candidate] = counts.get(candidate, 0) + 1
    if counts:
        return max(sorted(counts), key=lambda key: counts[key])
    return int(fallback or 0)


def suggest_duplicate_target_index(s, source_index):
    source_index = int(source_index or 0)
    used = {int(getattr(si, 'index', 0) or 0) for si in getattr(s, 'sirens', []) if getattr(si, 'object_name', '') or getattr(si, 'bone_name', '')}
    for idx in range(1, MAX_SIRENS + 1):
        if idx != source_index and idx not in used:
            return idx
    return max(1, min(MAX_SIRENS, source_index + 1 if source_index < MAX_SIRENS else MAX_SIRENS))


def duplicate_siren_hierarchy(scene, source_obj, old_index, new_index, extra_sources=None):
    if not scene or not source_obj:
        return None, []

    hierarchy_children = iter_siren_object_hierarchy(source_obj)
    extra_sources = [obj for obj in (extra_sources or []) if obj and obj not in {source_obj} and obj not in hierarchy_children]
    extra_source_set = set(extra_sources)
    sources = [source_obj] + hierarchy_children + extra_sources
    object_map = {}
    for src in sources:
        dup = src.copy()
        data = getattr(src, 'data', None)
        if data is not None:
            try:
                dup.data = data.copy()
            except Exception:
                dup.data = data
        try:
            dup.animation_data_clear()
        except Exception:
            pass

        linked = False
        for col in getattr(src, 'users_collection', []) or []:
            try:
                col.objects.link(dup)
                linked = True
            except Exception:
                pass
        if (not linked) and getattr(scene, 'collection', None):
            scene.collection.objects.link(dup)
        object_map[src] = dup

    for src, dup in object_map.items():
        if src == source_obj:
            dup.parent = None
            dup.parent_type = 'OBJECT'
            dup.parent_bone = ''
            dup.matrix_parent_inverse = Matrix.Identity(4)
        elif src in extra_source_set:
            dup.parent = object_map[source_obj]
            dup.parent_type = 'OBJECT'
            dup.parent_bone = ''
            try:
                dup.matrix_parent_inverse = object_map[source_obj].matrix_world.inverted()
            except Exception:
                dup.matrix_parent_inverse = Matrix.Identity(4)
        elif src.parent in object_map:
            dup.parent = object_map[src.parent]
            dup.parent_type = src.parent_type
            dup.parent_bone = src.parent_bone
            try:
                dup.matrix_parent_inverse = src.matrix_parent_inverse.copy()
            except Exception:
                pass
        else:
            dup.parent = src.parent
            dup.parent_type = src.parent_type
            dup.parent_bone = src.parent_bone
            try:
                dup.matrix_parent_inverse = src.matrix_parent_inverse.copy()
            except Exception:
                pass
        dup.matrix_world = src.matrix_world.copy()
        _copy_obj_rotation(dup, src)
        dup.scale = src.scale.copy()

    dup_root = object_map.get(source_obj)
    retarget_siren_hierarchy(dup_root, old_index, new_index, object_map=object_map, detach_root=True)
    return dup_root, [object_map[src] for src in sources if src in object_map]


def resolve_context_siren(scene, s, require_linked=False, update_active=True):
    if not s or not getattr(s, "sirens", None):
        return None

    active_obj = getattr(bpy.context, "active_object", None)
    idx = infer_siren_index_from_object(active_obj, s=s) if active_obj else 0
    if 1 <= idx <= len(s.sirens):
        if update_active:
            s.active_siren = idx - 1
        return s.sirens[idx - 1]

    cur_idx = max(0, min(int(getattr(s, "active_siren", 0) or 0), len(s.sirens) - 1))
    cur_si = s.sirens[cur_idx]
    if not require_linked:
        return cur_si
    if siren_obj(cur_si) or siren_pose_bone(scene, cur_si)[1]:
        return cur_si

    for si in s.sirens:
        if siren_obj(si) or siren_pose_bone(scene, si)[1]:
            if update_active:
                s.active_siren = max(0, int(getattr(si, "index", 1)) - 1)
            return si
    return cur_si


def scene_armature_items(self, context):
    scene = getattr(context, "scene", None) if context else getattr(bpy.context, "scene", None)
    items = []
    if scene:
        arm_names = sorted({obj.name for obj in scene.objects if obj.type == "ARMATURE"}, key=str.lower)
        items = [(name, name, "") for name in arm_names]
    if not items:
        items = [("__NONE__", "(No armatures found)", "")]
    return items


def scene_siren_items(self, context):
    scene = getattr(context, "scene", None) if context else getattr(bpy.context, "scene", None)
    s = getattr(scene, "nels", None) if scene else None
    items = []
    if s and getattr(s, "sirens", None):
        for si in s.sirens:
            obj = siren_obj(si)
            arm, pb = siren_pose_bone(scene, si) if scene else (None, None)
            if obj or pb:
                idx = int(getattr(si, "index", 0) or 0)
                label = f"siren{idx}"
                desc = str(getattr(obj, "name", "") or getattr(pb, "name", "") or label)
                items.append((label, label, desc))
    if not items and s and getattr(s, "sirens", None):
        for si in s.sirens:
            idx = int(getattr(si, "index", 0) or 0)
            label = f"siren{idx}"
            items.append((label, label, ""))
    if not items:
        items = [("__NONE__", "(No sirens found)", "")]
    return items


def update_tool_working_siren(self, context):
    s = getattr(getattr(context, "scene", None), "nels", None) if context else None
    if not s or not getattr(s, "sirens", None):
        return
    val = str(getattr(s, "tool_working_siren", "") or "")
    if not val or val == "__NONE__":
        return
    idx = siren_index_from_name(val)
    if 1 <= idx <= len(s.sirens):
        s.active_siren = idx - 1


def update_siren_expanded(self, context):
    if not getattr(self, "expanded", False):
        return
    scene = getattr(context, "scene", None) if context else getattr(bpy.context, "scene", None)
    s = getattr(scene, "nels", None) if scene else None
    if not s or not getattr(s, "sirens", None):
        return
    target_idx = max(0, int(getattr(self, "index", 1) or 1) - 1)
    for si in s.sirens:
        if si != self and getattr(si, "expanded", False):
            si.expanded = False
    s.active_siren = min(target_idx, max(0, len(s.sirens) - 1))
    try:
        s.tool_working_siren = f"siren{int(getattr(self, 'index', 1) or 1)}"
    except Exception:
        pass
    tag_preview_ui_redraw()


def sync_tool_working_siren(scene, s):
    if not scene or not s or not getattr(s, "sirens", None):
        return False
    si = resolve_context_siren(scene, s, require_linked=False, update_active=True)
    if not si:
        return False
    idx = int(getattr(si, "index", 0) or 0)
    target = f"siren{idx}"
    if str(getattr(s, "tool_working_siren", "") or "") != target:
        s.tool_working_siren = target
        return True
    return False


def _norm_angle(v):
    try:
        a = float(v)
    except Exception:
        a = 0.0
    return (a + math.pi) % (2.0 * math.pi) - math.pi


def direction_preset_from_value(v, tol=0.0002):
    vn = _norm_angle(v)
    best_key = None
    best_delta = 1e9
    for key, ang in DIRECTIONS.items():
        d = abs(_norm_angle(vn - ang))
        if d < best_delta:
            best_delta = d
            best_key = key
    if best_key is not None and best_delta <= tol:
        return best_key
    return None


def dir_val(si):
    return float(si.custom_direction) if si.direction_mode == "CUSTOM" else DIRECTIONS.get(si.direction_preset, 0.0)


def sync_scale_factor_controls(s):
    global _SCALE_FACTOR_SYNC_GUARD
    if not s or _SCALE_FACTOR_SYNC_GUARD:
        return

    _SCALE_FACTOR_SYNC_GUARD = True
    try:
        sf = max(0.0, float(getattr(s, "scale_factor", 0.5)))
        s.scale_factor_choice = scale_factor_choice_from_value(sf)
        s.scale_factor_custom = sf
    except Exception:
        pass
    finally:
        _SCALE_FACTOR_SYNC_GUARD = False


def update_scale_factor_choice(self, context):
    global _SCALE_FACTOR_SYNC_GUARD
    if _SCALE_FACTOR_SYNC_GUARD:
        return

    _SCALE_FACTOR_SYNC_GUARD = True
    try:
        ch = getattr(self, "scale_factor_choice", "SF_2")
        if ch == "CUSTOM":
            self.scale_factor = max(0.0, float(getattr(self, "scale_factor_custom", 0.5)))
        else:
            self.scale_factor = float(SCALE_FACTOR_PRESET_VALUES.get(ch, 0.5))
            self.scale_factor_custom = self.scale_factor
    except Exception:
        pass
    finally:
        _SCALE_FACTOR_SYNC_GUARD = False
    mark_preview_dirty(context)


def update_scale_factor_custom(self, context):
    if getattr(self, "scale_factor_choice", "SF_2") != "CUSTOM":
        return
    update_scale_factor_choice(self, context)


def update_scale_factor_value(self, context):
    sync_scale_factor_controls(self)
    mark_preview_dirty(context)


def sync_siren_selector_controls(si):
    if not si:
        return
    try:
        si.pattern_select = UNSAVED_PATTERN_KEY if getattr(si, "pattern_source", "LIBRARY") == "CUSTOM" else normalize_pattern_key(getattr(si, "pattern_choice", "PAT_0"))
    except Exception:
        pass
    try:
        si.color_select = "__CUSTOM__" if getattr(si, "color_mode", "PRESET") == "CUSTOM" else normalize_color_key(getattr(si, "color_preset", "COL_0"))
    except Exception:
        pass
    try:
        si.direction_select = "__CUSTOM__" if getattr(si, "direction_mode", "PRESET") == "CUSTOM" else str(getattr(si, "direction_preset", "FRONT") or "FRONT")
    except Exception:
        pass


def update_pattern_select(self, context):
    scene = getattr(context, "scene", None) if context else None
    s = getattr(scene, "nels", None) if scene else None
    current_select = getattr(self, "pattern_select", "PAT_0")
    if current_select in {UNSAVED_PATTERN_KEY, "__CUSTOM__"}:
        if getattr(self, "pattern_source", "LIBRARY") != "CUSTOM" and s:
            p = get_pattern(s, getattr(self, "pattern_choice", "PAT_0"))
            if p:
                self.custom_visibility = getattr(p, "visibility", "BOTH") or "BOTH"
                bits = clean_bits(getattr(p, "bits", "0"))
                self.custom_bits = bits
                self.custom_value = str(parse_u32(getattr(p, "value", bits_to_int(bits))))
        self.pattern_source = "CUSTOM"
        if current_select == "__CUSTOM__":
            self.pattern_select = UNSAVED_PATTERN_KEY
    else:
        self.pattern_source = "LIBRARY"
        self.pattern_choice = normalize_pattern_key(current_select)
    queue_preview_refresh_feedback(scene)
    mark_preview_dirty(context, scene=scene, immediate=False)


def update_color_select(self, context):
    scene = getattr(context, "scene", None) if context else None
    s = getattr(scene, "nels", None) if scene else None
    if getattr(self, "color_select", "COL_0") == "__CUSTOM__":
        if getattr(self, "color_mode", "PRESET") != "CUSTOM" and s:
            c = get_color(s, getattr(self, "color_preset", "COL_0"))
            if c:
                self.custom_color = color_to_rgb(getattr(c, "value", COLORS["GENERAL_WHITE"]))
        self.color_mode = "CUSTOM"
    else:
        self.color_mode = "PRESET"
        self.color_preset = normalize_color_key(self.color_select)
    mark_preview_dirty(context)


def update_direction_select(self, context):
    if getattr(self, "direction_select", "FRONT") == "__CUSTOM__":
        if getattr(self, "direction_mode", "PRESET") != "CUSTOM":
            self.custom_direction = float(DIRECTIONS.get(getattr(self, "direction_preset", "FRONT"), 0.0))
        self.direction_mode = "CUSTOM"
    else:
        self.direction_mode = "PRESET"
        self.direction_preset = self.direction_select
        self.custom_direction = float(DIRECTIONS.get(self.direction_preset, 0.0))
    update_siren_direction(self, context)

def scale_val(si, scene=None):
    scn = scene if scene is not None else getattr(bpy.context, "scene", None)
    settings = getattr(scn, "nels", None) if scn else None
    if settings and hasattr(settings, "scale_factor"):
        try:
            return max(0.0, float(settings.scale_factor))
        except Exception:
            pass

    # Backward compatibility fallback.
    try:
        if getattr(si, "scale_mode", "PRESET") == "CUSTOM":
            return max(0.0, float(getattr(si, "custom_scale", 0.5)))
        return SCALES.get(getattr(si, "scale_preset", "SCALE_50"), 0.5)
    except Exception:
        return 0.5


def scale_factor_from_siren(si, scene=None):
    sc = max(0.0, scale_val(si, scene=scene))
    if sc <= 0.0:
        return 0.0
    return 1.0 / sc


def format_scale_factor(v):
    try:
        fv = float(v)
    except Exception:
        fv = 0.0
    if abs(fv - round(fv)) < 0.000001:
        return str(int(round(fv)))
    return f8(fv)


def shown_sim_scale(s, si):
    return 1.0


def hidden_sim_scale(s, si):
    return max(0.0, scale_val(si))


def _store_rest_loc(obj, force=False):
    if (not force) and ("_nels_rest_loc" in obj):
        return
    obj["_nels_rest_loc"] = [float(obj.location[0]), float(obj.location[1]), float(obj.location[2])]
    obj["_nels_rest_rot"] = [float(obj.rotation_euler[0]), float(obj.rotation_euler[1]), float(obj.rotation_euler[2])]
    obj["_nels_rest_scale"] = [float(obj.scale[0]), float(obj.scale[1]), float(obj.scale[2])]
    try:
        obj["_nels_rest_world"] = [float(v) for row in obj.matrix_world for v in row]
    except Exception:
        pass


def _rest_loc(obj):
    data = obj.get("_nels_rest_loc")
    if isinstance(data, (list, tuple)) and len(data) == 3:
        return Vector((float(data[0]), float(data[1]), float(data[2])))
    _store_rest_loc(obj)
    data = obj.get("_nels_rest_loc")
    return Vector((float(data[0]), float(data[1]), float(data[2])))


def _rest_rot(obj):
    data = obj.get("_nels_rest_rot")
    if isinstance(data, (list, tuple)) and len(data) == 3:
        return Vector((float(data[0]), float(data[1]), float(data[2])))
    _store_rest_loc(obj)
    data = obj.get("_nels_rest_rot", [0.0, 0.0, 0.0])
    return Vector((float(data[0]), float(data[1]), float(data[2])))


def _rest_scale(obj):
    data = obj.get("_nels_rest_scale")
    if isinstance(data, (list, tuple)) and len(data) == 3:
        return Vector((float(data[0]), float(data[1]), float(data[2])))
    _store_rest_loc(obj)
    data = obj.get("_nels_rest_scale", [1.0, 1.0, 1.0])
    return Vector((float(data[0]), float(data[1]), float(data[2])))


def _rest_world_matrix(obj):
    data = obj.get("_nels_rest_world")
    if isinstance(data, (list, tuple)) and len(data) == 16:
        return Matrix((
            (float(data[0]), float(data[1]), float(data[2]), float(data[3])),
            (float(data[4]), float(data[5]), float(data[6]), float(data[7])),
            (float(data[8]), float(data[9]), float(data[10]), float(data[11])),
            (float(data[12]), float(data[13]), float(data[14]), float(data[15])),
        ))
    _store_rest_loc(obj)
    data = obj.get("_nels_rest_world", [1.0, 0.0, 0.0, 0.0, 0.0, 1.0, 0.0, 0.0, 0.0, 0.0, 1.0, 0.0, 0.0, 0.0, 0.0, 1.0])
    return Matrix((
        (float(data[0]), float(data[1]), float(data[2]), float(data[3])),
        (float(data[4]), float(data[5]), float(data[6]), float(data[7])),
        (float(data[8]), float(data[9]), float(data[10]), float(data[11])),
        (float(data[12]), float(data[13]), float(data[14]), float(data[15])),
    ))


def rotator_preview_targets(si):
    o = siren_obj(si)
    if not o:
        return []
    direct_children = [child for child in o.children if getattr(child, "type", "") != "ARMATURE"]
    return direct_children if direct_children else [o]


def rotator_preview_pose_bones(scene, si):
    arm, pb = siren_pose_bone(scene, si)
    if not arm or not pb:
        return []
    return [child for child in getattr(pb, "children", []) if child]


def iter_pose_bone_descendants(pb):
    found = []
    stack = list(getattr(pb, "children", []))
    while stack:
        cur = stack.pop(0)
        if not cur or cur in found:
            continue
        found.append(cur)
        stack.extend(list(getattr(cur, "children", [])))
    return found


def siren_descendant_bone_names(scene, si):
    arm, pb = siren_pose_bone(scene, si)
    if not arm or not pb:
        return set()
    return {child.name for child in iter_pose_bone_descendants(pb)}


def siren_descendant_bone_objects(scene, si):
    arm, pb = siren_pose_bone(scene, si)
    if not arm or not pb or not scene:
        return []
    names = siren_descendant_bone_names(scene, si)
    if not names:
        return []
    found = []
    for obj in scene.objects:
        try:
            if obj.parent == arm and obj.parent_type == "BONE" and obj.parent_bone in names:
                found.append(obj)
        except Exception:
            continue
    return found


def apply_rotator_preview_targets(si, turns=0.0, keyframe_frame=None):
    if not si or getattr(si, "siren_type", "FLASHER") != "ROTATOR":
        return 0

    rot_sign = 1.0 if getattr(si, "rotator_clockwise", True) else -1.0
    updated = 0
    for obj in rotator_preview_targets(si):
        _store_rest_loc(obj)
        rest_loc = _rest_loc(obj)
        rest_rot = _rest_rot(obj)
        rest_scale = _rest_scale(obj)
        obj.rotation_mode = "XYZ"
        obj.location = rest_loc
        obj.scale = rest_scale
        obj.rotation_euler = rest_rot
        obj.rotation_euler[2] = rest_rot[2] + rot_sign * turns * math.tau
        if keyframe_frame is not None:
            obj.keyframe_insert(data_path="rotation_euler", index=2, frame=keyframe_frame)
        updated += 1
    return updated


def apply_rotator_preview_pose_targets(scene, si, turns=0.0, keyframe_frame=None):
    if not si or getattr(si, "siren_type", "FLASHER") != "ROTATOR":
        return 0

    arm, _pb = siren_pose_bone(scene, si)
    if not arm:
        return 0

    rot_sign = 1.0 if getattr(si, "rotator_clockwise", True) else -1.0
    updated = 0
    for target in rotator_preview_pose_bones(scene, si):
        _store_rest_pose_bone(arm, target)
        rest_loc, rest_rot, rest_sc = _rest_pose_bone(arm, target)
        target.rotation_mode = "XYZ"
        target.location = rest_loc
        target.scale = rest_sc
        target.rotation_euler = rest_rot
        target.rotation_euler[2] = rest_rot[2] + rot_sign * turns * math.tau
        if keyframe_frame is not None:
            target.keyframe_insert(data_path="rotation_euler", index=2, frame=keyframe_frame)
        updated += 1
    return updated


def target_sim_loc(obj, mode):
    rest = _rest_loc(obj)
    if mode == "ON":
        return rest
    if obj.parent_type == "BONE":
        return Vector((0.0, 0.0, 0.0))
    return rest


def _vector_mul(a, b):
    return Vector((float(a[0]) * float(b[0]), float(a[1]) * float(b[1]), float(a[2]) * float(b[2])))


def _vector_div_scalar(v, scalar):
    val = float(scalar)
    return Vector((float(v[0]) / val, float(v[1]) / val, float(v[2]) / val))


def siren_object_driven_by_bone(scene, si):
    o = siren_obj(si)
    arm, pb = siren_pose_bone(scene, si)
    return bool(o and arm and pb and o.parent == arm and o.parent_type == "BONE" and o.parent_bone == pb.name)


def iter_siren_object_hierarchy(root):
    if not root:
        return []
    found = []
    stack = list(getattr(root, "children", []))
    while stack:
        obj = stack.pop(0)
        if not obj or obj in found:
            continue
        if getattr(obj, "type", "") != "ARMATURE":
            found.append(obj)
        stack.extend(list(getattr(obj, "children", [])))
    return found


def scale_object_data(obj, factor_vec):
    if not obj:
        return False
    data = getattr(obj, "data", None)
    if data is None or not hasattr(data, "transform"):
        return False
    try:
        if getattr(data, "users", 1) > 1:
            obj.data = data.copy()
            data = obj.data
        data.transform(Matrix.Diagonal((float(factor_vec[0]), float(factor_vec[1]), float(factor_vec[2]), 1.0)))
        if hasattr(data, "update"):
            data.update()
        return True
    except Exception:
        return False


def siren_child_objects(si):
    o = siren_obj(si)
    if not o:
        return []
    return [child for child in getattr(o, "children", []) if child and getattr(child, "type", "") != "ARMATURE"]


def apply_siren_child_object_compensation(si, scalar):
    root = siren_obj(si)
    if not root:
        return
    root.rotation_mode = "XYZ"
    parent_loc = root.matrix_world.translation.copy()
    parent_rot = root.matrix_world.to_quaternion()
    parent_noscale = Matrix.LocRotScale(parent_loc, parent_rot, Vector((1.0, 1.0, 1.0)))
    for child in siren_child_objects(si):
        _store_rest_loc(child)
        rest_loc = _rest_loc(child)
        rest_rot = Euler(_rest_rot(child), "XYZ")
        rest_scale = _rest_scale(child)
        child_local = Matrix.LocRotScale(rest_loc, rest_rot.to_quaternion(), rest_scale)
        child.matrix_world = parent_noscale @ child_local


def apply_siren_child_pose_compensation(scene, si, scalar):
    val = max(0.000001, float(scalar))
    arm, _pb = siren_pose_bone(scene, si)
    if not arm:
        return
    for child in rotator_preview_pose_bones(scene, si):
        _store_rest_pose_bone(arm, child)
        rest_loc, rest_rot, rest_sc = _rest_pose_bone(arm, child)
        child.rotation_mode = "XYZ"
        child.location = _vector_div_scalar(rest_loc, val)
        child.rotation_euler = rest_rot
        child.scale = (rest_sc[0] / val, rest_sc[1] / val, rest_sc[2] / val)


def apply_siren_descendant_bone_object_compensation(scene, si, mode, keyframe_frame=None, preserved_world=None):
    preserved_world = dict(preserved_world or {})
    for obj in siren_descendant_bone_objects(scene, si):
        _store_rest_loc(obj)
        obj.rotation_mode = "XYZ"
        rest_loc = _rest_loc(obj)
        rest_rot = Euler(_rest_rot(obj), "XYZ")
        rest_scale = _rest_scale(obj)

        preserved = preserved_world.get(obj)
        if preserved is not None:
            obj.matrix_world = preserved
        else:
            arm = getattr(obj, "parent", None)
            bone_name = str(getattr(obj, "parent_bone", "") or "")
            pose_bone = None
            try:
                if arm and getattr(arm, "type", "") == "ARMATURE" and bone_name:
                    pose_bone = getattr(getattr(arm, "pose", None), "bones", {}).get(bone_name)
            except Exception:
                pose_bone = None

            if pose_bone:
                parent_world = (arm.matrix_world @ pose_bone.matrix).copy()
                parent_noscale = Matrix.LocRotScale(parent_world.translation.copy(), parent_world.to_quaternion(), Vector((1.0, 1.0, 1.0)))
                child_local = Matrix.LocRotScale(rest_loc, rest_rot.to_quaternion(), rest_scale)
                obj.matrix_world = parent_noscale @ child_local
            elif mode == "OFF":
                obj.matrix_world = _rest_world_matrix(obj)
            else:
                obj.location = rest_loc
                obj.rotation_euler = rest_rot
                obj.scale = rest_scale

        if keyframe_frame is not None:
            obj.keyframe_insert(data_path="location", frame=keyframe_frame)
            obj.keyframe_insert(data_path="scale", frame=keyframe_frame)


def restore_siren_default_state(scene, si):
    restored = 0
    o = siren_obj(si)
    if o:
        _store_rest_loc(o)
        o.rotation_mode = "XYZ"
        o.location = _rest_loc(o)
        o.rotation_euler = _rest_rot(o)
        o.scale = _rest_scale(o)
        restored += 1
        for child in iter_siren_object_hierarchy(o):
            if any(k in child for k in ("_nels_rest_loc", "_nels_rest_rot", "_nels_rest_scale")):
                child.rotation_mode = "XYZ"
                child.location = _rest_loc(child)
                child.rotation_euler = _rest_rot(child)
                child.scale = _rest_scale(child)
                restored += 1

    arm, pb = siren_pose_bone(scene, si)
    if arm and pb:
        _store_rest_pose_bone(arm, pb)
        rest_loc, rest_rot, rest_sc = _rest_pose_bone(arm, pb)
        pb.rotation_mode = "XYZ"
        pb.location = rest_loc
        pb.rotation_euler = rest_rot
        pb.scale = rest_sc
        restored += 1
        for child in rotator_preview_pose_bones(scene, si):
            key = _pose_rest_key(child.name)
            if key in arm:
                rest_loc, rest_rot, rest_sc = _rest_pose_bone(arm, child)
                child.rotation_mode = "XYZ"
                child.location = rest_loc
                child.rotation_euler = rest_rot
                child.scale = rest_sc
                restored += 1
    for obj in siren_descendant_bone_objects(scene, si):
        if any(k in obj for k in ("_nels_rest_loc", "_nels_rest_rot", "_nels_rest_scale")):
            obj.rotation_mode = "XYZ"
            obj.location = _rest_loc(obj)
            obj.rotation_euler = _rest_rot(obj)
            obj.scale = _rest_scale(obj)
            restored += 1

    return restored


def bake_siren_scale_state(scene, s, si, mode):
    o = siren_obj(si)
    if not o:
        return False, "No linked siren mesh found for the selected siren"

    target_scalar = shown_sim_scale(s, si) if mode == "ON" else hidden_sim_scale(s, si)
    if target_scalar <= 0.0:
        return False, "Scale Factor must be above 0 before baking the hidden siren scale"

    arm, pb = siren_pose_bone(scene, si)
    bone_driven = siren_object_driven_by_bone(scene, si)

    current_effective = Vector((float(o.scale[0]), float(o.scale[1]), float(o.scale[2])))
    if bone_driven and pb:
        current_effective = _vector_mul(current_effective, Vector((float(pb.scale[0]), float(pb.scale[1]), float(pb.scale[2]))))

    factor_vec = _vector_div_scalar(current_effective, target_scalar)
    baked = 1 if scale_object_data(o, factor_vec) else 0

    o.rotation_mode = "XYZ"
    o.scale = (1.0, 1.0, 1.0)
    _store_rest_loc(o, force=True)

    if arm and pb:
        pb.rotation_mode = "XYZ"
        pb.scale = (1.0, 1.0, 1.0)
        _store_rest_pose_bone(arm, pb, force=True)

    apply_sim_state(scene, s, si, mode)

    if hasattr(scene, "view_layers"):
        try:
            bpy.context.view_layer.update()
        except Exception:
            pass

    queue_preview_refresh_feedback(scene)
    mark_preview_dirty(scene=scene, immediate=False)
    return True, f"Baked {mode.lower()} scale for siren{si.index} on {max(1, baked)} object(s)"



def _pose_rest_key(bone_name):
    return f"_nels_rest_pose_{bone_name}"


def _store_rest_pose_bone(arm, pb, force=False):
    key = _pose_rest_key(pb.name)
    if (not force) and (key in arm):
        return
    old_mode = pb.rotation_mode
    try:
        pb.rotation_mode = "XYZ"
        arm[key] = [
            float(pb.location[0]),
            float(pb.location[1]),
            float(pb.location[2]),
            float(pb.rotation_euler[0]),
            float(pb.rotation_euler[1]),
            float(pb.rotation_euler[2]),
            float(pb.scale[0]),
            float(pb.scale[1]),
            float(pb.scale[2]),
        ]
    finally:
        pb.rotation_mode = old_mode


def _rest_pose_bone(arm, pb):
    key = _pose_rest_key(pb.name)
    data = arm.get(key)
    if isinstance(data, (list, tuple)) and len(data) == 9:
        loc = Vector((float(data[0]), float(data[1]), float(data[2])))
        rot = Vector((float(data[3]), float(data[4]), float(data[5])))
        sc = Vector((float(data[6]), float(data[7]), float(data[8])))
        return loc, rot, sc
    _store_rest_pose_bone(arm, pb)
    data = arm.get(key, [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 1.0, 1.0, 1.0])
    loc = Vector((float(data[0]), float(data[1]), float(data[2])))
    rot = Vector((float(data[3]), float(data[4]), float(data[5])))
    sc = Vector((float(data[6]), float(data[7]), float(data[8])))
    return loc, rot, sc


def apply_sim_state(scene, s, si, mode, turns=0.0, keyframe_frame=None):
    o = siren_obj(si)
    arm, pb = siren_pose_bone(scene, si)
    sc = shown_sim_scale(s, si) if mode == "ON" else hidden_sim_scale(s, si)
    applied = False

    preserved_desc_world = {}
    if keyframe_frame is None and mode == "OFF":
        try:
            for child_obj in siren_descendant_bone_objects(scene, si):
                preserved_desc_world[child_obj] = child_obj.matrix_world.copy()
        except Exception:
            preserved_desc_world = {}

    is_rotator = getattr(si, "siren_type", "FLASHER") == "ROTATOR"
    rotation_only_key = bool(keyframe_frame is not None and is_rotator and mode == "ON" and abs(float(turns)) > 0.000001)
    object_driven_by_bone = bool(o and arm and pb and o.parent == arm and o.parent_type == "BONE" and o.parent_bone == pb.name)

    if o:
        _store_rest_loc(o)
        rest_loc = _rest_loc(o)
        rest_rot = _rest_rot(o)
        rest_scale = _rest_scale(o)

        o.rotation_mode = "XYZ"
        o.rotation_euler = rest_rot
        if is_rotator and not (arm and pb):
            rot_sign = 1.0 if getattr(si, "rotator_clockwise", True) else -1.0
            o.rotation_euler[2] = rest_rot[2] + rot_sign * turns * math.tau

        o.location = rest_loc
        if object_driven_by_bone or (arm and pb and is_rotator):
            o.scale = rest_scale
        else:
            o.scale = (rest_scale[0] * sc, rest_scale[1] * sc, rest_scale[2] * sc)

        if keyframe_frame is not None:
            if (not rotation_only_key) and not (object_driven_by_bone or (arm and pb and is_rotator)):
                o.keyframe_insert(data_path="scale", frame=keyframe_frame)
            if is_rotator and not (arm and pb):
                o.keyframe_insert(data_path="rotation_euler", index=2, frame=keyframe_frame)
        applied = True

    if arm and pb:
        _store_rest_pose_bone(arm, pb)
        rest_loc, rest_rot, rest_sc = _rest_pose_bone(arm, pb)
        pb.rotation_mode = "XYZ"
        pb.location = rest_loc
        pb.rotation_euler = rest_rot
        if is_rotator:
            rot_sign = 1.0 if getattr(si, "rotator_clockwise", True) else -1.0
            pb.rotation_euler = (rest_rot[0], rest_rot[1], rest_rot[2] + rot_sign * turns * math.tau)
        pb.scale = (rest_sc[0] * sc, rest_sc[1] * sc, rest_sc[2] * sc)

        if keyframe_frame is not None:
            if not rotation_only_key:
                pb.keyframe_insert(data_path="scale", frame=keyframe_frame)
            if is_rotator:
                pb.keyframe_insert(data_path="rotation_euler", index=2, frame=keyframe_frame)
        applied = True

    if applied:
        try:
            bpy.context.view_layer.update()
        except Exception:
            pass

    if o:
        apply_siren_child_object_compensation(si, sc)
    if arm and pb:
        apply_siren_child_pose_compensation(scene, si, sc)
        apply_siren_descendant_bone_object_compensation(scene, si, mode, keyframe_frame=keyframe_frame, preserved_world=preserved_desc_world)

    return applied


def _ensure_cycles_fcurve(fc):
    if not fc:
        return
    for m in fc.modifiers:
        if m.type == "CYCLES":
            return
    mod = fc.modifiers.new(type="CYCLES")
    mod.mode_before = "REPEAT"
    mod.mode_after = "REPEAT"


def _iter_action_fcurves(action):
    if not action:
        return

    # Blender <= 4.x API.
    legacy = getattr(action, "fcurves", None)
    if legacy is not None:
        for fc in legacy:
            yield fc
        return

    # Blender 5.x layered Action API.
    for layer in getattr(action, "layers", []):
        for strip in getattr(layer, "strips", []):
            for bag in getattr(strip, "channelbags", []):
                for fc in getattr(bag, "fcurves", []):
                    yield fc

def _clear_cycles_modifiers(action, path_predicate):
    for fc in _iter_action_fcurves(action):
        data_path = str(getattr(fc, "data_path", ""))
        if not path_predicate(data_path):
            continue
        try:
            for m in list(fc.modifiers):
                if m.type == "CYCLES":
                    fc.modifiers.remove(m)
        except Exception:
            pass


def _set_preview_key_interpolation(scene, si):
    def _set_interp(fc, mode):
        try:
            for kp in fc.keyframe_points:
                kp.interpolation = mode
        except Exception:
            pass

    o = siren_obj(si)
    if o and o.animation_data and o.animation_data.action:
        for fc in _iter_action_fcurves(o.animation_data.action):
            if fc.data_path in {"location", "scale"}:
                _set_interp(fc, "CONSTANT")
            elif si.siren_type == "ROTATOR" and fc.data_path == "rotation_euler" and int(getattr(fc, "array_index", -1)) == 2:
                _set_interp(fc, "LINEAR")

    if getattr(si, "siren_type", "FLASHER") == "ROTATOR":
        for target in rotator_preview_targets(si):
            if not target or target == o:
                continue
            act = getattr(getattr(target, "animation_data", None), "action", None)
            if not act:
                continue
            for fc in _iter_action_fcurves(act):
                if fc.data_path == "rotation_euler" and int(getattr(fc, "array_index", -1)) == 2:
                    _set_interp(fc, "LINEAR")

    arm, pb = siren_pose_bone(scene, si)
    if arm and pb and arm.animation_data and arm.animation_data.action:
        target_bones = {pb.name}
        if getattr(si, "siren_type", "FLASHER") == "ROTATOR":
            target_bones.update(child.name for child in rotator_preview_pose_bones(scene, si))

        for fc in _iter_action_fcurves(arm.animation_data.action):
            path = str(getattr(fc, "data_path", ""))
            prefix = 'pose.bones["'
            if not path.startswith(prefix):
                continue
            bone_name = path[len(prefix):].split('"]', 1)[0]
            if bone_name not in target_bones:
                continue
            if path.endswith(".location") or path.endswith(".scale"):
                _set_interp(fc, "CONSTANT")
            elif si.siren_type == "ROTATOR" and path.endswith(".rotation_euler") and int(getattr(fc, "array_index", -1)) == 2:
                _set_interp(fc, "LINEAR")


def preview_step_frames(bpm, fps):
    bpm_val = max(1.0, float(bpm))
    fps_val = max(1.0, float(fps))
    return max(0.01, (60.0 / bpm_val) * fps_val)


def preview_cycle_frames(bpm, fps, bit_count=32):
    return preview_step_frames(bpm, fps) * max(1, int(bit_count))


def start_delay_frames(bpm, fps, si):
    try:
        delay = max(0.0, float(getattr(si, "start_delay", 0.0) or 0.0))
    except Exception:
        delay = 0.0
    return delay * preview_step_frames(bpm, fps)

def ensure_siren_preview_cycles(scene, si):
    o = siren_obj(si)
    if o and o.animation_data and o.animation_data.action:
        act = o.animation_data.action
        for fc in _iter_action_fcurves(act):
            if fc.data_path in {"location", "scale", "rotation_euler"}:
                _ensure_cycles_fcurve(fc)

    if getattr(si, "siren_type", "FLASHER") == "ROTATOR":
        for target in rotator_preview_targets(si):
            if not target or target == o:
                continue
            act = getattr(getattr(target, "animation_data", None), "action", None)
            if not act:
                continue
            for fc in _iter_action_fcurves(act):
                if fc.data_path == "rotation_euler" and int(getattr(fc, "array_index", -1)) == 2:
                    _ensure_cycles_fcurve(fc)

    arm, pb = siren_pose_bone(scene, si)
    if arm and pb and arm.animation_data and arm.animation_data.action:
        target_bones = {pb.name}
        if getattr(si, "siren_type", "FLASHER") == "ROTATOR":
            target_bones.update(child.name for child in rotator_preview_pose_bones(scene, si))
        act = arm.animation_data.action
        for fc in _iter_action_fcurves(act):
            path = str(getattr(fc, "data_path", ""))
            prefix = 'pose.bones["'
            if not path.startswith(prefix):
                continue
            bone_name = path[len(prefix):].split('"]', 1)[0]
            if bone_name not in target_bones:
                continue
            if path.endswith(".location") or path.endswith(".scale") or path.endswith(".rotation_euler"):
                _ensure_cycles_fcurve(fc)
def rot_speed(bpm, si):
    if si.rotator_speed_mode == "CUSTOM":
        return float(bpm) / 100.0 * (max(0.0, si.rotator_custom_percent) / 6.25)
    return float(bpm) / 100.0 * ROT_SPEED.get(si.rotator_speed_mode, 1.0)


def rotator_cycle_frames(bpm, fps, si):
    rpm = max(0.000001, float(rot_speed(bpm, si)))
    fps_val = max(1.0, float(fps))
    return max(1.0, (60.0 / rpm) * fps_val)


def siren_base_color_rgb(s, si):
    if si.color_mode == "PRESET":
        c = get_color(s, si.color_preset)
        return color_to_rgb(c.value) if c else (1.0, 0.0, 0.0)
    return tuple(si.custom_color)


def get_siren_configured_color(self):
    try:
        scene = getattr(bpy.context, "scene", None)
        s = getattr(scene, "nels", None) if scene else None
        return tuple(siren_base_color_rgb(s, self)) if s else tuple(self.custom_color)
    except Exception:
        return (1.0, 1.0, 1.0)


def color_hex(s, si):
    if si.color_mode == "PRESET":
        c = get_color(s, si.color_preset)
        return clean_color_value(c.value) if c else "0xFFFF0000"
    return rgb_to_color(si.custom_color)

def pattern_triplet(s, si):
    if si.pattern_source == "CUSTOM":
        bits = repeat_32(si.custom_bits)
        return bits, bits_to_int(bits), si.custom_visibility
    p = get_pattern(s, si.pattern_choice)
    if not p:
        return "0" * 32, 0, "BOTH"
    bits = repeat_32(p.bits)
    return bits, bits_to_int(bits), p.visibility


def siren_is_active(si):
    if not si:
        return False

    has_object = bool(si.object_name and si.object_name in bpy.data.objects)
    has_bone = False
    try:
        scene = getattr(bpy.context, "scene", None)
        arm, pb = siren_pose_bone(scene, si)
        has_bone = bool(arm and pb)
    except Exception:
        has_bone = False
    return has_object or has_bone

def siren_has_output(s, si):
    if not s or not si:
        return False
    _, seq, vis = pattern_triplet(s, si)
    if seq == 0:
        return False
    if si.siren_type == "ROTATOR":
        return vis in {"BOTH", "ROTATOR"}
    return vis in {"BOTH", "FLASHER"}


def ensure_defaults(s):
    if not s.patterns:
        data = load_global_library_data()
        loaded = False
        pats = data.get("patterns", []) if isinstance(data, dict) else []
        if isinstance(pats, list) and pats:
            for pd in pats:
                if not isinstance(pd, dict):
                    continue
                p = s.patterns.add()
                p.name = str(pd.get("name", "Pattern") or "Pattern")
                p.visibility = "FLASHER" if pd.get("visibility", "BOTH") == "FLASHER" else "BOTH"
                p.bits = clean_bits(pd.get("bits", int_to_bits(pd.get("value", 0)))) or "0"
                p.value = str(parse_u32(pd.get("value", bits_to_int(p.bits))))
                p.allow_duplicate = bool(pd.get("allow_duplicate", False))
            loaded = bool(s.patterns)

        if not loaded:
            populate_default_patterns(s)

    migrate_legacy_default_patterns(s)

    ensure_off_pattern(s)
    if s.patterns:
        s.active_pattern = min(max(0, s.active_pattern), len(s.patterns) - 1)
    save_global_library(s)


def ensure_off_pattern(s):
    for p in s.patterns:
        if (p.name or "").strip().lower() == "off":
            if not hasattr(p, "allow_duplicate"):
                continue
            return
    p = s.patterns.add()
    p.name = "Off"
    p.visibility = "BOTH"
    p.bits = "0"
    p.value = "0"
    p.allow_duplicate = False


def ensure_default_color_entries(s):
    if not s:
        return False
    changed = False
    existing = {(str(getattr(c, "name", "") or "").strip().lower(), clean_color_value(getattr(c, "value", "0xFFFF0000"))) for c in getattr(s, "colors", [])}
    existing_values = {clean_color_value(getattr(c, "value", "0xFFFF0000")) for c in getattr(s, "colors", [])}
    for _key, label, value in COLOR_ITEMS:
        sig = (label.strip().lower(), clean_color_value(value))
        if sig in existing or sig[1] in existing_values:
            continue
        c = s.colors.add()
        c.name = label
        c.value = clean_color_value(value)
        c.rgb = color_to_rgb(c.value)
        existing.add(sig)
        existing_values.add(sig[1])
        changed = True
    return changed


def ensure_color_defaults(s):
    loaded = bool(getattr(s, "colors", None))
    if not loaded:
        data = load_global_library_data()
        cols = data.get("colors", []) if isinstance(data, dict) else []
        if isinstance(cols, list) and cols:
            for cd in cols:
                if not isinstance(cd, dict):
                    continue
                c = s.colors.add()
                c.name = str(cd.get("name", "Colour") or "Colour")
                c.value = clean_color_value(cd.get("value", "0xFFFF0000"))
                c.rgb = color_to_rgb(c.value)
            loaded = bool(s.colors)

    if not loaded:
        for name, value in DEFAULT_COLOR_LIBRARY:
            c = s.colors.add()
            c.name = name
            c.value = clean_color_value(value)
            c.rgb = color_to_rgb(c.value)

    changed = ensure_default_color_entries(s)
    s.active_color = min(max(0, s.active_color), max(0, len(s.colors) - 1)) if s.colors else 0
    if changed or not loaded:
        save_global_library(s)


def ensure_other_attributes_defaults(s):
    if not s or s.other_attributes:
        return

    defaults = [
        ("Scale Factor 2", "0.5"),
        ("Scale Factor 10", "0.1"),
        ("Scale Factor 100", "0.01"),
    ]
    for disp, ret in defaults:
        a = s.other_attributes.add()
        a.display_value = disp
        a.return_value = ret
    s.active_other_attribute = 0


def add_siren(s, si, idx):
    si.index = idx
    si.name = f"siren{idx}"
    si.enabled = False
    si.siren_type = "FLASHER"
    si.rotator_speed_mode = "P50"
    si.rotator_custom_percent = 50.0
    si.rotator_clockwise = True
    si.pattern_source = "LIBRARY"
    si.pattern_choice = off_pattern_key(s)
    si.custom_visibility = "BOTH"
    si.custom_bits = "0"
    si.custom_value = "0"
    si.color_mode = "PRESET"
    si.color_preset = white_color_key(s)
    si.custom_color = (1.0, 1.0, 1.0)
    si.flash_preview = True
    si.direction_mode = "PRESET"
    si.direction_preset = "FRONT"
    si.scale_mode = "PRESET"
    si.scale_preset = "SCALE_50"
    si.custom_scale = 0.5
    si.sync_to_bpm = True
    si.flash = True
    si.light = False
    si.spot_light = False
    si.cast_shadows = False
    si.light_group = 1
    si.start_delay = 0.0
    si.light_speed = 0.0
    si.light_multiples = 2
    si.corona_intensity = 0.5
    si.corona_size = 0.0
    si.corona_pull = 0.00000001
    si.light_intensity = 0.5
    si.corona_face_camera = False
    si.object_name = ""
    si.anchor_name = ""
    si.bone_name = ""
    si.filter_selected = True
    si.expanded = (idx == 1)
    sync_siren_selector_controls(si)


def ensure_sirens(s, count):
    count = max(0, min(MAX_SIRENS, int(count)))
    while len(s.sirens) < count:
        i = len(s.sirens) + 1
        si = s.sirens.add()
        add_siren(s, si, i)
    while len(s.sirens) > count:
        s.sirens.remove(len(s.sirens) - 1)
    s.siren_count = count
    s.active_siren = min(s.active_siren, max(0, count - 1))
    for i, si in enumerate(s.sirens, start=1):
        si.index = i
        si.name = f"siren{i}"
    if count > 0 and not any(bool(getattr(si, "expanded", False)) for si in s.sirens):
        s.sirens[min(int(getattr(s, "active_siren", 0) or 0), count - 1)].expanded = True
    if hasattr(s, "preview_dirty"):
        s.preview_dirty = True



def _sync_pattern_bits(pg):
    bits = repeat_32(pg.bits)
    val = str(bits_to_int(bits))
    if pg.bits != bits:
        pg.bits = bits
    if pg.value != val:
        pg.value = val


def _sync_pattern_value(pg):
    val = str(parse_u32(pg.value))
    bits = int_to_bits(val)
    if pg.value != val:
        pg.value = val
    if pg.bits != bits:
        pg.bits = bits


def update_pattern_bits(self, context):
    scene = getattr(context, "scene", None) if context else getattr(bpy.context, "scene", None)
    _sync_pattern_bits(self)
    save_library_from_context(context)
    queue_preview_refresh_feedback(scene)
    mark_preview_dirty(context, scene=scene, immediate=False)


def update_pattern_value(self, context):
    scene = getattr(context, "scene", None) if context else getattr(bpy.context, "scene", None)
    _sync_pattern_value(self)
    save_library_from_context(context)
    queue_preview_refresh_feedback(scene)
    mark_preview_dirty(context, scene=scene, immediate=False)


def update_pattern_meta(self, context):
    scene = getattr(context, "scene", None) if context else getattr(bpy.context, "scene", None)
    save_library_from_context(context)
    queue_preview_refresh_feedback(scene)
    mark_preview_dirty(context, scene=scene, immediate=False)


def update_color_name(self, context):
    save_library_from_context(context)


def _sync_siren_bits(si):
    bits = repeat_32(si.custom_bits)
    val = str(bits_to_int(bits))
    if si.custom_bits != bits:
        si.custom_bits = bits
    if si.custom_value != val:
        si.custom_value = val


def _sync_siren_value(si):
    val = str(parse_u32(si.custom_value))
    bits = int_to_bits(val)
    if si.custom_value != val:
        si.custom_value = val
    if si.custom_bits != bits:
        si.custom_bits = bits


def update_siren_bits(self, context):
    scene = getattr(context, "scene", None) if context else getattr(bpy.context, "scene", None)
    _sync_siren_bits(self)
    queue_preview_refresh_feedback(scene)
    mark_preview_dirty(context, scene=scene, immediate=False)


def update_siren_value(self, context):
    scene = getattr(context, "scene", None) if context else getattr(bpy.context, "scene", None)
    _sync_siren_value(self)
    queue_preview_refresh_feedback(scene)
    mark_preview_dirty(context, scene=scene, immediate=False)

PREVIEW_OFF_RGB = (0.18, 0.18, 0.18)


def _emissive_level(rgb, gain):
    g = max(0.0, float(gain))
    return tuple(max(0.0, min(1.0, float(c) * g)) for c in rgb)


def _preview_lit_color(rgb, intensity=1.0):
    base = tuple(max(0.0, min(1.0, float(c))) for c in rgb)
    peak = max(base) if base else 0.0
    if peak > 0.000001:
        vivid = tuple(min(1.0, c / peak) for c in base)
    else:
        vivid = (1.0, 1.0, 1.0)
    t = max(0.0, min(1.0, float(intensity)))
    return tuple((PREVIEW_OFF_RGB[i] * (1.0 - t)) + (vivid[i] * t) for i in range(3))


def _emissive_color(rgb, lit):
    if lit:
        return _preview_lit_color(rgb, 1.0)
    return PREVIEW_OFF_RGB


def apply_sollumz_emissive_multiplier(obj, value=10.0):
    if not obj or getattr(obj, "type", "") != "MESH":
        return
    mats = getattr(getattr(obj, "data", None), "materials", None)
    if not mats:
        return
    try:
        target = float(value)
    except Exception:
        target = 10.0

    for mat in mats:
        if mat is None:
            continue
        try:
            sp = getattr(mat, "shader_properties", None)
            if sp is not None:
                if hasattr(sp, "emissive_multiplier"):
                    setattr(sp, "emissive_multiplier", target)
                elif hasattr(sp, "emissiveMultiplier"):
                    setattr(sp, "emissiveMultiplier", target)

            if hasattr(mat, "emissive_multiplier"):
                setattr(mat, "emissive_multiplier", target)
            if hasattr(mat, "emissiveMultiplier"):
                setattr(mat, "emissiveMultiplier", target)

            if "emissiveMultiplier" in mat:
                mat["emissiveMultiplier"] = target
        except Exception:
            pass


def _head_tail_preview(s, key, base_rgb, preview_on=True):
    if not s:
        return tuple(base_rgb)
    if not preview_on:
        return tuple(base_rgb)
    scn = getattr(bpy.context, "scene", None)
    p = get_pattern(s, key)
    bits = repeat_32(p.bits) if p else ("0" * 32)
    return _emissive_color(base_rgb, preview_pattern_is_on(bits, s.bpm, scene=scn))


def get_left_head_preview(self):
    try:
        return tuple(self.left_head_preview_cache)
    except Exception:
        return _head_tail_preview(self, self.left_head, (1.0, 1.0, 1.0), getattr(self, "head_tail_preview", True))


def get_right_head_preview(self):
    try:
        return tuple(self.right_head_preview_cache)
    except Exception:
        return _head_tail_preview(self, self.right_head, (1.0, 1.0, 1.0), getattr(self, "head_tail_preview", True))


def get_left_tail_preview(self):
    try:
        return tuple(self.left_tail_preview_cache)
    except Exception:
        return _head_tail_preview(self, self.left_tail, (1.0, 0.0, 0.0), getattr(self, "head_tail_preview", True))


def get_right_tail_preview(self):
    try:
        return tuple(self.right_tail_preview_cache)
    except Exception:
        return _head_tail_preview(self, self.right_tail, (1.0, 0.0, 0.0), getattr(self, "head_tail_preview", True))


def update_rotator_settings(self, context):
    scene = getattr(context, "scene", None) if context else None
    s = getattr(scene, "nels", None) if scene else None
    if self.siren_type == "ROTATOR":
        if s:
            off_key = off_pattern_key(s)
            if normalize_pattern_key(self.pattern_choice) == off_key:
                self.pattern_choice = find_pattern_key_by_name(s, "Single Sweep")
        bpm = getattr(s, "bpm", 800) if s else 800
        self.light_speed = rot_speed(bpm, self)
    mark_preview_dirty(context, scene=scene)


def update_siren_type(self, context):
    if self.siren_type == "ROTATOR":
        self.pattern_source = "LIBRARY"
    update_rotator_settings(self, context)
    sync_siren_selector_controls(self)
    mark_preview_dirty(context)


def update_bpm(self, context):
    for si in self.sirens:
        if si.siren_type == "ROTATOR":
            try:
                si.light_speed = rot_speed(self.bpm, si)
            except Exception:
                pass
    mark_preview_dirty(context)



def preview_updates_suspended():
    return _PREVIEW_UPDATE_SUSPEND > 0


def suspend_preview_updates():
    global _PREVIEW_UPDATE_SUSPEND
    _PREVIEW_UPDATE_SUSPEND += 1


def resume_preview_updates():
    global _PREVIEW_UPDATE_SUSPEND
    _PREVIEW_UPDATE_SUSPEND = max(0, _PREVIEW_UPDATE_SUSPEND - 1)


def tag_all_ui_redraw():
    wm = getattr(bpy.context, "window_manager", None)
    if not wm:
        return
    try:
        for win in wm.windows:
            screen = getattr(win, "screen", None)
            if not screen:
                continue
            for area in screen.areas:
                try:
                    area.tag_redraw()
                except Exception:
                    pass
                for region in getattr(area, "regions", []):
                    try:
                        region.tag_redraw()
                    except Exception:
                        pass
    except Exception:
        pass


def custom_preview_overlay_enabled():
    return False
def tag_preview_ui_redraw():
    wm = getattr(bpy.context, "window_manager", None)
    if not wm:
        return
    try:
        for win in wm.windows:
            screen = getattr(win, "screen", None)
            if not screen:
                continue
            for area in screen.areas:
                if getattr(area, "type", "") != "VIEW_3D":
                    continue
                for region in getattr(area, "regions", []):
                    if getattr(region, "type", "") != "UI":
                        continue
                    try:
                        region.tag_redraw()
                    except Exception:
                        pass
    except Exception:
        pass

def ui_wrap_width_chars(context, fallback=34):
    try:
        region = getattr(context, "region", None)
        width = int(getattr(region, "width", 0) or 0)
        if width <= 0:
            return fallback
        return max(18, min(56, int((width - 42) / 6.8)))
    except Exception:
        return fallback


def draw_wrapped_text(layout, context, text, icon="NONE"):
    msg = str(text or "").strip()
    if not msg:
        return
    width = ui_wrap_width_chars(context)
    lines = textwrap.wrap(msg, width=width, break_long_words=False, break_on_hyphens=False) or [msg]
    for i, line in enumerate(lines):
        if i == 0 and icon and icon != "NONE":
            layout.label(text=line, icon=icon)
        else:
            layout.label(text=line)


def preview_cache_signature(scene):
    s = getattr(scene, "nels", None) if scene else None
    if not s:
        return ""

    values = []
    for prop in ("left_head_preview_cache", "right_head_preview_cache", "left_tail_preview_cache", "right_tail_preview_cache"):
        try:
            values.extend(round(float(c), 4) for c in getattr(s, prop))
        except Exception:
            values.extend((0.0, 0.0, 0.0))

    for si in s.sirens:
        try:
            values.extend(round(float(c), 4) for c in si.preview_color_cache)
        except Exception:
            values.extend((0.0, 0.0, 0.0))
    return "|".join(f"{v:.4f}" for v in values)


def preview_targets_animated(scene):
    s = getattr(scene, "nels", None) if scene else None
    if not s:
        return False

    if getattr(s, "head_tail_preview", True):
        for key in (getattr(s, "left_head", ""), getattr(s, "right_head", ""), getattr(s, "left_tail", ""), getattr(s, "right_tail", "")):
            p = get_pattern(s, key)
            bits = repeat_32(p.bits) if p else ("0" * 32)
            if "1" in bits:
                return True

    for si in s.sirens:
        if not getattr(si, "flash_preview", True):
            continue
        if getattr(si, "siren_type", "FLASHER") == "ROTATOR":
            return True
        bits, seq, vis = pattern_triplet(s, si)
        if seq and vis in {"BOTH", "FLASHER"} and "1" in bits:
            return True
    return False


def queue_preview_refresh_feedback(scene, message="Preview refresh in progress..."):
    s = getattr(scene, "nels", None) if scene else None
    if not s:
        return
    now = _time.time()
    s.preview_refresh_pending = True
    s.preview_refresh_started_at = now
    s.preview_refresh_done_at = 0.0
    s.preview_refresh_signature = preview_cache_signature(scene)
    s.preview_refresh_has_motion = preview_targets_animated(scene)
    s.preview_animating_until = max(float(getattr(s, "preview_animating_until", 0.0) or 0.0), now + 2.5)
    s.status_message = message
    tag_preview_ui_redraw()


def update_preview_refresh_feedback(scene):
    s = getattr(scene, "nels", None) if scene else None
    if not s:
        return False

    changed = False
    now = _time.time()
    status = str(getattr(s, "status_message", "") or "")

    if getattr(s, "preview_refresh_pending", False):
        started = float(getattr(s, "preview_refresh_started_at", now) or now)
        has_motion = bool(getattr(s, "preview_refresh_has_motion", False))
        current_signature = preview_cache_signature(scene)
        previous_signature = str(getattr(s, "preview_refresh_signature", "") or "")
        if current_signature != previous_signature or ((not has_motion) and (now - started) >= 0.25):
            s.preview_refresh_pending = False
            s.preview_refresh_signature = current_signature
            s.preview_refresh_done_at = now
            if status.startswith("Preview refresh"):
                s.status_message = "Preview refresh complete"
            changed = True
        return changed

    done_at = float(getattr(s, "preview_refresh_done_at", 0.0) or 0.0)
    if done_at > 0.0 and status == "Preview refresh complete" and (now - done_at) >= 1.0:
        s.preview_refresh_done_at = 0.0
        s.status_message = ""
        changed = True
    return changed


def mark_preview_dirty(context=None, scene=None, immediate=True):
    sc = scene
    if sc is None and context is not None:
        sc = getattr(context, "scene", None)
    if sc is None:
        sc = getattr(bpy.context, "scene", None)
    s = getattr(sc, "nels", None) if sc else None
    if not s:
        return
    now = _time.time()
    s.preview_dirty = True
    s.preview_last_step = -1
    s.preview_animating_until = max(float(getattr(s, "preview_animating_until", 0.0) or 0.0), now + 1.5)
    if not timeline_playing():
        try:
            s.preview_time_origin = now
        except Exception:
            pass
    if getattr(s, "auto_timeline_preview", False) and (not preview_updates_suspended()):
        s.auto_timeline_pending = True
        s.auto_timeline_requested_at = _time.time()
        try:
            rebuild_auto_timeline_preview(sc)
        except Exception:
            pass
    if preview_updates_suspended() or (not immediate):
        tag_preview_ui_redraw()
        return
    try:
        refresh_siren_preview_cache(sc)
    except Exception:
        pass
    tag_preview_ui_redraw()



def refresh_preview_visibility_state(scene, restart_clock=False):
    s = getattr(scene, "nels", None) if scene else None
    if not s:
        return False
    now = _time.time()
    if restart_clock:
        try:
            s.preview_time_origin = now
        except Exception:
            pass
    s.preview_last_step = -1
    changed = False
    try:
        changed = bool(refresh_siren_preview_cache(scene)) or changed
    except Exception:
        pass
    tag_preview_ui_redraw()
    return changed


def update_preview_visibility_state(self, context):
    scene = getattr(context, "scene", None) if context else getattr(bpy.context, "scene", None)
    mark_preview_dirty(context, scene=scene, immediate=False)
    s = getattr(scene, "nels", None) if scene else None
    restart_clock = bool(
        s
        and getattr(s, "all_flash_previews", True)
        and getattr(s, "show_sirens_section", True)
        and getattr(s, "show_siren_preview_panel", False)
        and getattr(s, "siren_preview_running", True)
    )
    refresh_preview_visibility_state(scene, restart_clock=restart_clock)

def update_preview_only(self, context):
    mark_preview_dirty(context)


def update_pattern_preview_only(self, context):
    scene = getattr(context, "scene", None) if context else getattr(bpy.context, "scene", None)
    queue_preview_refresh_feedback(scene)
    mark_preview_dirty(context, scene=scene, immediate=False)



def env_light_name_for_siren(index):
    return f"nels_env_siren{int(index)}"


def siren_env_transform(scene, si):
    obj = siren_obj(si)
    arm, pb = siren_pose_bone(scene, si)

    if arm and pb:
        base_matrix = arm.matrix_world @ pb.matrix
        pos = base_matrix.translation.copy()
        direction = (base_matrix.to_quaternion() @ Vector((0.0, 1.0, 0.0))).normalized()
        return pos, direction

    if obj:
        base_matrix = obj.matrix_world.copy()
        pos = base_matrix.translation.copy()
        direction = (base_matrix.to_quaternion() @ Vector((0.0, 1.0, 0.0))).normalized()
        return pos, direction

    return None, None


def env_light_world_matrix(position, direction):
    try:
        direction = Vector(direction)
    except Exception:
        direction = Vector((0.0, 1.0, 0.0))
    if direction.length <= 0.000001:
        direction = Vector((0.0, 1.0, 0.0))
    direction.normalize()
    quat = Vector((0.0, 0.0, -1.0)).rotation_difference(direction)
    return Matrix.LocRotScale(Vector(position), quat, Vector((1.0, 1.0, 1.0)))


def clear_environment_lights(scene):
    removed = 0
    scene_objects = set(getattr(scene, "objects", [])) if scene else set()
    for obj in list(bpy.data.objects):
        if not obj or not obj.get("_nels_env_light"):
            continue
        if scene and scene_objects and obj not in scene_objects:
            continue
        try:
            data = getattr(obj, "data", None)
            bpy.data.objects.remove(obj, do_unlink=True)
            if data and getattr(data, "users", 0) == 0:
                bpy.data.lights.remove(data)
            removed += 1
        except Exception:
            pass
    return removed


def enable_viewport_scene_lights():
    wm = getattr(bpy.context, "window_manager", None)
    if not wm:
        return
    try:
        for win in wm.windows:
            screen = getattr(win, "screen", None)
            if not screen:
                continue
            for area in screen.areas:
                if getattr(area, "type", "") != "VIEW_3D":
                    continue
                for space in getattr(area, "spaces", []):
                    if getattr(space, "type", "") != "VIEW_3D":
                        continue
                    shading = getattr(space, "shading", None)
                    if not shading:
                        continue
                    for attr in ("use_scene_lights", "use_scene_lights_render"):
                        if hasattr(shading, attr):
                            try:
                                setattr(shading, attr, True)
                            except Exception:
                                pass
    except Exception:
        pass


def generate_environment_lights(scene, s):
    if not scene or not s:
        return 0, 0

    enable_viewport_scene_lights()
    collection = getattr(scene, "collection", None)
    created = 0
    updated = 0
    outer_angle = max(1.0, min(179.0, float(getattr(s, "light_outer_angle", 70.0) or 70.0)))
    inner_angle = max(0.0, min(outer_angle, float(getattr(s, "light_inner_angle", 2.29061) or 2.29061)))
    falloff = max(1.0, float(getattr(s, "light_falloff_max", 100.0) or 100.0))
    offset = max(0.05, float(getattr(s, "light_offset", 0.0) or 0.0) + 0.05)
    blend = 0.15
    if outer_angle > 0.0001:
        blend = max(0.0, min(1.0, 1.0 - (inner_angle / outer_angle)))

    for si in s.sirens:
        if not siren_is_active(si):
            continue
        position, direction = siren_env_transform(scene, si)
        if position is None or direction is None:
            continue
        try:
            direction = Vector(direction)
        except Exception:
            direction = Vector((0.0, 1.0, 0.0))
        if direction.length <= 0.000001:
            direction = Vector((0.0, 1.0, 0.0))
        direction.normalize()
        base_rgb = tuple(max(0.0, min(1.0, float(c))) for c in siren_base_color_rgb(s, si))
        peak = max(base_rgb) if base_rgb else 0.0
        vivid_rgb = tuple(min(1.0, c / peak) for c in base_rgb) if peak > 0.000001 else (1.0, 1.0, 1.0)

        name = env_light_name_for_siren(si.index)
        light_obj = bpy.data.objects.get(name)
        if not light_obj or getattr(light_obj, "type", "") != "LIGHT":
            light_data = bpy.data.lights.new(name=name, type="SPOT")
            light_obj = bpy.data.objects.new(name, light_data)
            light_obj["_nels_env_light"] = True
            if collection:
                collection.objects.link(light_obj)
            created += 1
        else:
            updated += 1

        light_obj["_nels_env_light"] = True
        light_data = light_obj.data
        light_data.type = "SPOT"
        light_data.color = vivid_rgb
        light_data.energy = max(2500.0, float(getattr(si, "light_intensity", 0.5) or 0.5) * 20000.0)
        light_data.shadow_soft_size = max(0.001, float(getattr(si, "corona_size", 0.0) or 0.0) + 0.05)
        light_data.spot_size = math.radians(outer_angle)
        light_data.spot_blend = blend
        if hasattr(light_data, "use_custom_distance"):
            light_data.use_custom_distance = True
        if hasattr(light_data, "cutoff_distance"):
            light_data.cutoff_distance = falloff
        if hasattr(light_data, "use_shadow"):
            light_data.use_shadow = bool(getattr(si, "cast_shadows", False))
        if hasattr(light_data, "diffuse_factor"):
            light_data.diffuse_factor = 1.0
        if hasattr(light_data, "specular_factor"):
            light_data.specular_factor = 1.0
        light_obj.hide_select = False
        light_obj.hide_viewport = False
        light_obj.hide_render = False
        light_obj.location = Vector(position) + (direction * offset)
        light_obj.rotation_mode = "QUATERNION"
        light_obj.rotation_quaternion = Vector((0.0, 0.0, -1.0)).rotation_difference(direction)

    return created, updated

def apply_car_light_simulation(scene, s, blink_indicators=False, now=None):
    if not scene or not s:
        return 0

    sim_now = playback_seconds(scene=scene, now=now)

    blink_on = True
    if blink_indicators and (s.car_left_indicator_on or s.car_right_indicator_on):
        ts = sim_now
        blink_on = ((ts * 1.5) % 1.0) < 0.5  # Standard-like turn signal cadence.

    head_l_on = bool(s.car_headlights_on) and pattern_is_on(s, s.left_head, s.bpm, now=sim_now, scene=scene)
    head_r_on = bool(s.car_headlights_on) and pattern_is_on(s, s.right_head, s.bpm, now=sim_now, scene=scene)
    tail_l_on = bool(s.car_taillights_on) and pattern_is_on(s, s.left_tail, s.bpm, now=sim_now, scene=scene)
    tail_r_on = bool(s.car_taillights_on) and pattern_is_on(s, s.right_tail, s.bpm, now=sim_now, scene=scene)

    left_on = bool(s.car_left_indicator_on) and blink_on
    right_on = bool(s.car_right_indicator_on) and blink_on
    extra_on = bool(s.car_extra_lights_on)

    touched = set()

    def _apply(objs, show):
        for obj in objs:
            if is_object_visible(obj) != bool(show):
                set_object_visible(obj, show)
                touched.add(obj.name)

    heads = scene_objects_by_keywords(scene, HEADLIGHT_KEYS)
    tails = scene_objects_by_keywords(scene, TAILLIGHT_KEYS)
    hl, hr, hc = split_side_objects(heads)
    tl, tr, tc = split_side_objects(tails)

    _apply(hl, head_l_on)
    _apply(hr, head_r_on)
    _apply(hc, bool(head_l_on or head_r_on))

    _apply(tl, tail_l_on)
    _apply(tr, tail_r_on)
    _apply(tc, bool(tail_l_on or tail_r_on))

    _apply(scene_objects_by_keywords(scene, LEFT_INDICATOR_KEYS), left_on)
    _apply(scene_objects_by_keywords(scene, RIGHT_INDICATOR_KEYS), right_on)
    _apply(scene_objects_by_keywords(scene, EXTRA_LIGHT_KEYS), extra_on)

    preview_states = {
        "always_on": True,
        "headlight_l": head_l_on,
        "headlight_r": head_r_on,
        "taillight_l": tail_l_on,
        "taillight_r": tail_r_on,
        "brakelight_l": tail_l_on,
        "brakelight_r": tail_r_on,
        "brakelight_m": bool(tail_l_on or tail_r_on),
        "reversinglight_l": False,
        "reversinglight_r": False,
        "indicator_lf": left_on,
        "indicator_lr": left_on,
        "indicator_rf": right_on,
        "indicator_rr": right_on,
        "extralight_1": extra_on,
        "extralight_2": extra_on,
        "extralight_3": extra_on,
        "extralight_4": extra_on,
    }
    touched_count = apply_light_id_preview(scene, s, preview_states)
    return len(touched) + int(touched_count)

def update_car_light_toggle(self, context):
    scene = getattr(context, "scene", None) if context else getattr(bpy.context, "scene", None)
    s = getattr(scene, "nels", None) if scene else None
    if not s:
        return
    apply_car_light_simulation(scene, s, blink_indicators=True, now=playback_seconds(scene=scene))


def timeline_playing():
    wm = getattr(bpy.context, "window_manager", None)
    if not wm:
        return False
    try:
        for win in wm.windows:
            screen = getattr(win, "screen", None)
            if screen and getattr(screen, "is_animation_playing", False):
                return True
    except Exception:
        return False
    return False



def stop_timeline_playback():
    wm = getattr(bpy.context, "window_manager", None)
    if not wm:
        return False
    stopped = False
    try:
        for win in wm.windows:
            screen = getattr(win, "screen", None)
            if not screen or not getattr(screen, "is_animation_playing", False):
                continue
            area = next((a for a in screen.areas if getattr(a, "type", "") == "VIEW_3D"), None)
            if area is None and getattr(screen, "areas", None):
                area = screen.areas[0]
            region = next((r for r in getattr(area, "regions", []) if getattr(r, "type", "") == "WINDOW"), None) if area else None
            try:
                with bpy.context.temp_override(window=win, screen=screen, area=area, region=region):
                    bpy.ops.screen.animation_cancel(restore_frame=False)
                stopped = True
            except Exception:
                try:
                    with bpy.context.temp_override(window=win, screen=screen, area=area, region=region):
                        bpy.ops.screen.animation_play()
                    stopped = True
                except Exception:
                    pass
    except Exception:
        return False
    return stopped

def set_scene_warning(scene, msg):
    s = getattr(scene, "nels", None) if scene else None
    if s and hasattr(s, "status_message"):
        s.status_message = str(msg or "")


def siren_direction_warning(scene, si):
    if not scene or not si:
        return ""
    if not siren_obj(si):
        return ""

    arm, pb = siren_pose_bone(scene, si)
    has_bone = bool(arm and pb and getattr(si, "bone_name", ""))
    if has_bone:
        return ""
    return f"Warning: Siren {si.index} has no linked bone for direction sync"


def active_siren_direction_warning(scene):
    s = getattr(scene, "nels", None) if scene else None
    if not s or not s.sirens:
        return ""

    idx = max(0, min(int(s.active_siren), len(s.sirens) - 1))
    return siren_direction_warning(scene, s.sirens[idx])


def refresh_direction_warning(scene):
    s = getattr(scene, "nels", None) if scene else None
    if not s:
        return
    msg = str(getattr(s, "status_message", "") or "")
    if msg.startswith("Warning: Siren ") and msg.endswith(" has no linked bone for direction sync"):
        s.status_message = ""


def apply_siren_direction_to_bone(scene, si, set_warning=True):
    if not scene or not si:
        return False

    arm, pb = siren_pose_bone(scene, si)
    if not arm or not pb:
        if set_warning:
            set_scene_warning(scene, f"Warning: Siren {si.index} has no linked bone for direction sync")
        return False

    ang = dir_val(si)
    vec = Vector((math.sin(ang), math.cos(ang), 0.0))
    if vec.length < 0.000001:
        vec = Vector((0.0, 1.0, 0.0))

    old_active = getattr(bpy.context.view_layer.objects, "active", None)
    old_mode = getattr(bpy.context, "mode", "OBJECT")

    try:
        if old_mode != "OBJECT":
            bpy.ops.object.mode_set(mode="OBJECT")
        bpy.ops.object.select_all(action="DESELECT")
        arm.select_set(True)
        bpy.context.view_layer.objects.active = arm
        bpy.ops.object.mode_set(mode="EDIT")

        eb = arm.data.edit_bones.get(pb.name) or arm.data.edit_bones.get(si.bone_name)
        if not eb:
            bpy.ops.object.mode_set(mode="OBJECT")
            if set_warning:
                set_scene_warning(scene, f"Warning: Could not find linked bone for siren {si.index}")
            return False

        head = eb.head.copy()
        length = (eb.tail - eb.head).length
        if length < 0.000001:
            length = 0.05
        eb.tail = head + vec.normalized() * length

        bpy.ops.object.mode_set(mode="OBJECT")
        pose_bone = arm.pose.bones.get(eb.name)
        if pose_bone:
            _store_rest_pose_bone(arm, pose_bone, force=True)

        if set_warning:
            set_scene_warning(scene, "")
        return True
    except Exception:
        if set_warning:
            set_scene_warning(scene, f"Warning: Failed to apply direction to siren {si.index} bone")
        return False
    finally:
        try:
            if old_active and old_active.name in bpy.data.objects:
                bpy.context.view_layer.objects.active = old_active
        except Exception:
            pass
        try:
            if old_mode != "OBJECT" and getattr(bpy.context, "mode", "OBJECT") == "OBJECT":
                bpy.ops.object.mode_set(mode=old_mode)
        except Exception:
            pass



def apply_all_siren_directions(scene):
    s = getattr(scene, "nels", None) if scene else None
    if not s or not s.sirens:
        return 0

    groups = {}
    for si in s.sirens:
        arm, pb = siren_pose_bone(scene, si)
        if arm and pb:
            groups.setdefault(arm.name, []).append((si, pb.name))

    if not groups:
        return 0

    updated = 0
    old_active = getattr(bpy.context.view_layer.objects, "active", None)
    old_mode = getattr(bpy.context, "mode", "OBJECT")

    try:
        if old_mode != "OBJECT":
            bpy.ops.object.mode_set(mode="OBJECT")
        bpy.ops.object.select_all(action="DESELECT")

        for arm_name, entries in groups.items():
            arm = bpy.data.objects.get(arm_name)
            if not arm or arm.type != "ARMATURE":
                continue

            bpy.ops.object.select_all(action="DESELECT")
            arm.select_set(True)
            bpy.context.view_layer.objects.active = arm
            bpy.ops.object.mode_set(mode="EDIT")

            updated_names = []
            for si, bone_name in entries:
                eb = arm.data.edit_bones.get(bone_name)
                if not eb:
                    continue
                ang = dir_val(si)
                vec = Vector((math.sin(ang), math.cos(ang), 0.0))
                if vec.length < 0.000001:
                    vec = Vector((0.0, 1.0, 0.0))
                head = eb.head.copy()
                length = (eb.tail - eb.head).length
                if length < 0.000001:
                    length = 0.05
                eb.tail = head + vec.normalized() * length
                updated_names.append(eb.name)
                updated += 1

            bpy.ops.object.mode_set(mode="OBJECT")
            for bone_name in updated_names:
                pb = arm.pose.bones.get(bone_name)
                if pb:
                    _store_rest_pose_bone(arm, pb, force=True)
    except Exception:
        return updated
    finally:
        try:
            if getattr(bpy.context, "mode", "OBJECT") != "OBJECT":
                bpy.ops.object.mode_set(mode="OBJECT")
        except Exception:
            pass
        try:
            if old_active and old_active.name in bpy.data.objects:
                bpy.context.view_layer.objects.active = old_active
        except Exception:
            pass
        try:
            if old_mode != "OBJECT" and getattr(bpy.context, "mode", "OBJECT") == "OBJECT":
                bpy.ops.object.mode_set(mode=old_mode)
        except Exception:
            pass

    return updated

def update_siren_direction(self, context):
    scene = getattr(context, "scene", None) if context else getattr(bpy.context, "scene", None)
    apply_siren_direction_to_bone(scene, self, set_warning=False)
    mark_preview_dirty(context, scene=scene)


def update_siren_bone_link(self, context):
    scene = getattr(context, "scene", None) if context else getattr(bpy.context, "scene", None)
    if self.bone_name:
        apply_siren_direction_to_bone(scene, self, set_warning=True)
    mark_preview_dirty(context, scene=scene)


def selected_mesh_name_from_context(context):
    active = getattr(context, "active_object", None)
    if active and getattr(active, "type", "") == "MESH":
        return active.name
    for obj in getattr(context, "selected_objects", []) or []:
        if obj and getattr(obj, "type", "") == "MESH":
            return obj.name
    return ""


def selected_armature_from_context(context, scene=None, s=None):
    active = getattr(context, "active_object", None)
    if active and getattr(active, "type", "") == "ARMATURE":
        return active
    if active and getattr(active, "parent", None) and getattr(active.parent, "type", "") == "ARMATURE":
        return active.parent
    for obj in getattr(context, "selected_objects", []) or []:
        if obj and getattr(obj, "type", "") == "ARMATURE":
            return obj
        if obj and getattr(obj, "parent", None) and getattr(obj.parent, "type", "") == "ARMATURE":
            return obj.parent
    arm_name = str(getattr(s, "armature_name", "") or "")
    if arm_name:
        arm = bpy.data.objects.get(arm_name)
        if arm and getattr(arm, "type", "") == "ARMATURE":
            if not scene or arm.name in getattr(scene, "objects", {}):
                return arm
    return None


def selected_bone_name_from_context(context, arm=None):
    active = getattr(context, "active_object", None)
    if arm and active and getattr(active, "parent", None) == arm and getattr(active, "parent_type", "") == "BONE" and getattr(active, "parent_bone", ""):
        return str(active.parent_bone)

    active_pose_bone = getattr(context, "active_pose_bone", None)
    if active_pose_bone and ((not arm) or active == arm):
        return str(active_pose_bone.name)

    active_bone = getattr(context, "active_bone", None)
    if active_bone and ((not arm) or active == arm):
        return str(active_bone.name)

    if active and getattr(active, "parent_type", "") == "BONE" and getattr(active, "parent_bone", ""):
        if (not arm) or getattr(active, "parent", None) == arm:
            return str(active.parent_bone)
    return ""

def compute_siren_preview_color(scene, s, si, now=None):
    try:
        base = siren_base_color_rgb(s, si) if s else tuple(si.custom_color)
        if not getattr(si, "flash_preview", True) or not s:
            return tuple(base)

        bits, _, vis = pattern_triplet(s, si)
        ts = preview_seconds(scene=scene, now=now)

        if si.siren_type == "ROTATOR":
            if vis not in {"BOTH", "ROTATOR"}:
                return _emissive_color(base, False)
            return _preview_lit_color(base, 1.0)

        vis_ok = vis in {"BOTH", "FLASHER"}
        bpm = max(1.0, float(getattr(s, "bpm", 800)))
        steps_per_second = bpm / 60.0
        idx = int(ts * steps_per_second) % 32
        on = bits[idx] == "1"
        return _emissive_color(base, bool(vis_ok and on))
    except Exception:
        return (1.0, 0.0, 0.0)


def get_siren_preview_color(self):
    scene = getattr(bpy.context, "scene", None)
    s = getattr(scene, "nels", None) if scene else None
    return compute_siren_preview_color(scene, s, self)

def compute_siren_preview_static_color(s, si):
    try:
        base = siren_base_color_rgb(s, si) if s else tuple(getattr(si, "custom_color", (1.0, 1.0, 1.0)))
        if getattr(si, "siren_type", "FLASHER") == "ROTATOR":
            return tuple(base)
        _bits, seq, vis = pattern_triplet(s, si)
        if (not seq) or (vis not in {"BOTH", "FLASHER"}):
            return PREVIEW_OFF_RGB
        return tuple(base)
    except Exception:
        return PREVIEW_OFF_RGB



def refresh_siren_preview_cache(scene):
    s = getattr(scene, "nels", None) if scene else None
    if not s:
        return False
    if scene and getattr(s, "preview_generated", False) and timeline_playing() and (not getattr(s, "preview_refresh_pending", False)):
        return False

    ts = playback_seconds(scene=scene)
    bpm = max(1.0, float(getattr(s, "bpm", 800) or 800))
    step_idx = int(ts * (bpm / 60.0)) % 32
    if (not getattr(s, "preview_refresh_pending", False)) and int(getattr(s, "preview_last_step", -1) or -1) == step_idx:
        return False

    changed = False
    animate_sirens = bool(getattr(s, "show_sirens_section", True) and getattr(s, "show_siren_preview_panel", False) and getattr(s, "siren_preview_running", True))

    head_tail = (
        ("left_head_preview_cache", _head_tail_preview(s, s.left_head, (1.0, 1.0, 1.0), getattr(s, "head_tail_preview", True))),
        ("right_head_preview_cache", _head_tail_preview(s, s.right_head, (1.0, 1.0, 1.0), getattr(s, "head_tail_preview", True))),
        ("left_tail_preview_cache", _head_tail_preview(s, s.left_tail, (1.0, 0.0, 0.0), getattr(s, "head_tail_preview", True))),
        ("right_tail_preview_cache", _head_tail_preview(s, s.right_tail, (1.0, 0.0, 0.0), getattr(s, "head_tail_preview", True))),
    )
    for prop, col in head_tail:
        try:
            if tuple(getattr(s, prop)) != tuple(col):
                setattr(s, prop, col)
                changed = True
        except Exception:
            pass

    for si in s.sirens:
        col = compute_siren_preview_color(scene, s, si, now=ts) if animate_sirens else compute_siren_preview_static_color(s, si)
        try:
            if tuple(si.preview_color_cache) != tuple(col):
                si.preview_color_cache = col
                changed = True
        except Exception:
            pass

    s.preview_last_step = step_idx
    return changed


def update_lib_color_rgb(self, context):
    v = rgb_to_color(self.rgb)
    if self.value != v:
        self.value = v
    save_library_from_context(context)


def update_lib_color_value(self, context):
    v = clean_color_value(self.value)
    if self.value != v:
        self.value = v
    rgb = color_to_rgb(v)
    if tuple(self.rgb) != rgb:
        self.rgb = rgb
    save_library_from_context(context)


def _draw_preview_rect(shader, x0, y0, x1, y1, color):
    if not shader or not batch_for_shader:
        return
    verts = ((x0, y0), (x1, y0), (x1, y1), (x0, y1))
    batch = batch_for_shader(shader, "TRI_FAN", {"pos": verts})
    shader.uniform_float("color", color)
    batch.draw(shader)


def _clip_range(start, end, lower, upper):
    return max(lower, start), min(upper, end)


def draw_custom_preview_overlay():
    return




