def ensure_custom_preview_draw_handler():
    remove_custom_preview_draw_handler()
    return

def remove_custom_preview_draw_handler():
    global _CUSTOM_PREVIEW_DRAW_HANDLE
    if not _CUSTOM_PREVIEW_DRAW_HANDLE:
        return
    try:
        bpy.types.SpaceView3D.draw_handler_remove(_CUSTOM_PREVIEW_DRAW_HANDLE, "WINDOW")
    except Exception:
        pass
    _CUSTOM_PREVIEW_DRAW_HANDLE = None


class NELSPattern(PropertyGroup):
    name: StringProperty(default="Pattern", update=update_pattern_meta)
    allow_duplicate: BoolProperty(default=False, update=update_pattern_meta)
    visibility: EnumProperty(items=VISIBILITY_ITEMS, default="BOTH", update=update_pattern_meta)
    bits: StringProperty(default="00001111000011110000111100001111", maxlen=32, update=update_pattern_bits)
    value: StringProperty(default="252645135", update=update_pattern_value)


class NELSColor(PropertyGroup):
    name: StringProperty(default="Colour", update=update_color_name)
    value: StringProperty(default="0xFFFF0000", update=update_lib_color_value)
    rgb: FloatVectorProperty(subtype="COLOR", size=3, min=0.0, max=1.0, default=(1.0, 0.0, 0.0), update=update_lib_color_rgb)


class NELSOtherAttribute(PropertyGroup):
    display_value: StringProperty(default="Attribute")
    return_value: StringProperty(default="")


class NELSBodyOpening(PropertyGroup):
    key: StringProperty(default="door_dside_f")
    name: StringProperty(default="Body Opening")
    expanded: BoolProperty(default=False)
    opening_type: EnumProperty(items=BODY_OPENING_TYPES, default="HINGED", update=update_body_opening_type)
    rot_x: BoolProperty(default=True)
    rot_y: BoolProperty(default=True)
    rot_z: BoolProperty(default=True)
    slide_x: BoolProperty(default=False)
    slide_y: BoolProperty(default=False)
    slide_z: BoolProperty(default=False)
    limit_rotation: BoolProperty(default=True)
    limit_translation: BoolProperty(default=False)
    object_name: StringProperty(default="")
    anchor_name: StringProperty(default="")
    bone_name: StringProperty(default="")
    closed_source: StringProperty(default="")
    open_source: StringProperty(default="")
    closed_location: FloatVectorProperty(size=3, default=(0.0, 0.0, 0.0), subtype="TRANSLATION")
    closed_rotation: FloatVectorProperty(size=3, default=(0.0, 0.0, 0.0), subtype="EULER")
    open_location: FloatVectorProperty(size=3, default=(0.0, 0.0, 0.0), subtype="TRANSLATION")
    open_rotation: FloatVectorProperty(size=3, default=(0.0, 0.0, 0.0), subtype="EULER")


class NELSSiren(PropertyGroup):
    index: IntProperty(default=1, min=1, max=MAX_SIRENS)
    name: StringProperty(default="Siren 1")
    enabled: BoolProperty(default=False)
    expanded: BoolProperty(default=False, update=update_siren_expanded)
    filter_selected: BoolProperty(default=True, update=update_preview_visibility_state)
    siren_type: EnumProperty(items=SIREN_TYPES, default="FLASHER", update=update_siren_type)
    rotator_speed_mode: EnumProperty(items=ROT_SPEED_ITEMS, default="P50", update=update_rotator_settings)
    rotator_custom_percent: FloatProperty(default=50.0, min=0.0, update=update_rotator_settings)
    rotator_clockwise: BoolProperty(default=True, update=update_preview_only)

    pattern_source: EnumProperty(items=[("LIBRARY", "Saved Pattern", ""), ("CUSTOM", "Custom Pattern", "")], default="LIBRARY", update=update_pattern_preview_only)
    pattern_choice: EnumProperty(items=pattern_items, update=update_pattern_preview_only)
    pattern_select: EnumProperty(items=pattern_select_items, update=update_pattern_select)
    custom_visibility: EnumProperty(items=VISIBILITY_ITEMS, default="BOTH", update=update_pattern_preview_only)
    custom_bits: StringProperty(default="00001111000011110000111100001111", maxlen=32, update=update_siren_bits)
    custom_value: StringProperty(default="252645135", update=update_siren_value)

    color_mode: EnumProperty(items=[("PRESET", "Preset", ""), ("CUSTOM", "Custom", "")], default="PRESET")
    color_preset: EnumProperty(items=color_items)
    color_select: EnumProperty(items=color_select_items, update=update_color_select)
    custom_color: FloatVectorProperty(subtype="COLOR", size=3, min=0.0, max=1.0, default=(1.0, 1.0, 1.0))
    configured_color: FloatVectorProperty(subtype="COLOR", size=3, min=0.0, max=1.0, get=get_siren_configured_color)
    flash_preview: BoolProperty(default=True)
    preview_color_cache: FloatVectorProperty(subtype="COLOR", size=3, min=0.0, max=1.0, default=(0.07, 0.07, 0.07))
    preview_color: FloatVectorProperty(subtype="COLOR", size=3, min=0.0, max=1.0, get=get_siren_preview_color)

    direction_mode: EnumProperty(items=[("PRESET", "Preset", ""), ("CUSTOM", "Custom", "")], default="PRESET", update=update_siren_direction)
    direction_preset: EnumProperty(items=DIRECTION_ITEMS, default="FRONT", update=update_siren_direction)
    direction_select: EnumProperty(items=direction_select_items, update=update_direction_select)
    custom_direction: FloatProperty(default=0.0, precision=8, update=update_siren_direction)
    scale_mode: EnumProperty(items=[("PRESET", "Preset", ""), ("CUSTOM", "Custom", "")], default="PRESET", update=update_preview_only)
    scale_preset: EnumProperty(items=SCALE_ITEMS, default="SCALE_50", update=update_preview_only)
    custom_scale: FloatProperty(default=0.5, min=0.0, precision=8, update=update_preview_only)

    sync_to_bpm: BoolProperty(default=True, update=update_preview_only)
    show_copy_config: BoolProperty(default=False)
    show_linking: BoolProperty(default=False)

    show_advanced: BoolProperty(default=False)
    flash: BoolProperty(default=True)
    light: BoolProperty(default=False)
    spot_light: BoolProperty(default=False)
    cast_shadows: BoolProperty(default=False)
    light_group: IntProperty(default=1, min=0)
    start_delay: FloatProperty(default=0.0, precision=8)
    light_speed: FloatProperty(default=0.0, precision=8)
    light_multiples: IntProperty(default=2, min=0)
    corona_intensity: FloatProperty(default=0.5, precision=8)
    corona_size: FloatProperty(default=0.0, precision=8)
    corona_pull: FloatProperty(default=0.00000001, precision=8)
    light_intensity: FloatProperty(default=0.5, precision=8)
    corona_face_camera: BoolProperty(default=False)

    object_name: StringProperty(default="")
    anchor_name: StringProperty(default="")
    bone_name: StringProperty(default="", update=update_siren_bone_link)



def update_saved_config(self, context):
    scene = getattr(context, "scene", None)
    if scene is None:
        return

    saved_name = str(getattr(self, "saved_config", "") or "")
    if not saved_name or saved_name == NO_SAVED_CFG:
        return

    fp = os.path.join(cfg_dir(), saved_name)
    if not os.path.exists(fp):
        return

    try:
        with open(fp, "r", encoding="utf-8") as h:
            data = json.load(h)
        apply_settings_dict(self, data)
        ensure_scene_defaults(scene)
    except Exception:
        pass


class NELSSettings(PropertyGroup):
    config_name: StringProperty(default="new_lightbar")
    vehicle_name: StringProperty(name="vehicle_name", default="police")
    vehicle_id: IntProperty(name="siren_id", default=25000, min=1, soft_min=25000)
    saved_config: EnumProperty(items=saved_cfg_items, update=update_saved_config)
    show_vehicle_export_notes: BoolProperty(default=False)
    show_vehicle_export_requirements: BoolProperty(default=False)

    bpm: IntProperty(default=800, min=1, update=update_bpm)
    scale_factor_choice: EnumProperty(items=SCALE_FACTOR_PRESET_ITEMS, default="SF_2", update=update_scale_factor_choice)
    scale_factor_custom: FloatProperty(default=0.5, min=0.0, precision=8, update=update_scale_factor_custom)
    scale_factor: FloatProperty(default=0.5, min=0.0, precision=8, update=update_scale_factor_value)
    left_head: EnumProperty(items=pattern_items, update=update_pattern_preview_only)
    right_head: EnumProperty(items=pattern_items, update=update_pattern_preview_only)
    left_tail: EnumProperty(items=pattern_items, update=update_pattern_preview_only)
    right_tail: EnumProperty(items=pattern_items, update=update_pattern_preview_only)

    all_flash_previews: BoolProperty(default=True, update=update_preview_visibility_state)
    list_flash_preview: BoolProperty(default=True, update=update_preview_visibility_state)
    head_tail_preview: BoolProperty(default=True, update=update_preview_visibility_state)
    left_head_preview_cache: FloatVectorProperty(subtype="COLOR", size=3, min=0.0, max=1.0, default=(0.07, 0.07, 0.07))
    right_head_preview_cache: FloatVectorProperty(subtype="COLOR", size=3, min=0.0, max=1.0, default=(0.07, 0.07, 0.07))
    left_tail_preview_cache: FloatVectorProperty(subtype="COLOR", size=3, min=0.0, max=1.0, default=(0.07, 0.0, 0.0))
    right_tail_preview_cache: FloatVectorProperty(subtype="COLOR", size=3, min=0.0, max=1.0, default=(0.07, 0.0, 0.0))
    left_head_preview: FloatVectorProperty(subtype="COLOR", size=3, min=0.0, max=1.0, get=get_left_head_preview)
    right_head_preview: FloatVectorProperty(subtype="COLOR", size=3, min=0.0, max=1.0, get=get_right_head_preview)
    left_tail_preview: FloatVectorProperty(subtype="COLOR", size=3, min=0.0, max=1.0, get=get_left_tail_preview)
    right_tail_preview: FloatVectorProperty(subtype="COLOR", size=3, min=0.0, max=1.0, get=get_right_tail_preview)

    show_adv_main: BoolProperty(default=False)
    show_sirens_section: BoolProperty(default=True, update=update_preview_visibility_state)
    show_siren_filters: BoolProperty(default=True, update=update_preview_visibility_state)
    show_siren_preview_panel: BoolProperty(default=False, update=update_preview_visibility_state)
    siren_preview_running: BoolProperty(default=True, update=update_preview_visibility_state)
    siren_filter_direction: EnumProperty(items=DIRECTION_ITEMS, default="FRONT")
    show_other_attributes: BoolProperty(default=False)
    use_real_lights: BoolProperty(default=True)
    time_multiplier: FloatProperty(default=1.0, precision=8)
    light_falloff_max: FloatProperty(default=100.0, precision=8)
    light_falloff_exp: FloatProperty(default=100.0, precision=8)
    light_inner_angle: FloatProperty(default=2.29061, precision=8)
    light_outer_angle: FloatProperty(default=70.0, precision=8)
    light_offset: FloatProperty(default=0.0, precision=8)
    texture_name: StringProperty(default="VehicleLight_sirenlight")
    left_head_mult: IntProperty(default=1, min=0)
    right_head_mult: IntProperty(default=1, min=0)
    left_tail_mult: IntProperty(default=1, min=0)
    right_tail_mult: IntProperty(default=1, min=0)

    patterns: CollectionProperty(type=NELSPattern)
    active_pattern: IntProperty(default=0)

    colors: CollectionProperty(type=NELSColor)
    active_color: IntProperty(default=0)

    other_attributes: CollectionProperty(type=NELSOtherAttribute)
    active_other_attribute: IntProperty(default=0)

    body_openings: CollectionProperty(type=NELSBodyOpening)
    active_body_opening: IntProperty(default=0)
    body_opening_autodetect_at: FloatProperty(default=0.0, options={"HIDDEN"})

    sirens: CollectionProperty(type=NELSSiren)
    active_siren: IntProperty(default=0)
    tool_working_siren: EnumProperty(items=scene_siren_items, update=update_tool_working_siren)
    tool_copy_siren_source: EnumProperty(items=scene_siren_items)
    tool_origin_object: StringProperty(default="")
    siren_count: IntProperty(default=0, min=0, max=MAX_SIRENS)

    armature_name: StringProperty(default="")

    pattern_library_path: StringProperty(default=os.path.join(os.path.expanduser("~"), "Downloads", "flash_patterns.json"), subtype="FILE_PATH")

    wheel_all_axes_degrees: FloatProperty(default=25.0, precision=3)
    car_headlights_on: BoolProperty(default=False, update=update_car_light_toggle)
    car_taillights_on: BoolProperty(default=False, update=update_car_light_toggle)
    car_left_indicator_on: BoolProperty(default=False, update=update_car_light_toggle)
    car_right_indicator_on: BoolProperty(default=False, update=update_car_light_toggle)
    car_extra_lights_on: BoolProperty(default=False, update=update_car_light_toggle)
    car_light_id_target: EnumProperty(items=SOLLUMZ_LIGHT_ID_UI_ITEMS, default="always_on")
    car_light_id_custom_value: IntProperty(default=0, min=0)
    car_light_id_set_target: EnumProperty(items=SOLLUMZ_LIGHT_ID_UI_ITEMS, default="always_on")
    car_light_id_set_custom_value: IntProperty(default=0, min=0)
    car_light_id_select_target: EnumProperty(items=SOLLUMZ_LIGHT_ID_UI_ITEMS, default="always_on")
    car_light_id_select_custom_value: IntProperty(default=0, min=0)
    car_light_id_preview: BoolProperty(default=True, options={"HIDDEN"})
    car_light_id_signature: StringProperty(default="", options={"HIDDEN"})
    car_light_id_checked_at: FloatProperty(default=0.0, options={"HIDDEN"})
    vehicle_export_directory: StringProperty(default=os.path.join(os.path.expanduser("~"), "Downloads"), subtype="DIR_PATH")
    vehicle_export_model_name: StringProperty(default="")
    vehicle_export_game_version: EnumProperty(
        items=[
            ("GEN8", "Legacy (Gen8)", "Export for the classic GTA V PC/console resource format"),
            ("GEN9", "Enhanced (Gen9)", "Export for the enhanced GTA V resource format"),
        ],
        default="GEN8",
    )
    export_path: StringProperty(default=os.path.join(os.path.expanduser("~"), "Downloads", "carcols.meta"), subtype="FILE_PATH")
    status_message: StringProperty(default="")
    preview_generated: BoolProperty(default=False, options={"HIDDEN"})
    preview_dirty: BoolProperty(default=False, options={"HIDDEN"})
    preview_refresh_pending: BoolProperty(default=False, options={"HIDDEN"})
    preview_refresh_has_motion: BoolProperty(default=False, options={"HIDDEN"})
    preview_refresh_started_at: FloatProperty(default=0.0, options={"HIDDEN"})
    preview_refresh_done_at: FloatProperty(default=0.0, options={"HIDDEN"})
    preview_refresh_signature: StringProperty(default="", options={"HIDDEN"})
    head_tail_initialized: BoolProperty(default=False, options={"HIDDEN"})
    preview_time_origin: FloatProperty(default=0.0, options={"HIDDEN"})
    preview_last_step: IntProperty(default=-1, options={"HIDDEN"})
    preview_animating_until: FloatProperty(default=0.0, options={"HIDDEN"})
    auto_timeline_preview: BoolProperty(default=False, update=lambda self, context: update_auto_timeline_preview(self, context))
    custom_preview_overlay: BoolProperty(default=False, update=update_preview_only)
    auto_timeline_pending: BoolProperty(default=False, options={"HIDDEN"})
    auto_timeline_requested_at: FloatProperty(default=0.0, options={"HIDDEN"})
    update_check_on_startup: BoolProperty(default=True)
    update_remote_version: StringProperty(default="")
    update_last_checked: StringProperty(default="")
    update_status: StringProperty(default="Not checked yet")
    update_available: BoolProperty(default=False)
    update_check_in_progress: BoolProperty(default=False, options={"HIDDEN"})
    update_install_in_progress: BoolProperty(default=False, options={"HIDDEN"})
    update_restart_required: BoolProperty(default=False)


def settings_to_dict(s):
    return {
        "config_name": s.config_name,
        "vehicle_name": s.vehicle_name,
        "vehicle_id": s.vehicle_id,
        "bpm": s.bpm,
        "scale_factor": s.scale_factor,
        "left_head": s.left_head,
        "right_head": s.right_head,
        "left_tail": s.left_tail,
        "right_tail": s.right_tail,
        "scale_factor_choice": s.scale_factor_choice,
        "scale_factor_custom": s.scale_factor_custom,
        "main": {k: getattr(s, k) for k in ["use_real_lights", "time_multiplier", "light_falloff_max", "light_falloff_exp", "light_inner_angle", "light_outer_angle", "light_offset", "texture_name", "left_head_mult", "right_head_mult", "left_tail_mult", "right_tail_mult", "armature_name", "siren_count"]},
        "patterns": [{"name": p.name, "visibility": p.visibility, "bits": clean_bits(p.bits), "value": parse_u32(p.value), "allow_duplicate": bool(getattr(p, "allow_duplicate", False))} for p in s.patterns],
        "colors": [{"name": c.name, "value": clean_color_value(c.value)} for c in s.colors],
        "other_attributes": [{"display_value": a.display_value, "return_value": a.return_value} for a in s.other_attributes],
        "body_openings": [{k: getattr(op, k) for k in ["key", "name", "opening_type", "rot_x", "rot_y", "rot_z", "slide_x", "slide_y", "slide_z", "limit_rotation", "limit_translation", "object_name", "anchor_name", "bone_name", "closed_source", "open_source"]} | {"closed_location": list(op.closed_location), "closed_rotation": list(op.closed_rotation), "open_location": list(op.open_location), "open_rotation": list(op.open_rotation)} for op in s.body_openings],
        "sirens": [{k: getattr(si, k) for k in ["index", "name", "enabled", "siren_type", "rotator_speed_mode", "rotator_custom_percent", "rotator_clockwise", "pattern_source", "pattern_choice", "custom_visibility", "custom_bits", "custom_value", "color_mode", "color_preset", "direction_mode", "direction_preset", "custom_direction", "scale_mode", "scale_preset", "custom_scale", "sync_to_bpm", "flash_preview", "flash", "light", "spot_light", "cast_shadows", "light_group", "start_delay", "light_speed", "light_multiples", "corona_intensity", "corona_size", "corona_pull", "light_intensity", "corona_face_camera", "object_name", "anchor_name", "bone_name"]} | {"custom_color": list(si.custom_color)} for si in s.sirens],
    }


def apply_settings_dict(s, data):
    if not isinstance(data, dict):
        return

    for k in ["config_name", "vehicle_name", "vehicle_id", "bpm", "scale_factor", "scale_factor_choice", "scale_factor_custom", "left_head", "right_head", "left_tail", "right_tail", "all_flash_previews"]:
        if k in data:
            if k in {"left_head", "right_head", "left_tail", "right_tail"}:
                setattr(s, k, normalize_pattern_key(data[k]))
            elif k == "scale_factor_choice":
                setattr(s, k, data[k] if data[k] in {it[0] for it in SCALE_FACTOR_PRESET_ITEMS} else "CUSTOM")
            else:
                setattr(s, k, data[k])

    main = data.get("main", {})
    if not isinstance(main, dict):
        main = {}
    for k, v in main.items():
        if hasattr(s, k):
            setattr(s, k, v)

    s.patterns.clear()
    patterns_data = data.get("patterns", [])
    if not isinstance(patterns_data, list):
        patterns_data = []
    for pd in patterns_data:
        if not isinstance(pd, dict):
            continue
        p = s.patterns.add()
        p.name = pd.get("name", "Pattern")
        p.allow_duplicate = bool(pd.get("allow_duplicate", False))
        p.visibility = "FLASHER" if pd.get("visibility", "BOTH") == "FLASHER" else "BOTH"
        p.bits = clean_bits(pd.get("bits", int_to_bits(pd.get("value", 0))))
        p.value = str(parse_u32(pd.get("value", bits_to_int(p.bits))))
    ensure_off_pattern(s)
    if not s.patterns:
        ensure_defaults(s)

    s.colors.clear()
    colors_data = data.get("colors", [])
    if not isinstance(colors_data, list):
        colors_data = []
    for cd in colors_data:
        if not isinstance(cd, dict):
            continue
        c = s.colors.add()
        c.name = cd.get("name", "Colour")
        c.value = clean_color_value(cd.get("value", "0xFFFF0000"))
        c.rgb = color_to_rgb(c.value)
    ensure_color_defaults(s)

    s.other_attributes.clear()
    attrs_data = data.get("other_attributes", [])
    if not isinstance(attrs_data, list):
        attrs_data = []
    for ad in attrs_data:
        if not isinstance(ad, dict):
            continue
        a = s.other_attributes.add()
        a.display_value = str(ad.get("display_value", "Attribute") or "Attribute")
        a.return_value = str(ad.get("return_value", "") or "")
    if not s.other_attributes:
        ensure_other_attributes_defaults(s)

    s.body_openings.clear()
    openings_data = data.get("body_openings", [])
    if not isinstance(openings_data, list):
        openings_data = []
    for od in openings_data:
        if not isinstance(od, dict):
            continue
        op = s.body_openings.add()
        for key in ["key", "name", "opening_type", "rot_x", "rot_y", "rot_z", "slide_x", "slide_y", "slide_z", "limit_rotation", "limit_translation", "object_name", "anchor_name", "bone_name", "closed_source", "open_source"]:
            if hasattr(op, key) and key in od:
                setattr(op, key, od[key])
        for key in ["closed_location", "closed_rotation", "open_location", "open_rotation"]:
            value = od.get(key, None)
            if isinstance(value, list) and len(value) >= 3:
                setattr(op, key, (float(value[0]), float(value[1]), float(value[2])))
    ensure_body_opening_defaults(s)

    loaded_sirens = data.get("sirens", [])
    if not isinstance(loaded_sirens, list):
        loaded_sirens = []

    try:
        requested_count = int(main.get("siren_count", data.get("siren_count", 0)))
    except Exception:
        requested_count = 0
    requested_count = max(requested_count, len(loaded_sirens))
    ensure_sirens(s, requested_count)

    for i, sd in enumerate(loaded_sirens):
        if i >= len(s.sirens):
            break
        if not isinstance(sd, dict):
            continue
        si = s.sirens[i]
        for k, v in sd.items():
            if k == "custom_color" and isinstance(v, list) and len(v) >= 3:
                si.custom_color = (float(v[0]), float(v[1]), float(v[2]))
            elif k == "custom_value":
                si.custom_value = str(parse_u32(v))
            elif k == "pattern_choice":
                si.pattern_choice = normalize_pattern_key(v)
            elif k == "color_preset":
                legacy = COLORS.get(str(v), None)
                if legacy:
                    target = clean_color_value(legacy)
                    idx = 0
                    for ci, col in enumerate(s.colors):
                        if clean_color_value(col.value) == target:
                            idx = ci
                            break
                    si.color_preset = f"COL_{idx}"
                else:
                    si.color_preset = normalize_color_key(v)
            elif hasattr(si, k):
                setattr(si, k, v)

    for i, si in enumerate(s.sirens, start=1):
        si.index = i
        si.name = f"siren{i}"
        si.color_preset = normalize_color_key(si.color_preset)
        si.pattern_choice = normalize_pattern_key(si.pattern_choice)
        sync_siren_selector_controls(si)

    try:
        current_id = int(s.vehicle_id)
    except Exception:
        current_id = 0
    if current_id <= 0:
        s.vehicle_id = generate_siren_id(s.vehicle_name)

    sync_scale_factor_controls(s)
    s.head_tail_initialized = True
    save_global_library(s)


def clear_missing_associations(scene):
    s = getattr(scene, "nels", None)
    if not s:
        return

    arm = None
    if s.armature_name:
        arm_obj = bpy.data.objects.get(s.armature_name)
        if arm_obj and arm_obj.type == "ARMATURE":
            arm = arm_obj
        else:
            s.armature_name = ""

    for si in s.sirens:
        if si.object_name and si.object_name not in bpy.data.objects:
            si.object_name = ""
        if si.anchor_name and si.anchor_name not in bpy.data.objects:
            si.anchor_name = ""
        if si.bone_name:
            has_bone = bool(arm and si.bone_name in arm.data.bones)
            if not has_bone:
                for obj in bpy.data.objects:
                    if obj.type != "ARMATURE":
                        continue
                    if si.bone_name in obj.data.bones:
                        has_bone = True
                        if not arm:
                            arm = obj
                            s.armature_name = obj.name
                        break
            if not has_bone:
                si.bone_name = ""
        si.enabled = bool(si.object_name or si.bone_name)

def ensure_scene_defaults(scene):
    s = getattr(scene, "nels", None)
    if not s:
        return None

    if not s.patterns:
        ensure_defaults(s)
    migrate_legacy_default_patterns(s)
    ensure_off_pattern(s)
    ensure_color_defaults(s)
    ensure_other_attributes_defaults(s)
    ensure_body_opening_defaults(s)
    sync_scale_factor_controls(s)

    off_key = off_pattern_key(s)
    if not getattr(s, "head_tail_initialized", False):
        s.left_head = off_key
        s.right_head = off_key
        s.left_tail = off_key
        s.right_tail = off_key
        s.head_tail_initialized = True
    else:
        if not s.left_head:
            s.left_head = off_key
        if not s.right_head:
            s.right_head = off_key
        if not s.left_tail:
            s.left_tail = off_key
        if not s.right_tail:
            s.right_tail = off_key

    if not s.saved_config:
        s.saved_config = NO_SAVED_CFG
    for si in s.sirens:
        si.color_preset = normalize_color_key(si.color_preset)
        si.pattern_choice = normalize_pattern_key(si.pattern_choice)
        if si.siren_type == "ROTATOR":
            update_rotator_settings(si, bpy.context)
        sync_siren_selector_controls(si)
    clear_missing_associations(scene)
    auto_detect_scene_sirens(scene, create_missing=(len(s.sirens) == 0), sync_direction=False)
    auto_detect_body_opening_links(scene, s)

    try:
        current_id = int(s.vehicle_id)
    except Exception:
        current_id = 0
    if current_id <= 0:
        s.vehicle_id = generate_siren_id(s.vehicle_name)
    normalize_update_state(s)
    refresh_siren_preview_cache(scene)
    schedule_startup_update_check(scene)
    return s










