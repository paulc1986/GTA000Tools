from __future__ import annotations

from types import SimpleNamespace

import bpy

from . import (
    ops_asset,
    ops_library,
    ops_update,
    preferences,
    properties as asset_properties,
    scanner,
    ui as asset_ui,
    updater,
)
from .preview_cache import preview_manager
from .registration import safe_register_class, safe_unregister_class

_REGISTERED_UI_CLASSES = (
    preferences.BGAL_UL_LibraryRoots,
    asset_ui.BGAL_UL_AssetList,
    asset_ui.BGAL_UL_ManagerCategories,
    asset_ui.BGAL_UL_ManagerSubcategories,
    asset_ui.BGAL_UL_ManagerTags,
    asset_ui.BGAL_MT_AssetActions,
)


def _panel_proxy(panel, **attrs):
    proxy = SimpleNamespace(layout=panel.layout)
    for name, value in attrs.items():
        setattr(proxy, name, value)
    return proxy


def _draw_panel(panel_cls, panel, context, **attrs) -> None:
    panel_cls.draw(_panel_proxy(panel, **attrs), context)


def register_asset_library_integration() -> None:
    preview_manager.register()
    asset_properties.register()
    ops_library.register()
    ops_asset.register()
    ops_update.register()
    for cls in _REGISTERED_UI_CLASSES:
        safe_register_class(cls)
    try:
        scanner.load_cached_index_into_runtime(bpy.context)
    except Exception:
        pass
    try:
        scanner.ensure_auto_refresh_timer(bpy.context)
    except Exception:
        pass
    try:
        updater.reset_update_state(bpy.context)
    except Exception:
        pass
    try:
        updater.ensure_update_timer(bpy.context)
    except Exception:
        pass
    try:
        if hasattr(bpy.context.window_manager, 'bgal_browser'):
            asset_properties.refresh_visible_assets(bpy.context)
    except Exception:
        pass


def unregister_asset_library_integration() -> None:
    try:
        updater.stop_update_timer()
    except Exception:
        pass
    try:
        scanner.stop_auto_refresh_timer()
    except Exception:
        pass
    for cls in reversed(_REGISTERED_UI_CLASSES):
        safe_unregister_class(cls)
    try:
        ops_update.unregister()
    except Exception:
        pass
    try:
        ops_asset.unregister()
    except Exception:
        pass
    try:
        ops_library.unregister()
    except Exception:
        pass
    try:
        asset_properties.unregister()
    except Exception:
        pass
    try:
        preview_manager.unregister()
    except Exception:
        pass


def draw_asset_library_assets(panel, context) -> None:
    _draw_panel(
        asset_ui.BGAL_PT_Browser,
        panel,
        context,
        draw_asset_card=asset_ui.BGAL_PT_Browser.draw_asset_card,
    )



def draw_asset_library_details(panel, context) -> None:
    _draw_panel(asset_ui.BGAL_PT_Details, panel, context)



def draw_asset_library_paths(panel, context) -> None:
    _draw_panel(asset_ui.BGAL_PT_Libraries, panel, context)
    _draw_panel(asset_ui.BGAL_PT_Roots, panel, context)
    prefs = asset_ui.addon_preferences(context)
    if prefs is None:
        return
    settings = panel.layout.box()
    asset_ui.draw_section_title(settings, 'Library Scan Settings', 'FILE_REFRESH')
    settings.prop(prefs, 'grouping_mode')
    settings.prop(prefs, 'auto_generate_missing_previews')
    settings.prop(prefs, 'auto_refresh_enabled')
    interval = settings.row()
    interval.enabled = bool(getattr(prefs, 'auto_refresh_enabled', True))
    interval.prop(prefs, 'auto_refresh_interval')



def draw_asset_library_categories(panel, context) -> None:
    _draw_panel(asset_ui.BGAL_PT_Categories, panel, context)



def draw_asset_library_subcategories(panel, context) -> None:
    _draw_panel(asset_ui.BGAL_PT_Subcategories, panel, context)



def draw_asset_library_tags(panel, context) -> None:
    _draw_panel(asset_ui.BGAL_PT_Tags, panel, context)



def draw_asset_library_information(panel, context) -> None:
    layout = panel.layout
    browser = getattr(context.window_manager, 'bgal_browser', None)
    asset = asset_ui.get_active_asset(context)
    local_version = updater.local_version_text()

    layout.label(text=f"Installed Version: {local_version}", icon='BLENDER')
    layout.label(text=f"Indexed {len(runtime.all_assets())} assets", icon='OUTLINER')
    layout.label(text=f"Showing {len(getattr(browser, 'visible_assets', []))} assets", icon='VIEWZOOM')

    if asset is not None:
        layout.label(text=f"Selected: {asset.display_name}", icon='RESTRICT_SELECT_OFF')

    roots = asset_ui.enabled_root_labels(context)
    if roots:
        label = f"Libraries: {', '.join(roots[:2])}" + (' ...' if len(roots) > 2 else '')
        layout.label(text=label, icon='FILE_FOLDER')
    else:
        layout.label(text='Libraries: No enabled asset library paths', icon='FILE_FOLDER')

    status_text = str(getattr(browser, 'status_text', '') or '').strip()
    if status_text:
        status_box = layout.box()
        status_box.label(text=status_text, icon='INFO')

    links = layout.box()
    asset_ui.draw_section_title(links, 'GTA 000 Tools', 'URL')
    open_repo = links.operator('wm.url_open', text='Open GTA 000 Tools GitHub', icon='URL')
    open_repo.url = 'https://github.com/paulc1986/GTA000Tools'
    open_wiki = links.operator('wm.url_open', text='Open GTA 000 Tools Wiki', icon='HELP')
    open_wiki.url = 'https://github.com/paulc1986/GTA000Tools/wiki'
