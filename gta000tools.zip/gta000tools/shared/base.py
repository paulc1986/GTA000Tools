
bl_info = {
    "name": "GTA 000 Tools",
    "author": "Codex",
    "version": (0, 2, 66),
    "blender": (3, 6, 0),
    "location": "View3D > Sidebar > Tool and GTA 000",
    "description": "Build non-ELS lightbar configs, manage grouped assets, and export vehicle resources and carcols.meta",
    "category": "Object",
}

import io
import json
import math
import os
import re
import shutil
import tempfile
import textwrap
import threading
import time as _time
import urllib.error
import urllib.request
import xml.dom.minidom
import xml.etree.ElementTree as ET
import zipfile

try:
    import blf
    import gpu
    from gpu_extras.batch import batch_for_shader
except Exception:
    blf = None
    gpu = None
    batch_for_shader = None

import bmesh
import bpy
import bpy.utils.previews
import addon_utils
from bpy.app.handlers import persistent
from mathutils import Euler, Matrix, Vector
from bpy.props import (
    BoolProperty,
    CollectionProperty,
    EnumProperty,
    FloatProperty,
    FloatVectorProperty,
    IntProperty,
    PointerProperty,
    StringProperty,
)
from bpy.types import AddonPreferences, Menu, Operator, Panel, PropertyGroup, UIList

MAX_SIRENS = 32
NO_SAVED_CFG = "__NONE__"
UNSAVED_PATTERN_KEY = "__UNSAVED__"
UPDATE_REPO_URL = "https://github.com/paulc1986/GTA000Tools"
UPDATE_ZIP_URL = "https://raw.githubusercontent.com/paulc1986/GTA000Tools/main/gta000tools.zip"
SOLLUMZ_REPO_URL = "https://github.com/Sollumz/Sollumz"
SOLLUMZ_RELEASE_API_URL = "https://api.github.com/repos/Sollumz/Sollumz/releases/latest"
UPDATE_REQUEST_TIMEOUT = 20

BODY_OPENING_TYPES = [
    ("HINGED", "Hinged", "Rotation-based opening"),
    ("SLIDING", "Sliding", "Translation-based opening"),
    ("HINGED_SLIDING", "Hinged + Sliding", "Rotation and translation opening"),
]

DEFAULT_BODY_OPENINGS = [
    ("bonnet", "Bonnet", "HINGED"),
    ("boot", "Boot", "HINGED"),
    ("door_dside_f", "Driver Front Door", "HINGED"),
    ("door_pside_f", "Passenger Front Door", "HINGED"),
    ("door_dside_r", "Driver Rear Door", "HINGED"),
    ("door_pside_r", "Passenger Rear Door", "HINGED"),
]

_UPDATE_LOCK = threading.Lock()
_UPDATE_THREAD = None
_UPDATE_RESULT = None
_UPDATE_STARTUP_SCHEDULED = False

PANEL_ICON_FILES = {
    "gta000": "gta000_icon",
    "lightbar": "lightbar",
    "patterns": "patterns",
    "colors": "colours",
    "body_openings": "body_openings",
    "door": "door",
    "bonnet": "bonnet",
    "boot": "boot",
    "car_functions": "car_functions",
    "simulation": "simulation",
    "useful_tools": "useful_tools",
    "updates": "updates",
}

PANEL_ICON_EXTENSIONS = (".png", ".gif")

PANEL_FALLBACK_ICONS = {
    "gta000": "TOOL_SETTINGS",
    "lightbar": "LIGHT",
    "patterns": "FILE_TEXT",
    "colors": "MATERIAL",
    "body_openings": "ARMATURE_DATA",
    "door": "CON_ROTLIKE",
    "bonnet": "CON_ROTLIKE",
    "boot": "CON_ROTLIKE",
    "car_functions": "SCENE_DATA",
    "simulation": "ANIM",
    "useful_tools": "TOOL_SETTINGS",
    "updates": "IMPORT",
}

_PREVIEW_COLLECTIONS = {}
_CUSTOM_PREVIEW_DRAW_HANDLE = None
_UI_PANEL_DRAW_TIMESTAMPS = {}


ADDON_MODULE_NAME = __package__ or os.path.basename(os.path.dirname(__file__)) or "gta000tools"


def get_addon_preferences(context=None):
    try:
        prefs = getattr(context, "preferences", None) if context else getattr(bpy.context, "preferences", None)
        addons = getattr(prefs, "addons", None) if prefs else None
        addon = addons.get(ADDON_MODULE_NAME) if addons else None
        return getattr(addon, "preferences", None) if addon else None
    except Exception:
        return None


def alpha_rotators_enabled(context=None):
    prefs = get_addon_preferences(context)
    return bool(getattr(prefs, "alpha_rotators", False)) if prefs else False


def icon_color_mode(context=None):
    prefs = get_addon_preferences(context)
    return str(getattr(prefs, "icon_color_mode", "DEFAULT") or "DEFAULT") if prefs else "DEFAULT"


def panel_location_mode(context=None):
    prefs = get_addon_preferences(context)
    return str(getattr(prefs, "panel_location", "VIEWPORT") or "VIEWPORT") if prefs else "VIEWPORT"


def panel_location_visible(target, context=None):
    mode = panel_location_mode(context)
    if mode == "BOTH":
        return True
    return mode == str(target or "")


def update_addon_preferences_ui(self, context):
    tag_all_ui_redraw()


def update_asset_library_preferences(self, context):
    tag_all_ui_redraw()
    try:
        from .asset_library import scanner
        scanner.sync_auto_refresh_snapshot(context, prefs=self)
    except Exception:
        pass


LEGACY_EXTERNAL_ADDON_MODULES = ("blend_package_asset_library",)


def cleanup_stale_external_addon_preferences(context=None):
    try:
        preferences = getattr(context or bpy.context, "preferences", None)
        addons = getattr(preferences, "addons", None) if preferences is not None else None
        if addons is None:
            return 0
        entries = [item for item in addons if getattr(item, "module", "") in LEGACY_EXTERNAL_ADDON_MODULES]
        removed = 0
        for item in reversed(entries):
            try:
                addons.remove(item)
                removed += 1
            except Exception:
                pass
        return removed
    except Exception:
        return 0


def _ui_panel_draw_key(scene, panel_key):
    try:
        return (int(scene.as_pointer()), str(panel_key or ""))
    except Exception:
        return (str(getattr(scene, "name", "")), str(panel_key or ""))


def mark_panel_drawn(scene, panel_key):
    if not scene:
        return
    _UI_PANEL_DRAW_TIMESTAMPS[_ui_panel_draw_key(scene, panel_key)] = _time.time()


def panel_drawn_recently(scene, panel_key, max_age=0.75):
    if not scene:
        return False
    ts = float(_UI_PANEL_DRAW_TIMESTAMPS.get(_ui_panel_draw_key(scene, panel_key), 0.0) or 0.0)
    if ts <= 0.0:
        return False
    return (_time.time() - ts) <= max(0.05, float(max_age))

try:
    from .asset_library.properties import BGAL_PG_LibraryRoot
    from .asset_library import constants as BGAL_CONSTANTS
except Exception:
    BGAL_PG_LibraryRoot = None
    BGAL_CONSTANTS = None

class GTA000TOOLS_Preferences(AddonPreferences):
    bl_idname = ADDON_MODULE_NAME

    panel_location: EnumProperty(
        name="Panel Location",
        description="Choose where GTA 000 Tools panels appear in the viewport sidebar",
        items=[
            ("VIEWPORT", "Viewport Menu (Default)", "Show panels only in the GTA 000 viewport tab"),
            ("TOOL", "Item/Tool Menu", "Show panels only in the built-in Tool tab"),
            ("BOTH", "Both", "Show panels in both GTA 000 and Tool tabs"),
        ],
        default="VIEWPORT",
        update=update_addon_preferences_ui,
    )

    icon_color_mode: EnumProperty(
        name="Icon Colour Mode",
        description="Choose how addon icons are selected for Blender themes",
        items=[
            ("DEFAULT", "Default", "Follow the current Blender theme"),
            ("LIGHT", "Light", "Always use the light icon variant when available"),
            ("DARK", "Dark", "Always use the dark icon variant when available"),
        ],
        default="DEFAULT",
        update=update_addon_preferences_ui,
    )

    alpha_rotators: BoolProperty(
        name="Rotators",
        description="Show experimental rotator controls in the siren editor",
        default=False,
        update=update_addon_preferences_ui,
    )

    library_roots: CollectionProperty(type=BGAL_PG_LibraryRoot)
    active_root_index: IntProperty(default=0)
    grouping_mode: EnumProperty(
        name="Asset Grouping",
        items=(getattr(BGAL_CONSTANTS, "GROUPING_MODE_ITEMS", (("AUTO", "Metadata Then Folder", "Use metadata first, then folder structure"),))),
        default="AUTO",
        update=update_asset_library_preferences,
    )
    auto_generate_missing_previews: BoolProperty(
        name="Auto Generate Missing Previews",
        description="Render cached previews for asset entries that do not provide a thumbnail image",
        default=True,
        update=update_asset_library_preferences,
    )
    auto_refresh_enabled: BoolProperty(
        name="Auto Refresh Asset Libraries",
        description="Periodically rescan enabled asset library roots when files change",
        default=True,
        update=update_asset_library_preferences,
    )
    auto_refresh_interval: IntProperty(
        name="Asset Auto Refresh Interval (Seconds)",
        description="How often to check enabled asset library roots for changes",
        default=20,
        min=5,
        soft_max=300,
        update=update_asset_library_preferences,
    )
    asset_preview_size_px: IntProperty(
        name="Max Preview Size (px)",
        description="Target square preview size for asset list and grid thumbnails",
        default=48,
        min=48,
        soft_max=512,
        update=update_addon_preferences_ui,
    )

    def draw(self, context):
        layout = self.layout
        panel_box = layout.box()
        panel_box.label(text="Panel Location")
        panel_box.prop(self, "panel_location", expand=False)
        panel_box.label(text="Viewport Menu uses the GTA 000 tab", icon="INFO")

        icon_box = layout.box()
        icon_box.label(text="Icons")
        icon_box.prop(self, "icon_color_mode")
        icon_box.label(text="Default follows the current Blender theme", icon="INFO")

        box = layout.box()
        box.label(text="Alpha Features")
        box.prop(self, "alpha_rotators")
        box.label(text="Untick to keep the siren editor flasher-only", icon="INFO")

        if BGAL_PG_LibraryRoot is not None:
            asset_box = layout.box()
            asset_box.label(text="Asset Library")
            asset_box.label(text="Folder mapping and library roots are managed here for GTA 000 Tools.", icon="FILE_FOLDER")
            roots_row = asset_box.row()
            roots_row.template_list("BGAL_UL_library_roots", "", self, "library_roots", self, "active_root_index", rows=3)
            buttons = roots_row.column(align=True)
            buttons.operator("bgal.root_add", text="", icon="ADD")
            buttons.operator("bgal.root_remove", text="", icon="REMOVE")
            buttons.operator("bgal.scan_libraries", text="", icon="FILE_REFRESH").force = True
            settings = asset_box.box()
            settings.label(text="Folder Mapping")
            settings.prop(self, "grouping_mode")
            settings.prop(self, "auto_generate_missing_previews")
            settings.prop(self, "auto_refresh_enabled")
            interval = settings.row()
            interval.enabled = self.auto_refresh_enabled
            interval.prop(self, "auto_refresh_interval")
            display = asset_box.box()
            display.label(text="Display")
            display.prop(self, "asset_preview_size_px")
            display.label(text="Used by asset list and grid thumbnails", icon="INFO")

def addon_version_tuple():
    try:
        return tuple(int(v) for v in bl_info.get("version", (0, 0, 0)))
    except Exception:
        return (0, 0, 0)


def version_to_str(version):
    try:
        return ".".join(str(int(v)) for v in tuple(version))
    except Exception:
        return "0.0.0"


def compare_versions(a, b):
    av = tuple(int(v) for v in tuple(a))
    bv = tuple(int(v) for v in tuple(b))
    if av == bv:
        return 0
    return 1 if av > bv else -1


def update_timestamp_string(ts=None):
    if ts is None:
        ts = _time.time()
    try:
        return _time.strftime("%Y-%m-%d %H:%M:%S", _time.localtime(float(ts)))
    except Exception:
        return ""


def parse_version_tuple_from_init_text(text):
    if not text:
        return None
    m = re.search(r'"version"\s*:\s*\(\s*(\d+)\s*,\s*(\d+)\s*,\s*(\d+)\s*\)', str(text))
    if not m:
        return None
    return tuple(int(m.group(i)) for i in range(1, 4))


def parse_version_tuple_from_string(text):
    if not text:
        return None
    m = re.search(r'(\d+)\.(\d+)\.(\d+)', str(text))
    if not m:
        return None
    return tuple(int(m.group(i)) for i in range(1, 4))


def normalize_update_state(s):
    if not s:
        return

    current = addon_version_tuple()
    current_str = version_to_str(current)
    remote = parse_version_tuple_from_string(getattr(s, "update_remote_version", ""))
    status = str(getattr(s, "update_status", "") or "")

    if remote and compare_versions(current, remote) >= 0:
        s.update_available = False
        s.update_remote_version = current_str
        if getattr(s, "update_restart_required", False):
            s.update_restart_required = False
            s.update_check_in_progress = False
            s.update_install_in_progress = False
            if status.startswith("Update installed:") or status.startswith("Update available:"):
                s.update_status = f"GTA 000 Tools is up to date ({current_str})"
        elif status.startswith("Update available:"):
            s.update_status = f"GTA 000 Tools is up to date ({current_str})"


def displayed_update_version(s):
    current = addon_version_tuple()
    current_str = version_to_str(current)
    remote_str = str(getattr(s, "update_remote_version", "") or "").strip()
    remote = parse_version_tuple_from_string(remote_str)
    if not remote:
        return remote_str or current_str
    return current_str if compare_versions(current, remote) >= 0 else remote_str


def update_request_headers():
    return {"User-Agent": f"GTA000Tools/{version_to_str(addon_version_tuple())}"}


def find_sollumz_module_name():
    try:
        for mod in addon_utils.modules():
            name = str(getattr(mod, "__name__", "") or "")
            info = getattr(mod, "bl_info", {}) or {}
            label = str(info.get("name", "") or "")
            if name.lower() == "sollumz" or "sollumz" in name.lower() or "sollumz" in label.lower():
                return name
    except Exception:
        pass
    return ""


def sollumz_enabled():
    module_name = find_sollumz_module_name()
    if not module_name:
        return False
    try:
        prefs = getattr(getattr(bpy.context, "preferences", None), "addons", None)
        return bool(prefs and module_name in prefs)
    except Exception:
        return False


def sollumz_status():
    module_name = find_sollumz_module_name()
    return {
        "module": module_name,
        "installed": bool(module_name),
        "enabled": bool(module_name) and sollumz_enabled(),
    }


def download_url_bytes(url):
    req = urllib.request.Request(str(url), headers=update_request_headers() | {"Accept": "application/vnd.github+json"})
    with urllib.request.urlopen(req, timeout=UPDATE_REQUEST_TIMEOUT) as resp:
        return resp.read()


def fetch_sollumz_release_asset_info():
    data = download_url_bytes(SOLLUMZ_RELEASE_API_URL)
    payload = json.loads(data.decode("utf-8", errors="ignore"))
    tag_name = str(payload.get("tag_name", "") or payload.get("name", "") or "")
    assets = payload.get("assets", []) or []
    for asset in assets:
        name = str(asset.get("name", "") or "")
        url = str(asset.get("browser_download_url", "") or "")
        if name.lower().endswith(".zip") and url:
            return {"tag": tag_name, "name": name, "url": url}
    raise RuntimeError("Could not find a Sollumz release zip in the latest GitHub release")


def addon_roots_from_zip_bytes(data):
    roots = []
    with zipfile.ZipFile(io.BytesIO(data)) as zf:
        for name in zf.namelist():
            norm = str(name or "").strip("/")
            if not norm.endswith("__init__.py"):
                continue
            if "/" not in norm:
                continue
            root = norm.split("/", 1)[0]
            if root and root not in roots:
                roots.append(root)
    return roots


def install_addon_from_zip_bytes(data, name_hint=""):
    fd, tmp_path = tempfile.mkstemp(suffix=".zip")
    os.close(fd)
    try:
        with open(tmp_path, "wb") as fh:
            fh.write(data)
        bpy.ops.preferences.addon_install(filepath=tmp_path, overwrite=True)
        try:
            addon_utils.modules_refresh()
        except Exception:
            pass

        candidates = []
        for root in addon_roots_from_zip_bytes(data):
            if root not in candidates:
                candidates.append(root)
        hint = str(name_hint or "").strip().lower()
        try:
            for mod in addon_utils.modules():
                mod_name = str(getattr(mod, "__name__", "") or "")
                info = getattr(mod, "bl_info", {}) or {}
                label = str(info.get("name", "") or "")
                if hint and (hint in mod_name.lower() or hint in label.lower()):
                    if mod_name not in candidates:
                        candidates.append(mod_name)
        except Exception:
            pass

        enabled_module = ""
        for mod_name in candidates:
            try:
                bpy.ops.preferences.addon_enable(module=mod_name)
                enabled_module = mod_name
                break
            except Exception:
                continue
        return enabled_module
    finally:
        try:
            os.remove(tmp_path)
        except Exception:
            pass


def download_update_zip_bytes():
    req = urllib.request.Request(UPDATE_ZIP_URL, headers=update_request_headers())
    with urllib.request.urlopen(req, timeout=UPDATE_REQUEST_TIMEOUT) as resp:
        return resp.read()


def inspect_update_zip_bytes(data):
    if not data:
        raise RuntimeError("Downloaded update file was empty")
    with zipfile.ZipFile(io.BytesIO(data)) as zf:
        names = [name for name in zf.namelist() if name.lower().endswith("/__init__.py") or name == "__init__.py"]
        names.sort(key=lambda name: ("gta000tools/__init__.py" not in name.lower(), len(name)))
        for name in names:
            try:
                text = zf.read(name).decode("utf-8", errors="ignore")
            except Exception:
                continue
            version = parse_version_tuple_from_init_text(text)
            if version:
                root = name.rsplit("/", 1)[0] if "/" in name else ""
                return version, root
    raise RuntimeError("Could not locate GTA 000 Tools package inside the downloaded zip")


def addon_install_target_dir():
    return os.path.dirname(os.path.abspath(__file__))


def iter_relative_files(root_dir):
    rels = {}
    for current_root, dirs, files in os.walk(root_dir):
        dirs[:] = [d for d in dirs if d != "__pycache__"]
        for name in files:
            if name.endswith((".pyc", ".pyo")):
                continue
            full = os.path.join(current_root, name)
            rel = os.path.relpath(full, root_dir)
            rels[rel] = full
    return rels


def prune_empty_dirs(root_dir):
    for current_root, dirs, files in os.walk(root_dir, topdown=False):
        dirs[:] = [d for d in dirs if d != "__pycache__"]
        if current_root == root_dir:
            continue
        try:
            if not os.listdir(current_root):
                os.rmdir(current_root)
        except Exception:
            pass


def sync_addon_directory(source_dir, target_dir):
    if not os.path.isdir(source_dir):
        raise RuntimeError("Update package did not contain a valid addon directory")
    os.makedirs(target_dir, exist_ok=True)
    source_files = iter_relative_files(source_dir)
    target_files = iter_relative_files(target_dir)

    stale_files = sorted(set(target_files) - set(source_files), reverse=True)
    for rel in stale_files:
        try:
            os.remove(os.path.join(target_dir, rel))
        except FileNotFoundError:
            pass

    for rel, src in source_files.items():
        dst = os.path.join(target_dir, rel)
        os.makedirs(os.path.dirname(dst), exist_ok=True)
        shutil.copy2(src, dst)

    prune_empty_dirs(target_dir)


def install_update_from_zip_bytes(data, target_dir=None):
    target_dir = target_dir or addon_install_target_dir()
    version, root = inspect_update_zip_bytes(data)
    temp_parent = os.path.dirname(os.path.abspath(target_dir)) or os.path.abspath(target_dir)
    stage_name = f"gta000tools_update_{int(_time.time() * 1000)}"
    temp_dir = os.path.join(temp_parent, stage_name)
    os.makedirs(temp_dir, exist_ok=True)
    try:
        with zipfile.ZipFile(io.BytesIO(data)) as zf:
            zf.extractall(temp_dir)
        source_dir = os.path.join(temp_dir, root) if root else temp_dir
        if not os.path.isfile(os.path.join(source_dir, "__init__.py")):
            for current_root, dirs, files in os.walk(temp_dir):
                if "__init__.py" in files:
                    source_dir = current_root
                    break
        sync_addon_directory(source_dir, target_dir)
    finally:
        shutil.rmtree(temp_dir, ignore_errors=True)
    return version


def set_update_ui_state(message="", available=None, remote_version=None, checking=None, installing=None, restart_required=None, checked_at=None, set_status=False):
    scenes = getattr(bpy.data, "scenes", None) or []
    for scene in scenes:
        s = getattr(scene, "nels", None)
        if not s:
            continue
        if message is not None:
            s.update_status = str(message or "")
            if set_status:
                s.status_message = str(message or "")
        if available is not None:
            s.update_available = bool(available)
        if remote_version is not None:
            s.update_remote_version = str(remote_version or "")
        if checking is not None:
            s.update_check_in_progress = bool(checking)
        if installing is not None:
            s.update_install_in_progress = bool(installing)
        if restart_required is not None:
            s.update_restart_required = bool(restart_required)
        if checked_at is not None:
            s.update_last_checked = str(checked_at or "")


def start_update_job(kind):
    global _UPDATE_THREAD, _UPDATE_RESULT
    with _UPDATE_LOCK:
        if _UPDATE_THREAD and _UPDATE_THREAD.is_alive():
            return False
        _UPDATE_RESULT = None

        def worker():
            global _UPDATE_THREAD, _UPDATE_RESULT
            result = {"kind": kind, "ok": False}
            try:
                data = download_update_zip_bytes()
                remote_version, _root = inspect_update_zip_bytes(data)
                result["remote_version"] = remote_version
                if kind == "INSTALL":
                    installed_version = install_update_from_zip_bytes(data)
                    result["installed_version"] = installed_version
                result["ok"] = True
            except Exception as ex:
                result["error"] = str(ex)
            with _UPDATE_LOCK:
                _UPDATE_RESULT = result
                _UPDATE_THREAD = None

        _UPDATE_THREAD = threading.Thread(target=worker, name=f"gta000tools_update_{kind.lower()}", daemon=True)
        _UPDATE_THREAD.start()
    return True


def apply_update_job_result():
    global _UPDATE_RESULT
    with _UPDATE_LOCK:
        result = _UPDATE_RESULT
        _UPDATE_RESULT = None
    if not result:
        return False

    checked_at = update_timestamp_string()
    current_version = addon_version_tuple()
    kind = str(result.get("kind", "CHECK") or "CHECK")
    remote_version = tuple(result.get("remote_version") or ())
    remote_version_str = version_to_str(remote_version) if remote_version else ""

    if not result.get("ok"):
        message = f"Update {kind.lower()} failed: {result.get('error', 'Unknown error')}"
        set_update_ui_state(message=message, checking=False, installing=False, checked_at=checked_at, set_status=True)
        tag_preview_ui_redraw()
        return True

    if kind == "INSTALL":
        installed_version = tuple(result.get("installed_version") or remote_version or current_version)
        message = f"Update installed: {version_to_str(installed_version)}. Restart Blender to load the new version."
        set_update_ui_state(message=message, available=False, remote_version=version_to_str(installed_version), checking=False, installing=False, restart_required=True, checked_at=checked_at, set_status=True)
        tag_preview_ui_redraw()
        return True

    available = bool(remote_version and compare_versions(remote_version, current_version) > 0)
    if available:
        message = f"Update available: {version_to_str(current_version)} -> {remote_version_str}"
        set_update_ui_state(message=message, available=True, remote_version=remote_version_str, checking=False, installing=False, restart_required=False, checked_at=checked_at, set_status=True)
    else:
        message = f"GTA 000 Tools is up to date ({version_to_str(current_version)})"
        set_update_ui_state(message=message, available=False, remote_version=remote_version_str or version_to_str(current_version), checking=False, installing=False, restart_required=False, checked_at=checked_at, set_status=False)
    tag_preview_ui_redraw()
    return True


def begin_update_operation(kind, automatic=False):
    message = "Checking GitHub for updates..." if kind == "CHECK" else "Installing update from GitHub..."
    started = start_update_job(kind)
    if not started:
        if not automatic:
            set_update_ui_state(message="An update task is already running", set_status=True)
            tag_preview_ui_redraw()
        return False

    set_update_ui_state(
        message=message,
        checking=(kind == "CHECK"),
        installing=(kind == "INSTALL"),
        restart_required=False if kind == "INSTALL" else None,
        set_status=(not automatic),
    )
    tag_preview_ui_redraw()
    return True


def schedule_startup_update_check(scene=None):
    global _UPDATE_STARTUP_SCHEDULED
    if _UPDATE_STARTUP_SCHEDULED:
        return
    s = getattr(scene, "nels", None) if scene else None
    if s and not bool(getattr(s, "update_check_on_startup", True)):
        return
    _UPDATE_STARTUP_SCHEDULED = True

    def deferred():
        try:
            begin_update_operation("CHECK", automatic=True)
        except Exception:
            pass
        return None

    try:
        bpy.app.timers.register(deferred, first_interval=2.0)
    except Exception:
        _UPDATE_STARTUP_SCHEDULED = False


VISIBILITY_ITEMS = [
    ("BOTH", "Rotator + Flasher", ""),
    ("ROTATOR", "Rotator", ""),
    ("FLASHER", "Flasher", ""),
]

SIREN_TYPES = [("FLASHER", "Flasher", ""), ("ROTATOR", "Rotator", "")]

ROT_SPEED = {
    "P50": 8.0,
    "P25": 4.0,
    "P12_5": 2.0,
    "P6_25": 1.0,
    "P3_125": 0.5,
}

ROT_SPEED_ITEMS = [
    ("P50", "Rotate at 50% BPM", "BPM/100*8"),
    ("P25", "Rotate at 25% BPM", "BPM/100*4"),
    ("P12_5", "Rotate at 12.5% BPM", "BPM/100*2"),
    ("P6_25", "Rotate at 6.25% BPM", "BPM/100"),
    ("P3_125", "Rotate at 3.125% BPM", "BPM/100*0.5"),
    ("CUSTOM", "Enter custom % of BPM", ""),
]

DIRECTIONS = {
    "FRONT": 0.0,
    "DRIVER": -1.57079633,
    "PASSENGER": 1.57079633,
    "BACK": 3.14159265,
    "BACK_LEFT": 2.35619449,
    "BACK_RIGHT": -2.35619449,
    "FRONT_LEFT": 0.78539816,
    "FRONT_RIGHT": -0.78539816,
}

DIRECTION_ITEMS = [
    ("FRONT", "Front", "0.00000000"),
    ("DRIVER", "Driver Side", "-1.57079633"),
    ("PASSENGER", "Passenger Side", "1.57079633"),
    ("BACK", "Back", "3.14159265"),
    ("BACK_LEFT", "Back Left", "2.35619449"),
    ("BACK_RIGHT", "Back Right", "-2.35619449"),
    ("FRONT_LEFT", "Front Left", "0.78539816"),
    ("FRONT_RIGHT", "Front Right", "-0.78539816"),
]

SCALES = {"SCALE_50": 0.5, "SCALE_10": 0.1, "SCALE_01": 0.01}
SCALE_ITEMS = [
    ("SCALE_50", "Scale to 50% (0.5)", ""),
    ("SCALE_10", "Scale to 10% (0.1)", ""),
    ("SCALE_01", "Scale to 1% (0.01)", ""),
]
SCALE_FACTOR_PRESET_ITEMS = [
    ("SF_2", "Scale Factor 2 (0.5)", "Stored value: 0.5"),
    ("SF_10", "Scale Factor 10 (0.1)", "Stored value: 0.1"),
    ("SF_100", "Scale Factor 100 (0.01)", "Stored value: 0.01"),
    ("CUSTOM", "Custom", "Use a custom stored value"),
]
SCALE_FACTOR_PRESET_VALUES = {"SF_2": 0.5, "SF_10": 0.1, "SF_100": 0.01}

COLORS = {
    "LED_AMBER": "0xFFFF4800",
    "LED_BLUE": "0xFF000AFF",
    "LED_RED": "0xFFFF0300",
    "HALOGEN_BLUE": "0xFF2130FF",
    "HALOGEN_RED": "0xFFFF1405",
    "GENERAL_AMBER": "0xFFFF6400",
    "GENERAL_AMBER_BRIGHT": "0xFFFFFF00",
    "GENERAL_BLUE": "0xFF0000FF",
    "GENERAL_GREEN": "0xFF00C853",
    "GENERAL_PINK": "0xFFFF2D95",
    "GENERAL_PURPLE": "0xFF673AB7",
    "GENERAL_RED": "0xFFFF0000",
    "GENERAL_WHITE": "0xFFFFFFFF",
    "NO_COLOUR": "0xFF000000",
}

COLOR_ITEMS = [
    ("LED_AMBER", "LED - Amber", COLORS["LED_AMBER"]),
    ("LED_BLUE", "LED - Blue", COLORS["LED_BLUE"]),
    ("LED_RED", "LED - Red", COLORS["LED_RED"]),
    ("HALOGEN_BLUE", "Halogen - Blue", COLORS["HALOGEN_BLUE"]),
    ("HALOGEN_RED", "Halogen - Red", COLORS["HALOGEN_RED"]),
    ("GENERAL_AMBER", "General - Amber", COLORS["GENERAL_AMBER"]),
    ("GENERAL_AMBER_BRIGHT", "General - Amber Bright", COLORS["GENERAL_AMBER_BRIGHT"]),
    ("GENERAL_BLUE", "General - Blue", COLORS["GENERAL_BLUE"]),
    ("GENERAL_GREEN", "General - Green", COLORS["GENERAL_GREEN"]),
    ("GENERAL_PINK", "General - Pink", COLORS["GENERAL_PINK"]),
    ("GENERAL_PURPLE", "General - Purple", COLORS["GENERAL_PURPLE"]),
    ("GENERAL_RED", "General - Red", COLORS["GENERAL_RED"]),
    ("GENERAL_WHITE", "General - White", COLORS["GENERAL_WHITE"]),
    ("NO_COLOUR", "No Colour", COLORS["NO_COLOUR"]),
]

DEFAULT_COLOR_LIBRARY = [(label, value) for _, label, value in COLOR_ITEMS]

DEFAULT_PATTERNS = [
    ("Always On / Steady Burn", 4294967295),
    ("Code 3 Pursuit - Stage 1 - Blue", 4042322160),
    ("Code 3 Pursuit - Stage 1 - Red", 252645135),
    ("Code 3 Pursuit - Stage 2 - Blue", 1840278960),
    ("Code 3 Pursuit - Stage 2 - Red", 115017435),
    ("Code 3 Pursuit - Stage 3 - Blue", 1426085120),
    ("Code 3 Pursuit - Stage 3 - Red", 5570645),
    ("Code 3 Pursuit - Sweep - LED 1", 2147581953),
    ("Code 3 Pursuit - Sweep - LED 2", 1073889282),
    ("Code 3 Pursuit - Sweep - LED 3", 537141252),
    ("Code 3 Pursuit - Sweep - LED 4", 268963848),
    ("Code 3 Pursuit - Sweep - LED 5", 135268368),
    ("Code 3 Pursuit - Sweep - LED 6", 69207072),
    ("Code 3 Pursuit - Sweep - LED 7", 37749312),
    ("Code 3 Pursuit - Sweep - LED 8", 25166208),
    ("Double Flash Blue", 168430090),
    ("Double Flash Red", 2694881440),
    ("ECCO Split Double - Left - LED 1", 2684395520),
    ("ECCO Split Double - Right - LED 1", 167774720),
    ("ECCO Split Double - Left - LED 2", 10485920),
    ("ECCO Split Double - Right - LED 2", 655370),
    ("ED3790 - Blue", 2818615296),
    ("ED3790 - Red", 2752554),
    ("ED3790 - White", 41943680),
    ("Strobe - Blue", 9044106),
    ("Strobe - Red", 2315291136),
    ("Tripple Flash - Right", 2852170240),
    ("Tripple Flash - Left", 11141290),
    ("Tripple Flash - Gap - Blue", 2818615296),
    ("Tripple Flash - Gap - Red", 11010216),
    ("Wig Wag - Left", 8323199),
    ("Wig Wag - Right", 2130738944),
    ("Off", 0),
]

LEGACY_DEFAULT_PATTERNS = [
    ("Alternating Quad", 4042264335),
    ("Split 50/50", 4278255360),
    ("Rapid 2x2", 3435973836),
    ("Single Sweep", 4278190080),
    ("Pulsed", 252645135),
    ("Off", 0),
]

HEADLIGHT_KEYS = ("headlight", "head_light", "hl_", "light_head")
TAILLIGHT_KEYS = ("taillight", "tail_light", "rear_light", "brake_light")
LEFT_INDICATOR_KEYS = ("indicator_l", "left_indicator", "turn_l", "blinker_l")
RIGHT_INDICATOR_KEYS = ("indicator_r", "right_indicator", "turn_r", "blinker_r")
EXTRA_LIGHT_KEYS = ("extra_light", "aux_light", "warning_light")
LEFT_SIDE_TOKENS = {"left", "driver", "l", "lf", "lr"}
RIGHT_SIDE_TOKENS = {"right", "passenger", "r", "rf", "rr"}
WHEEL_PREVIEW_PREFIX = "_gta000_wheel_preview_"
LIGHT_ID_PREVIEW_PREFIX = "_gta000_lightid_preview_"
SOLLUMZ_LIGHT_ID_NAME_TO_VALUE = {
    "always_on": 0,
    "headlight_l": 1,
    "headlight_r": 2,
    "taillight_l": 3,
    "taillight_r": 4,
    "indicator_lf": 5,
    "indicator_rf": 6,
    "indicator_lr": 7,
    "indicator_rr": 8,
    "brakelight_l": 9,
    "brakelight_r": 10,
    "brakelight_m": 11,
    "reversinglight_l": 12,
    "reversinglight_r": 13,
    "extralight_1": 14,
    "extralight_2": 15,
    "extralight_3": 16,
    "extralight_4": 17,
}
SOLLUMZ_LIGHT_ID_VALUE_TO_NAME = {v: k for k, v in SOLLUMZ_LIGHT_ID_NAME_TO_VALUE.items()}
SOLLUMZ_LIGHT_ID_COLOR = {
    "always_on": (1.0, 1.0, 1.0),
    "headlight_l": (1.0, 1.0, 1.0),
    "headlight_r": (1.0, 1.0, 1.0),
    "taillight_l": (1.0, 0.08, 0.08),
    "taillight_r": (1.0, 0.08, 0.08),
    "brakelight_l": (1.0, 0.08, 0.08),
    "brakelight_r": (1.0, 0.08, 0.08),
    "brakelight_m": (1.0, 0.08, 0.08),
    "indicator_lf": (1.0, 0.42, 0.0),
    "indicator_rf": (1.0, 0.42, 0.0),
    "indicator_lr": (1.0, 0.42, 0.0),
    "indicator_rr": (1.0, 0.42, 0.0),
    "reversinglight_l": (1.0, 1.0, 1.0),
    "reversinglight_r": (1.0, 1.0, 1.0),
    "extralight_1": (1.0, 1.0, 1.0),
    "extralight_2": (1.0, 1.0, 1.0),
    "extralight_3": (1.0, 1.0, 1.0),
    "extralight_4": (1.0, 1.0, 1.0),
}
SOLLUMZ_LIGHT_ID_ATTR_NAMES = {
    "lightid",
    "lightids",
    "light_id",
    "light_ids",
    "vehiclelightid",
    "vehiclelightids",
    "vehicle_light_id",
    "vehicle_light_ids",
    "externallightid",
    "external_light_id",
    "externalstateid",
    "external_state_id",
}
SOLLUMZ_LIGHT_ID_UI_ITEMS = [
    ("always_on", "Always On", "Always-on polygons"),
    ("headlight_l", "Left Headlight (headlight_l)", ""),
    ("headlight_r", "Right Headlight (headlight_r)", ""),
    ("taillight_l", "Left Taillight (taillight_l)", ""),
    ("taillight_r", "Right Taillight (taillight_r)", ""),
    ("indicator_lf", "Front Left Indicator (indicator_lf)", ""),
    ("indicator_rf", "Front Right Indicator (indicator_rf)", ""),
    ("indicator_lr", "Rear Left Indicator (indicator_lr)", ""),
    ("indicator_rr", "Rear Right Indicator (indicator_rr)", ""),
    ("brakelight_l", "Left Brakelight (brakelight_l)", ""),
    ("brakelight_r", "Right Brakelight (brakelight_r)", ""),
    ("brakelight_m", "Center Brakelight (brakelight_m)", ""),
    ("reversinglight_l", "Left Reversing Light (reversinglight_l)", ""),
    ("reversinglight_r", "Right Reversing Light (reversinglight_r)", ""),
    ("extralight_1", "Extra Front Left (extralight_1)", ""),
    ("extralight_2", "Extra Front Right (extralight_2)", ""),
    ("extralight_3", "Extra Rear Left (extralight_3)", ""),
    ("extralight_4", "Extra Rear Right (extralight_4)", ""),
    ("CUSTOM", "Custom", "Use a custom numeric Light ID"),
]
def f8(v):
    return f"{float(v):.8f}"


def b(v):
    return "true" if v else "false"


def clean_bits(txt):
    return "".join(ch for ch in str(txt) if ch in "01")[:32]


def repeat_32(txt):
    bits = clean_bits(txt)
    if not bits:
        return "0" * 32
    if len(bits) == 32:
        return bits
    return (bits * ((32 + len(bits) - 1) // len(bits)))[:32]


def bits_to_int(txt):
    return int(repeat_32(txt), 2)

def invert_bits(txt):
    bits = repeat_32(txt)
    return "".join("1" if ch == "0" else "0" for ch in bits)



def parse_u32(v):
    txt = str(v).strip()
    try:
        n = int(txt, 10)
    except Exception:
        try:
            n = int(txt, 0)
        except Exception:
            n = 0
    return n & 0xFFFFFFFF


def int_to_bits(v):
    return format(parse_u32(v), "032b")


def cfg_dir():
    candidates = []
    names = ["gta000tools", "non_els_lightbar_tool"]

    for name in names:
        try:
            p = bpy.utils.user_resource("CONFIG", path=name, create=False)
            if p:
                candidates.append(p)
        except Exception:
            pass

    try:
        base = bpy.utils.user_resource("CONFIG")
        if base:
            for name in names:
                candidates.append(os.path.join(base, name))
    except Exception:
        pass

    for name in names:
        candidates.append(os.path.join(tempfile.gettempdir(), name))

    for p in candidates:
        target = p
        if os.path.isfile(target):
            target = target + "_data"
        try:
            os.makedirs(target, exist_ok=True)
            return target
        except Exception:
            continue

    return tempfile.gettempdir()


def safe_name(name):
    return re.sub(r"[^A-Za-z0-9_\- ]+", "", str(name)).strip().replace(" ", "_") or "lightbar_config"



_LIBRARY_FILE = "library.json"
_LIBRARY_SYNC_GUARD = False
_LIVE_PREVIEW_GUARD = False
_SCALE_FACTOR_SYNC_GUARD = False
_PREVIEW_UPDATE_SUSPEND = 0

def library_path():
    return os.path.join(cfg_dir(), _LIBRARY_FILE)

def load_global_library_data():
    fp = library_path()
    if not os.path.exists(fp):
        return {}
    try:
        with open(fp, "r", encoding="utf-8") as h:
            data = json.load(h)
        return data if isinstance(data, dict) else {}
    except Exception:
        return {}

def save_global_library(s):
    global _LIBRARY_SYNC_GUARD
    if _LIBRARY_SYNC_GUARD or not s:
        return
    try:
        data = {
            "patterns": [
                {
                    "name": p.name,
                    "visibility": p.visibility,
                    "bits": repeat_32(p.bits),
                    "value": parse_u32(p.value),
                    "allow_duplicate": bool(getattr(p, "allow_duplicate", False)),
                }
                for p in s.patterns
            ],
            "colors": [
                {
                    "name": c.name,
                    "value": clean_color_value(c.value),
                }
                for c in s.colors
            ],
        }
        with open(library_path(), "w", encoding="utf-8") as h:
            json.dump(data, h, indent=2)
    except Exception:
        pass

def save_library_from_context(context):
    scene = getattr(context, "scene", None) if context else None
    s = getattr(scene, "nels", None) if scene else None
    if s:
        save_global_library(s)


def config_json_files():
    excluded = {
        _LIBRARY_FILE.lower(),
        "asset_index.json",
        "ui_state.json",
    }
    files = []
    root = cfg_dir()
    for n in sorted(os.listdir(root)):
        lower = n.lower()
        if not lower.endswith(".json"):
            continue
        if lower in excluded:
            continue
        fp = os.path.join(root, n)
        if not os.path.isfile(fp):
            continue
        files.append(n)
    return files
def generate_siren_id(seed_text=""):
    base = 25000
    try:
        rnd = int.from_bytes(os.urandom(2), "little")
    except Exception:
        rnd = sum(ord(ch) for ch in str(seed_text))
    return base + (rnd % 50000)

def pattern_key_index(key):
    txt = str(key).strip()
    if txt.startswith("PAT_"):
        txt = txt[4:]
    try:
        return int(txt)
    except Exception:
        return 0


def normalize_pattern_key(key):
    return f"PAT_{max(0, pattern_key_index(key))}"



def find_pattern_key_by_name(s, name):
    if not s or not getattr(s, "patterns", None):
        return "PAT_0"
    target = str(name or "").strip().lower()
    for i, p in enumerate(s.patterns):
        if (p.name or "").strip().lower() == target:
            return f"PAT_{i}"
    return "PAT_0"


def pattern_duplicate_key(name):
    return re.sub(r"\s+", " ", str(name or "").strip()).lower()


def pattern_duplicate_indices(s, idx):
    if not s or not getattr(s, "patterns", None):
        return []
    if idx < 0 or idx >= len(s.patterns):
        return []
    key = pattern_duplicate_key(getattr(s.patterns[idx], "name", ""))
    if not key:
        return []
    matches = [i for i, p in enumerate(s.patterns) if pattern_duplicate_key(getattr(p, "name", "")) == key]
    return matches if len(matches) > 1 else []


def pattern_duplicate_is_allowed(s, idx):
    matches = pattern_duplicate_indices(s, idx)
    return bool(matches) and all(bool(getattr(s.patterns[i], "allow_duplicate", False)) for i in matches)


def pattern_display_name(s, idx):
    p = s.patterns[idx]
    base = str(getattr(p, "name", "") or f"Pattern {idx + 1}")
    matches = pattern_duplicate_indices(s, idx)
    if not matches:
        return base
    try:
        pos = matches.index(idx) + 1
    except ValueError:
        pos = 1
    return f"{base} [{pos}]"


def set_pattern_duplicate_allowed(s, idx, allowed):
    matches = pattern_duplicate_indices(s, idx)
    if not matches:
        return 0
    for i in matches:
        s.patterns[i].allow_duplicate = bool(allowed)
    return len(matches)


def remove_pattern_duplicates_keep_selected(s, idx):
    matches = pattern_duplicate_indices(s, idx)
    if not matches:
        return 0, idx
    removed = 0
    keep_idx = idx
    for i in reversed(matches):
        if i == idx:
            continue
        s.patterns.remove(i)
        removed += 1
        if i < keep_idx:
            keep_idx -= 1
    if 0 <= keep_idx < len(s.patterns):
        s.patterns[keep_idx].allow_duplicate = False
    return removed, keep_idx


def populate_default_patterns(s):
    s.patterns.clear()
    for name, value in DEFAULT_PATTERNS:
        p = s.patterns.add()
        p.name = name
        p.visibility = "BOTH"
        p.bits = int_to_bits(value)
        p.value = str(parse_u32(value))
        p.allow_duplicate = False
    s.active_pattern = 0


def patterns_match_defaults(s, defaults):
    actual = [(pattern_duplicate_key(getattr(p, "name", "")), parse_u32(getattr(p, "value", 0))) for p in getattr(s, "patterns", [])]
    expected = [(pattern_duplicate_key(name), parse_u32(value)) for name, value in defaults]
    return actual == expected


def migrate_legacy_default_patterns(s):
    legacy_sigs = {(pattern_duplicate_key(name), parse_u32(value)) for name, value in LEGACY_DEFAULT_PATTERNS}
    default_sigs = {(pattern_duplicate_key(name), parse_u32(value)) for name, value in DEFAULT_PATTERNS}
    seen_legacy = set()
    extras = []
    for p in getattr(s, "patterns", []):
        sig = (pattern_duplicate_key(getattr(p, "name", "")), parse_u32(getattr(p, "value", 0)))
        if sig in legacy_sigs:
            seen_legacy.add(sig)
            continue
        if sig in default_sigs:
            continue
        extras.append({
            "name": p.name,
            "allow_duplicate": bool(getattr(p, "allow_duplicate", False)),
            "visibility": "FLASHER" if getattr(p, "visibility", "BOTH") == "FLASHER" else "BOTH",
            "bits": repeat_32(getattr(p, "bits", "0")),
            "value": str(parse_u32(getattr(p, "value", 0))),
        })

    if not seen_legacy:
        return False

    populate_default_patterns(s)
    for pd in extras:
        p = s.patterns.add()
        p.name = pd["name"]
        p.allow_duplicate = pd["allow_duplicate"]
        p.visibility = pd["visibility"]
        p.bits = pd["bits"]
        p.value = pd["value"]
    s.active_pattern = min(max(0, s.active_pattern), max(0, len(s.patterns) - 1))
    return True
def clean_color_value(txt):
    raw = str(txt).strip().upper().replace("#", "")
    if raw.startswith("0X"):
        raw = raw[2:]
    raw = "".join(ch for ch in raw if ch in "0123456789ABCDEF")
    if len(raw) == 6:
        raw = "FF" + raw
    if len(raw) != 8:
        return "0xFFFF0000"
    return "0x" + raw


def _srgb_channel_to_linear(value):
    v = max(0.0, min(1.0, float(value)))
    if v <= 0.04045:
        return v / 12.92
    return ((v + 0.055) / 1.055) ** 2.4


def _linear_channel_to_srgb(value):
    v = max(0.0, min(1.0, float(value)))
    if v <= 0.0031308:
        return v * 12.92
    return 1.055 * (v ** (1.0 / 2.4)) - 0.055


def color_to_rgb(value):
    v = clean_color_value(value)
    hx = v[4:]
    sr = int(hx[0:2], 16) / 255.0
    sg = int(hx[2:4], 16) / 255.0
    sb = int(hx[4:6], 16) / 255.0
    return (_srgb_channel_to_linear(sr), _srgb_channel_to_linear(sg), _srgb_channel_to_linear(sb))


def rgb_to_color(rgb):
    r = int(round(_linear_channel_to_srgb(max(0.0, min(1.0, float(rgb[0])))) * 255))
    g = int(round(_linear_channel_to_srgb(max(0.0, min(1.0, float(rgb[1])))) * 255))
    b0 = int(round(_linear_channel_to_srgb(max(0.0, min(1.0, float(rgb[2])))) * 255))
    return f"0xFF{r:02X}{g:02X}{b0:02X}"

def color_key_index(key):
    txt = str(key).strip()
    if txt.startswith("COL_"):
        txt = txt[4:]
    try:
        return int(txt)
    except Exception:
        return 0


def normalize_color_key(key):
    return f"COL_{max(0, color_key_index(key))}"



def find_color_key_by_value(s, value):
    if not s or not getattr(s, "colors", None):
        return "COL_0"
    target = clean_color_value(value)
    for i, c in enumerate(s.colors):
        if clean_color_value(getattr(c, "value", "0xFFFF0000")) == target:
            return f"COL_{i}"
    return "COL_0"
def color_items(self, context):
    try:
        scene = getattr(context, "scene", None) if context else None
        s = getattr(scene, "nels", None) if scene else None
        if not s or not s.colors:
            return [("COL_0", "Colour 1", "")]
        items = []
        for i, c in enumerate(s.colors):
            nm = str(c.name or f"Colour {i + 1}")
            vv = clean_color_value(getattr(c, "value", "0xFFFF0000"))
            items.append((f"COL_{i}", nm, vv))
        return items or [("COL_0", "Colour 1", "")]
    except Exception:
        return [("COL_0", "Colour 1", "")]


def get_color(s, key):
    if not s.colors:
        return None
    i = max(0, min(color_key_index(key), len(s.colors) - 1))
    return s.colors[i]

def pattern_items(self, context):
    s = getattr(context.scene, "nels", None) if context and context.scene else None
    if not s or not s.patterns:
        return [("PAT_0", "(No Patterns)", "")]
    return [(f"PAT_{i}", pattern_display_name(s, i), p.visibility) for i, p in enumerate(s.patterns)]


def pattern_select_items(self, context):
    return list(pattern_items(self, context)) + [(UNSAVED_PATTERN_KEY, "Unsaved Pattern", "")]


def color_select_items(self, context):
    return list(color_items(self, context)) + [("__CUSTOM__", "Custom", "")]


def direction_select_items(self, context):
    return list(DIRECTION_ITEMS) + [("__CUSTOM__", "Custom", "")]

def saved_cfg_items(self, context):
    items = [(NO_SAVED_CFG, "(No Saved Configs)", "")]
    for n in config_json_files():
        items.append((n, os.path.splitext(n)[0], ""))
    return items


def get_pattern(s, key):
    if not s.patterns:
        return None
    i = max(0, min(pattern_key_index(key), len(s.patterns) - 1))
    return s.patterns[i]


def normalize_pattern_visibility(visibility):
    return "FLASHER" if str(visibility or "").upper() == "FLASHER" else "BOTH"


def pattern_matches_visibility(pattern_visibility, requested_visibility):
    pattern_vis = normalize_pattern_visibility(pattern_visibility)
    requested_vis = normalize_pattern_visibility(requested_visibility)
    return pattern_vis == requested_vis or (requested_vis == "FLASHER" and pattern_vis == "BOTH")


def find_pattern_key_by_bits(s, bits, visibility="BOTH"):
    bits32 = repeat_32(bits)
    for i, p in enumerate(getattr(s, "patterns", [])):
        if repeat_32(getattr(p, "bits", "0")) != bits32:
            continue
        if pattern_matches_visibility(getattr(p, "visibility", "BOTH"), visibility):
            return f"PAT_{i}"
    return ""


def next_pattern_name(s, base_name="Unsaved Pattern"):
    base = str(base_name or "Unsaved Pattern").strip() or "Unsaved Pattern"
    existing = {str(getattr(p, "name", "") or "").strip().casefold() for p in getattr(s, "patterns", [])}
    if base.casefold() not in existing:
        return base
    i = 2
    while f"{base} {i}".casefold() in existing:
        i += 1
    return f"{base} {i}"


def get_or_add_pattern(s, name, visibility, bits):
    bits32 = repeat_32(bits)
    vis = normalize_pattern_visibility(visibility)
    existing_key = find_pattern_key_by_bits(s, bits32, vis)
    if existing_key:
        return existing_key
    p = s.patterns.add()
    p.name = name or f"Pattern {len(s.patterns)}"
    p.visibility = vis
    p.bits = bits32
    p.value = str(bits_to_int(bits32))
    s.active_pattern = len(s.patterns) - 1
    save_global_library(s)
    return f"PAT_{s.active_pattern}"


def off_pattern_key(s):
    return find_pattern_key_by_name(s, "off")


def white_color_key(s):
    return find_color_key_by_value(s, COLORS["GENERAL_WHITE"])


def playback_seconds(scene=None, now=None):
    if now is not None:
        try:
            return float(now)
        except Exception:
            pass

    scn = scene if scene is not None else getattr(bpy.context, "scene", None)
    if scn and timeline_playing():
        try:
            fps_base = float(getattr(scn.render, "fps_base", 1.0) or 1.0)
            fps = float(getattr(scn.render, "fps", 24.0))
            fps_real = fps / fps_base if fps_base != 0.0 else fps
            if fps_real <= 0.0:
                fps_real = 24.0
            return float(scn.frame_current) / fps_real
        except Exception:
            pass
    return _time.time()


def pattern_is_on(s, key, bpm, now=None, scene=None):
    p = get_pattern(s, key)
    bits = repeat_32(p.bits) if p else ("0" * 32)
    ts = playback_seconds(scene=scene, now=now)
    steps_per_second = max(1.0, float(bpm)) / 60.0
    idx = int(ts * steps_per_second) % 32
    return bits[idx] == "1"


def preview_seconds(scene=None, now=None):
    ts = playback_seconds(scene=scene, now=now)
    scn = scene if scene is not None else getattr(bpy.context, "scene", None)
    if scn and (not timeline_playing()):
        s = getattr(scn, "nels", None)
        if s:
            origin = float(getattr(s, "preview_time_origin", 0.0) or 0.0)
            if origin > 0.0:
                return max(0.0, ts - origin)
    return ts


def preview_pattern_is_on(bits, bpm, scene=None, now=None):
    bits32 = repeat_32(bits)
    ts = preview_seconds(scene=scene, now=now)
    steps_per_second = max(1.0, float(bpm)) / 60.0
    idx = int(ts * steps_per_second) % 32
    return bits32[idx] == "1"


def scale_factor_choice_from_value(val):
    try:
        fv = float(val)
    except Exception:
        return "CUSTOM"
    for key, pv in SCALE_FACTOR_PRESET_VALUES.items():
        if abs(fv - pv) <= 0.000001:
            return key
    return "CUSTOM"

def siren_index_from_name(name):
    m = re.match(r"^siren\s*(\d+)", str(name or "").strip().lower())
    if not m:
        return 0
    try:
        idx = int(m.group(1))
    except Exception:
        return 0
    return idx if 1 <= idx <= MAX_SIRENS else 0



def extra_index_from_name(name):
    m = re.match(r"^extra[_\-\s]?(\d+)(?:\..*)?$", str(name or "").strip().lower())
    if not m:
        return 0
    try:
        return int(m.group(1))
    except Exception:
        return 0


def scene_extra_objects(scene):
    if not scene:
        return []
    found = []
    for obj in scene.objects:
        idx = extra_index_from_name(obj.name)
        if idx > 0:
            found.append((idx, obj.name, obj))
    found.sort(key=lambda it: (it[0], it[1].lower()))
    return [it[2] for it in found]


def is_object_visible(obj):
    try:
        return not obj.hide_get()
    except Exception:
        return not bool(getattr(obj, "hide_viewport", False))


def set_object_visible(obj, show):
    hide = not bool(show)
    try:
        obj.hide_set(hide)
    except Exception:
        pass
    try:
        obj.hide_viewport = hide
    except Exception:
        pass
    try:
        obj.hide_render = hide
    except Exception:
        pass


def extra_display_name(obj):
    idx = extra_index_from_name(getattr(obj, "name", ""))
    if idx <= 0:
        return getattr(obj, "name", "")
    base = f"extra_{idx}".lower()
    nm = str(getattr(obj, "name", ""))
    if nm.lower() == base:
        return f"Extra {idx}"
    return f"Extra {idx} ({nm})"


def collision_name_matches(name):
    return ".col" in str(name or "").lower()


def scene_collision_objects(scene):
    if not scene:
        return []
    found = []
    for obj in scene.objects:
        name = str(getattr(obj, "name", "") or "")
        if not collision_name_matches(name):
            continue
        if name.startswith(WHEEL_PREVIEW_PREFIX) or name.startswith(LIGHT_ID_PREVIEW_PREFIX):
            continue
        found.append(obj)
    found.sort(key=lambda obj: str(getattr(obj, "name", "") or "").lower())
    return found


def _name_has_any(name, keys):
    txt = str(name or "").lower()
    return any(k in txt for k in keys)


def scene_objects_by_keywords(scene, keywords):
    if not scene:
        return []
    out = []
    for obj in scene.objects:
        nm = str(getattr(obj, "name", ""))
        if nm.startswith(WHEEL_PREVIEW_PREFIX) or nm.startswith(LIGHT_ID_PREVIEW_PREFIX):
            continue
        if _name_has_any(nm, keywords):
            out.append(obj)
    return out

def object_side(name):
    nm = str(name or "").lower()
    tokens = [t for t in re.split(r"[^a-z0-9]+", nm) if t]

    left = any(t in LEFT_SIDE_TOKENS for t in tokens) or bool(re.search(r"(?:^|[_\-.])(l|lf|lr)(?:$|[_\-.])", nm))
    right = any(t in RIGHT_SIDE_TOKENS for t in tokens) or bool(re.search(r"(?:^|[_\-.])(r|rf|rr)(?:$|[_\-.])", nm))

    if left and not right:
        return "LEFT"
    if right and not left:
        return "RIGHT"
    return "CENTER"


def split_side_objects(objs):
    left = []
    right = []
    center = []
    for obj in objs:
        side = object_side(getattr(obj, "name", ""))
        if side == "LEFT":
            left.append(obj)
        elif side == "RIGHT":
            right.append(obj)
        else:
            center.append(obj)
    return left, right, center


def normalize_light_id_name(value):
    txt = str(value or "").strip().lower().replace("-", "_").replace(" ", "_")
    txt = re.sub(r"[^a-z0-9_]+", "", txt)
    return txt


def light_id_name_from_raw(value):
    if value is None:
        return ""
    txt = normalize_light_id_name(value)
    if txt in SOLLUMZ_LIGHT_ID_NAME_TO_VALUE:
        return txt
    try:
        iv = int(float(value))
    except Exception:
        return ""
    return SOLLUMZ_LIGHT_ID_VALUE_TO_NAME.get(iv, "")


def current_light_id_name(s):
    if not s:
        return "always_on"
    key = str(getattr(s, "car_light_id_target", "always_on") or "always_on")
    if key == "CUSTOM":
        custom_key = light_id_name_from_raw(getattr(s, "car_light_id_custom_value", 0))
        return custom_key or ""
    key = normalize_light_id_name(key)
    return key if key in SOLLUMZ_LIGHT_ID_NAME_TO_VALUE else "always_on"


def current_light_id_value(s):
    if not s:
        return 0
    key = str(getattr(s, "car_light_id_target", "always_on") or "always_on")
    if key == "CUSTOM":
        try:
            return max(0, int(getattr(s, "car_light_id_custom_value", 0) or 0))
        except Exception:
            return 0
    return int(SOLLUMZ_LIGHT_ID_NAME_TO_VALUE.get(normalize_light_id_name(key), 0))


def light_id_ui_label_from_raw(value):
    key = light_id_name_from_raw(value)
    if key:
        return next((item[1] for item in SOLLUMZ_LIGHT_ID_UI_ITEMS if item[0] == key), key)
    try:
        return f"Custom ({int(float(value))})"
    except Exception:
        return "Unknown"


def light_id_value_from_alpha(alpha):
    try:
        raw = int(round(max(0.0, min(1.0, float(alpha))) * 255.0))
    except Exception:
        return -1
    return raw if raw in SOLLUMZ_LIGHT_ID_VALUE_TO_NAME else -1


def editable_light_id_color_layer(bm, create=False):
    if not bm:
        return None
    loops = getattr(bm, "loops", None)
    layers = getattr(loops, "layers", None) if loops else None
    colors = getattr(layers, "color", None) if layers else None
    if colors is None:
        return None

    try:
        keys = list(colors.keys())
    except Exception:
        keys = []
    for key in keys:
        try:
            layer = colors.get(key)
        except Exception:
            layer = None
        if layer is not None:
            return layer

    try:
        return colors[0]
    except Exception:
        pass

    if not create:
        return None
    try:
        return colors.new("Color")
    except Exception:
        return None


def face_light_id_values(face, color_layer):
    values = []
    if not face or color_layer is None:
        return values
    for loop in getattr(face, "loops", []) or []:
        try:
            value = light_id_value_from_alpha(loop[color_layer][3])
        except Exception:
            value = -1
        if value >= 0:
            values.append(value)
    return values


def face_light_id_value(face, color_layer):
    values = face_light_id_values(face, color_layer)
    if not values:
        return None
    counts = {}
    for value in values:
        counts[value] = counts.get(value, 0) + 1
    return max(counts.items(), key=lambda item: (item[1], -item[0]))[0]


def selected_face_light_id_label(context):
    if not light_id_face_select_ready(context):
        return ""
    obj = getattr(context, "active_object", None)
    if not obj or getattr(obj, "type", "") != "MESH":
        return ""
    try:
        bm = bmesh.from_edit_mesh(obj.data)
        bm.faces.ensure_lookup_table()
        selected_faces = [face for face in bm.faces if face.select]
        if not selected_faces:
            return "No faces selected"
        color_layer = editable_light_id_color_layer(bm, create=False)
        if color_layer is None:
            return "No Face Corner > Byte Color layer"
        values = set()
        for face in selected_faces:
            face_values = set(face_light_id_values(face, color_layer))
            if len(face_values) > 1:
                return "Mixed Light IDs"
            values.add(next(iter(face_values)) if face_values else None)
        if values == {None}:
            return "No Light ID assigned"
        if len(values) > 1:
            return "Mixed Light IDs"
        value = next(iter(values))
        if value is None:
            return "No Light ID assigned"
        return light_id_ui_label_from_raw(value)
    except Exception:
        return ""


def light_id_face_select_ready(context):
    obj = getattr(context, "active_object", None)
    if not obj or getattr(obj, "type", "") != "MESH":
        return False
    if getattr(context, "mode", "") != "EDIT_MESH":
        return False
    try:
        mode = getattr(context.tool_settings, "mesh_select_mode", (False, False, False))
        return bool(mode[2])
    except Exception:
        return False


def editable_light_id_face_layer(bm, create=False):
    if not bm:
        return None
    layers = getattr(getattr(bm, "faces", None), "layers", None)
    ints = getattr(layers, "int", None) if layers else None
    if ints is None:
        return None

    for name in ("light_id", "lightid", "vehicle_light_id", "vehiclelightid", "external_light_id", "externallightid"):
        try:
            layer = ints.get(name)
        except Exception:
            layer = None
        if layer is not None:
            return layer

    try:
        for name in ints.keys():
            if normalize_light_id_name(name) in SOLLUMZ_LIGHT_ID_ATTR_NAMES:
                layer = ints.get(name)
                if layer is not None:
                    return layer
    except Exception:
        pass

    if not create:
        return None
    try:
        return ints.new("light_id")
    except Exception:
        return None

def remove_object_and_mesh_data(obj):
    if not obj:
        return
    mesh = getattr(obj, "data", None)
    try:
        bpy.data.objects.remove(obj, do_unlink=True)
    except Exception:
        return
    try:
        if mesh and getattr(mesh, "users", 0) <= 0:
            bpy.data.meshes.remove(mesh)
    except Exception:
        pass


def light_id_preview_material(light_key):
    key = normalize_light_id_name(light_key)
    mat_name = f"_gta000_lightid_mat_{key}"
    mat = bpy.data.materials.get(mat_name)
    if mat is None:
        mat = bpy.data.materials.new(mat_name)
    rgb = SOLLUMZ_LIGHT_ID_COLOR.get(key, (1.0, 1.0, 1.0))
    mat.use_nodes = True
    nodes = mat.node_tree.nodes
    links = mat.node_tree.links
    nodes.clear()
    out = nodes.new("ShaderNodeOutputMaterial")
    emit = nodes.new("ShaderNodeEmission")
    emit.inputs[0].default_value = (rgb[0], rgb[1], rgb[2], 1.0)
    emit.inputs[1].default_value = 6.0
    out.location = (220.0, 0.0)
    emit.location = (0.0, 0.0)
    links.new(emit.outputs[0], out.inputs[0])
    if hasattr(mat, "shadow_method"):
        try:
            mat.shadow_method = "NONE"
        except Exception:
            pass
    return mat


def _mesh_light_id_attr_values(mesh, attr):
    data = getattr(attr, "data", None)
    domain = str(getattr(attr, "domain", "") or "").upper()
    if not data:
        return []
    if domain == "FACE":
        return [light_id_name_from_raw(getattr(item, "value", None)) for item in data[:len(mesh.polygons)]]
    if domain == "CORNER":
        values = []
        data_len = len(data)
        for poly in mesh.polygons:
            names = []
            start = int(getattr(poly, "loop_start", 0) or 0)
            total = int(getattr(poly, "loop_total", 0) or 0)
            for li in range(start, min(start + total, data_len)):
                key = light_id_name_from_raw(getattr(data[li], "value", None))
                if key:
                    names.append(key)
            if not names:
                values.append("")
            else:
                counts = {}
                for key in names:
                    counts[key] = counts.get(key, 0) + 1
                values.append(max(counts.items(), key=lambda item: item[1])[0])
        return values
    return []


def mesh_light_id_face_groups(obj):
    mesh = getattr(obj, "data", None)
    if not obj or getattr(obj, "type", "") != "MESH" or mesh is None:
        return {}

    bm = bmesh.new()
    try:
        bm.from_mesh(mesh)
        bm.faces.ensure_lookup_table()
        color_layer = editable_light_id_color_layer(bm, create=False)
        if color_layer is None:
            return {}
        groups = {}
        for face in bm.faces:
            value = face_light_id_value(face, color_layer)
            if value is None:
                continue
            light_key = light_id_name_from_raw(value)
            if not light_key:
                continue
            groups.setdefault(light_key, []).append(face.index)
        return groups
    finally:
        try:
            bm.free()
        except Exception:
            pass


def light_id_preview_object_name(src_obj, light_key):
    return f"{LIGHT_ID_PREVIEW_PREFIX}{safe_name(src_obj.name)}_{normalize_light_id_name(light_key)}"


def clear_light_id_preview_objects(scene):
    if not scene:
        return 0
    removed = 0
    for obj in list(scene.objects):
        if str(getattr(obj, "name", "")).startswith(LIGHT_ID_PREVIEW_PREFIX):
            remove_object_and_mesh_data(obj)
            removed += 1
    return removed


def light_id_preview_signature(scene):
    if not scene:
        return ""
    parts = []
    for obj in scene.objects:
        if getattr(obj, "type", "") != "MESH":
            continue
        nm = str(getattr(obj, "name", ""))
        if nm.startswith(LIGHT_ID_PREVIEW_PREFIX) or nm.startswith(WHEEL_PREVIEW_PREFIX):
            continue
        mesh = getattr(obj, "data", None)
        if mesh is None:
            continue
        attrs = []
        for attr in getattr(mesh, "attributes", []) or []:
            domain = str(getattr(attr, "domain", "") or "").upper()
            if domain in {"FACE", "CORNER"}:
                attrs.append(f"{attr.name}:{domain}")
        if hasattr(mesh, "polygon_layers_int"):
            try:
                for layer in mesh.polygon_layers_int:
                    attrs.append(f"{layer.name}:FACE")
            except Exception:
                pass
        if not attrs:
            continue
        parts.append(f"{obj.name}|{mesh.name}|{len(mesh.polygons)}|{','.join(sorted(set(attrs)))}")
    parts.sort()
    return "\n".join(parts)


def build_light_id_preview_object(scene, src_obj, light_key, poly_indices):
    if not scene or not src_obj or not poly_indices:
        return None

    name = light_id_preview_object_name(src_obj, light_key)
    existing = bpy.data.objects.get(name)
    if existing and getattr(existing, "type", "") == "MESH":
        existing["_gta000_lightid_key"] = normalize_light_id_name(light_key)
        existing["_gta000_lightid_source"] = src_obj.name
        existing.parent = src_obj
        existing.matrix_parent_inverse = src_obj.matrix_world.inverted()
        existing.hide_select = True
        return existing

    bm = bmesh.new()
    bm.from_mesh(src_obj.data)
    bm.faces.ensure_lookup_table()
    keep = set(int(i) for i in poly_indices)
    delete_faces = [face for idx, face in enumerate(bm.faces) if idx not in keep]
    if delete_faces:
        bmesh.ops.delete(bm, geom=delete_faces, context="FACES")
    if not bm.faces:
        bm.free()
        return None

    for vert in bm.verts:
        if not vert.link_faces:
            continue
        normal = Vector((0.0, 0.0, 0.0))
        for face in vert.link_faces:
            normal += face.normal
        if normal.length > 0.0:
            normal.normalize()
            vert.co += normal * 0.0003

    mesh = bpy.data.meshes.new(name)
    bm.to_mesh(mesh)
    bm.free()
    mesh.materials.clear()
    mesh.materials.append(light_id_preview_material(light_key))
    for poly in mesh.polygons:
        poly.material_index = 0

    preview = bpy.data.objects.new(name, mesh)
    preview["_gta000_lightid_key"] = normalize_light_id_name(light_key)
    preview["_gta000_lightid_source"] = src_obj.name
    preview.hide_select = True
    preview.parent = src_obj
    preview.matrix_parent_inverse = src_obj.matrix_world.inverted()
    preview.show_in_front = True

    linked = False
    for col in getattr(src_obj, "users_collection", []) or []:
        try:
            col.objects.link(preview)
            linked = True
        except Exception:
            pass
    if (not linked) and getattr(scene, "collection", None):
        scene.collection.objects.link(preview)
    return preview


def rebuild_light_id_preview_objects(scene, s):
    if not scene or not s:
        return 0
    clear_light_id_preview_objects(scene)
    created = 0
    for obj in scene.objects:
        if getattr(obj, "type", "") != "MESH":
            continue
        nm = str(getattr(obj, "name", ""))
        if nm.startswith(LIGHT_ID_PREVIEW_PREFIX) or nm.startswith(WHEEL_PREVIEW_PREFIX):
            continue
        groups = mesh_light_id_face_groups(obj)
        if not groups:
            continue
        for light_key, poly_indices in groups.items():
            if build_light_id_preview_object(scene, obj, light_key, poly_indices):
                created += 1
    s.car_light_id_signature = light_id_preview_signature(scene)
    return created


def apply_light_id_preview(scene, s, states):
    if not scene or not s:
        return 0

    now_ts = _time.time()
    last_checked = float(getattr(s, "car_light_id_checked_at", 0.0) or 0.0)
    has_preview = any(str(getattr(obj, "name", "")).startswith(LIGHT_ID_PREVIEW_PREFIX) for obj in scene.objects)
    if (not has_preview) or (now_ts - last_checked >= 1.0):
        signature = light_id_preview_signature(scene)
        s.car_light_id_checked_at = now_ts
        if signature != str(getattr(s, "car_light_id_signature", "") or ""):
            rebuild_light_id_preview_objects(scene, s)

    touched = 0
    for obj in scene.objects:
        if not str(getattr(obj, "name", "")).startswith(LIGHT_ID_PREVIEW_PREFIX):
            continue
        key = normalize_light_id_name(obj.get("_gta000_lightid_key", ""))
        show = bool(states.get(key, False))
        if is_object_visible(obj) != show:
            set_object_visible(obj, show)
            touched += 1
    return touched

def wheel_bone_key(name):
    nm = str(name or "").lower()
    m = re.search(r"wheel[_\-]?(lf|rf|lr|rr)", nm)
    if not m:
        return ""
    return f"wheel_{m.group(1)}"


def wheel_pose_bones(scene):
    s = getattr(scene, "nels", None) if scene else None
    if not s or not s.armature_name:
        return (None, [])
    arm = bpy.data.objects.get(s.armature_name)
    if not arm or arm.type != "ARMATURE":
        return (None, [])

    all_wheel = [pb for pb in arm.pose.bones if "wheel" in pb.name.lower()]
    keyed = {}
    for pb in all_wheel:
        key = wheel_bone_key(pb.name)
        if key and key not in keyed:
            keyed[key] = pb

    if keyed:
        ordered = [keyed[k] for k in ("wheel_lf", "wheel_rf", "wheel_lr", "wheel_rr") if k in keyed]
        if ordered:
            return (arm, ordered)
    return (arm, all_wheel)


def has_real_wheel_for_bone(scene, arm, bone_name):
    for obj in scene.objects:
        if obj.type != "MESH" or obj.name.startswith(WHEEL_PREVIEW_PREFIX):
            continue
        nm = obj.name.lower()
        if "wheel" not in nm or "steer" in nm:
            continue
        if obj.parent == arm and obj.parent_type == "BONE" and obj.parent_bone == bone_name:
            return True
    return False
def clear_wheel_preview_objects(scene):
    if not scene:
        return 0
    removed = 0
    for obj in list(scene.objects):
        if obj.name.startswith(WHEEL_PREVIEW_PREFIX):
            try:
                bpy.data.objects.remove(obj, do_unlink=True)
                removed += 1
            except Exception:
                pass
    return removed


def scene_wheel_mesh_objects(scene, arm=None, bones=None):
    if not scene:
        return []

    if arm is None or bones is None:
        try:
            arm, bones = wheel_pose_bones(scene)
        except Exception:
            arm, bones = None, []

    bones = list(bones or [])
    bone_names = {pb.name for pb in bones}
    preferred = ("wheel_lf", "wheel_rf", "wheel_lr", "wheel_rr")

    candidates = []
    for obj in scene.objects:
        if getattr(obj, "type", "") != "MESH" or str(getattr(obj, "name", "") or "").startswith(WHEEL_PREVIEW_PREFIX):
            continue
        obj_name = str(getattr(obj, "name", "") or "")
        name_lower = obj_name.lower()
        if "steer" in name_lower:
            continue
        if bone_names and obj.parent == arm and getattr(obj, "parent_type", "") == "BONE" and getattr(obj, "parent_bone", "") in bone_names:
            parent_key = str(getattr(obj, "parent_bone", "") or "").lower()
            prio = preferred.index(parent_key) if parent_key in preferred else 99
            candidates.append((0, prio, name_lower, obj))

    if candidates:
        candidates.sort(key=lambda item: (item[0], item[1], item[2]))
        return [item[3] for item in candidates]

    bone_world_positions = []
    if arm and bones:
        for pb in bones:
            try:
                bone_world_positions.append(arm.matrix_world @ pb.head)
            except Exception:
                pass

    loose = []
    for obj in scene.objects:
        if getattr(obj, "type", "") != "MESH" or str(getattr(obj, "name", "") or "").startswith(WHEEL_PREVIEW_PREFIX):
            continue
        obj_name = str(getattr(obj, "name", "") or "")
        name_lower = obj_name.lower()
        if "steer" in name_lower or "wheel" not in name_lower:
            continue
        if bone_world_positions:
            pos = obj.matrix_world.translation
            dist = min((pos - bp).length for bp in bone_world_positions)
            loose.append((dist, name_lower, obj))
        else:
            loose.append((999999.0, name_lower, obj))

    loose.sort(key=lambda item: (item[0], item[1]))
    return [item[2] for item in loose]


def find_source_wheel_object(context, arm, bones):
    scene = getattr(context, "scene", None) if context else None
    if not scene:
        return None

    wheels = scene_wheel_mesh_objects(scene, arm, bones)
    if not wheels:
        return None

    active = getattr(context, "active_object", None)
    if active in wheels:
        return active
    return wheels[0]


def _copy_obj_rotation(dst, src):
    dst.rotation_mode = src.rotation_mode
    if src.rotation_mode == "QUATERNION":
        dst.rotation_quaternion = src.rotation_quaternion.copy()
    elif src.rotation_mode == "AXIS_ANGLE":
        dst.rotation_axis_angle = tuple(src.rotation_axis_angle)
    else:
        dst.rotation_euler = src.rotation_euler.copy()


def simulate_tyres_on_wheel_bones(context, arm, bones):
    scene = getattr(context, "scene", None) if context else None
    try:
        vl = getattr(context, "view_layer", None) if context else getattr(bpy.context, "view_layer", None)
        if vl:
            vl.update()
    except Exception:
        pass

    if not scene:
        return (0, 0, "Scene not available")

    src = find_source_wheel_object(context, arm, bones)
    if not src:
        return (0, 0, "Warning: Could not find a source wheel mesh (select/use a real wheel mesh, not steering wheel)")

    # Determine source wheel bone robustly (explicit parent > name key > nearest).
    bone_head_world = {}
    for pb in bones:
        bd = arm.data.bones.get(pb.name)
        if bd:
            bone_head_world[pb.name] = arm.matrix_world @ bd.head_local
        else:
            bone_head_world[pb.name] = arm.matrix_world @ pb.head

    source_bone_name = ""
    if src.parent == arm and src.parent_type == "BONE" and src.parent_bone in bone_head_world:
        source_bone_name = src.parent_bone

    if not source_bone_name:
        src_key = wheel_bone_key(src.name)
        if src_key:
            for pb in bones:
                if wheel_bone_key(pb.name) == src_key:
                    source_bone_name = pb.name
                    break

    if not source_bone_name:
        src_pos = src.matrix_world.translation
        ref_bone = min(bones, key=lambda pb: (src_pos - bone_head_world[pb.name]).length)
        source_bone_name = ref_bone.name

    src_world = src.matrix_world.copy()
    src_head = bone_head_world[source_bone_name]
    source_pose_bone = arm.pose.bones.get(source_bone_name)
    source_bone_world = (arm.matrix_world @ source_pose_bone.matrix.copy()) if source_pose_bone else Matrix.Translation(src_head)
    source_local = source_bone_world.inverted() @ src_world

    linked = 0
    skipped = 0
    cleaned = 0
    for pb in bones:
        nm = f"{WHEEL_PREVIEW_PREFIX}{pb.name}"
        is_source_bone = pb.name == source_bone_name
        has_real = has_real_wheel_for_bone(scene, arm, pb.name)
        if is_source_bone or has_real:
            stale = bpy.data.objects.get(nm)
            if stale:
                try:
                    bpy.data.objects.remove(stale, do_unlink=True)
                    cleaned += 1
                except Exception:
                    pass
            skipped += 1
            continue

        dup = bpy.data.objects.get(nm)
        if not dup:
            dup = src.copy()
            dup.data = src.data
            dup.name = nm
            linked_to_any = False
            if src.users_collection:
                for col in src.users_collection:
                    try:
                        col.objects.link(dup)
                        linked_to_any = True
                    except Exception:
                        pass
            if (not linked_to_any) and scene.collection:
                scene.collection.objects.link(dup)

        dup.parent = None
        dup.parent_type = "OBJECT"
        dup.parent_bone = ""
        target_pose_world = arm.matrix_world @ pb.matrix.copy()
        target_world = target_pose_world @ source_local
        dup.matrix_world = target_world
        _copy_obj_rotation(dup, src)
        dup.scale = src.scale.copy()
        set_object_visible(dup, True)
        linked += 1

    msg = f"Tyre simulation updated using '{src.name}': {linked} wheel previews linked, {cleaned} stale removed"
    return linked, skipped, msg


def normalize_import_scale_factor(value):
    try:
        sc = float(value)
    except Exception:
        sc = 0.5
    if sc > 1.0:
        sc = 1.0 / sc
    return max(0.0, sc)


def apply_scale_to_settings(s, factor):
    if not s:
        return
    s.scale_factor = normalize_import_scale_factor(factor)
    sync_scale_factor_controls(s)


def apply_scale_to_siren(si, factor):
    # Legacy compatibility for older saved configs; runtime scale now uses scene-level scale_factor.
    sc = normalize_import_scale_factor(factor)
    if abs(sc - 0.5) < 0.000001:
        si.scale_mode = "PRESET"
        si.scale_preset = "SCALE_50"
    elif abs(sc - 0.1) < 0.000001:
        si.scale_mode = "PRESET"
        si.scale_preset = "SCALE_10"
    elif abs(sc - 0.01) < 0.000001:
        si.scale_mode = "PRESET"
        si.scale_preset = "SCALE_01"
    else:
        si.scale_mode = "CUSTOM"
        si.custom_scale = sc






