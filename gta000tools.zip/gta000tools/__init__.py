bl_info = {
    "name": "GTA 000 Tools",
    "author": "Codex",
    "version": (0, 2, 66),
    "blender": (3, 6, 0),
    "location": "View3D > Sidebar > Tool and GTA 000",
    "description": "Build non-ELS lightbar configs, manage grouped assets, and export vehicle resources and carcols.meta",
    "category": "Object",
}
from pathlib import Path

_MODULE_FILES = (
    "shared/base.py",
    "core/scene_logic.py",
    "core/properties_and_defaults.py",
    "operators/main.py",
    "ui/main.py",
)


def _load_addon_modules():
    addon_root = Path(__file__).resolve().parent
    namespace = globals()
    for rel_path in _MODULE_FILES:
        module_path = addon_root / rel_path
        code = compile(module_path.read_text(encoding="utf-8"), str(module_path), "exec")
        exec(code, namespace, namespace)


_load_addon_modules()

from .asset_library.bridge import (
    draw_asset_library_assets,
    draw_asset_library_categories,
    draw_asset_library_details,
    draw_asset_library_information,
    draw_asset_library_paths,
    draw_asset_library_subcategories,
    draw_asset_library_tags,
    register_asset_library_integration,
    unregister_asset_library_integration,
)

del _load_addon_modules
del _MODULE_FILES
del Path
