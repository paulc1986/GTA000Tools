
bl_info = {
    "name": "GTA 000 Tools",
    "author": "Codex",
    "version": (0, 1, 85),
    "blender": (3, 6, 0),
    "location": "View3D > Sidebar > Tool and GTA 000",
    "description": "Build non-ELS lightbar configs and export carcols.meta",
    "category": "Object",
}

import io
import json
import math
import os
import re
import shutil
import tempfile
import threading
import time as _time
import urllib.error
import urllib.request
import xml.dom.minidom
import xml.etree.ElementTree as ET
import zipfile

import bpy
import bpy.utils.previews
from bpy.app.handlers import persistent
from mathutils import Matrix, Vector
from bpy.props import (
    BoolProperty,
    CollectionProperty,
    EnumProperty,
    FloatProperty,
    FloatVectorProperty,
    IntProperty,
    PointerProperty,
    StringProperty,
)
from bpy.types import Menu, Operator, Panel, PropertyGroup, UIList

MAX_SIRENS = 32
NO_SAVED_CFG = "__NONE__"
UNSAVED_PATTERN_KEY = "__UNSAVED__"
UPDATE_REPO_URL = "https://github.com/paulc1986/GTA000Tools"
UPDATE_ZIP_URL = "https://raw.githubusercontent.com/paulc1986/GTA000Tools/main/gta000tools.zip"
UPDATE_REQUEST_TIMEOUT = 20

_UPDATE_LOCK = threading.Lock()
_UPDATE_THREAD = None
_UPDATE_RESULT = None
_UPDATE_STARTUP_SCHEDULED = False

PANEL_ICON_FILES = {
    "lightbar": "lightbar",
    "patterns": "patterns",
    "colors": "colours",
    "car_functions": "car_functions",
    "simulation": "simulation",
    "useful_tools": "useful_tools",
    "updates": "updates",
}

PANEL_ICON_EXTENSIONS = (".png", ".gif")

PANEL_FALLBACK_ICONS = {
    "lightbar": "LIGHT",
    "patterns": "FILE_TEXT",
    "colors": "MATERIAL",
    "car_functions": "SCENE_DATA",
    "simulation": "ANIM",
    "useful_tools": "TOOL_SETTINGS",
    "updates": "IMPORT",
}

_PREVIEW_COLLECTIONS = {}


def addon_version_tuple():
    try:
        return tuple(int(v) for v in bl_info.get("version", (0, 0, 0)))
    except Exception:
        return (0, 0, 0)


def version_to_str(version):
    try:
        return ".".join(str(int(v)) for v in tuple(version))
    except Exception:
        return "0.0.0"


def compare_versions(a, b):
    av = tuple(int(v) for v in tuple(a))
    bv = tuple(int(v) for v in tuple(b))
    if av == bv:
        return 0
    return 1 if av > bv else -1


def update_timestamp_string(ts=None):
    if ts is None:
        ts = _time.time()
    try:
        return _time.strftime("%Y-%m-%d %H:%M:%S", _time.localtime(float(ts)))
    except Exception:
        return ""


def parse_version_tuple_from_init_text(text):
    if not text:
        return None
    m = re.search(r'"version"\s*:\s*\(\s*(\d+)\s*,\s*(\d+)\s*,\s*(\d+)\s*\)', str(text))
    if not m:
        return None
    return tuple(int(m.group(i)) for i in range(1, 4))


def parse_version_tuple_from_string(text):
    if not text:
        return None
    m = re.search(r'(\d+)\.(\d+)\.(\d+)', str(text))
    if not m:
        return None
    return tuple(int(m.group(i)) for i in range(1, 4))


def normalize_update_state(s):
    if not s:
        return

    current = addon_version_tuple()
    current_str = version_to_str(current)
    remote = parse_version_tuple_from_string(getattr(s, "update_remote_version", ""))
    status = str(getattr(s, "update_status", "") or "")

    if remote and compare_versions(current, remote) >= 0:
        s.update_available = False
        if getattr(s, "update_restart_required", False):
            s.update_restart_required = False
            s.update_check_in_progress = False
            s.update_install_in_progress = False
            if status.startswith("Update installed:") or status.startswith("Update available:"):
                s.update_status = f"GTA 000 Tools is up to date ({current_str})"
        elif status.startswith("Update available:"):
            s.update_status = f"GTA 000 Tools is up to date ({current_str})"


def update_request_headers():
    return {"User-Agent": f"GTA000Tools/{version_to_str(addon_version_tuple())}"}


def download_update_zip_bytes():
    req = urllib.request.Request(UPDATE_ZIP_URL, headers=update_request_headers())
    with urllib.request.urlopen(req, timeout=UPDATE_REQUEST_TIMEOUT) as resp:
        return resp.read()


def inspect_update_zip_bytes(data):
    if not data:
        raise RuntimeError("Downloaded update file was empty")
    with zipfile.ZipFile(io.BytesIO(data)) as zf:
        names = [name for name in zf.namelist() if name.lower().endswith("/__init__.py") or name == "__init__.py"]
        names.sort(key=lambda name: ("gta000tools/__init__.py" not in name.lower(), len(name)))
        for name in names:
            try:
                text = zf.read(name).decode("utf-8", errors="ignore")
            except Exception:
                continue
            version = parse_version_tuple_from_init_text(text)
            if version:
                root = name.rsplit("/", 1)[0] if "/" in name else ""
                return version, root
    raise RuntimeError("Could not locate GTA 000 Tools package inside the downloaded zip")


def addon_install_target_dir():
    return os.path.dirname(os.path.abspath(__file__))


def iter_relative_files(root_dir):
    rels = {}
    for current_root, dirs, files in os.walk(root_dir):
        dirs[:] = [d for d in dirs if d != "__pycache__"]
        for name in files:
            if name.endswith((".pyc", ".pyo")):
                continue
            full = os.path.join(current_root, name)
            rel = os.path.relpath(full, root_dir)
            rels[rel] = full
    return rels


def prune_empty_dirs(root_dir):
    for current_root, dirs, files in os.walk(root_dir, topdown=False):
        dirs[:] = [d for d in dirs if d != "__pycache__"]
        if current_root == root_dir:
            continue
        try:
            if not os.listdir(current_root):
                os.rmdir(current_root)
        except Exception:
            pass


def sync_addon_directory(source_dir, target_dir):
    if not os.path.isdir(source_dir):
        raise RuntimeError("Update package did not contain a valid addon directory")
    os.makedirs(target_dir, exist_ok=True)
    source_files = iter_relative_files(source_dir)
    target_files = iter_relative_files(target_dir)

    stale_files = sorted(set(target_files) - set(source_files), reverse=True)
    for rel in stale_files:
        try:
            os.remove(os.path.join(target_dir, rel))
        except FileNotFoundError:
            pass

    for rel, src in source_files.items():
        dst = os.path.join(target_dir, rel)
        os.makedirs(os.path.dirname(dst), exist_ok=True)
        shutil.copy2(src, dst)

    prune_empty_dirs(target_dir)


def install_update_from_zip_bytes(data, target_dir=None):
    target_dir = target_dir or addon_install_target_dir()
    version, root = inspect_update_zip_bytes(data)
    temp_parent = os.path.dirname(os.path.abspath(target_dir)) or os.path.abspath(target_dir)
    stage_name = f"gta000tools_update_{int(_time.time() * 1000)}"
    temp_dir = os.path.join(temp_parent, stage_name)
    os.makedirs(temp_dir, exist_ok=True)
    try:
        with zipfile.ZipFile(io.BytesIO(data)) as zf:
            zf.extractall(temp_dir)
        source_dir = os.path.join(temp_dir, root) if root else temp_dir
        if not os.path.isfile(os.path.join(source_dir, "__init__.py")):
            for current_root, dirs, files in os.walk(temp_dir):
                if "__init__.py" in files:
                    source_dir = current_root
                    break
        sync_addon_directory(source_dir, target_dir)
    finally:
        shutil.rmtree(temp_dir, ignore_errors=True)
    return version


def set_update_ui_state(message="", available=None, remote_version=None, checking=None, installing=None, restart_required=None, checked_at=None, set_status=False):
    scenes = getattr(bpy.data, "scenes", None) or []
    for scene in scenes:
        s = getattr(scene, "nels", None)
        if not s:
            continue
        if message is not None:
            s.update_status = str(message or "")
            if set_status:
                s.status_message = str(message or "")
        if available is not None:
            s.update_available = bool(available)
        if remote_version is not None:
            s.update_remote_version = str(remote_version or "")
        if checking is not None:
            s.update_check_in_progress = bool(checking)
        if installing is not None:
            s.update_install_in_progress = bool(installing)
        if restart_required is not None:
            s.update_restart_required = bool(restart_required)
        if checked_at is not None:
            s.update_last_checked = str(checked_at or "")


def start_update_job(kind):
    global _UPDATE_THREAD, _UPDATE_RESULT
    with _UPDATE_LOCK:
        if _UPDATE_THREAD and _UPDATE_THREAD.is_alive():
            return False
        _UPDATE_RESULT = None

        def worker():
            global _UPDATE_THREAD, _UPDATE_RESULT
            result = {"kind": kind, "ok": False}
            try:
                data = download_update_zip_bytes()
                remote_version, _root = inspect_update_zip_bytes(data)
                result["remote_version"] = remote_version
                if kind == "INSTALL":
                    installed_version = install_update_from_zip_bytes(data)
                    result["installed_version"] = installed_version
                result["ok"] = True
            except Exception as ex:
                result["error"] = str(ex)
            with _UPDATE_LOCK:
                _UPDATE_RESULT = result
                _UPDATE_THREAD = None

        _UPDATE_THREAD = threading.Thread(target=worker, name=f"gta000tools_update_{kind.lower()}", daemon=True)
        _UPDATE_THREAD.start()
    return True


def apply_update_job_result():
    global _UPDATE_RESULT
    with _UPDATE_LOCK:
        result = _UPDATE_RESULT
        _UPDATE_RESULT = None
    if not result:
        return False

    checked_at = update_timestamp_string()
    current_version = addon_version_tuple()
    kind = str(result.get("kind", "CHECK") or "CHECK")
    remote_version = tuple(result.get("remote_version") or ())
    remote_version_str = version_to_str(remote_version) if remote_version else ""

    if not result.get("ok"):
        message = f"Update {kind.lower()} failed: {result.get('error', 'Unknown error')}"
        set_update_ui_state(message=message, checking=False, installing=False, checked_at=checked_at, set_status=True)
        tag_preview_ui_redraw()
        return True

    if kind == "INSTALL":
        installed_version = tuple(result.get("installed_version") or remote_version or current_version)
        message = f"Update installed: {version_to_str(installed_version)}. Restart Blender to load the new version."
        set_update_ui_state(message=message, available=False, remote_version=version_to_str(installed_version), checking=False, installing=False, restart_required=True, checked_at=checked_at, set_status=True)
        tag_preview_ui_redraw()
        return True

    available = bool(remote_version and compare_versions(remote_version, current_version) > 0)
    if available:
        message = f"Update available: {version_to_str(current_version)} -> {remote_version_str}"
        set_update_ui_state(message=message, available=True, remote_version=remote_version_str, checking=False, installing=False, restart_required=False, checked_at=checked_at, set_status=True)
    else:
        message = f"GTA 000 Tools is up to date ({version_to_str(current_version)})"
        set_update_ui_state(message=message, available=False, remote_version=remote_version_str or version_to_str(current_version), checking=False, installing=False, restart_required=False, checked_at=checked_at, set_status=False)
    tag_preview_ui_redraw()
    return True


def begin_update_operation(kind, automatic=False):
    message = "Checking GitHub for updates..." if kind == "CHECK" else "Installing update from GitHub..."
    started = start_update_job(kind)
    if not started:
        if not automatic:
            set_update_ui_state(message="An update task is already running", set_status=True)
            tag_preview_ui_redraw()
        return False

    set_update_ui_state(
        message=message,
        checking=(kind == "CHECK"),
        installing=(kind == "INSTALL"),
        restart_required=False if kind == "INSTALL" else None,
        set_status=(not automatic),
    )
    tag_preview_ui_redraw()
    return True


def schedule_startup_update_check(scene=None):
    global _UPDATE_STARTUP_SCHEDULED
    if _UPDATE_STARTUP_SCHEDULED:
        return
    s = getattr(scene, "nels", None) if scene else None
    if s and not bool(getattr(s, "update_check_on_startup", True)):
        return
    _UPDATE_STARTUP_SCHEDULED = True

    def deferred():
        try:
            begin_update_operation("CHECK", automatic=True)
        except Exception:
            pass
        return None

    try:
        bpy.app.timers.register(deferred, first_interval=2.0)
    except Exception:
        _UPDATE_STARTUP_SCHEDULED = False


VISIBILITY_ITEMS = [
    ("BOTH", "Rotator + Flasher", ""),
    ("ROTATOR", "Rotator", ""),
    ("FLASHER", "Flasher", ""),
]

SIREN_TYPES = [("FLASHER", "Flasher", ""), ("ROTATOR", "Rotator", "")]

ROT_SPEED = {
    "P50": 8.0,
    "P25": 4.0,
    "P12_5": 2.0,
    "P6_25": 1.0,
    "P3_125": 0.5,
}

ROT_SPEED_ITEMS = [
    ("P50", "Rotate at 50% BPM", "BPM/100*8"),
    ("P25", "Rotate at 25% BPM", "BPM/100*4"),
    ("P12_5", "Rotate at 12.5% BPM", "BPM/100*2"),
    ("P6_25", "Rotate at 6.25% BPM", "BPM/100"),
    ("P3_125", "Rotate at 3.125% BPM", "BPM/100*0.5"),
    ("CUSTOM", "Enter custom % of BPM", ""),
]

DIRECTIONS = {
    "FRONT": 0.0,
    "DRIVER": -1.57079633,
    "PASSENGER": 1.57079633,
    "BACK": 3.14159265,
    "BACK_LEFT": 2.35619449,
    "BACK_RIGHT": -2.35619449,
    "FRONT_LEFT": 0.78539816,
    "FRONT_RIGHT": -0.78539816,
}

DIRECTION_ITEMS = [
    ("FRONT", "Front", "0.00000000"),
    ("DRIVER", "Driver Side", "-1.57079633"),
    ("PASSENGER", "Passenger Side", "1.57079633"),
    ("BACK", "Back", "3.14159265"),
    ("BACK_LEFT", "Back Left", "2.35619449"),
    ("BACK_RIGHT", "Back Right", "-2.35619449"),
    ("FRONT_LEFT", "Front Left", "0.78539816"),
    ("FRONT_RIGHT", "Front Right", "-0.78539816"),
]

SCALES = {"SCALE_50": 0.5, "SCALE_10": 0.1, "SCALE_01": 0.01}
SCALE_ITEMS = [
    ("SCALE_50", "Scale to 50% (0.5)", ""),
    ("SCALE_10", "Scale to 10% (0.1)", ""),
    ("SCALE_01", "Scale to 1% (0.01)", ""),
]
SCALE_FACTOR_PRESET_ITEMS = [
    ("SF_2", "Scale Factor 2 (0.5)", "Stored value: 0.5"),
    ("SF_10", "Scale Factor 10 (0.1)", "Stored value: 0.1"),
    ("SF_100", "Scale Factor 100 (0.01)", "Stored value: 0.01"),
    ("CUSTOM", "Custom", "Use a custom stored value"),
]
SCALE_FACTOR_PRESET_VALUES = {"SF_2": 0.5, "SF_10": 0.1, "SF_100": 0.01}

COLORS = {
    "LED_AMBER": "0xFFFF4800",
    "LED_BLUE": "0xFF000AFF",
    "LED_RED": "0xFFFF0300",
    "HALOGEN_BLUE": "0xFF2130FF",
    "HALOGEN_RED": "0xFFFF1405",
    "GENERAL_AMBER": "0xFFFF6400",
    "GENERAL_AMBER_BRIGHT": "0xFFFFFF00",
    "GENERAL_BLUE": "0xFF0000FF",
    "GENERAL_GREEN": "0xFF00C853",
    "GENERAL_PINK": "0xFFFF2D95",
    "GENERAL_PURPLE": "0xFF673AB7",
    "GENERAL_RED": "0xFFFF0000",
    "GENERAL_WHITE": "0xFFFFFFFF",
    "NO_COLOUR": "0xFF000000",
}

COLOR_ITEMS = [
    ("LED_AMBER", "LED - Amber", COLORS["LED_AMBER"]),
    ("LED_BLUE", "LED - Blue", COLORS["LED_BLUE"]),
    ("LED_RED", "LED - Red", COLORS["LED_RED"]),
    ("HALOGEN_BLUE", "Halogen - Blue", COLORS["HALOGEN_BLUE"]),
    ("HALOGEN_RED", "Halogen - Red", COLORS["HALOGEN_RED"]),
    ("GENERAL_AMBER", "General - Amber", COLORS["GENERAL_AMBER"]),
    ("GENERAL_AMBER_BRIGHT", "General - Amber Bright", COLORS["GENERAL_AMBER_BRIGHT"]),
    ("GENERAL_BLUE", "General - Blue", COLORS["GENERAL_BLUE"]),
    ("GENERAL_GREEN", "General - Green", COLORS["GENERAL_GREEN"]),
    ("GENERAL_PINK", "General - Pink", COLORS["GENERAL_PINK"]),
    ("GENERAL_PURPLE", "General - Purple", COLORS["GENERAL_PURPLE"]),
    ("GENERAL_RED", "General - Red", COLORS["GENERAL_RED"]),
    ("GENERAL_WHITE", "General - White", COLORS["GENERAL_WHITE"]),
    ("NO_COLOUR", "No Colour", COLORS["NO_COLOUR"]),
]

DEFAULT_COLOR_LIBRARY = [(label, value) for _, label, value in COLOR_ITEMS]

DEFAULT_PATTERNS = [
    ("Always On / Steady Burn", 4294967295),
    ("Code 3 Pursuit - Stage 1 - Blue", 4042322160),
    ("Code 3 Pursuit - Stage 1 - Red", 252645135),
    ("Code 3 Pursuit - Stage 2 - Blue", 1840278960),
    ("Code 3 Pursuit - Stage 2 - Red", 115017435),
    ("Code 3 Pursuit - Stage 3 - Blue", 1426085120),
    ("Code 3 Pursuit - Stage 3 - Red", 5570645),
    ("Code 3 Pursuit - Sweep - LED 1", 2147581953),
    ("Code 3 Pursuit - Sweep - LED 2", 1073889282),
    ("Code 3 Pursuit - Sweep - LED 3", 537141252),
    ("Code 3 Pursuit - Sweep - LED 4", 268963848),
    ("Code 3 Pursuit - Sweep - LED 5", 135268368),
    ("Code 3 Pursuit - Sweep - LED 6", 69207072),
    ("Code 3 Pursuit - Sweep - LED 7", 37749312),
    ("Code 3 Pursuit - Sweep - LED 8", 25166208),
    ("Double Flash Blue", 168430090),
    ("Double Flash Red", 2694881440),
    ("ECCO Split Double - Left - LED 1", 2684395520),
    ("ECCO Split Double - Right - LED 1", 167774720),
    ("ECCO Split Double - Left - LED 2", 10485920),
    ("ECCO Split Double - Right - LED 2", 655370),
    ("ED3790 - Blue", 2818615296),
    ("ED3790 - Red", 2752554),
    ("ED3790 - White", 41943680),
    ("Strobe - Blue", 9044106),
    ("Strobe - Red", 2315291136),
    ("Tripple Flash - Right", 2852170240),
    ("Tripple Flash - Left", 11141290),
    ("Tripple Flash - Gap - Blue", 2818615296),
    ("Tripple Flash - Gap - Red", 11010216),
    ("Wig Wag - Left", 8323199),
    ("Wig Wag - Right", 2130738944),
    ("Off", 0),
]

LEGACY_DEFAULT_PATTERNS = [
    ("Alternating Quad", 4042264335),
    ("Split 50/50", 4278255360),
    ("Rapid 2x2", 3435973836),
    ("Single Sweep", 4278190080),
    ("Pulsed", 252645135),
    ("Off", 0),
]

HEADLIGHT_KEYS = ("headlight", "head_light", "hl_", "light_head")
TAILLIGHT_KEYS = ("taillight", "tail_light", "rear_light", "brake_light")
LEFT_INDICATOR_KEYS = ("indicator_l", "left_indicator", "turn_l", "blinker_l")
RIGHT_INDICATOR_KEYS = ("indicator_r", "right_indicator", "turn_r", "blinker_r")
EXTRA_LIGHT_KEYS = ("extra_light", "aux_light", "warning_light")
LEFT_SIDE_TOKENS = {"left", "driver", "l", "lf", "lr"}
RIGHT_SIDE_TOKENS = {"right", "passenger", "r", "rf", "rr"}
WHEEL_PREVIEW_PREFIX = "_gta000_wheel_preview_"
def f8(v):
    return f"{float(v):.8f}"


def b(v):
    return "true" if v else "false"


def clean_bits(txt):
    return "".join(ch for ch in str(txt) if ch in "01")[:32]


def repeat_32(txt):
    bits = clean_bits(txt)
    if not bits:
        return "0" * 32
    if len(bits) == 32:
        return bits
    return (bits * ((32 + len(bits) - 1) // len(bits)))[:32]


def bits_to_int(txt):
    return int(repeat_32(txt), 2)

def invert_bits(txt):
    bits = repeat_32(txt)
    return "".join("1" if ch == "0" else "0" for ch in bits)



def parse_u32(v):
    txt = str(v).strip()
    try:
        n = int(txt, 10)
    except Exception:
        try:
            n = int(txt, 0)
        except Exception:
            n = 0
    return n & 0xFFFFFFFF


def int_to_bits(v):
    return format(parse_u32(v), "032b")


def cfg_dir():
    candidates = []
    names = ["gta000tools", "non_els_lightbar_tool"]

    for name in names:
        try:
            p = bpy.utils.user_resource("CONFIG", path=name, create=False)
            if p:
                candidates.append(p)
        except Exception:
            pass

    try:
        base = bpy.utils.user_resource("CONFIG")
        if base:
            for name in names:
                candidates.append(os.path.join(base, name))
    except Exception:
        pass

    for name in names:
        candidates.append(os.path.join(tempfile.gettempdir(), name))

    for p in candidates:
        target = p
        if os.path.isfile(target):
            target = target + "_data"
        try:
            os.makedirs(target, exist_ok=True)
            return target
        except Exception:
            continue

    return tempfile.gettempdir()


def safe_name(name):
    return re.sub(r"[^A-Za-z0-9_\- ]+", "", str(name)).strip().replace(" ", "_") or "lightbar_config"



_LIBRARY_FILE = "library.json"
_LIBRARY_SYNC_GUARD = False
_LIVE_PREVIEW_GUARD = False
_SCALE_FACTOR_SYNC_GUARD = False
_PREVIEW_UPDATE_SUSPEND = 0

def library_path():
    return os.path.join(cfg_dir(), _LIBRARY_FILE)

def load_global_library_data():
    fp = library_path()
    if not os.path.exists(fp):
        return {}
    try:
        with open(fp, "r", encoding="utf-8") as h:
            data = json.load(h)
        return data if isinstance(data, dict) else {}
    except Exception:
        return {}

def save_global_library(s):
    global _LIBRARY_SYNC_GUARD
    if _LIBRARY_SYNC_GUARD or not s:
        return
    try:
        data = {
            "patterns": [
                {
                    "name": p.name,
                    "visibility": p.visibility,
                    "bits": repeat_32(p.bits),
                    "value": parse_u32(p.value),
                    "allow_duplicate": bool(getattr(p, "allow_duplicate", False)),
                }
                for p in s.patterns
            ],
            "colors": [
                {
                    "name": c.name,
                    "value": clean_color_value(c.value),
                }
                for c in s.colors
            ],
        }
        with open(library_path(), "w", encoding="utf-8") as h:
            json.dump(data, h, indent=2)
    except Exception:
        pass

def save_library_from_context(context):
    scene = getattr(context, "scene", None) if context else None
    s = getattr(scene, "nels", None) if scene else None
    if s:
        save_global_library(s)


def config_json_files():
    files = []
    for n in sorted(os.listdir(cfg_dir())):
        if not n.lower().endswith(".json"):
            continue
        if n.lower() == _LIBRARY_FILE.lower():
            continue
        files.append(n)
    return files
def generate_siren_id(seed_text=""):
    base = 25000
    try:
        rnd = int.from_bytes(os.urandom(2), "little")
    except Exception:
        rnd = sum(ord(ch) for ch in str(seed_text))
    return base + (rnd % 50000)

def pattern_key_index(key):
    txt = str(key).strip()
    if txt.startswith("PAT_"):
        txt = txt[4:]
    try:
        return int(txt)
    except Exception:
        return 0


def normalize_pattern_key(key):
    return f"PAT_{max(0, pattern_key_index(key))}"



def find_pattern_key_by_name(s, name):
    if not s or not getattr(s, "patterns", None):
        return "PAT_0"
    target = str(name or "").strip().lower()
    for i, p in enumerate(s.patterns):
        if (p.name or "").strip().lower() == target:
            return f"PAT_{i}"
    return "PAT_0"


def pattern_duplicate_key(name):
    return re.sub(r"\s+", " ", str(name or "").strip()).lower()


def pattern_duplicate_indices(s, idx):
    if not s or not getattr(s, "patterns", None):
        return []
    if idx < 0 or idx >= len(s.patterns):
        return []
    key = pattern_duplicate_key(getattr(s.patterns[idx], "name", ""))
    if not key:
        return []
    matches = [i for i, p in enumerate(s.patterns) if pattern_duplicate_key(getattr(p, "name", "")) == key]
    return matches if len(matches) > 1 else []


def pattern_duplicate_is_allowed(s, idx):
    matches = pattern_duplicate_indices(s, idx)
    return bool(matches) and all(bool(getattr(s.patterns[i], "allow_duplicate", False)) for i in matches)


def pattern_display_name(s, idx):
    p = s.patterns[idx]
    base = str(getattr(p, "name", "") or f"Pattern {idx + 1}")
    matches = pattern_duplicate_indices(s, idx)
    if not matches:
        return base
    try:
        pos = matches.index(idx) + 1
    except ValueError:
        pos = 1
    return f"{base} [{pos}]"


def set_pattern_duplicate_allowed(s, idx, allowed):
    matches = pattern_duplicate_indices(s, idx)
    if not matches:
        return 0
    for i in matches:
        s.patterns[i].allow_duplicate = bool(allowed)
    return len(matches)


def remove_pattern_duplicates_keep_selected(s, idx):
    matches = pattern_duplicate_indices(s, idx)
    if not matches:
        return 0, idx
    removed = 0
    keep_idx = idx
    for i in reversed(matches):
        if i == idx:
            continue
        s.patterns.remove(i)
        removed += 1
        if i < keep_idx:
            keep_idx -= 1
    if 0 <= keep_idx < len(s.patterns):
        s.patterns[keep_idx].allow_duplicate = False
    return removed, keep_idx


def populate_default_patterns(s):
    s.patterns.clear()
    for name, value in DEFAULT_PATTERNS:
        p = s.patterns.add()
        p.name = name
        p.visibility = "BOTH"
        p.bits = int_to_bits(value)
        p.value = str(parse_u32(value))
        p.allow_duplicate = False
    s.active_pattern = 0


def patterns_match_defaults(s, defaults):
    actual = [(pattern_duplicate_key(getattr(p, "name", "")), parse_u32(getattr(p, "value", 0))) for p in getattr(s, "patterns", [])]
    expected = [(pattern_duplicate_key(name), parse_u32(value)) for name, value in defaults]
    return actual == expected


def migrate_legacy_default_patterns(s):
    legacy_sigs = {(pattern_duplicate_key(name), parse_u32(value)) for name, value in LEGACY_DEFAULT_PATTERNS}
    default_sigs = {(pattern_duplicate_key(name), parse_u32(value)) for name, value in DEFAULT_PATTERNS}
    seen_legacy = set()
    extras = []
    for p in getattr(s, "patterns", []):
        sig = (pattern_duplicate_key(getattr(p, "name", "")), parse_u32(getattr(p, "value", 0)))
        if sig in legacy_sigs:
            seen_legacy.add(sig)
            continue
        if sig in default_sigs:
            continue
        extras.append({
            "name": p.name,
            "allow_duplicate": bool(getattr(p, "allow_duplicate", False)),
            "visibility": "FLASHER" if getattr(p, "visibility", "BOTH") == "FLASHER" else "BOTH",
            "bits": repeat_32(getattr(p, "bits", "0")),
            "value": str(parse_u32(getattr(p, "value", 0))),
        })

    if not seen_legacy:
        return False

    populate_default_patterns(s)
    for pd in extras:
        p = s.patterns.add()
        p.name = pd["name"]
        p.allow_duplicate = pd["allow_duplicate"]
        p.visibility = pd["visibility"]
        p.bits = pd["bits"]
        p.value = pd["value"]
    s.active_pattern = min(max(0, s.active_pattern), max(0, len(s.patterns) - 1))
    return True
def clean_color_value(txt):
    raw = str(txt).strip().upper().replace("#", "")
    if raw.startswith("0X"):
        raw = raw[2:]
    raw = "".join(ch for ch in raw if ch in "0123456789ABCDEF")
    if len(raw) == 6:
        raw = "FF" + raw
    if len(raw) != 8:
        return "0xFFFF0000"
    return "0x" + raw


def color_to_rgb(value):
    v = clean_color_value(value)
    hx = v[4:]
    return (int(hx[0:2], 16) / 255.0, int(hx[2:4], 16) / 255.0, int(hx[4:6], 16) / 255.0)


def rgb_to_color(rgb):
    r = int(round(max(0.0, min(1.0, float(rgb[0]))) * 255))
    g = int(round(max(0.0, min(1.0, float(rgb[1]))) * 255))
    b0 = int(round(max(0.0, min(1.0, float(rgb[2]))) * 255))
    return f"0xFF{r:02X}{g:02X}{b0:02X}"


def color_key_index(key):
    txt = str(key).strip()
    if txt.startswith("COL_"):
        txt = txt[4:]
    try:
        return int(txt)
    except Exception:
        return 0


def normalize_color_key(key):
    return f"COL_{max(0, color_key_index(key))}"



def find_color_key_by_value(s, value):
    if not s or not getattr(s, "colors", None):
        return "COL_0"
    target = clean_color_value(value)
    for i, c in enumerate(s.colors):
        if clean_color_value(getattr(c, "value", "0xFFFF0000")) == target:
            return f"COL_{i}"
    return "COL_0"
def color_items(self, context):
    try:
        scene = getattr(context, "scene", None) if context else None
        s = getattr(scene, "nels", None) if scene else None
        if not s or not s.colors:
            return [("COL_0", "Colour 1", "")]
        items = []
        for i, c in enumerate(s.colors):
            nm = str(c.name or f"Colour {i + 1}")
            vv = clean_color_value(getattr(c, "value", "0xFFFF0000"))
            items.append((f"COL_{i}", nm, vv))
        return items or [("COL_0", "Colour 1", "")]
    except Exception:
        return [("COL_0", "Colour 1", "")]


def get_color(s, key):
    if not s.colors:
        return None
    i = max(0, min(color_key_index(key), len(s.colors) - 1))
    return s.colors[i]

def pattern_items(self, context):
    s = getattr(context.scene, "nels", None) if context and context.scene else None
    if not s or not s.patterns:
        return [("PAT_0", "(No Patterns)", "")]
    return [(f"PAT_{i}", pattern_display_name(s, i), p.visibility) for i, p in enumerate(s.patterns)]


def pattern_select_items(self, context):
    return list(pattern_items(self, context)) + [(UNSAVED_PATTERN_KEY, "Unsaved Pattern", "")]


def color_select_items(self, context):
    return list(color_items(self, context)) + [("__CUSTOM__", "Custom", "")]


def direction_select_items(self, context):
    return list(DIRECTION_ITEMS) + [("__CUSTOM__", "Custom", "")]

def saved_cfg_items(self, context):
    items = [(NO_SAVED_CFG, "(No Saved Configs)", "")]
    for n in config_json_files():
        items.append((n, os.path.splitext(n)[0], ""))
    return items


def get_pattern(s, key):
    if not s.patterns:
        return None
    i = max(0, min(pattern_key_index(key), len(s.patterns) - 1))
    return s.patterns[i]


def normalize_pattern_visibility(visibility):
    return "FLASHER" if str(visibility or "").upper() == "FLASHER" else "BOTH"


def pattern_matches_visibility(pattern_visibility, requested_visibility):
    pattern_vis = normalize_pattern_visibility(pattern_visibility)
    requested_vis = normalize_pattern_visibility(requested_visibility)
    return pattern_vis == requested_vis or (requested_vis == "FLASHER" and pattern_vis == "BOTH")


def find_pattern_key_by_bits(s, bits, visibility="BOTH"):
    bits32 = repeat_32(bits)
    for i, p in enumerate(getattr(s, "patterns", [])):
        if repeat_32(getattr(p, "bits", "0")) != bits32:
            continue
        if pattern_matches_visibility(getattr(p, "visibility", "BOTH"), visibility):
            return f"PAT_{i}"
    return ""


def next_pattern_name(s, base_name="Unsaved Pattern"):
    base = str(base_name or "Unsaved Pattern").strip() or "Unsaved Pattern"
    existing = {str(getattr(p, "name", "") or "").strip().casefold() for p in getattr(s, "patterns", [])}
    if base.casefold() not in existing:
        return base
    i = 2
    while f"{base} {i}".casefold() in existing:
        i += 1
    return f"{base} {i}"


def get_or_add_pattern(s, name, visibility, bits):
    bits32 = repeat_32(bits)
    vis = normalize_pattern_visibility(visibility)
    existing_key = find_pattern_key_by_bits(s, bits32, vis)
    if existing_key:
        return existing_key
    p = s.patterns.add()
    p.name = name or f"Pattern {len(s.patterns)}"
    p.visibility = vis
    p.bits = bits32
    p.value = str(bits_to_int(bits32))
    s.active_pattern = len(s.patterns) - 1
    save_global_library(s)
    return f"PAT_{s.active_pattern}"


def off_pattern_key(s):
    return find_pattern_key_by_name(s, "off")


def white_color_key(s):
    return find_color_key_by_value(s, COLORS["GENERAL_WHITE"])


def playback_seconds(scene=None, now=None):
    if now is not None:
        try:
            return float(now)
        except Exception:
            pass

    scn = scene if scene is not None else getattr(bpy.context, "scene", None)
    if scn and timeline_playing():
        try:
            fps_base = float(getattr(scn.render, "fps_base", 1.0) or 1.0)
            fps = float(getattr(scn.render, "fps", 24.0))
            fps_real = fps / fps_base if fps_base != 0.0 else fps
            if fps_real <= 0.0:
                fps_real = 24.0
            return float(scn.frame_current) / fps_real
        except Exception:
            pass
    return _time.time()


def pattern_is_on(s, key, bpm, now=None, scene=None):
    p = get_pattern(s, key)
    bits = repeat_32(p.bits) if p else ("0" * 32)
    ts = playback_seconds(scene=scene, now=now)
    steps_per_second = max(1.0, float(bpm)) / 60.0
    idx = int(ts * steps_per_second) % 32
    return bits[idx] == "1"


def preview_seconds(scene=None, now=None):
    ts = playback_seconds(scene=scene, now=now)
    scn = scene if scene is not None else getattr(bpy.context, "scene", None)
    if scn and (not timeline_playing()):
        s = getattr(scn, "nels", None)
        if s:
            origin = float(getattr(s, "preview_time_origin", 0.0) or 0.0)
            if origin > 0.0:
                return max(0.0, ts - origin)
    return ts


def preview_pattern_is_on(bits, bpm, scene=None, now=None):
    bits32 = repeat_32(bits)
    ts = preview_seconds(scene=scene, now=now)
    steps_per_second = max(1.0, float(bpm)) / 60.0
    idx = int(ts * steps_per_second) % 32
    return bits32[idx] == "1"


def scale_factor_choice_from_value(val):
    try:
        fv = float(val)
    except Exception:
        return "CUSTOM"
    for key, pv in SCALE_FACTOR_PRESET_VALUES.items():
        if abs(fv - pv) <= 0.000001:
            return key
    return "CUSTOM"

def siren_index_from_name(name):
    m = re.match(r"^siren\s*(\d+)", str(name or "").strip().lower())
    if not m:
        return 0
    try:
        idx = int(m.group(1))
    except Exception:
        return 0
    return idx if 1 <= idx <= MAX_SIRENS else 0



def extra_index_from_name(name):
    m = re.match(r"^extra[_\-\s]?(\d+)(?:\..*)?$", str(name or "").strip().lower())
    if not m:
        return 0
    try:
        return int(m.group(1))
    except Exception:
        return 0


def scene_extra_objects(scene):
    if not scene:
        return []
    found = []
    for obj in scene.objects:
        idx = extra_index_from_name(obj.name)
        if idx > 0:
            found.append((idx, obj.name, obj))
    found.sort(key=lambda it: (it[0], it[1].lower()))
    return [it[2] for it in found]


def is_object_visible(obj):
    try:
        return not obj.hide_get()
    except Exception:
        return not bool(getattr(obj, "hide_viewport", False))


def set_object_visible(obj, show):
    hide = not bool(show)
    try:
        obj.hide_set(hide)
    except Exception:
        pass
    try:
        obj.hide_viewport = hide
    except Exception:
        pass
    try:
        obj.hide_render = hide
    except Exception:
        pass


def extra_display_name(obj):
    idx = extra_index_from_name(getattr(obj, "name", ""))
    if idx <= 0:
        return getattr(obj, "name", "")
    base = f"extra_{idx}".lower()
    nm = str(getattr(obj, "name", ""))
    if nm.lower() == base:
        return f"Extra {idx}"
    return f"Extra {idx} ({nm})"


def _name_has_any(name, keys):
    txt = str(name or "").lower()
    return any(k in txt for k in keys)


def scene_objects_by_keywords(scene, keywords):
    if not scene:
        return []
    out = []
    for obj in scene.objects:
        if _name_has_any(obj.name, keywords):
            out.append(obj)
    return out


def object_side(name):
    nm = str(name or "").lower()
    tokens = [t for t in re.split(r"[^a-z0-9]+", nm) if t]

    left = any(t in LEFT_SIDE_TOKENS for t in tokens) or bool(re.search(r"(?:^|[_\-.])(l|lf|lr)(?:$|[_\-.])", nm))
    right = any(t in RIGHT_SIDE_TOKENS for t in tokens) or bool(re.search(r"(?:^|[_\-.])(r|rf|rr)(?:$|[_\-.])", nm))

    if left and not right:
        return "LEFT"
    if right and not left:
        return "RIGHT"
    return "CENTER"


def split_side_objects(objs):
    left = []
    right = []
    center = []
    for obj in objs:
        side = object_side(getattr(obj, "name", ""))
        if side == "LEFT":
            left.append(obj)
        elif side == "RIGHT":
            right.append(obj)
        else:
            center.append(obj)
    return left, right, center


def wheel_bone_key(name):
    nm = str(name or "").lower()
    m = re.search(r"wheel[_\-]?(lf|rf|lr|rr)", nm)
    if not m:
        return ""
    return f"wheel_{m.group(1)}"


def wheel_pose_bones(scene):
    s = getattr(scene, "nels", None) if scene else None
    if not s or not s.armature_name:
        return (None, [])
    arm = bpy.data.objects.get(s.armature_name)
    if not arm or arm.type != "ARMATURE":
        return (None, [])

    all_wheel = [pb for pb in arm.pose.bones if "wheel" in pb.name.lower()]
    keyed = {}
    for pb in all_wheel:
        key = wheel_bone_key(pb.name)
        if key and key not in keyed:
            keyed[key] = pb

    if keyed:
        ordered = [keyed[k] for k in ("wheel_lf", "wheel_rf", "wheel_lr", "wheel_rr") if k in keyed]
        if ordered:
            return (arm, ordered)
    return (arm, all_wheel)


def has_real_wheel_for_bone(scene, arm, bone_name):
    for obj in scene.objects:
        if obj.type != "MESH" or obj.name.startswith(WHEEL_PREVIEW_PREFIX):
            continue
        nm = obj.name.lower()
        if "wheel" not in nm or "steer" in nm:
            continue
        if obj.parent == arm and obj.parent_type == "BONE" and obj.parent_bone == bone_name:
            return True
    return False
def clear_wheel_preview_objects(scene):
    if not scene:
        return 0
    removed = 0
    for obj in list(scene.objects):
        if obj.name.startswith(WHEEL_PREVIEW_PREFIX):
            try:
                bpy.data.objects.remove(obj, do_unlink=True)
                removed += 1
            except Exception:
                pass
    return removed


def find_source_wheel_object(context, arm, bones):
    scene = getattr(context, "scene", None) if context else None
    if not scene:
        return None

    bone_names = {pb.name for pb in bones}
    active = getattr(context, "active_object", None)
    if (
        active
        and active.type == "MESH"
        and (not active.name.startswith(WHEEL_PREVIEW_PREFIX))
        and active.parent == arm
        and active.parent_type == "BONE"
        and active.parent_bone in bone_names
    ):
        return active

    preferred = ("wheel_lf", "wheel_rf", "wheel_lr", "wheel_rr")
    candidates = []
    for obj in scene.objects:
        if obj.type != "MESH" or obj.name.startswith(WHEEL_PREVIEW_PREFIX):
            continue
        if obj.parent == arm and obj.parent_type == "BONE" and obj.parent_bone in bone_names:
            pb = obj.parent_bone.lower()
            prio = preferred.index(pb) if pb in preferred else 99
            candidates.append((prio, obj.name.lower(), obj))

    if candidates:
        candidates.sort(key=lambda it: (it[0], it[1]))
        return candidates[0][2]

    # Fallback: choose a likely wheel mesh by name/proximity, but explicitly ignore steering wheels.
    bone_world_positions = [arm.matrix_world @ pb.head for pb in bones]
    loose = []
    for obj in scene.objects:
        nm = obj.name.lower()
        if obj.type != "MESH" or obj.name.startswith(WHEEL_PREVIEW_PREFIX):
            continue
        if "steer" in nm:
            continue
        if "wheel" not in nm:
            continue
        if not bone_world_positions:
            continue
        pos = obj.matrix_world.translation
        dist = min((pos - bp).length for bp in bone_world_positions)
        loose.append((dist, nm, obj))

    if loose:
        loose.sort(key=lambda it: (it[0], it[1]))
        return loose[0][2]
    return None


def _copy_obj_rotation(dst, src):
    dst.rotation_mode = src.rotation_mode
    if src.rotation_mode == "QUATERNION":
        dst.rotation_quaternion = src.rotation_quaternion.copy()
    elif src.rotation_mode == "AXIS_ANGLE":
        dst.rotation_axis_angle = tuple(src.rotation_axis_angle)
    else:
        dst.rotation_euler = src.rotation_euler.copy()


def simulate_tyres_on_wheel_bones(context, arm, bones):
    scene = getattr(context, "scene", None) if context else None
    try:
        vl = getattr(context, "view_layer", None) if context else getattr(bpy.context, "view_layer", None)
        if vl:
            vl.update()
    except Exception:
        pass

    if not scene:
        return (0, 0, "Scene not available")

    src = find_source_wheel_object(context, arm, bones)
    if not src:
        return (0, 0, "Warning: Could not find a source wheel mesh (select/use a real wheel mesh, not steering wheel)")

    # Determine source wheel bone robustly (explicit parent > name key > nearest).
    bone_head_world = {}
    for pb in bones:
        bd = arm.data.bones.get(pb.name)
        if bd:
            bone_head_world[pb.name] = arm.matrix_world @ bd.head_local
        else:
            bone_head_world[pb.name] = arm.matrix_world @ pb.head

    source_bone_name = ""
    if src.parent == arm and src.parent_type == "BONE" and src.parent_bone in bone_head_world:
        source_bone_name = src.parent_bone

    if not source_bone_name:
        src_key = wheel_bone_key(src.name)
        if src_key:
            for pb in bones:
                if wheel_bone_key(pb.name) == src_key:
                    source_bone_name = pb.name
                    break

    if not source_bone_name:
        src_pos = src.matrix_world.translation
        ref_bone = min(bones, key=lambda pb: (src_pos - bone_head_world[pb.name]).length)
        source_bone_name = ref_bone.name

    src_world = src.matrix_world.copy()
    src_head = bone_head_world[source_bone_name]

    linked = 0
    skipped = 0
    cleaned = 0
    for pb in bones:
        nm = f"{WHEEL_PREVIEW_PREFIX}{pb.name}"
        is_source_bone = pb.name == source_bone_name
        has_real = has_real_wheel_for_bone(scene, arm, pb.name)
        if is_source_bone or has_real:
            stale = bpy.data.objects.get(nm)
            if stale:
                try:
                    bpy.data.objects.remove(stale, do_unlink=True)
                    cleaned += 1
                except Exception:
                    pass
            skipped += 1
            continue

        dup = bpy.data.objects.get(nm)
        if not dup:
            dup = src.copy()
            dup.data = src.data
            dup.name = nm
            linked_to_any = False
            if src.users_collection:
                for col in src.users_collection:
                    try:
                        col.objects.link(dup)
                        linked_to_any = True
                    except Exception:
                        pass
            if (not linked_to_any) and scene.collection:
                scene.collection.objects.link(dup)

        dup.parent = arm
        dup.parent_type = "OBJECT"
        dup.parent_bone = ""
        target_head = bone_head_world.get(pb.name, src_head)
        target_world = src_world.copy()
        target_world.translation = src_world.translation + (target_head - src_head)
        dup.matrix_parent_inverse = arm.matrix_world.inverted()
        dup.matrix_world = target_world
        _copy_obj_rotation(dup, src)
        dup.scale = src.scale.copy()
        set_object_visible(dup, True)
        linked += 1

    msg = f"Tyre simulation updated using '{src.name}': {linked} wheel previews linked, {cleaned} stale removed"
    return linked, skipped, msg


def normalize_import_scale_factor(value):
    try:
        sc = float(value)
    except Exception:
        sc = 0.5
    if sc > 1.0:
        sc = 1.0 / sc
    return max(0.0, sc)


def apply_scale_to_settings(s, factor):
    if not s:
        return
    s.scale_factor = normalize_import_scale_factor(factor)
    sync_scale_factor_controls(s)


def apply_scale_to_siren(si, factor):
    # Legacy compatibility for older saved configs; runtime scale now uses scene-level scale_factor.
    sc = normalize_import_scale_factor(factor)
    if abs(sc - 0.5) < 0.000001:
        si.scale_mode = "PRESET"
        si.scale_preset = "SCALE_50"
    elif abs(sc - 0.1) < 0.000001:
        si.scale_mode = "PRESET"
        si.scale_preset = "SCALE_10"
    elif abs(sc - 0.01) < 0.000001:
        si.scale_mode = "PRESET"
        si.scale_preset = "SCALE_01"
    else:
        si.scale_mode = "CUSTOM"
        si.custom_scale = sc


def auto_detect_scene_sirens(scene, create_missing=True, sync_direction=False):
    s = getattr(scene, "nels", None)
    if not s:
        return (0, 0, 0)

    scene_objects = list(getattr(scene, "objects", [])) if scene else list(bpy.data.objects)

    arm = None
    if s.armature_name:
        arm = next((obj for obj in scene_objects if obj.name == s.armature_name and obj.type == "ARMATURE"), None)

    best_arm = arm
    best_bones = {}
    best_count = 0
    for obj in scene_objects:
        if obj.type != "ARMATURE":
            continue
        bone_map = {}
        for b in obj.data.bones:
            idx = siren_index_from_name(b.name)
            if idx and idx not in bone_map:
                bone_map[idx] = b.name
        if len(bone_map) > best_count:
            best_count = len(bone_map)
            best_arm = obj
            best_bones = bone_map

    if best_arm and s.armature_name != best_arm.name:
        s.armature_name = best_arm.name
    if not best_bones and best_arm and best_arm.type == "ARMATURE":
        for b in best_arm.data.bones:
            idx = siren_index_from_name(b.name)
            if idx and idx not in best_bones:
                best_bones[idx] = b.name

    obj_map = {}
    for obj in scene_objects:
        idx = siren_index_from_name(obj.name)
        if idx and idx not in obj_map:
            obj_map[idx] = obj.name
        if best_arm and obj.parent == best_arm and obj.parent_type == "BONE":
            bidx = siren_index_from_name(obj.parent_bone)
            if bidx and bidx not in obj_map:
                obj_map[bidx] = obj.name

    max_idx = max([0, len(s.sirens)] + list(obj_map.keys()) + list(best_bones.keys()))
    if create_missing and max_idx > len(s.sirens):
        ensure_sirens(s, max_idx)

    linked = 0
    for i, si in enumerate(s.sirens, start=1):
        if (not si.bone_name) and i in best_bones:
            si.bone_name = best_bones[i]
            linked += 1

        if (not si.object_name) and i in obj_map:
            si.object_name = obj_map[i]
            o = bpy.data.objects.get(si.object_name)
            if o:
                _store_rest_loc(o)
            linked += 1

        if si.object_name and (not si.bone_name) and best_arm:
            o = bpy.data.objects.get(si.object_name)
            if o and o.parent == best_arm and o.parent_type == "BONE":
                bidx = siren_index_from_name(o.parent_bone)
                if bidx == i:
                    si.bone_name = o.parent_bone

        si.enabled = bool(si.object_name or si.bone_name)

    if sync_direction:
        apply_all_siren_directions(scene)

    return (len(obj_map), len(best_bones), linked)

def siren_obj(si):
    if si.object_name and si.object_name in bpy.data.objects:
        return bpy.data.objects[si.object_name]
    n = f"siren{si.index}"
    return bpy.data.objects.get(n)



def siren_pose_bone(scene, si):
    s = getattr(scene, "nels", None) if scene else None
    candidates = []
    if s and s.armature_name:
        arm = bpy.data.objects.get(s.armature_name)
        if arm and arm.type == "ARMATURE":
            candidates.append(arm)
    for obj in bpy.data.objects:
        if obj.type == "ARMATURE" and obj not in candidates:
            candidates.append(obj)

    names = []
    if si and si.bone_name:
        names.append(si.bone_name)
    if si:
        names.append(f"siren{si.index}")

    for arm in candidates:
        for bn in names:
            if not bn:
                continue
            pb = arm.pose.bones.get(bn)
            if pb:
                if si and not si.bone_name:
                    si.bone_name = pb.name
                if s and not s.armature_name:
                    s.armature_name = arm.name
                return arm, pb
    return None, None


def swappable_siren_items(self, context):
    scene = getattr(context, "scene", None) if context else getattr(bpy.context, "scene", None)
    s = getattr(scene, "nels", None) if scene else None
    items = []
    if s:
        for si in s.sirens:
            obj = siren_obj(si)
            arm, pb = siren_pose_bone(scene, si)
            if obj and obj.type == "MESH" and arm and pb:
                items.append((str(si.index), f"Siren {si.index}", f"{obj.name} on {arm.name}:{pb.name}"))
    if items:
        return items
    return [("__NONE__", "(No complete sirens found)", "Link mesh and bone for at least two sirens first")]


def siren_slot_by_index(s, idx):
    if not s:
        return None
    try:
        needle = int(idx)
    except Exception:
        return None
    for si in s.sirens:
        if int(getattr(si, "index", 0)) == needle:
            return si
    return None


def pick_anchor_object(context, arm, si):
    active = getattr(context.view_layer.objects, "active", None)
    selected = [o for o in context.selected_objects if o and o.type != "ARMATURE"]

    if si and si.object_name:
        non_siren = [o for o in selected if o.name != si.object_name]
        if non_siren:
            selected = non_siren

    if active and active in selected:
        return active
    if selected:
        return selected[0]
    if active and active.type != "ARMATURE":
        if not si or active.name != si.object_name:
            return active

    if si and si.anchor_name and si.anchor_name in bpy.data.objects:
        anchor = bpy.data.objects[si.anchor_name]
        if anchor.type != "ARMATURE":
            return anchor
    return None


def pick_reference_object(context, si):
    active = getattr(context.view_layer.objects, "active", None)
    selected = [o for o in context.selected_objects if o and o.type != "ARMATURE"]

    if si and si.object_name:
        selected = [o for o in selected if o.name != si.object_name]

    if active and active in selected:
        return active
    if selected:
        return selected[0]
    if active and active.type != "ARMATURE":
        if not si or active.name != si.object_name:
            return active
    return None


def set_object_origin_from_reference(obj, reference):
    if not obj or not reference:
        return False, "Missing source or reference object"
    if getattr(obj, "type", "") != "MESH":
        return False, "The linked siren object must be a mesh"
    if getattr(obj, "data", None) is None or not hasattr(obj.data, "transform"):
        return False, "The linked siren object has no editable mesh data"

    old_world = obj.matrix_world.copy()
    new_world = old_world.copy()
    new_world.translation = reference.matrix_world.translation.copy()

    try:
        transform = new_world.inverted() @ old_world
    except Exception:
        return False, "Could not calculate the new siren origin transform"

    try:
        if getattr(obj.data, "users", 1) > 1:
            obj.data = obj.data.copy()
        obj.data.transform(transform)
        if hasattr(obj.data, "update"):
            obj.data.update()
        obj.matrix_world = new_world
        _store_rest_loc(obj, force=True)
        return True, f"Set {obj.name} origin to {reference.name}"
    except Exception as ex:
        return False, f"Could not set siren origin: {ex}"
def infer_siren_index_from_object(obj, s=None):
    seen = set()
    cur = obj
    while cur and cur not in seen:
        seen.add(cur)
        idx = siren_index_from_name(getattr(cur, "name", ""))
        if idx:
            return idx
        idx = siren_index_from_name(getattr(cur, "parent_bone", ""))
        if idx:
            return idx
        if s:
            for si in getattr(s, "sirens", []):
                if getattr(si, "object_name", "") == getattr(cur, "name", ""):
                    return int(getattr(si, "index", 0) or 0)
        cur = getattr(cur, "parent", None)
    return 0


def resolve_context_siren(scene, s, require_linked=False, update_active=True):
    if not s or not getattr(s, "sirens", None):
        return None

    active_obj = getattr(bpy.context, "active_object", None)
    idx = infer_siren_index_from_object(active_obj, s=s) if active_obj else 0
    if 1 <= idx <= len(s.sirens):
        if update_active:
            s.active_siren = idx - 1
        return s.sirens[idx - 1]

    cur_idx = max(0, min(int(getattr(s, "active_siren", 0) or 0), len(s.sirens) - 1))
    cur_si = s.sirens[cur_idx]
    if not require_linked:
        return cur_si
    if siren_obj(cur_si) or siren_pose_bone(scene, cur_si)[1]:
        return cur_si

    for si in s.sirens:
        if siren_obj(si) or siren_pose_bone(scene, si)[1]:
            if update_active:
                s.active_siren = max(0, int(getattr(si, "index", 1)) - 1)
            return si
    return cur_si


def scene_armature_items(self, context):
    scene = getattr(context, "scene", None) if context else getattr(bpy.context, "scene", None)
    items = []
    if scene:
        arm_names = sorted({obj.name for obj in scene.objects if obj.type == "ARMATURE"}, key=str.lower)
        items = [(name, name, "") for name in arm_names]
    if not items:
        items = [("__NONE__", "(No armatures found)", "")]
    return items


def _norm_angle(v):
    try:
        a = float(v)
    except Exception:
        a = 0.0
    return (a + math.pi) % (2.0 * math.pi) - math.pi


def direction_preset_from_value(v, tol=0.0002):
    vn = _norm_angle(v)
    best_key = None
    best_delta = 1e9
    for key, ang in DIRECTIONS.items():
        d = abs(_norm_angle(vn - ang))
        if d < best_delta:
            best_delta = d
            best_key = key
    if best_key is not None and best_delta <= tol:
        return best_key
    return None


def dir_val(si):
    return float(si.custom_direction) if si.direction_mode == "CUSTOM" else DIRECTIONS.get(si.direction_preset, 0.0)


def sync_scale_factor_controls(s):
    global _SCALE_FACTOR_SYNC_GUARD
    if not s or _SCALE_FACTOR_SYNC_GUARD:
        return

    _SCALE_FACTOR_SYNC_GUARD = True
    try:
        sf = max(0.0, float(getattr(s, "scale_factor", 0.5)))
        s.scale_factor_choice = scale_factor_choice_from_value(sf)
        s.scale_factor_custom = sf
    except Exception:
        pass
    finally:
        _SCALE_FACTOR_SYNC_GUARD = False


def update_scale_factor_choice(self, context):
    global _SCALE_FACTOR_SYNC_GUARD
    if _SCALE_FACTOR_SYNC_GUARD:
        return

    _SCALE_FACTOR_SYNC_GUARD = True
    try:
        ch = getattr(self, "scale_factor_choice", "SF_2")
        if ch == "CUSTOM":
            self.scale_factor = max(0.0, float(getattr(self, "scale_factor_custom", 0.5)))
        else:
            self.scale_factor = float(SCALE_FACTOR_PRESET_VALUES.get(ch, 0.5))
            self.scale_factor_custom = self.scale_factor
    except Exception:
        pass
    finally:
        _SCALE_FACTOR_SYNC_GUARD = False
    mark_preview_dirty(context)


def update_scale_factor_custom(self, context):
    if getattr(self, "scale_factor_choice", "SF_2") != "CUSTOM":
        return
    update_scale_factor_choice(self, context)


def update_scale_factor_value(self, context):
    sync_scale_factor_controls(self)
    mark_preview_dirty(context)


def sync_siren_selector_controls(si):
    if not si:
        return
    try:
        si.pattern_select = UNSAVED_PATTERN_KEY if getattr(si, "pattern_source", "LIBRARY") == "CUSTOM" else normalize_pattern_key(getattr(si, "pattern_choice", "PAT_0"))
    except Exception:
        pass
    try:
        si.color_select = "__CUSTOM__" if getattr(si, "color_mode", "PRESET") == "CUSTOM" else normalize_color_key(getattr(si, "color_preset", "COL_0"))
    except Exception:
        pass
    try:
        si.direction_select = "__CUSTOM__" if getattr(si, "direction_mode", "PRESET") == "CUSTOM" else str(getattr(si, "direction_preset", "FRONT") or "FRONT")
    except Exception:
        pass


def update_pattern_select(self, context):
    scene = getattr(context, "scene", None) if context else None
    s = getattr(scene, "nels", None) if scene else None
    current_select = getattr(self, "pattern_select", "PAT_0")
    if current_select in {UNSAVED_PATTERN_KEY, "__CUSTOM__"}:
        if getattr(self, "pattern_source", "LIBRARY") != "CUSTOM" and s:
            p = get_pattern(s, getattr(self, "pattern_choice", "PAT_0"))
            if p:
                self.custom_visibility = getattr(p, "visibility", "BOTH") or "BOTH"
                bits = clean_bits(getattr(p, "bits", "0"))
                self.custom_bits = bits
                self.custom_value = str(parse_u32(getattr(p, "value", bits_to_int(bits))))
        self.pattern_source = "CUSTOM"
        if current_select == "__CUSTOM__":
            self.pattern_select = UNSAVED_PATTERN_KEY
    else:
        self.pattern_source = "LIBRARY"
        self.pattern_choice = normalize_pattern_key(current_select)
    queue_preview_refresh_feedback(scene)
    mark_preview_dirty(context, scene=scene, immediate=False)


def update_color_select(self, context):
    scene = getattr(context, "scene", None) if context else None
    s = getattr(scene, "nels", None) if scene else None
    if getattr(self, "color_select", "COL_0") == "__CUSTOM__":
        if getattr(self, "color_mode", "PRESET") != "CUSTOM" and s:
            c = get_color(s, getattr(self, "color_preset", "COL_0"))
            if c:
                self.custom_color = color_to_rgb(getattr(c, "value", COLORS["GENERAL_WHITE"]))
        self.color_mode = "CUSTOM"
    else:
        self.color_mode = "PRESET"
        self.color_preset = normalize_color_key(self.color_select)
    mark_preview_dirty(context)


def update_direction_select(self, context):
    if getattr(self, "direction_select", "FRONT") == "__CUSTOM__":
        if getattr(self, "direction_mode", "PRESET") != "CUSTOM":
            self.custom_direction = float(DIRECTIONS.get(getattr(self, "direction_preset", "FRONT"), 0.0))
        self.direction_mode = "CUSTOM"
    else:
        self.direction_mode = "PRESET"
        self.direction_preset = self.direction_select
        self.custom_direction = float(DIRECTIONS.get(self.direction_preset, 0.0))
    update_siren_direction(self, context)

def scale_val(si, scene=None):
    scn = scene if scene is not None else getattr(bpy.context, "scene", None)
    settings = getattr(scn, "nels", None) if scn else None
    if settings and hasattr(settings, "scale_factor"):
        try:
            return max(0.0, float(settings.scale_factor))
        except Exception:
            pass

    # Backward compatibility fallback.
    try:
        if getattr(si, "scale_mode", "PRESET") == "CUSTOM":
            return max(0.0, float(getattr(si, "custom_scale", 0.5)))
        return SCALES.get(getattr(si, "scale_preset", "SCALE_50"), 0.5)
    except Exception:
        return 0.5


def scale_factor_from_siren(si, scene=None):
    sc = max(0.0, scale_val(si, scene=scene))
    if sc <= 0.0:
        return 0.0
    return 1.0 / sc


def format_scale_factor(v):
    try:
        fv = float(v)
    except Exception:
        fv = 0.0
    if abs(fv - round(fv)) < 0.000001:
        return str(int(round(fv)))
    return f8(fv)


def shown_sim_scale(s, si):
    return 1.0


def hidden_sim_scale(s, si):
    return max(0.0, scale_val(si))


def _store_rest_loc(obj, force=False):
    if (not force) and ("_nels_rest_loc" in obj):
        return
    obj["_nels_rest_loc"] = [float(obj.location[0]), float(obj.location[1]), float(obj.location[2])]
    obj["_nels_rest_rot"] = [float(obj.rotation_euler[0]), float(obj.rotation_euler[1]), float(obj.rotation_euler[2])]
    obj["_nels_rest_scale"] = [float(obj.scale[0]), float(obj.scale[1]), float(obj.scale[2])]


def _rest_loc(obj):
    data = obj.get("_nels_rest_loc")
    if isinstance(data, (list, tuple)) and len(data) == 3:
        return Vector((float(data[0]), float(data[1]), float(data[2])))
    _store_rest_loc(obj)
    data = obj.get("_nels_rest_loc")
    return Vector((float(data[0]), float(data[1]), float(data[2])))


def _rest_rot(obj):
    data = obj.get("_nels_rest_rot")
    if isinstance(data, (list, tuple)) and len(data) == 3:
        return Vector((float(data[0]), float(data[1]), float(data[2])))
    _store_rest_loc(obj)
    data = obj.get("_nels_rest_rot", [0.0, 0.0, 0.0])
    return Vector((float(data[0]), float(data[1]), float(data[2])))


def _rest_scale(obj):
    data = obj.get("_nels_rest_scale")
    if isinstance(data, (list, tuple)) and len(data) == 3:
        return Vector((float(data[0]), float(data[1]), float(data[2])))
    _store_rest_loc(obj)
    data = obj.get("_nels_rest_scale", [1.0, 1.0, 1.0])
    return Vector((float(data[0]), float(data[1]), float(data[2])))


def rotator_preview_targets(si):
    o = siren_obj(si)
    if not o:
        return []
    direct_children = [child for child in o.children if getattr(child, "type", "") != "ARMATURE"]
    return direct_children if direct_children else [o]


def rotator_preview_pose_bones(scene, si):
    arm, pb = siren_pose_bone(scene, si)
    if not arm or not pb:
        return []
    return [child for child in getattr(pb, "children", []) if child]


def apply_rotator_preview_targets(si, turns=0.0, keyframe_frame=None):
    if not si or getattr(si, "siren_type", "FLASHER") != "ROTATOR":
        return 0

    rot_sign = 1.0 if getattr(si, "rotator_clockwise", True) else -1.0
    updated = 0
    for obj in rotator_preview_targets(si):
        _store_rest_loc(obj)
        rest_loc = _rest_loc(obj)
        rest_rot = _rest_rot(obj)
        rest_scale = _rest_scale(obj)
        obj.rotation_mode = "XYZ"
        obj.location = rest_loc
        obj.scale = rest_scale
        obj.rotation_euler = rest_rot
        obj.rotation_euler[2] = rest_rot[2] + rot_sign * turns * math.tau
        if keyframe_frame is not None:
            obj.keyframe_insert(data_path="rotation_euler", index=2, frame=keyframe_frame)
        updated += 1
    return updated


def apply_rotator_preview_pose_targets(scene, si, turns=0.0, keyframe_frame=None):
    if not si or getattr(si, "siren_type", "FLASHER") != "ROTATOR":
        return 0

    arm, _pb = siren_pose_bone(scene, si)
    if not arm:
        return 0

    rot_sign = 1.0 if getattr(si, "rotator_clockwise", True) else -1.0
    updated = 0
    for target in rotator_preview_pose_bones(scene, si):
        _store_rest_pose_bone(arm, target)
        rest_loc, rest_rot, rest_sc = _rest_pose_bone(arm, target)
        target.rotation_mode = "XYZ"
        target.location = rest_loc
        target.scale = rest_sc
        target.rotation_euler = rest_rot
        target.rotation_euler[2] = rest_rot[2] + rot_sign * turns * math.tau
        if keyframe_frame is not None:
            target.keyframe_insert(data_path="rotation_euler", index=2, frame=keyframe_frame)
        updated += 1
    return updated


def target_sim_loc(obj, mode):
    rest = _rest_loc(obj)
    if mode == "ON":
        return rest
    if obj.parent_type == "BONE":
        return Vector((0.0, 0.0, 0.0))
    return rest


def _vector_mul(a, b):
    return Vector((float(a[0]) * float(b[0]), float(a[1]) * float(b[1]), float(a[2]) * float(b[2])))


def _vector_div_scalar(v, scalar):
    val = float(scalar)
    return Vector((float(v[0]) / val, float(v[1]) / val, float(v[2]) / val))


def siren_object_driven_by_bone(scene, si):
    o = siren_obj(si)
    arm, pb = siren_pose_bone(scene, si)
    return bool(o and arm and pb and o.parent == arm and o.parent_type == "BONE" and o.parent_bone == pb.name)


def iter_siren_object_hierarchy(root):
    if not root:
        return []
    found = []
    stack = list(getattr(root, "children", []))
    while stack:
        obj = stack.pop(0)
        if not obj or obj in found:
            continue
        if getattr(obj, "type", "") != "ARMATURE":
            found.append(obj)
        stack.extend(list(getattr(obj, "children", [])))
    return found


def scale_object_data(obj, factor_vec):
    if not obj:
        return False
    data = getattr(obj, "data", None)
    if data is None or not hasattr(data, "transform"):
        return False
    try:
        if getattr(data, "users", 1) > 1:
            obj.data = data.copy()
            data = obj.data
        data.transform(Matrix.Diagonal((float(factor_vec[0]), float(factor_vec[1]), float(factor_vec[2]), 1.0)))
        if hasattr(data, "update"):
            data.update()
        return True
    except Exception:
        return False


def siren_child_objects(si):
    o = siren_obj(si)
    if not o:
        return []
    return iter_siren_object_hierarchy(o)


def apply_siren_child_object_compensation(si, scalar):
    val = max(0.000001, float(scalar))
    for child in siren_child_objects(si):
        _store_rest_loc(child)
        rest_loc = _rest_loc(child)
        rest_rot = _rest_rot(child)
        rest_scale = _rest_scale(child)
        child.rotation_mode = "XYZ"
        child.location = _vector_div_scalar(rest_loc, val)
        child.rotation_euler = rest_rot
        child.scale = (rest_scale[0] / val, rest_scale[1] / val, rest_scale[2] / val)


def apply_siren_child_pose_compensation(scene, si, scalar):
    val = max(0.000001, float(scalar))
    arm, _pb = siren_pose_bone(scene, si)
    if not arm:
        return
    for child in rotator_preview_pose_bones(scene, si):
        _store_rest_pose_bone(arm, child)
        rest_loc, rest_rot, rest_sc = _rest_pose_bone(arm, child)
        child.rotation_mode = "XYZ"
        child.location = _vector_div_scalar(rest_loc, val)
        child.rotation_euler = rest_rot
        child.scale = (rest_sc[0] / val, rest_sc[1] / val, rest_sc[2] / val)


def restore_siren_default_state(scene, si):
    restored = 0
    o = siren_obj(si)
    if o:
        _store_rest_loc(o)
        o.rotation_mode = "XYZ"
        o.location = _rest_loc(o)
        o.rotation_euler = _rest_rot(o)
        o.scale = _rest_scale(o)
        restored += 1
        for child in iter_siren_object_hierarchy(o):
            if any(k in child for k in ("_nels_rest_loc", "_nels_rest_rot", "_nels_rest_scale")):
                child.rotation_mode = "XYZ"
                child.location = _rest_loc(child)
                child.rotation_euler = _rest_rot(child)
                child.scale = _rest_scale(child)
                restored += 1

    arm, pb = siren_pose_bone(scene, si)
    if arm and pb:
        _store_rest_pose_bone(arm, pb)
        rest_loc, rest_rot, rest_sc = _rest_pose_bone(arm, pb)
        pb.rotation_mode = "XYZ"
        pb.location = rest_loc
        pb.rotation_euler = rest_rot
        pb.scale = rest_sc
        restored += 1
        for child in rotator_preview_pose_bones(scene, si):
            key = _pose_rest_key(child.name)
            if key in arm:
                rest_loc, rest_rot, rest_sc = _rest_pose_bone(arm, child)
                child.rotation_mode = "XYZ"
                child.location = rest_loc
                child.rotation_euler = rest_rot
                child.scale = rest_sc
                restored += 1
    return restored


def bake_siren_scale_state(scene, s, si, mode):
    o = siren_obj(si)
    if not o:
        return False, "No linked siren mesh found for the selected siren"

    target_scalar = shown_sim_scale(s, si) if mode == "ON" else hidden_sim_scale(s, si)
    if target_scalar <= 0.0:
        return False, "Scale Factor must be above 0 before baking the hidden siren scale"

    arm, pb = siren_pose_bone(scene, si)
    bone_driven = siren_object_driven_by_bone(scene, si)

    current_effective = Vector((float(o.scale[0]), float(o.scale[1]), float(o.scale[2])))
    if bone_driven and pb:
        current_effective = _vector_mul(current_effective, Vector((float(pb.scale[0]), float(pb.scale[1]), float(pb.scale[2]))))

    factor_vec = _vector_div_scalar(current_effective, target_scalar)
    baked = 1 if scale_object_data(o, factor_vec) else 0

    o.rotation_mode = "XYZ"
    o.scale = (1.0, 1.0, 1.0)
    _store_rest_loc(o, force=True)

    if arm and pb:
        pb.rotation_mode = "XYZ"
        pb.scale = (1.0, 1.0, 1.0)
        _store_rest_pose_bone(arm, pb, force=True)

    apply_sim_state(scene, s, si, mode)

    if hasattr(scene, "view_layers"):
        try:
            bpy.context.view_layer.update()
        except Exception:
            pass

    queue_preview_refresh_feedback(scene)
    mark_preview_dirty(scene=scene, immediate=False)
    return True, f"Baked {mode.lower()} scale for siren{si.index} on {max(1, baked)} object(s)"



def _pose_rest_key(bone_name):
    return f"_nels_rest_pose_{bone_name}"


def _store_rest_pose_bone(arm, pb, force=False):
    key = _pose_rest_key(pb.name)
    if (not force) and (key in arm):
        return
    old_mode = pb.rotation_mode
    try:
        pb.rotation_mode = "XYZ"
        arm[key] = [
            float(pb.location[0]),
            float(pb.location[1]),
            float(pb.location[2]),
            float(pb.rotation_euler[0]),
            float(pb.rotation_euler[1]),
            float(pb.rotation_euler[2]),
            float(pb.scale[0]),
            float(pb.scale[1]),
            float(pb.scale[2]),
        ]
    finally:
        pb.rotation_mode = old_mode


def _rest_pose_bone(arm, pb):
    key = _pose_rest_key(pb.name)
    data = arm.get(key)
    if isinstance(data, (list, tuple)) and len(data) == 9:
        loc = Vector((float(data[0]), float(data[1]), float(data[2])))
        rot = Vector((float(data[3]), float(data[4]), float(data[5])))
        sc = Vector((float(data[6]), float(data[7]), float(data[8])))
        return loc, rot, sc
    _store_rest_pose_bone(arm, pb)
    data = arm.get(key, [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 1.0, 1.0, 1.0])
    loc = Vector((float(data[0]), float(data[1]), float(data[2])))
    rot = Vector((float(data[3]), float(data[4]), float(data[5])))
    sc = Vector((float(data[6]), float(data[7]), float(data[8])))
    return loc, rot, sc


def apply_sim_state(scene, s, si, mode, turns=0.0, keyframe_frame=None):
    o = siren_obj(si)
    arm, pb = siren_pose_bone(scene, si)
    sc = shown_sim_scale(s, si) if mode == "ON" else hidden_sim_scale(s, si)
    applied = False

    is_rotator = getattr(si, "siren_type", "FLASHER") == "ROTATOR"
    object_driven_by_bone = bool(o and arm and pb and o.parent == arm and o.parent_type == "BONE" and o.parent_bone == pb.name)

    if o:
        _store_rest_loc(o)
        rest_loc = _rest_loc(o)
        rest_rot = _rest_rot(o)
        rest_scale = _rest_scale(o)

        o.rotation_mode = "XYZ"
        o.rotation_euler = rest_rot
        if is_rotator and not (arm and pb):
            rot_sign = 1.0 if getattr(si, "rotator_clockwise", True) else -1.0
            o.rotation_euler[2] = rest_rot[2] + rot_sign * turns * math.tau

        if object_driven_by_bone or (arm and pb and is_rotator):
            o.location = rest_loc
            o.scale = rest_scale
        else:
            off_loc = target_sim_loc(o, "OFF")
            if o.parent_type != "BONE" and arm and pb:
                off_loc = arm.matrix_world @ pb.matrix.translation
            o.location = rest_loc if mode == "ON" else off_loc
            o.scale = (rest_scale[0] * sc, rest_scale[1] * sc, rest_scale[2] * sc)

        if keyframe_frame is not None:
            o.keyframe_insert(data_path="scale", frame=keyframe_frame)
            o.keyframe_insert(data_path="location", frame=keyframe_frame)
            if is_rotator and not (arm and pb):
                o.keyframe_insert(data_path="rotation_euler", index=2, frame=keyframe_frame)
        applied = True

    if arm and pb:
        _store_rest_pose_bone(arm, pb)
        rest_loc, rest_rot, rest_sc = _rest_pose_bone(arm, pb)
        pb.rotation_mode = "XYZ"
        pb.location = rest_loc
        pb.rotation_euler = rest_rot
        if is_rotator:
            rot_sign = 1.0 if getattr(si, "rotator_clockwise", True) else -1.0
            pb.rotation_euler = (rest_rot[0], rest_rot[1], rest_rot[2] + rot_sign * turns * math.tau)
        pb.scale = (rest_sc[0] * sc, rest_sc[1] * sc, rest_sc[2] * sc)

        if keyframe_frame is not None:
            pb.keyframe_insert(data_path="location", frame=keyframe_frame)
            pb.keyframe_insert(data_path="scale", frame=keyframe_frame)
            if is_rotator:
                pb.keyframe_insert(data_path="rotation_euler", index=2, frame=keyframe_frame)
        applied = True

    if o:
        apply_siren_child_object_compensation(si, sc)
    if arm and pb:
        apply_siren_child_pose_compensation(scene, si, sc)

    return applied


def _ensure_cycles_fcurve(fc):
    if not fc:
        return
    for m in fc.modifiers:
        if m.type == "CYCLES":
            return
    mod = fc.modifiers.new(type="CYCLES")
    mod.mode_before = "REPEAT"
    mod.mode_after = "REPEAT"


def _iter_action_fcurves(action):
    if not action:
        return

    # Blender <= 4.x API.
    legacy = getattr(action, "fcurves", None)
    if legacy is not None:
        for fc in legacy:
            yield fc
        return

    # Blender 5.x layered Action API.
    for layer in getattr(action, "layers", []):
        for strip in getattr(layer, "strips", []):
            for bag in getattr(strip, "channelbags", []):
                for fc in getattr(bag, "fcurves", []):
                    yield fc

def _clear_cycles_modifiers(action, path_predicate):
    for fc in _iter_action_fcurves(action):
        data_path = str(getattr(fc, "data_path", ""))
        if not path_predicate(data_path):
            continue
        try:
            for m in list(fc.modifiers):
                if m.type == "CYCLES":
                    fc.modifiers.remove(m)
        except Exception:
            pass


def _set_preview_key_interpolation(scene, si):
    def _set_interp(fc, mode):
        try:
            for kp in fc.keyframe_points:
                kp.interpolation = mode
        except Exception:
            pass

    o = siren_obj(si)
    if o and o.animation_data and o.animation_data.action:
        for fc in _iter_action_fcurves(o.animation_data.action):
            if fc.data_path in {"location", "scale"}:
                _set_interp(fc, "CONSTANT")
            elif si.siren_type == "ROTATOR" and fc.data_path == "rotation_euler" and int(getattr(fc, "array_index", -1)) == 2:
                _set_interp(fc, "LINEAR")

    if getattr(si, "siren_type", "FLASHER") == "ROTATOR":
        for target in rotator_preview_targets(si):
            if not target or target == o:
                continue
            act = getattr(getattr(target, "animation_data", None), "action", None)
            if not act:
                continue
            for fc in _iter_action_fcurves(act):
                if fc.data_path == "rotation_euler" and int(getattr(fc, "array_index", -1)) == 2:
                    _set_interp(fc, "LINEAR")

    arm, pb = siren_pose_bone(scene, si)
    if arm and pb and arm.animation_data and arm.animation_data.action:
        target_bones = {pb.name}
        if getattr(si, "siren_type", "FLASHER") == "ROTATOR":
            target_bones.update(child.name for child in rotator_preview_pose_bones(scene, si))

        for fc in _iter_action_fcurves(arm.animation_data.action):
            path = str(getattr(fc, "data_path", ""))
            prefix = 'pose.bones["'
            if not path.startswith(prefix):
                continue
            bone_name = path[len(prefix):].split('"]', 1)[0]
            if bone_name not in target_bones:
                continue
            if path.endswith(".location") or path.endswith(".scale"):
                _set_interp(fc, "CONSTANT")
            elif si.siren_type == "ROTATOR" and path.endswith(".rotation_euler") and int(getattr(fc, "array_index", -1)) == 2:
                _set_interp(fc, "LINEAR")


def preview_step_frames(bpm, fps):
    bpm_val = max(1.0, float(bpm))
    fps_val = max(1.0, float(fps))
    return max(0.01, (60.0 / bpm_val) * fps_val)


def preview_cycle_frames(bpm, fps, bit_count=32):
    return preview_step_frames(bpm, fps) * max(1, int(bit_count))


def start_delay_frames(bpm, fps, si):
    try:
        delay = max(0.0, float(getattr(si, "start_delay", 0.0) or 0.0))
    except Exception:
        delay = 0.0
    return delay * preview_step_frames(bpm, fps)

def ensure_siren_preview_cycles(scene, si):
    o = siren_obj(si)
    if o and o.animation_data and o.animation_data.action:
        act = o.animation_data.action
        for fc in _iter_action_fcurves(act):
            if fc.data_path in {"location", "scale", "rotation_euler"}:
                _ensure_cycles_fcurve(fc)

    if getattr(si, "siren_type", "FLASHER") == "ROTATOR":
        for target in rotator_preview_targets(si):
            if not target or target == o:
                continue
            act = getattr(getattr(target, "animation_data", None), "action", None)
            if not act:
                continue
            for fc in _iter_action_fcurves(act):
                if fc.data_path == "rotation_euler" and int(getattr(fc, "array_index", -1)) == 2:
                    _ensure_cycles_fcurve(fc)

    arm, pb = siren_pose_bone(scene, si)
    if arm and pb and arm.animation_data and arm.animation_data.action:
        target_bones = {pb.name}
        if getattr(si, "siren_type", "FLASHER") == "ROTATOR":
            target_bones.update(child.name for child in rotator_preview_pose_bones(scene, si))
        act = arm.animation_data.action
        for fc in _iter_action_fcurves(act):
            path = str(getattr(fc, "data_path", ""))
            prefix = 'pose.bones["'
            if not path.startswith(prefix):
                continue
            bone_name = path[len(prefix):].split('"]', 1)[0]
            if bone_name not in target_bones:
                continue
            if path.endswith(".location") or path.endswith(".scale") or path.endswith(".rotation_euler"):
                _ensure_cycles_fcurve(fc)
def rot_speed(bpm, si):
    if si.rotator_speed_mode == "CUSTOM":
        return float(bpm) / 100.0 * (max(0.0, si.rotator_custom_percent) / 6.25)
    return float(bpm) / 100.0 * ROT_SPEED.get(si.rotator_speed_mode, 1.0)


def rotator_cycle_frames(bpm, fps, si):
    rpm = max(0.000001, float(rot_speed(bpm, si)))
    fps_val = max(1.0, float(fps))
    return max(1.0, (60.0 / rpm) * fps_val)


def siren_base_color_rgb(s, si):
    if si.color_mode == "PRESET":
        c = get_color(s, si.color_preset)
        return color_to_rgb(c.value) if c else (1.0, 0.0, 0.0)
    return tuple(si.custom_color)


def color_hex(s, si):
    if si.color_mode == "PRESET":
        c = get_color(s, si.color_preset)
        return clean_color_value(c.value) if c else "0xFFFF0000"
    return rgb_to_color(si.custom_color)

def pattern_triplet(s, si):
    if si.pattern_source == "CUSTOM":
        bits = repeat_32(si.custom_bits)
        return bits, bits_to_int(bits), si.custom_visibility
    p = get_pattern(s, si.pattern_choice)
    if not p:
        return "0" * 32, 0, "BOTH"
    bits = repeat_32(p.bits)
    return bits, bits_to_int(bits), p.visibility


def siren_is_active(si):
    if not si:
        return False

    has_object = bool(si.object_name and si.object_name in bpy.data.objects)
    has_bone = False
    try:
        scene = getattr(bpy.context, "scene", None)
        arm, pb = siren_pose_bone(scene, si)
        has_bone = bool(arm and pb)
    except Exception:
        has_bone = False
    return has_object or has_bone

def siren_has_output(s, si):
    if not s or not si:
        return False
    _, seq, vis = pattern_triplet(s, si)
    if seq == 0:
        return False
    if si.siren_type == "ROTATOR":
        return vis in {"BOTH", "ROTATOR"}
    return vis in {"BOTH", "FLASHER"}


def ensure_defaults(s):
    if not s.patterns:
        data = load_global_library_data()
        loaded = False
        pats = data.get("patterns", []) if isinstance(data, dict) else []
        if isinstance(pats, list) and pats:
            for pd in pats:
                if not isinstance(pd, dict):
                    continue
                p = s.patterns.add()
                p.name = str(pd.get("name", "Pattern") or "Pattern")
                p.visibility = "FLASHER" if pd.get("visibility", "BOTH") == "FLASHER" else "BOTH"
                p.bits = clean_bits(pd.get("bits", int_to_bits(pd.get("value", 0)))) or "0"
                p.value = str(parse_u32(pd.get("value", bits_to_int(p.bits))))
                p.allow_duplicate = bool(pd.get("allow_duplicate", False))
            loaded = bool(s.patterns)

        if not loaded:
            populate_default_patterns(s)

    migrate_legacy_default_patterns(s)

    ensure_off_pattern(s)
    if s.patterns:
        s.active_pattern = min(max(0, s.active_pattern), len(s.patterns) - 1)
    save_global_library(s)


def ensure_off_pattern(s):
    for p in s.patterns:
        if (p.name or "").strip().lower() == "off":
            if not hasattr(p, "allow_duplicate"):
                continue
            return
    p = s.patterns.add()
    p.name = "Off"
    p.visibility = "BOTH"
    p.bits = "0"
    p.value = "0"
    p.allow_duplicate = False


def ensure_default_color_entries(s):
    if not s:
        return False
    changed = False
    existing = {(str(getattr(c, "name", "") or "").strip().lower(), clean_color_value(getattr(c, "value", "0xFFFF0000"))) for c in getattr(s, "colors", [])}
    existing_values = {clean_color_value(getattr(c, "value", "0xFFFF0000")) for c in getattr(s, "colors", [])}
    for _key, label, value in COLOR_ITEMS:
        sig = (label.strip().lower(), clean_color_value(value))
        if sig in existing or sig[1] in existing_values:
            continue
        c = s.colors.add()
        c.name = label
        c.value = clean_color_value(value)
        c.rgb = color_to_rgb(c.value)
        existing.add(sig)
        existing_values.add(sig[1])
        changed = True
    return changed


def ensure_color_defaults(s):
    loaded = bool(getattr(s, "colors", None))
    if not loaded:
        data = load_global_library_data()
        cols = data.get("colors", []) if isinstance(data, dict) else []
        if isinstance(cols, list) and cols:
            for cd in cols:
                if not isinstance(cd, dict):
                    continue
                c = s.colors.add()
                c.name = str(cd.get("name", "Colour") or "Colour")
                c.value = clean_color_value(cd.get("value", "0xFFFF0000"))
                c.rgb = color_to_rgb(c.value)
            loaded = bool(s.colors)

    if not loaded:
        for name, value in DEFAULT_COLOR_LIBRARY:
            c = s.colors.add()
            c.name = name
            c.value = clean_color_value(value)
            c.rgb = color_to_rgb(c.value)

    changed = ensure_default_color_entries(s)
    s.active_color = min(max(0, s.active_color), max(0, len(s.colors) - 1)) if s.colors else 0
    if changed or not loaded:
        save_global_library(s)


def ensure_other_attributes_defaults(s):
    if not s or s.other_attributes:
        return

    defaults = [
        ("Scale Factor 2", "0.5"),
        ("Scale Factor 10", "0.1"),
        ("Scale Factor 100", "0.01"),
    ]
    for disp, ret in defaults:
        a = s.other_attributes.add()
        a.display_value = disp
        a.return_value = ret
    s.active_other_attribute = 0


def add_siren(s, si, idx):
    si.index = idx
    si.name = f"siren{idx}"
    si.enabled = False
    si.siren_type = "FLASHER"
    si.rotator_speed_mode = "P50"
    si.rotator_custom_percent = 50.0
    si.rotator_clockwise = True
    si.pattern_source = "LIBRARY"
    si.pattern_choice = off_pattern_key(s)
    si.custom_visibility = "BOTH"
    si.custom_bits = "0"
    si.custom_value = "0"
    si.color_mode = "PRESET"
    si.color_preset = white_color_key(s)
    si.custom_color = (1.0, 1.0, 1.0)
    si.flash_preview = True
    si.direction_mode = "PRESET"
    si.direction_preset = "FRONT"
    si.scale_mode = "PRESET"
    si.scale_preset = "SCALE_50"
    si.custom_scale = 0.5
    si.sync_to_bpm = True
    si.flash = True
    si.light = False
    si.spot_light = False
    si.cast_shadows = False
    si.light_group = 1
    si.start_delay = 0.0
    si.light_speed = 0.0
    si.light_multiples = 2
    si.corona_intensity = 0.5
    si.corona_size = 0.0
    si.corona_pull = 0.00000001
    si.light_intensity = 0.5
    si.corona_face_camera = False
    si.object_name = ""
    si.anchor_name = ""
    si.bone_name = ""
    sync_siren_selector_controls(si)


def ensure_sirens(s, count):
    count = max(0, min(MAX_SIRENS, int(count)))
    while len(s.sirens) < count:
        i = len(s.sirens) + 1
        si = s.sirens.add()
        add_siren(s, si, i)
    while len(s.sirens) > count:
        s.sirens.remove(len(s.sirens) - 1)
    s.siren_count = count
    s.active_siren = min(s.active_siren, max(0, count - 1))
    for i, si in enumerate(s.sirens, start=1):
        si.index = i
        si.name = f"siren{i}"
    if hasattr(s, "preview_dirty"):
        s.preview_dirty = True



def _sync_pattern_bits(pg):
    bits = repeat_32(pg.bits)
    val = str(bits_to_int(bits))
    if pg.bits != bits:
        pg.bits = bits
    if pg.value != val:
        pg.value = val


def _sync_pattern_value(pg):
    val = str(parse_u32(pg.value))
    bits = int_to_bits(val)
    if pg.value != val:
        pg.value = val
    if pg.bits != bits:
        pg.bits = bits


def update_pattern_bits(self, context):
    scene = getattr(context, "scene", None) if context else getattr(bpy.context, "scene", None)
    _sync_pattern_bits(self)
    save_library_from_context(context)
    queue_preview_refresh_feedback(scene)
    mark_preview_dirty(context, scene=scene, immediate=False)


def update_pattern_value(self, context):
    scene = getattr(context, "scene", None) if context else getattr(bpy.context, "scene", None)
    _sync_pattern_value(self)
    save_library_from_context(context)
    queue_preview_refresh_feedback(scene)
    mark_preview_dirty(context, scene=scene, immediate=False)


def update_pattern_meta(self, context):
    scene = getattr(context, "scene", None) if context else getattr(bpy.context, "scene", None)
    save_library_from_context(context)
    queue_preview_refresh_feedback(scene)
    mark_preview_dirty(context, scene=scene, immediate=False)


def update_color_name(self, context):
    save_library_from_context(context)


def _sync_siren_bits(si):
    bits = repeat_32(si.custom_bits)
    val = str(bits_to_int(bits))
    if si.custom_bits != bits:
        si.custom_bits = bits
    if si.custom_value != val:
        si.custom_value = val


def _sync_siren_value(si):
    val = str(parse_u32(si.custom_value))
    bits = int_to_bits(val)
    if si.custom_value != val:
        si.custom_value = val
    if si.custom_bits != bits:
        si.custom_bits = bits


def update_siren_bits(self, context):
    scene = getattr(context, "scene", None) if context else getattr(bpy.context, "scene", None)
    _sync_siren_bits(self)
    queue_preview_refresh_feedback(scene)
    mark_preview_dirty(context, scene=scene, immediate=False)


def update_siren_value(self, context):
    scene = getattr(context, "scene", None) if context else getattr(bpy.context, "scene", None)
    _sync_siren_value(self)
    queue_preview_refresh_feedback(scene)
    mark_preview_dirty(context, scene=scene, immediate=False)

PREVIEW_OFF_RGB = (0.18, 0.18, 0.18)


def _emissive_level(rgb, gain):
    g = max(0.0, float(gain))
    return tuple(max(0.0, min(1.0, float(c) * g)) for c in rgb)


def _preview_lit_color(rgb, intensity=1.0):
    base = tuple(max(0.0, min(1.0, float(c))) for c in rgb)
    peak = max(base) if base else 0.0
    if peak > 0.000001:
        vivid = tuple(min(1.0, c / peak) for c in base)
    else:
        vivid = (1.0, 1.0, 1.0)
    t = max(0.0, min(1.0, float(intensity)))
    return tuple((PREVIEW_OFF_RGB[i] * (1.0 - t)) + (vivid[i] * t) for i in range(3))


def _emissive_color(rgb, lit):
    if lit:
        return _preview_lit_color(rgb, 1.0)
    return PREVIEW_OFF_RGB


def apply_sollumz_emissive_multiplier(obj, value=10.0):
    if not obj or getattr(obj, "type", "") != "MESH":
        return
    mats = getattr(getattr(obj, "data", None), "materials", None)
    if not mats:
        return
    try:
        target = float(value)
    except Exception:
        target = 10.0

    for mat in mats:
        if mat is None:
            continue
        try:
            sp = getattr(mat, "shader_properties", None)
            if sp is not None:
                if hasattr(sp, "emissive_multiplier"):
                    setattr(sp, "emissive_multiplier", target)
                elif hasattr(sp, "emissiveMultiplier"):
                    setattr(sp, "emissiveMultiplier", target)

            if hasattr(mat, "emissive_multiplier"):
                setattr(mat, "emissive_multiplier", target)
            if hasattr(mat, "emissiveMultiplier"):
                setattr(mat, "emissiveMultiplier", target)

            if "emissiveMultiplier" in mat:
                mat["emissiveMultiplier"] = target
        except Exception:
            pass


def _head_tail_preview(s, key, base_rgb, preview_on=True):
    if not s:
        return tuple(base_rgb)
    if not preview_on:
        return tuple(base_rgb)
    scn = getattr(bpy.context, "scene", None)
    p = get_pattern(s, key)
    bits = repeat_32(p.bits) if p else ("0" * 32)
    return _emissive_color(base_rgb, preview_pattern_is_on(bits, s.bpm, scene=scn))


def get_left_head_preview(self):
    try:
        return tuple(self.left_head_preview_cache)
    except Exception:
        return _head_tail_preview(self, self.left_head, (1.0, 1.0, 1.0), getattr(self, "head_tail_preview", True))


def get_right_head_preview(self):
    try:
        return tuple(self.right_head_preview_cache)
    except Exception:
        return _head_tail_preview(self, self.right_head, (1.0, 1.0, 1.0), getattr(self, "head_tail_preview", True))


def get_left_tail_preview(self):
    try:
        return tuple(self.left_tail_preview_cache)
    except Exception:
        return _head_tail_preview(self, self.left_tail, (1.0, 0.0, 0.0), getattr(self, "head_tail_preview", True))


def get_right_tail_preview(self):
    try:
        return tuple(self.right_tail_preview_cache)
    except Exception:
        return _head_tail_preview(self, self.right_tail, (1.0, 0.0, 0.0), getattr(self, "head_tail_preview", True))


def update_rotator_settings(self, context):
    scene = getattr(context, "scene", None) if context else None
    s = getattr(scene, "nels", None) if scene else None
    if self.siren_type == "ROTATOR":
        if s:
            off_key = off_pattern_key(s)
            if normalize_pattern_key(self.pattern_choice) == off_key:
                self.pattern_choice = find_pattern_key_by_name(s, "Single Sweep")
        bpm = getattr(s, "bpm", 800) if s else 800
        self.light_speed = rot_speed(bpm, self)
    mark_preview_dirty(context, scene=scene)


def update_siren_type(self, context):
    if self.siren_type == "ROTATOR":
        self.pattern_source = "LIBRARY"
    update_rotator_settings(self, context)
    sync_siren_selector_controls(self)
    mark_preview_dirty(context)


def update_bpm(self, context):
    for si in self.sirens:
        if si.siren_type == "ROTATOR":
            try:
                si.light_speed = rot_speed(self.bpm, si)
            except Exception:
                pass
    mark_preview_dirty(context)



def preview_updates_suspended():
    return _PREVIEW_UPDATE_SUSPEND > 0


def suspend_preview_updates():
    global _PREVIEW_UPDATE_SUSPEND
    _PREVIEW_UPDATE_SUSPEND += 1


def resume_preview_updates():
    global _PREVIEW_UPDATE_SUSPEND
    _PREVIEW_UPDATE_SUSPEND = max(0, _PREVIEW_UPDATE_SUSPEND - 1)


def tag_all_ui_redraw():
    wm = getattr(bpy.context, "window_manager", None)
    if not wm:
        return
    try:
        for win in wm.windows:
            screen = getattr(win, "screen", None)
            if not screen:
                continue
            for area in screen.areas:
                try:
                    area.tag_redraw()
                except Exception:
                    pass
                for region in getattr(area, "regions", []):
                    try:
                        region.tag_redraw()
                    except Exception:
                        pass
    except Exception:
        pass


def tag_preview_ui_redraw():
    wm = getattr(bpy.context, "window_manager", None)
    if not wm:
        return
    try:
        for win in wm.windows:
            screen = getattr(win, "screen", None)
            if not screen:
                continue
            for area in screen.areas:
                if getattr(area, "type", "") != "VIEW_3D":
                    continue
                for region in getattr(area, "regions", []):
                    if getattr(region, "type", "") != "UI":
                        continue
                    try:
                        region.tag_redraw()
                    except Exception:
                        pass
    except Exception:
        pass


def preview_cache_signature(scene):
    s = getattr(scene, "nels", None) if scene else None
    if not s:
        return ""

    values = []
    for prop in ("left_head_preview_cache", "right_head_preview_cache", "left_tail_preview_cache", "right_tail_preview_cache"):
        try:
            values.extend(round(float(c), 4) for c in getattr(s, prop))
        except Exception:
            values.extend((0.0, 0.0, 0.0))

    for si in s.sirens:
        try:
            values.extend(round(float(c), 4) for c in si.preview_color_cache)
        except Exception:
            values.extend((0.0, 0.0, 0.0))
    return "|".join(f"{v:.4f}" for v in values)


def preview_targets_animated(scene):
    s = getattr(scene, "nels", None) if scene else None
    if not s:
        return False

    if getattr(s, "head_tail_preview", True):
        for key in (getattr(s, "left_head", ""), getattr(s, "right_head", ""), getattr(s, "left_tail", ""), getattr(s, "right_tail", "")):
            p = get_pattern(s, key)
            bits = repeat_32(p.bits) if p else ("0" * 32)
            if "1" in bits:
                return True

    for si in s.sirens:
        if not getattr(si, "flash_preview", True):
            continue
        if getattr(si, "siren_type", "FLASHER") == "ROTATOR":
            return True
        bits, seq, vis = pattern_triplet(s, si)
        if seq and vis in {"BOTH", "FLASHER"} and "1" in bits:
            return True
    return False


def queue_preview_refresh_feedback(scene, message="Preview refresh in progress..."):
    s = getattr(scene, "nels", None) if scene else None
    if not s:
        return
    s.preview_refresh_pending = True
    s.preview_refresh_started_at = _time.time()
    s.preview_refresh_done_at = 0.0
    s.preview_refresh_signature = preview_cache_signature(scene)
    s.preview_refresh_has_motion = preview_targets_animated(scene)
    s.status_message = message
    tag_preview_ui_redraw()


def update_preview_refresh_feedback(scene):
    s = getattr(scene, "nels", None) if scene else None
    if not s:
        return False

    changed = False
    now = _time.time()
    status = str(getattr(s, "status_message", "") or "")

    if getattr(s, "preview_refresh_pending", False):
        started = float(getattr(s, "preview_refresh_started_at", now) or now)
        has_motion = bool(getattr(s, "preview_refresh_has_motion", False))
        current_signature = preview_cache_signature(scene)
        previous_signature = str(getattr(s, "preview_refresh_signature", "") or "")
        if current_signature != previous_signature or ((not has_motion) and (now - started) >= 0.25):
            s.preview_refresh_pending = False
            s.preview_refresh_signature = current_signature
            s.preview_refresh_done_at = now
            if status.startswith("Preview refresh"):
                s.status_message = "Preview refresh complete"
            changed = True
        return changed

    done_at = float(getattr(s, "preview_refresh_done_at", 0.0) or 0.0)
    if done_at > 0.0 and status == "Preview refresh complete" and (now - done_at) >= 1.0:
        s.preview_refresh_done_at = 0.0
        s.status_message = ""
        changed = True
    return changed


def mark_preview_dirty(context=None, scene=None, immediate=True):
    sc = scene
    if sc is None and context is not None:
        sc = getattr(context, "scene", None)
    if sc is None:
        sc = getattr(bpy.context, "scene", None)
    s = getattr(sc, "nels", None) if sc else None
    if not s:
        return
    s.preview_dirty = True
    if not timeline_playing():
        try:
            s.preview_time_origin = _time.time()
        except Exception:
            pass
    if getattr(s, "auto_timeline_preview", False) and (not preview_updates_suspended()):
        s.auto_timeline_pending = True
        s.auto_timeline_requested_at = _time.time()
        try:
            rebuild_auto_timeline_preview(sc)
        except Exception:
            pass
    if preview_updates_suspended() or (not immediate):
        tag_preview_ui_redraw()
        return
    try:
        refresh_siren_preview_cache(sc)
    except Exception:
        pass
    tag_preview_ui_redraw()


def update_preview_only(self, context):
    mark_preview_dirty(context)


def update_pattern_preview_only(self, context):
    scene = getattr(context, "scene", None) if context else getattr(bpy.context, "scene", None)
    queue_preview_refresh_feedback(scene)
    mark_preview_dirty(context, scene=scene, immediate=False)



def apply_car_light_simulation(scene, s, blink_indicators=False, now=None):
    if not scene or not s:
        return 0

    sim_now = playback_seconds(scene=scene, now=now)

    blink_on = True
    if blink_indicators and (s.car_left_indicator_on or s.car_right_indicator_on):
        ts = sim_now
        blink_on = ((ts * 1.5) % 1.0) < 0.5  # Standard-like turn signal cadence.

    # Side-aware head/tail flashing based on configured lightbar flash patterns.
    head_l_on = bool(s.car_headlights_on) and pattern_is_on(s, s.left_head, s.bpm, now=sim_now, scene=scene)
    head_r_on = bool(s.car_headlights_on) and pattern_is_on(s, s.right_head, s.bpm, now=sim_now, scene=scene)
    tail_l_on = bool(s.car_taillights_on) and pattern_is_on(s, s.left_tail, s.bpm, now=sim_now, scene=scene)
    tail_r_on = bool(s.car_taillights_on) and pattern_is_on(s, s.right_tail, s.bpm, now=sim_now, scene=scene)

    left_on = bool(s.car_left_indicator_on) and blink_on
    right_on = bool(s.car_right_indicator_on) and blink_on

    touched = set()

    def _apply(objs, show):
        for obj in objs:
            set_object_visible(obj, show)
            touched.add(obj.name)

    heads = scene_objects_by_keywords(scene, HEADLIGHT_KEYS)
    tails = scene_objects_by_keywords(scene, TAILLIGHT_KEYS)
    hl, hr, hc = split_side_objects(heads)
    tl, tr, tc = split_side_objects(tails)

    _apply(hl, head_l_on)
    _apply(hr, head_r_on)
    _apply(hc, bool(head_l_on or head_r_on))

    _apply(tl, tail_l_on)
    _apply(tr, tail_r_on)
    _apply(tc, bool(tail_l_on or tail_r_on))

    _apply(scene_objects_by_keywords(scene, LEFT_INDICATOR_KEYS), left_on)
    _apply(scene_objects_by_keywords(scene, RIGHT_INDICATOR_KEYS), right_on)
    _apply(scene_objects_by_keywords(scene, EXTRA_LIGHT_KEYS), bool(s.car_extra_lights_on))
    return len(touched)


def update_car_light_toggle(self, context):
    scene = getattr(context, "scene", None) if context else getattr(bpy.context, "scene", None)
    s = getattr(scene, "nels", None) if scene else None
    if not s:
        return
    apply_car_light_simulation(scene, s, blink_indicators=True, now=playback_seconds(scene=scene))


def timeline_playing():
    wm = getattr(bpy.context, "window_manager", None)
    if not wm:
        return False
    try:
        for win in wm.windows:
            screen = getattr(win, "screen", None)
            if screen and getattr(screen, "is_animation_playing", False):
                return True
    except Exception:
        return False
    return False


def set_scene_warning(scene, msg):
    s = getattr(scene, "nels", None) if scene else None
    if s and hasattr(s, "status_message"):
        s.status_message = str(msg or "")


def active_siren_direction_warning(scene):
    s = getattr(scene, "nels", None) if scene else None
    if not s or not s.sirens:
        return ""

    idx = max(0, min(int(s.active_siren), len(s.sirens) - 1))
    si = s.sirens[idx]
    if not siren_obj(si):
        return ""

    arm, pb = siren_pose_bone(scene, si)
    has_bone = bool(arm and pb and getattr(si, "bone_name", ""))
    if has_bone:
        return ""
    return f"Warning: Siren {si.index} has no linked bone for direction sync"


def refresh_direction_warning(scene):
    s = getattr(scene, "nels", None) if scene else None
    if not s:
        return
    msg = str(getattr(s, "status_message", "") or "")
    if msg.startswith("Warning: Siren ") and msg.endswith(" has no linked bone for direction sync"):
        s.status_message = ""


def apply_siren_direction_to_bone(scene, si, set_warning=True):
    if not scene or not si:
        return False

    arm, pb = siren_pose_bone(scene, si)
    if not arm or not pb:
        if set_warning:
            set_scene_warning(scene, f"Warning: Siren {si.index} has no linked bone for direction sync")
        return False

    ang = dir_val(si)
    vec = Vector((math.sin(ang), math.cos(ang), 0.0))
    if vec.length < 0.000001:
        vec = Vector((0.0, 1.0, 0.0))

    old_active = getattr(bpy.context.view_layer.objects, "active", None)
    old_mode = getattr(bpy.context, "mode", "OBJECT")

    try:
        if old_mode != "OBJECT":
            bpy.ops.object.mode_set(mode="OBJECT")
        bpy.ops.object.select_all(action="DESELECT")
        arm.select_set(True)
        bpy.context.view_layer.objects.active = arm
        bpy.ops.object.mode_set(mode="EDIT")

        eb = arm.data.edit_bones.get(pb.name) or arm.data.edit_bones.get(si.bone_name)
        if not eb:
            bpy.ops.object.mode_set(mode="OBJECT")
            if set_warning:
                set_scene_warning(scene, f"Warning: Could not find linked bone for siren {si.index}")
            return False

        head = eb.head.copy()
        length = (eb.tail - eb.head).length
        if length < 0.000001:
            length = 0.05
        eb.tail = head + vec.normalized() * length

        bpy.ops.object.mode_set(mode="OBJECT")
        pose_bone = arm.pose.bones.get(eb.name)
        if pose_bone:
            _store_rest_pose_bone(arm, pose_bone, force=True)

        if set_warning:
            set_scene_warning(scene, "")
        return True
    except Exception:
        if set_warning:
            set_scene_warning(scene, f"Warning: Failed to apply direction to siren {si.index} bone")
        return False
    finally:
        try:
            if old_active and old_active.name in bpy.data.objects:
                bpy.context.view_layer.objects.active = old_active
        except Exception:
            pass
        try:
            if old_mode != "OBJECT" and getattr(bpy.context, "mode", "OBJECT") == "OBJECT":
                bpy.ops.object.mode_set(mode=old_mode)
        except Exception:
            pass



def apply_all_siren_directions(scene):
    s = getattr(scene, "nels", None) if scene else None
    if not s or not s.sirens:
        return 0

    groups = {}
    for si in s.sirens:
        arm, pb = siren_pose_bone(scene, si)
        if arm and pb:
            groups.setdefault(arm.name, []).append((si, pb.name))

    if not groups:
        return 0

    updated = 0
    old_active = getattr(bpy.context.view_layer.objects, "active", None)
    old_mode = getattr(bpy.context, "mode", "OBJECT")

    try:
        if old_mode != "OBJECT":
            bpy.ops.object.mode_set(mode="OBJECT")
        bpy.ops.object.select_all(action="DESELECT")

        for arm_name, entries in groups.items():
            arm = bpy.data.objects.get(arm_name)
            if not arm or arm.type != "ARMATURE":
                continue

            bpy.ops.object.select_all(action="DESELECT")
            arm.select_set(True)
            bpy.context.view_layer.objects.active = arm
            bpy.ops.object.mode_set(mode="EDIT")

            updated_names = []
            for si, bone_name in entries:
                eb = arm.data.edit_bones.get(bone_name)
                if not eb:
                    continue
                ang = dir_val(si)
                vec = Vector((math.sin(ang), math.cos(ang), 0.0))
                if vec.length < 0.000001:
                    vec = Vector((0.0, 1.0, 0.0))
                head = eb.head.copy()
                length = (eb.tail - eb.head).length
                if length < 0.000001:
                    length = 0.05
                eb.tail = head + vec.normalized() * length
                updated_names.append(eb.name)
                updated += 1

            bpy.ops.object.mode_set(mode="OBJECT")
            for bone_name in updated_names:
                pb = arm.pose.bones.get(bone_name)
                if pb:
                    _store_rest_pose_bone(arm, pb, force=True)
    except Exception:
        return updated
    finally:
        try:
            if getattr(bpy.context, "mode", "OBJECT") != "OBJECT":
                bpy.ops.object.mode_set(mode="OBJECT")
        except Exception:
            pass
        try:
            if old_active and old_active.name in bpy.data.objects:
                bpy.context.view_layer.objects.active = old_active
        except Exception:
            pass
        try:
            if old_mode != "OBJECT" and getattr(bpy.context, "mode", "OBJECT") == "OBJECT":
                bpy.ops.object.mode_set(mode=old_mode)
        except Exception:
            pass

    return updated

def update_siren_direction(self, context):
    scene = getattr(context, "scene", None) if context else getattr(bpy.context, "scene", None)
    apply_siren_direction_to_bone(scene, self, set_warning=False)
    mark_preview_dirty(context, scene=scene)


def update_siren_bone_link(self, context):
    scene = getattr(context, "scene", None) if context else getattr(bpy.context, "scene", None)
    if self.bone_name:
        apply_siren_direction_to_bone(scene, self, set_warning=True)
    mark_preview_dirty(context, scene=scene)

def compute_siren_preview_color(scene, s, si, now=None):
    try:
        base = siren_base_color_rgb(s, si) if s else tuple(si.custom_color)
        if not getattr(si, "flash_preview", True) or not s:
            return tuple(base)

        bits, _, vis = pattern_triplet(s, si)
        ts = preview_seconds(scene=scene, now=now)

        if si.siren_type == "ROTATOR":
            if vis not in {"BOTH", "ROTATOR"}:
                return _emissive_color(base, False)
            speed = max(0.01, rot_speed(s.bpm, si))
            phase = (ts * speed * 0.5) % 1.0
            if not getattr(si, "rotator_clockwise", True):
                phase = 1.0 - phase
            sweep = 1.0 - abs(phase * 2.0 - 1.0)
            lit = sweep > 0.35
            if lit:
                intensity = 0.55 + (0.45 * sweep)
                return _preview_lit_color(base, intensity)
            return _emissive_color(base, False)

        vis_ok = vis in {"BOTH", "FLASHER"}
        bpm = max(1.0, float(getattr(s, "bpm", 800)))
        steps_per_second = bpm / 60.0
        idx = int(ts * steps_per_second) % 32
        on = bits[idx] == "1"
        return _emissive_color(base, bool(vis_ok and on))
    except Exception:
        return (1.0, 0.0, 0.0)


def get_siren_preview_color(self):
    scene = getattr(bpy.context, "scene", None)
    s = getattr(scene, "nels", None) if scene else None
    return compute_siren_preview_color(scene, s, self)


def refresh_siren_preview_cache(scene):
    s = getattr(scene, "nels", None) if scene else None
    if not s:
        return False
    ts = playback_seconds(scene=scene)
    changed = False

    head_tail = (
        ("left_head_preview_cache", _head_tail_preview(s, s.left_head, (1.0, 1.0, 1.0), getattr(s, "head_tail_preview", True))),
        ("right_head_preview_cache", _head_tail_preview(s, s.right_head, (1.0, 1.0, 1.0), getattr(s, "head_tail_preview", True))),
        ("left_tail_preview_cache", _head_tail_preview(s, s.left_tail, (1.0, 0.0, 0.0), getattr(s, "head_tail_preview", True))),
        ("right_tail_preview_cache", _head_tail_preview(s, s.right_tail, (1.0, 0.0, 0.0), getattr(s, "head_tail_preview", True))),
    )
    for prop, col in head_tail:
        try:
            if tuple(getattr(s, prop)) != tuple(col):
                setattr(s, prop, col)
                changed = True
        except Exception:
            pass

    for si in s.sirens:
        col = compute_siren_preview_color(scene, s, si, now=ts)
        try:
            if tuple(si.preview_color_cache) != tuple(col):
                si.preview_color_cache = col
                changed = True
        except Exception:
            pass
    return changed


def update_lib_color_rgb(self, context):
    v = rgb_to_color(self.rgb)
    if self.value != v:
        self.value = v
    save_library_from_context(context)


def update_lib_color_value(self, context):
    v = clean_color_value(self.value)
    if self.value != v:
        self.value = v
    rgb = color_to_rgb(v)
    if tuple(self.rgb) != rgb:
        self.rgb = rgb
    save_library_from_context(context)


class NELSPattern(PropertyGroup):
    name: StringProperty(default="Pattern", update=update_pattern_meta)
    allow_duplicate: BoolProperty(default=False, update=update_pattern_meta)
    visibility: EnumProperty(items=VISIBILITY_ITEMS, default="BOTH", update=update_pattern_meta)
    bits: StringProperty(default="00001111000011110000111100001111", maxlen=32, update=update_pattern_bits)
    value: StringProperty(default="252645135", update=update_pattern_value)


class NELSColor(PropertyGroup):
    name: StringProperty(default="Colour", update=update_color_name)
    value: StringProperty(default="0xFFFF0000", update=update_lib_color_value)
    rgb: FloatVectorProperty(subtype="COLOR", size=3, min=0.0, max=1.0, default=(1.0, 0.0, 0.0), update=update_lib_color_rgb)


class NELSOtherAttribute(PropertyGroup):
    display_value: StringProperty(default="Attribute")
    return_value: StringProperty(default="")


class NELSSiren(PropertyGroup):
    index: IntProperty(default=1, min=1, max=MAX_SIRENS)
    name: StringProperty(default="Siren 1")
    enabled: BoolProperty(default=False)

    siren_type: EnumProperty(items=SIREN_TYPES, default="FLASHER", update=update_siren_type)
    rotator_speed_mode: EnumProperty(items=ROT_SPEED_ITEMS, default="P50", update=update_rotator_settings)
    rotator_custom_percent: FloatProperty(default=50.0, min=0.0, update=update_rotator_settings)
    rotator_clockwise: BoolProperty(default=True, update=update_preview_only)

    pattern_source: EnumProperty(items=[("LIBRARY", "Saved Pattern", ""), ("CUSTOM", "Custom Pattern", "")], default="LIBRARY", update=update_pattern_preview_only)
    pattern_choice: EnumProperty(items=pattern_items, update=update_pattern_preview_only)
    pattern_select: EnumProperty(items=pattern_select_items, update=update_pattern_select)
    custom_visibility: EnumProperty(items=VISIBILITY_ITEMS, default="BOTH", update=update_pattern_preview_only)
    custom_bits: StringProperty(default="00001111000011110000111100001111", maxlen=32, update=update_siren_bits)
    custom_value: StringProperty(default="252645135", update=update_siren_value)

    color_mode: EnumProperty(items=[("PRESET", "Preset", ""), ("CUSTOM", "Custom", "")], default="PRESET")
    color_preset: EnumProperty(items=color_items)
    color_select: EnumProperty(items=color_select_items, update=update_color_select)
    custom_color: FloatVectorProperty(subtype="COLOR", size=3, min=0.0, max=1.0, default=(1.0, 1.0, 1.0))
    flash_preview: BoolProperty(default=True)
    preview_color_cache: FloatVectorProperty(subtype="COLOR", size=3, min=0.0, max=1.0, default=(0.07, 0.07, 0.07))
    preview_color: FloatVectorProperty(subtype="COLOR", size=3, min=0.0, max=1.0, get=get_siren_preview_color)

    direction_mode: EnumProperty(items=[("PRESET", "Preset", ""), ("CUSTOM", "Custom", "")], default="PRESET", update=update_siren_direction)
    direction_preset: EnumProperty(items=DIRECTION_ITEMS, default="FRONT", update=update_siren_direction)
    direction_select: EnumProperty(items=direction_select_items, update=update_direction_select)
    custom_direction: FloatProperty(default=0.0, precision=8, update=update_siren_direction)
    scale_mode: EnumProperty(items=[("PRESET", "Preset", ""), ("CUSTOM", "Custom", "")], default="PRESET", update=update_preview_only)
    scale_preset: EnumProperty(items=SCALE_ITEMS, default="SCALE_50", update=update_preview_only)
    custom_scale: FloatProperty(default=0.5, min=0.0, precision=8, update=update_preview_only)

    sync_to_bpm: BoolProperty(default=True, update=update_preview_only)

    show_advanced: BoolProperty(default=False)
    flash: BoolProperty(default=True)
    light: BoolProperty(default=False)
    spot_light: BoolProperty(default=False)
    cast_shadows: BoolProperty(default=False)
    light_group: IntProperty(default=1, min=0)
    start_delay: FloatProperty(default=0.0, precision=8)
    light_speed: FloatProperty(default=0.0, precision=8)
    light_multiples: IntProperty(default=2, min=0)
    corona_intensity: FloatProperty(default=0.5, precision=8)
    corona_size: FloatProperty(default=0.0, precision=8)
    corona_pull: FloatProperty(default=0.00000001, precision=8)
    light_intensity: FloatProperty(default=0.5, precision=8)
    corona_face_camera: BoolProperty(default=False)

    object_name: StringProperty(default="")
    anchor_name: StringProperty(default="")
    bone_name: StringProperty(default="", update=update_siren_bone_link)


class NELSSettings(PropertyGroup):
    config_name: StringProperty(default="new_lightbar")
    vehicle_name: StringProperty(name="vehicle_name", default="police")
    vehicle_id: IntProperty(name="siren_id", default=25000, min=1, soft_min=25000)
    saved_config: EnumProperty(items=saved_cfg_items)

    bpm: IntProperty(default=800, min=1, update=update_bpm)
    scale_factor_choice: EnumProperty(items=SCALE_FACTOR_PRESET_ITEMS, default="SF_2", update=update_scale_factor_choice)
    scale_factor_custom: FloatProperty(default=0.5, min=0.0, precision=8, update=update_scale_factor_custom)
    scale_factor: FloatProperty(default=0.5, min=0.0, precision=8, update=update_scale_factor_value)
    left_head: EnumProperty(items=pattern_items, update=update_pattern_preview_only)
    right_head: EnumProperty(items=pattern_items, update=update_pattern_preview_only)
    left_tail: EnumProperty(items=pattern_items, update=update_pattern_preview_only)
    right_tail: EnumProperty(items=pattern_items, update=update_pattern_preview_only)

    list_flash_preview: BoolProperty(default=True)
    head_tail_preview: BoolProperty(default=True)
    left_head_preview_cache: FloatVectorProperty(subtype="COLOR", size=3, min=0.0, max=1.0, default=(0.07, 0.07, 0.07))
    right_head_preview_cache: FloatVectorProperty(subtype="COLOR", size=3, min=0.0, max=1.0, default=(0.07, 0.07, 0.07))
    left_tail_preview_cache: FloatVectorProperty(subtype="COLOR", size=3, min=0.0, max=1.0, default=(0.07, 0.0, 0.0))
    right_tail_preview_cache: FloatVectorProperty(subtype="COLOR", size=3, min=0.0, max=1.0, default=(0.07, 0.0, 0.0))
    left_head_preview: FloatVectorProperty(subtype="COLOR", size=3, min=0.0, max=1.0, get=get_left_head_preview)
    right_head_preview: FloatVectorProperty(subtype="COLOR", size=3, min=0.0, max=1.0, get=get_right_head_preview)
    left_tail_preview: FloatVectorProperty(subtype="COLOR", size=3, min=0.0, max=1.0, get=get_left_tail_preview)
    right_tail_preview: FloatVectorProperty(subtype="COLOR", size=3, min=0.0, max=1.0, get=get_right_tail_preview)

    show_adv_main: BoolProperty(default=False)
    show_other_attributes: BoolProperty(default=False)
    use_real_lights: BoolProperty(default=True)
    time_multiplier: FloatProperty(default=1.0, precision=8)
    light_falloff_max: FloatProperty(default=100.0, precision=8)
    light_falloff_exp: FloatProperty(default=100.0, precision=8)
    light_inner_angle: FloatProperty(default=2.29061, precision=8)
    light_outer_angle: FloatProperty(default=70.0, precision=8)
    light_offset: FloatProperty(default=0.0, precision=8)
    texture_name: StringProperty(default="VehicleLight_sirenlight")
    left_head_mult: IntProperty(default=1, min=0)
    right_head_mult: IntProperty(default=1, min=0)
    left_tail_mult: IntProperty(default=1, min=0)
    right_tail_mult: IntProperty(default=1, min=0)

    patterns: CollectionProperty(type=NELSPattern)
    active_pattern: IntProperty(default=0)

    colors: CollectionProperty(type=NELSColor)
    active_color: IntProperty(default=0)

    other_attributes: CollectionProperty(type=NELSOtherAttribute)
    active_other_attribute: IntProperty(default=0)

    sirens: CollectionProperty(type=NELSSiren)
    active_siren: IntProperty(default=0)
    siren_count: IntProperty(default=0, min=0, max=MAX_SIRENS)

    armature_name: StringProperty(default="")

    pattern_library_path: StringProperty(default=os.path.join(os.path.expanduser("~"), "Downloads", "flash_patterns.json"), subtype="FILE_PATH")

    wheel_all_axes_degrees: FloatProperty(default=25.0, precision=3)
    car_headlights_on: BoolProperty(default=False, update=update_car_light_toggle)
    car_taillights_on: BoolProperty(default=False, update=update_car_light_toggle)
    car_left_indicator_on: BoolProperty(default=False, update=update_car_light_toggle)
    car_right_indicator_on: BoolProperty(default=False, update=update_car_light_toggle)
    car_extra_lights_on: BoolProperty(default=False, update=update_car_light_toggle)

    export_path: StringProperty(default=os.path.join(os.path.expanduser("~"), "Downloads", "carcols.meta"), subtype="FILE_PATH")
    status_message: StringProperty(default="")
    preview_generated: BoolProperty(default=False, options={"HIDDEN"})
    preview_dirty: BoolProperty(default=False, options={"HIDDEN"})
    preview_refresh_pending: BoolProperty(default=False, options={"HIDDEN"})
    preview_refresh_has_motion: BoolProperty(default=False, options={"HIDDEN"})
    preview_refresh_started_at: FloatProperty(default=0.0, options={"HIDDEN"})
    preview_refresh_done_at: FloatProperty(default=0.0, options={"HIDDEN"})
    preview_refresh_signature: StringProperty(default="", options={"HIDDEN"})
    head_tail_initialized: BoolProperty(default=False, options={"HIDDEN"})
    preview_time_origin: FloatProperty(default=0.0, options={"HIDDEN"})
    auto_timeline_preview: BoolProperty(default=False, update=lambda self, context: update_auto_timeline_preview(self, context))
    auto_timeline_pending: BoolProperty(default=False, options={"HIDDEN"})
    auto_timeline_requested_at: FloatProperty(default=0.0, options={"HIDDEN"})
    update_check_on_startup: BoolProperty(default=True)
    update_remote_version: StringProperty(default="")
    update_last_checked: StringProperty(default="")
    update_status: StringProperty(default="Not checked yet")
    update_available: BoolProperty(default=False)
    update_check_in_progress: BoolProperty(default=False, options={"HIDDEN"})
    update_install_in_progress: BoolProperty(default=False, options={"HIDDEN"})
    update_restart_required: BoolProperty(default=False)


def settings_to_dict(s):
    return {
        "config_name": s.config_name,
        "vehicle_name": s.vehicle_name,
        "vehicle_id": s.vehicle_id,
        "bpm": s.bpm,
        "scale_factor": s.scale_factor,
        "left_head": s.left_head,
        "right_head": s.right_head,
        "left_tail": s.left_tail,
        "right_tail": s.right_tail,
        "scale_factor_choice": s.scale_factor_choice,
        "scale_factor_custom": s.scale_factor_custom,
        "main": {k: getattr(s, k) for k in ["use_real_lights", "time_multiplier", "light_falloff_max", "light_falloff_exp", "light_inner_angle", "light_outer_angle", "light_offset", "texture_name", "left_head_mult", "right_head_mult", "left_tail_mult", "right_tail_mult", "armature_name", "siren_count"]},
        "patterns": [{"name": p.name, "visibility": p.visibility, "bits": clean_bits(p.bits), "value": parse_u32(p.value), "allow_duplicate": bool(getattr(p, "allow_duplicate", False))} for p in s.patterns],
        "colors": [{"name": c.name, "value": clean_color_value(c.value)} for c in s.colors],
        "other_attributes": [{"display_value": a.display_value, "return_value": a.return_value} for a in s.other_attributes],
        "sirens": [{k: getattr(si, k) for k in ["index", "name", "enabled", "siren_type", "rotator_speed_mode", "rotator_custom_percent", "rotator_clockwise", "pattern_source", "pattern_choice", "custom_visibility", "custom_bits", "custom_value", "color_mode", "color_preset", "direction_mode", "direction_preset", "custom_direction", "scale_mode", "scale_preset", "custom_scale", "sync_to_bpm", "flash_preview", "flash", "light", "spot_light", "cast_shadows", "light_group", "start_delay", "light_speed", "light_multiples", "corona_intensity", "corona_size", "corona_pull", "light_intensity", "corona_face_camera", "object_name", "anchor_name", "bone_name"]} | {"custom_color": list(si.custom_color)} for si in s.sirens],
    }


def apply_settings_dict(s, data):
    if not isinstance(data, dict):
        return

    for k in ["config_name", "vehicle_name", "vehicle_id", "bpm", "scale_factor", "scale_factor_choice", "scale_factor_custom", "left_head", "right_head", "left_tail", "right_tail"]:
        if k in data:
            if k in {"left_head", "right_head", "left_tail", "right_tail"}:
                setattr(s, k, normalize_pattern_key(data[k]))
            elif k == "scale_factor_choice":
                setattr(s, k, data[k] if data[k] in {it[0] for it in SCALE_FACTOR_PRESET_ITEMS} else "CUSTOM")
            else:
                setattr(s, k, data[k])

    main = data.get("main", {})
    if not isinstance(main, dict):
        main = {}
    for k, v in main.items():
        if hasattr(s, k):
            setattr(s, k, v)

    s.patterns.clear()
    patterns_data = data.get("patterns", [])
    if not isinstance(patterns_data, list):
        patterns_data = []
    for pd in patterns_data:
        if not isinstance(pd, dict):
            continue
        p = s.patterns.add()
        p.name = pd.get("name", "Pattern")
        p.allow_duplicate = bool(pd.get("allow_duplicate", False))
        p.visibility = "FLASHER" if pd.get("visibility", "BOTH") == "FLASHER" else "BOTH"
        p.bits = clean_bits(pd.get("bits", int_to_bits(pd.get("value", 0))))
        p.value = str(parse_u32(pd.get("value", bits_to_int(p.bits))))
    ensure_off_pattern(s)
    if not s.patterns:
        ensure_defaults(s)

    s.colors.clear()
    colors_data = data.get("colors", [])
    if not isinstance(colors_data, list):
        colors_data = []
    for cd in colors_data:
        if not isinstance(cd, dict):
            continue
        c = s.colors.add()
        c.name = cd.get("name", "Colour")
        c.value = clean_color_value(cd.get("value", "0xFFFF0000"))
        c.rgb = color_to_rgb(c.value)
    ensure_color_defaults(s)

    s.other_attributes.clear()
    attrs_data = data.get("other_attributes", [])
    if not isinstance(attrs_data, list):
        attrs_data = []
    for ad in attrs_data:
        if not isinstance(ad, dict):
            continue
        a = s.other_attributes.add()
        a.display_value = str(ad.get("display_value", "Attribute") or "Attribute")
        a.return_value = str(ad.get("return_value", "") or "")
    if not s.other_attributes:
        ensure_other_attributes_defaults(s)

    loaded_sirens = data.get("sirens", [])
    if not isinstance(loaded_sirens, list):
        loaded_sirens = []

    try:
        requested_count = int(main.get("siren_count", data.get("siren_count", 0)))
    except Exception:
        requested_count = 0
    requested_count = max(requested_count, len(loaded_sirens))
    ensure_sirens(s, requested_count)

    for i, sd in enumerate(loaded_sirens):
        if i >= len(s.sirens):
            break
        if not isinstance(sd, dict):
            continue
        si = s.sirens[i]
        for k, v in sd.items():
            if k == "custom_color" and isinstance(v, list) and len(v) >= 3:
                si.custom_color = (float(v[0]), float(v[1]), float(v[2]))
            elif k == "custom_value":
                si.custom_value = str(parse_u32(v))
            elif k == "pattern_choice":
                si.pattern_choice = normalize_pattern_key(v)
            elif k == "color_preset":
                legacy = COLORS.get(str(v), None)
                if legacy:
                    target = clean_color_value(legacy)
                    idx = 0
                    for ci, col in enumerate(s.colors):
                        if clean_color_value(col.value) == target:
                            idx = ci
                            break
                    si.color_preset = f"COL_{idx}"
                else:
                    si.color_preset = normalize_color_key(v)
            elif hasattr(si, k):
                setattr(si, k, v)

    for i, si in enumerate(s.sirens, start=1):
        si.index = i
        si.name = f"siren{i}"
        si.color_preset = normalize_color_key(si.color_preset)
        si.pattern_choice = normalize_pattern_key(si.pattern_choice)
        sync_siren_selector_controls(si)

    try:
        current_id = int(s.vehicle_id)
    except Exception:
        current_id = 0
    if current_id <= 0:
        s.vehicle_id = generate_siren_id(s.vehicle_name)

    sync_scale_factor_controls(s)
    s.head_tail_initialized = True
    save_global_library(s)


def clear_missing_associations(scene):
    s = getattr(scene, "nels", None)
    if not s:
        return

    arm = None
    if s.armature_name:
        arm_obj = bpy.data.objects.get(s.armature_name)
        if arm_obj and arm_obj.type == "ARMATURE":
            arm = arm_obj
        else:
            s.armature_name = ""

    for si in s.sirens:
        if si.object_name and si.object_name not in bpy.data.objects:
            si.object_name = ""
        if si.anchor_name and si.anchor_name not in bpy.data.objects:
            si.anchor_name = ""
        if si.bone_name:
            has_bone = bool(arm and si.bone_name in arm.data.bones)
            if not has_bone:
                for obj in bpy.data.objects:
                    if obj.type != "ARMATURE":
                        continue
                    if si.bone_name in obj.data.bones:
                        has_bone = True
                        if not arm:
                            arm = obj
                            s.armature_name = obj.name
                        break
            if not has_bone:
                si.bone_name = ""
        si.enabled = bool(si.object_name or si.bone_name)

def ensure_scene_defaults(scene):
    s = getattr(scene, "nels", None)
    if not s:
        return None

    if not s.patterns:
        ensure_defaults(s)
    migrate_legacy_default_patterns(s)
    ensure_off_pattern(s)
    ensure_color_defaults(s)
    ensure_other_attributes_defaults(s)
    sync_scale_factor_controls(s)

    off_key = off_pattern_key(s)
    if not getattr(s, "head_tail_initialized", False):
        s.left_head = off_key
        s.right_head = off_key
        s.left_tail = off_key
        s.right_tail = off_key
        s.head_tail_initialized = True
    else:
        if not s.left_head:
            s.left_head = off_key
        if not s.right_head:
            s.right_head = off_key
        if not s.left_tail:
            s.left_tail = off_key
        if not s.right_tail:
            s.right_tail = off_key

    if not s.saved_config:
        s.saved_config = NO_SAVED_CFG
    for si in s.sirens:
        si.color_preset = normalize_color_key(si.color_preset)
        si.pattern_choice = normalize_pattern_key(si.pattern_choice)
        if si.siren_type == "ROTATOR":
            update_rotator_settings(si, bpy.context)
        sync_siren_selector_controls(si)
    clear_missing_associations(scene)
    auto_detect_scene_sirens(scene, create_missing=(len(s.sirens) == 0), sync_direction=False)

    try:
        current_id = int(s.vehicle_id)
    except Exception:
        current_id = 0
    if current_id <= 0:
        s.vehicle_id = generate_siren_id(s.vehicle_name)
    normalize_update_state(s)
    refresh_siren_preview_cache(scene)
    schedule_startup_update_check(scene)
    return s


class NELS_OT_initialize_defaults(Operator):
    bl_idname = "nels.initialize_defaults"
    bl_label = "Initialize Defaults"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        ensure_scene_defaults(context.scene)
        return {"FINISHED"}

class NELS_OT_pattern_tools(Operator):
    bl_idname = "nels.pattern_tools"
    bl_label = "Pattern Tools"
    bl_options = {"REGISTER", "UNDO"}

    action: EnumProperty(items=[("ADD", "ADD", ""), ("DUPLICATE", "DUPLICATE", ""), ("REMOVE", "REMOVE", ""), ("REPEAT", "REPEAT", ""), ("INVERT", "INVERT", "")])
    scope: EnumProperty(items=[("LIB", "LIB", ""), ("SIREN", "SIREN", "")], default="LIB")

    def execute(self, context):
        s = context.scene.nels
        if self.action == "ADD":
            p = s.patterns.add()
            p.name = f"Pattern {len(s.patterns)}"
            p.allow_duplicate = False
            p.visibility = "BOTH"
            p.bits = "00001111000011110000111100001111"
            p.value = str(bits_to_int(p.bits))
            s.active_pattern = len(s.patterns) - 1
            save_global_library(s)
            return {"FINISHED"}
        if self.action == "DUPLICATE":
            if not s.patterns:
                return {"CANCELLED"}
            i = max(0, min(s.active_pattern, len(s.patterns) - 1))
            src = s.patterns[i]
            p = s.patterns.add()
            p.name = f"{(src.name or f'Pattern {i + 1}')} Copy"
            p.allow_duplicate = False
            p.visibility = src.visibility
            p.bits = src.bits
            p.value = src.value
            s.active_pattern = len(s.patterns) - 1
            save_global_library(s)
            return {"FINISHED"}
        if self.action == "REMOVE":
            if s.patterns:
                i = max(0, min(s.active_pattern, len(s.patterns) - 1))
                s.patterns.remove(i)
                s.active_pattern = min(i, max(0, len(s.patterns) - 1))
            save_global_library(s)
            return {"FINISHED"}

        si = s.sirens[s.active_siren] if s.sirens and 0 <= s.active_siren < len(s.sirens) else None
        if self.scope == "LIB":
            p = s.patterns[s.active_pattern] if s.patterns and 0 <= s.active_pattern < len(s.patterns) else None
            if not p:
                return {"CANCELLED"}
            if self.action == "REPEAT":
                p.bits = repeat_32(p.bits)
            elif self.action == "INVERT":
                p.bits = invert_bits(p.bits)
            save_global_library(s)
            return {"FINISHED"}

        if not si:
            return {"CANCELLED"}
        if self.action == "REPEAT":
            si.custom_bits = repeat_32(si.custom_bits)
        elif self.action == "INVERT":
            si.custom_bits = invert_bits(si.custom_bits)
        return {"FINISHED"}


class NELS_OT_save_siren_pattern(Operator):
    bl_idname = "nels.save_siren_pattern"
    bl_label = "Save Pattern to Library"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        scene = getattr(context, "scene", None)
        s = getattr(scene, "nels", None) if scene else None
        if not s or not s.sirens:
            self.report({"ERROR"}, "No siren selected")
            return {"CANCELLED"}

        idx = max(0, min(getattr(s, "active_siren", 0), len(s.sirens) - 1))
        si = s.sirens[idx]
        bits = repeat_32(getattr(si, "custom_bits", "0"))
        value = str(bits_to_int(bits))
        visibility = getattr(si, "custom_visibility", "BOTH")

        existing_key = find_pattern_key_by_bits(s, bits, visibility)
        if existing_key:
            si.pattern_source = "LIBRARY"
            si.pattern_choice = existing_key
            sync_siren_selector_controls(si)
            mark_preview_dirty(context)
            self.report({"INFO"}, "Matched existing library pattern")
            return {"FINISHED"}

        p = s.patterns.add()
        p.name = next_pattern_name(s, "Unsaved Pattern")
        p.allow_duplicate = False
        p.visibility = normalize_pattern_visibility(visibility)
        p.bits = bits
        p.value = value
        s.active_pattern = len(s.patterns) - 1

        save_global_library(s)

        si.pattern_source = "LIBRARY"
        si.pattern_choice = f"PAT_{s.active_pattern}"
        si.custom_bits = bits
        si.custom_value = value
        sync_siren_selector_controls(si)
        mark_preview_dirty(context)
        self.report({"INFO"}, f"Saved pattern as {p.name}")
        return {"FINISHED"}


class NELS_OT_pattern_duplicate_resolution(Operator):
    bl_idname = "nels.pattern_duplicate_resolution"
    bl_label = "Resolve Pattern Duplicate"
    bl_options = {"REGISTER", "UNDO"}

    action: EnumProperty(items=[("ALLOW", "Allow Duplicate", ""), ("KEEP_SELECTED", "Keep Selected Only", ""), ("WARN", "Warn Again", "")], default="ALLOW")
    index: IntProperty(default=-1)

    def execute(self, context):
        s = context.scene.nels
        idx = max(0, min(self.index, len(s.patterns) - 1)) if s.patterns else -1
        matches = pattern_duplicate_indices(s, idx)
        if idx < 0 or not matches:
            self.report({"INFO"}, "No duplicate pattern name detected")
            return {"CANCELLED"}

        if self.action == "ALLOW":
            count = set_pattern_duplicate_allowed(s, idx, True)
            save_global_library(s)
            self.report({"INFO"}, f"Duplicate allowed for {count} patterns")
            return {"FINISHED"}

        if self.action == "WARN":
            count = set_pattern_duplicate_allowed(s, idx, False)
            save_global_library(s)
            self.report({"INFO"}, f"Duplicate warning restored for {count} patterns")
            return {"FINISHED"}

        removed, keep_idx = remove_pattern_duplicates_keep_selected(s, idx)
        s.active_pattern = min(max(0, keep_idx), max(0, len(s.patterns) - 1))
        save_global_library(s)
        self.report({"INFO"}, f"Removed {removed} duplicate patterns")
        return {"FINISHED"}


class NELS_OT_pattern_library_io(Operator):
    bl_idname = "nels.pattern_library_io"
    bl_label = "Pattern Library Import/Export"
    bl_options = {"REGISTER", "UNDO"}

    action: EnumProperty(items=[("EXPORT", "EXPORT", ""), ("IMPORT", "IMPORT", "")], default="EXPORT")

    def execute(self, context):
        s = context.scene.nels
        fp = bpy.path.abspath(getattr(s, "pattern_library_path", "") or "").strip()
        if not fp:
            self.report({"ERROR"}, "Pattern library path is empty")
            return {"CANCELLED"}
        if not fp.lower().endswith(".json"):
            fp += ".json"

        try:
            if self.action == "EXPORT":
                out_dir = os.path.dirname(fp)
                if out_dir:
                    os.makedirs(out_dir, exist_ok=True)

                data = {
                    "patterns": [
                        {
                            "name": p.name,
                            "visibility": "FLASHER" if p.visibility == "FLASHER" else "BOTH",
                            "bits": repeat_32(p.bits),
                            "value": parse_u32(p.value),
                            "allow_duplicate": bool(getattr(p, "allow_duplicate", False)),
                        }
                        for p in s.patterns
                    ]
                }
                with open(fp, "w", encoding="utf-8") as h:
                    json.dump(data, h, indent=2)
                s.pattern_library_path = fp
                s.status_message = f"Pattern library exported: {fp}"
                self.report({"INFO"}, s.status_message)
                return {"FINISHED"}

            if not os.path.exists(fp):
                self.report({"ERROR"}, f"Pattern library not found: {fp}")
                return {"CANCELLED"}

            with open(fp, "r", encoding="utf-8") as h:
                data = json.load(h)

            if isinstance(data, dict):
                pats = data.get("patterns", [])
            elif isinstance(data, list):
                pats = data
            else:
                self.report({"ERROR"}, "Invalid pattern library format")
                return {"CANCELLED"}

            if not isinstance(pats, list):
                self.report({"ERROR"}, "Pattern library must contain a list of patterns")
                return {"CANCELLED"}

            s.patterns.clear()
            for pd in pats:
                if not isinstance(pd, dict):
                    continue
                p = s.patterns.add()
                p.name = str(pd.get("name", "Pattern") or "Pattern")
                p.allow_duplicate = bool(pd.get("allow_duplicate", False))
                p.visibility = "FLASHER" if pd.get("visibility", "BOTH") == "FLASHER" else "BOTH"
                bits = clean_bits(pd.get("bits", int_to_bits(pd.get("value", 0)))) or "0"
                p.bits = bits
                p.value = str(parse_u32(pd.get("value", bits_to_int(bits))))

            ensure_off_pattern(s)
            s.active_pattern = min(max(0, s.active_pattern), max(0, len(s.patterns) - 1))
            save_global_library(s)
            s.pattern_library_path = fp
            s.status_message = f"Pattern library imported: {fp}"
            self.report({"INFO"}, s.status_message)
            return {"FINISHED"}
        except Exception as ex:
            self.report({"ERROR"}, f"Pattern library {self.action.lower()} failed: {ex}")
            return {"CANCELLED"}
class NELS_OT_color_tools(Operator):
    bl_idname = "nels.color_tools"
    bl_label = "Color Tools"
    bl_options = {"REGISTER", "UNDO"}

    action: EnumProperty(items=[("ADD", "ADD", ""), ("REMOVE", "REMOVE", "")])

    def execute(self, context):
        s = context.scene.nels
        ensure_color_defaults(s)

        if self.action == "ADD":
            c = s.colors.add()
            c.name = f"Custom Colour {len(s.colors)}"
            c.rgb = (1.0, 0.0, 0.0)
            c.value = rgb_to_color(c.rgb)
            s.active_color = len(s.colors) - 1
            save_global_library(s)
            return {"FINISHED"}

        if not s.colors:
            return {"CANCELLED"}
        i = max(0, min(s.active_color, len(s.colors) - 1))
        s.colors.remove(i)
        if not s.colors:
            ensure_color_defaults(s)
        s.active_color = min(i, max(0, len(s.colors) - 1))
        for si in s.sirens:
            si.color_preset = normalize_color_key(si.color_preset)
        save_global_library(s)
        return {"FINISHED"}


class NELS_OT_other_attr_tools(Operator):
    bl_idname = "nels.other_attr_tools"
    bl_label = "Other Attribute Tools"
    bl_options = {"REGISTER", "UNDO"}

    action: EnumProperty(items=[("ADD", "ADD", ""), ("REMOVE", "REMOVE", "")], default="ADD")

    def execute(self, context):
        s = context.scene.nels
        ensure_other_attributes_defaults(s)

        if self.action == "ADD":
            a = s.other_attributes.add()
            a.display_value = f"Attribute {len(s.other_attributes)}"
            a.return_value = ""
            s.active_other_attribute = len(s.other_attributes) - 1
            return {"FINISHED"}

        if not s.other_attributes:
            return {"CANCELLED"}
        i = max(0, min(s.active_other_attribute, len(s.other_attributes) - 1))
        s.other_attributes.remove(i)
        if not s.other_attributes:
            ensure_other_attributes_defaults(s)
        s.active_other_attribute = min(i, max(0, len(s.other_attributes) - 1))
        return {"FINISHED"}


class NELS_OT_car_lights_sim(Operator):
    bl_idname = "nels.car_lights_sim"
    bl_label = "Apply Car Light Simulation"
    bl_options = {"REGISTER", "UNDO"}

    action: EnumProperty(items=[("APPLY", "APPLY", ""), ("RESET", "RESET", "")], default="APPLY")

    def execute(self, context):
        s = context.scene.nels
        scene = context.scene

        if self.action == "RESET":
            s.car_headlights_on = False
            s.car_taillights_on = False
            s.car_left_indicator_on = False
            s.car_right_indicator_on = False
            s.car_extra_lights_on = False

        touched = apply_car_light_simulation(scene, s, blink_indicators=True, now=playback_seconds(scene=scene))
        msg = f"Applied car light simulation to {touched} objects"
        s.status_message = msg
        self.report({"INFO"}, msg)
        return {"FINISHED"}


class NELS_OT_wheel_simulation(Operator):
    bl_idname = "nels.wheel_simulation"
    bl_label = "Simulate Tyres"
    bl_options = {"REGISTER", "UNDO"}

    action: EnumProperty(items=[("APPLY", "APPLY", ""), ("RESET", "RESET", "")], default="APPLY")

    def execute(self, context):
        s = context.scene.nels
        scene = context.scene

        if self.action == "RESET":
            removed = clear_wheel_preview_objects(scene)
            msg = f"Cleared {removed} tyre preview objects"
            s.status_message = msg
            self.report({"INFO"}, msg)
            return {"FINISHED"}

        arm, bones = wheel_pose_bones(scene)
        if not arm or not bones:
            msg = "Warning: No wheel bones found (set Parent Skeleton and ensure wheel bone names contain 'wheel')"
            s.status_message = msg
            self.report({"WARNING"}, msg)
            return {"CANCELLED"}

        linked, skipped, msg = simulate_tyres_on_wheel_bones(context, arm, bones)
        s.status_message = msg
        if linked <= 0:
            self.report({"WARNING"}, msg)
            return {"CANCELLED"}

        self.report({"INFO"}, f"{msg} (source wheel kept: {skipped})")
        return {"FINISHED"}


class NELS_OT_extra_visibility(Operator):
    bl_idname = "nels.extra_visibility"
    bl_label = "Set Extra Visibility"
    bl_options = {"REGISTER", "UNDO"}

    object_name: StringProperty(default="")
    show: BoolProperty(default=True)

    def execute(self, context):
        obj = bpy.data.objects.get(self.object_name)
        if not obj:
            return {"CANCELLED"}
        set_object_visible(obj, self.show)
        return {"FINISHED"}


class NELS_OT_extras_visibility_all(Operator):
    bl_idname = "nels.extras_visibility_all"
    bl_label = "Set All Extras Visibility"
    bl_options = {"REGISTER", "UNDO"}

    show: BoolProperty(default=True)

    def execute(self, context):
        objs = scene_extra_objects(context.scene)
        for obj in objs:
            set_object_visible(obj, self.show)
        self.report({"INFO"}, f"Updated {len(objs)} extras")
        return {"FINISHED"}
class NELS_OT_set_siren_count(Operator):
    bl_idname = "nels.set_siren_count"
    bl_label = "Set Siren Count"
    bl_options = {"REGISTER", "UNDO"}
    count: IntProperty(default=20)

    def execute(self, context):
        ensure_sirens(context.scene.nels, self.count)
        return {"FINISHED"}



class NELS_OT_swap_sirens(Operator):
    bl_idname = "nels.swap_sirens"
    bl_label = "Swap Sirens"
    bl_options = {"REGISTER", "UNDO"}

    siren_a: EnumProperty(name="First Siren", items=swappable_siren_items)
    siren_b: EnumProperty(name="Second Siren", items=swappable_siren_items)

    def invoke(self, context, event):
        items = [item[0] for item in swappable_siren_items(self, context) if item[0] != "__NONE__"]
        if len(items) < 2:
            msg = "Warning: Link mesh and bone for at least two sirens before swapping"
            context.scene.nels.status_message = msg
            self.report({"WARNING"}, msg)
            return {"CANCELLED"}
        if self.siren_a not in items:
            self.siren_a = items[0]
        if self.siren_b not in items or self.siren_b == self.siren_a:
            self.siren_b = next((item for item in items if item != self.siren_a), items[0])
        return context.window_manager.invoke_props_dialog(self, width=360)

    def draw(self, context):
        l = self.layout
        l.label(text="Swap the scene mesh and bone names for two configured sirens.")
        l.prop(self, "siren_a", text="First Siren")
        l.prop(self, "siren_b", text="Second Siren")

    def execute(self, context):
        scene = context.scene
        s = scene.nels
        if self.siren_a == "__NONE__" or self.siren_b == "__NONE__":
            msg = "Warning: Link mesh and bone for at least two sirens before swapping"
            s.status_message = msg
            self.report({"WARNING"}, msg)
            return {"CANCELLED"}
        if self.siren_a == self.siren_b:
            msg = "Warning: Choose two different sirens to swap"
            s.status_message = msg
            self.report({"WARNING"}, msg)
            return {"CANCELLED"}

        si_a = siren_slot_by_index(s, self.siren_a)
        si_b = siren_slot_by_index(s, self.siren_b)
        if not si_a or not si_b:
            msg = "Warning: Could not resolve the selected sirens"
            s.status_message = msg
            self.report({"WARNING"}, msg)
            return {"CANCELLED"}

        obj_a = siren_obj(si_a)
        obj_b = siren_obj(si_b)
        arm_a, pb_a = siren_pose_bone(scene, si_a)
        arm_b, pb_b = siren_pose_bone(scene, si_b)
        if not obj_a or obj_a.type != "MESH" or not obj_b or obj_b.type != "MESH":
            msg = "Warning: Both selected sirens must have linked mesh objects before swapping"
            s.status_message = msg
            self.report({"WARNING"}, msg)
            return {"CANCELLED"}
        if not arm_a or not pb_a or not arm_b or not pb_b:
            msg = "Warning: Both selected sirens must have linked bones before swapping"
            s.status_message = msg
            self.report({"WARNING"}, msg)
            return {"CANCELLED"}

        old_obj_a_name = obj_a.name
        old_obj_b_name = obj_b.name
        old_bone_a_name = pb_a.name
        old_bone_b_name = pb_b.name
        new_obj_a_name = f"siren{si_b.index}"
        new_obj_b_name = f"siren{si_a.index}"
        new_bone_a_name = f"siren{si_b.index}"
        new_bone_b_name = f"siren{si_a.index}"

        def object_name_conflict(target_name):
            other = bpy.data.objects.get(target_name)
            return other is not None and other not in (obj_a, obj_b)

        def bone_name_conflict(arm, target_name, allowed_names):
            bone = arm.data.bones.get(target_name) if arm and getattr(arm, "data", None) else None
            return bone is not None and bone.name not in allowed_names

        if object_name_conflict(new_obj_a_name) or object_name_conflict(new_obj_b_name):
            msg = "Warning: A different scene object is already using one of the target siren names"
            s.status_message = msg
            self.report({"WARNING"}, msg)
            return {"CANCELLED"}

        allowed_a = {old_bone_a_name}
        allowed_b = {old_bone_b_name}
        if arm_a == arm_b:
            allowed_a.add(old_bone_b_name)
            allowed_b.add(old_bone_a_name)
        if bone_name_conflict(arm_a, new_bone_a_name, allowed_a) or bone_name_conflict(arm_b, new_bone_b_name, allowed_b):
            msg = "Warning: A different siren bone is already using one of the target siren names"
            s.status_message = msg
            self.report({"WARNING"}, msg)
            return {"CANCELLED"}

        def capture_children(arm, bone_name):
            links = []
            for child in scene.objects:
                try:
                    if child.parent == arm and child.parent_type == "BONE" and child.parent_bone == bone_name:
                        links.append((child, child.matrix_world.copy()))
                except Exception:
                    continue
            return links

        def restore_children(links, arm, bone_name):
            for child, matrix_world in links:
                try:
                    child.parent = arm
                    child.parent_type = "BONE"
                    child.parent_bone = bone_name
                    child.matrix_world = matrix_world
                except Exception:
                    continue

        child_links_a = capture_children(arm_a, old_bone_a_name)
        child_links_b = capture_children(arm_b, old_bone_b_name)
        temp_tag = _time.time_ns()
        temp_obj_a_name = f"__nels_swap_obj_{si_a.index}_{temp_tag}_a"
        temp_obj_b_name = f"__nels_swap_obj_{si_b.index}_{temp_tag}_b"
        temp_bone_a_name = f"__nels_swap_bone_{si_a.index}_{temp_tag}_a"
        temp_bone_b_name = f"__nels_swap_bone_{si_b.index}_{temp_tag}_b"

        old_active = getattr(context.view_layer.objects, "active", None)
        old_mode = getattr(context, "mode", "OBJECT")
        try:
            obj_a.name = temp_obj_a_name
            obj_b.name = temp_obj_b_name
            obj_a.name = new_obj_a_name
            obj_b.name = new_obj_b_name

            plans = []
            if arm_a == arm_b:
                plans.append((arm_a, [(old_bone_a_name, temp_bone_a_name), (old_bone_b_name, temp_bone_b_name)], [(temp_bone_a_name, new_bone_a_name), (temp_bone_b_name, new_bone_b_name)]))
            else:
                plans.append((arm_a, [(old_bone_a_name, temp_bone_a_name)], [(temp_bone_a_name, new_bone_a_name)]))
                plans.append((arm_b, [(old_bone_b_name, temp_bone_b_name)], [(temp_bone_b_name, new_bone_b_name)]))

            if old_mode != "OBJECT":
                bpy.ops.object.mode_set(mode="OBJECT")
            for arm, temp_pairs, final_pairs in plans:
                bpy.ops.object.select_all(action="DESELECT")
                arm.select_set(True)
                context.view_layer.objects.active = arm
                bpy.ops.object.mode_set(mode="EDIT")
                for old_name, temp_name in temp_pairs:
                    eb = arm.data.edit_bones.get(old_name)
                    if not eb:
                        raise RuntimeError(f"Missing editable bone {old_name}")
                    eb.name = temp_name
                for temp_name, final_name in final_pairs:
                    eb = arm.data.edit_bones.get(temp_name)
                    if not eb:
                        raise RuntimeError(f"Missing temporary bone {temp_name}")
                    eb.name = final_name
                bpy.ops.object.mode_set(mode="OBJECT")
        except Exception as exc:
            msg = f"Warning: Failed to swap sirens: {exc}"
            s.status_message = msg
            self.report({"WARNING"}, msg)
            return {"CANCELLED"}
        finally:
            try:
                if getattr(context, "mode", "OBJECT") != "OBJECT":
                    bpy.ops.object.mode_set(mode="OBJECT")
            except Exception:
                pass
            try:
                if old_active and old_active.name in bpy.data.objects:
                    context.view_layer.objects.active = old_active
            except Exception:
                pass
            try:
                if old_mode != "OBJECT" and getattr(context, "mode", "OBJECT") == "OBJECT":
                    bpy.ops.object.mode_set(mode=old_mode)
            except Exception:
                pass

        restore_children(child_links_a, arm_a, new_bone_a_name)
        restore_children(child_links_b, arm_b, new_bone_b_name)

        object_map = {old_obj_a_name: new_obj_a_name, old_obj_b_name: new_obj_b_name}
        bone_map = {old_bone_a_name: new_bone_a_name, old_bone_b_name: new_bone_b_name}
        for si in s.sirens:
            if si.object_name in object_map:
                si.object_name = object_map[si.object_name]
            if si.bone_name in bone_map:
                si.bone_name = bone_map[si.bone_name]
            si.enabled = bool(si.object_name or si.bone_name)

        anchor_a = si_a.anchor_name
        anchor_b = si_b.anchor_name
        si_a.object_name = f"siren{si_a.index}"
        si_b.object_name = f"siren{si_b.index}"
        si_a.bone_name = f"siren{si_a.index}"
        si_b.bone_name = f"siren{si_b.index}"
        si_a.anchor_name = anchor_b
        si_b.anchor_name = anchor_a
        si_a.enabled = True
        si_b.enabled = True

        apply_all_siren_directions(scene)
        refresh_direction_warning(scene)
        mark_preview_dirty(context)
        tag_all_ui_redraw()

        msg = f"Swapped Siren {si_a.index} and Siren {si_b.index}"
        s.status_message = msg
        self.report({"INFO"}, msg)
        return {"FINISHED"}


class NELS_OT_auto_detect(Operator):
    bl_idname = "nels.auto_detect"
    bl_label = "Auto-Detect Sirens/Bones"
    bl_options = {"REGISTER", "UNDO"}

    create_missing: BoolProperty(default=True)

    def execute(self, context):
        obj_count, bone_count, linked = auto_detect_scene_sirens(context.scene, create_missing=self.create_missing, sync_direction=True)
        self.report({"INFO"}, f"Detected objects: {obj_count}, bones: {bone_count}, linked: {linked}")
        return {"FINISHED"}


class NELS_OT_generate_siren_id(Operator):
    bl_idname = "nels.generate_siren_id"
    bl_label = "Generate Siren ID"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        s = context.scene.nels
        s.vehicle_id = generate_siren_id(s.vehicle_name)
        return {"FINISHED"}


def reset_scene_config_defaults(s, keep_name=False):
    cfg_name = s.config_name if keep_name and str(s.config_name).strip() else "new_lightbar"
    s.config_name = cfg_name
    s.vehicle_name = "police"
    s.vehicle_id = generate_siren_id(s.vehicle_name)
    s.bpm = 800
    s.scale_factor = 0.5
    s.scale_factor_choice = "SF_2"
    s.scale_factor_custom = 0.5
    s.patterns.clear()
    ensure_defaults(s)
    s.colors.clear()
    ensure_color_defaults(s)
    s.other_attributes.clear()
    ensure_other_attributes_defaults(s)
    s.sirens.clear()
    s.siren_count = 0
    off_key = off_pattern_key(s)
    s.left_head = off_key
    s.right_head = off_key
    s.left_tail = off_key
    s.right_tail = off_key
    s.saved_config = NO_SAVED_CFG
    s.car_headlights_on = False
    s.car_taillights_on = False
    s.car_left_indicator_on = False
    s.car_right_indicator_on = False
    s.car_extra_lights_on = False
    sync_scale_factor_controls(s)


class NELS_OT_new_save_load(Operator):
    bl_idname = "nels.new_save_load"
    bl_label = "Config IO"
    bl_options = {"REGISTER", "UNDO"}
    action: EnumProperty(items=[("NEW", "NEW", ""), ("SAVE", "SAVE", ""), ("LOAD", "LOAD", ""), ("DELETE", "DELETE", ""), ("RESET", "RESET", "")])

    def execute(self, context):
        s = context.scene.nels
        if self.action == "NEW":
            reset_scene_config_defaults(s, keep_name=False)
            auto_detect_scene_sirens(context.scene, create_missing=True, sync_direction=True)
            return {"FINISHED"}

        if self.action == "SAVE":
            fp = os.path.join(cfg_dir(), safe_name(s.config_name) + ".json")
            with open(fp, "w", encoding="utf-8") as h:
                json.dump(settings_to_dict(s), h, indent=2)
            s.saved_config = os.path.basename(fp)
            return {"FINISHED"}

        if self.action == "RESET":
            if s.saved_config and s.saved_config != NO_SAVED_CFG:
                fp = os.path.join(cfg_dir(), s.saved_config)
                if os.path.exists(fp):
                    with open(fp, "r", encoding="utf-8") as h:
                        data = json.load(h)
                    apply_settings_dict(s, data)
                    ensure_scene_defaults(context.scene)
                    return {"FINISHED"}
            reset_scene_config_defaults(s, keep_name=True)
            auto_detect_scene_sirens(context.scene, create_missing=True, sync_direction=True)
            return {"FINISHED"}

        if self.action == "DELETE":
            if not s.saved_config or s.saved_config == NO_SAVED_CFG:
                return {"CANCELLED"}
            fp = os.path.join(cfg_dir(), s.saved_config)
            if os.path.exists(fp):
                os.remove(fp)
            choices = config_json_files()
            s.saved_config = choices[0] if choices else NO_SAVED_CFG
            return {"FINISHED"}

        if not s.saved_config or s.saved_config == NO_SAVED_CFG:
            return {"CANCELLED"}
        fp = os.path.join(cfg_dir(), s.saved_config)
        if not os.path.exists(fp):
            return {"CANCELLED"}
        with open(fp, "r", encoding="utf-8") as h:
            data = json.load(h)
        apply_settings_dict(s, data)
        ensure_scene_defaults(context.scene)
        return {"FINISHED"}


class NELS_OT_export_config(Operator):
    bl_idname = "nels.export_config"
    bl_label = "Export Configuration"

    filepath: StringProperty(subtype="FILE_PATH")
    filter_glob: StringProperty(default="*.json", options={"HIDDEN"})

    def execute(self, context):
        s = context.scene.nels
        fp = self.filepath or bpy.path.abspath(f"//{safe_name(s.config_name)}.json")
        if not fp.lower().endswith(".json"):
            fp += ".json"
        out_dir = os.path.dirname(fp)
        if out_dir:
            os.makedirs(out_dir, exist_ok=True)
        with open(fp, "w", encoding="utf-8") as h:
            json.dump(settings_to_dict(s), h, indent=2)
        self.report({"INFO"}, f"Exported configuration: {fp}")
        return {"FINISHED"}

    def invoke(self, context, event):
        s = context.scene.nels
        if not self.filepath:
            self.filepath = bpy.path.abspath(f"//{safe_name(s.config_name)}.json")
        context.window_manager.fileselect_add(self)
        return {"RUNNING_MODAL"}


class NELS_OT_import_config(Operator):
    bl_idname = "nels.import_config"
    bl_label = "Import Configuration"

    filepath: StringProperty(subtype="FILE_PATH")
    filter_glob: StringProperty(default="*.json", options={"HIDDEN"})

    def execute(self, context):
        s = context.scene.nels
        fp = self.filepath
        if not fp or not os.path.exists(fp):
            self.report({"ERROR"}, "Configuration file not found")
            return {"CANCELLED"}

        with open(fp, "r", encoding="utf-8") as h:
            data = json.load(h)
        apply_settings_dict(s, data)
        ensure_scene_defaults(context.scene)
        self.report({"INFO"}, f"Imported configuration: {fp}")
        return {"FINISHED"}

    def invoke(self, context, event):
        self.filepath = bpy.path.abspath("//")
        context.window_manager.fileselect_add(self)
        return {"RUNNING_MODAL"}



def _read_xml_value(node, tag, default=None):
    if node is None:
        return default
    child = node.find(tag)
    if child is None:
        return default
    return child.attrib.get("value", default)


def _read_bool(value, default=False):
    txt = str(value).strip().lower()
    if txt in {"true", "1", "yes"}:
        return True
    if txt in {"false", "0", "no"}:
        return False
    return bool(default)


class NELS_OT_import_carcols(Operator):
    bl_idname = "nels.import_carcols"
    bl_label = "Import carcols.meta"

    filepath: StringProperty(subtype="FILE_PATH")
    filter_glob: StringProperty(default="*.meta;*.xml", options={"HIDDEN"})

    def execute(self, context):
        s = context.scene.nels
        fp = self.filepath
        if not fp or not os.path.exists(fp):
            self.report({"ERROR"}, "carcols.meta file not found")
            return {"CANCELLED"}

        suspend_preview_updates()
        try:
            try:
                tree = ET.parse(fp)
                root = tree.getroot()
            except Exception as ex:
                self.report({"ERROR"}, f"Invalid XML: {ex}")
                return {"CANCELLED"}

            top = root.find("./Sirens/Item")
            if top is None:
                self.report({"ERROR"}, "Invalid carcols format: missing Sirens/Item")
                return {"CANCELLED"}

            if not s.patterns:
                ensure_defaults(s)
            migrate_legacy_default_patterns(s)
            ensure_off_pattern(s)
            ensure_color_defaults(s)
            ensure_other_attributes_defaults(s)
            sync_scale_factor_controls(s)

            try:
                s.vehicle_id = int(_read_xml_value(top, "id", s.vehicle_id))
            except Exception:
                pass
            nm = top.find("name")
            if nm is not None and nm.text:
                s.vehicle_name = nm.text.strip() or s.vehicle_name

            try:
                s.bpm = int(_read_xml_value(top, "sequencerBpm", s.bpm))
            except Exception:
                pass

            off_key = off_pattern_key(s)
            s.left_head = off_key
            s.right_head = off_key
            s.left_tail = off_key
            s.right_tail = off_key
            s.head_tail_initialized = True

            for tag, prop in [("leftHeadLight", "left_head"), ("rightHeadLight", "right_head"), ("leftTailLight", "left_tail"), ("rightTailLight", "right_tail")]:
                sec = top.find(tag)
                if sec is None:
                    continue
                seq = parse_u32(_read_xml_value(sec, "sequencer", 0))
                bits = int_to_bits(seq)
                setattr(s, prop, off_key if seq == 0 else normalize_pattern_key(get_or_add_pattern(s, f"Imported {tag}", "BOTH", bits)))

            sirens_node = top.find("sirens")
            if sirens_node is None:
                self.report({"ERROR"}, "Invalid carcols format: missing sirens block")
                return {"CANCELLED"}

            items = [n for n in sirens_node.findall("Item")]
            ensure_sirens(s, len(items))
            imported_scale_factor = None

            for i, it in enumerate(items):
                if i >= len(s.sirens):
                    break
                si = s.sirens[i]
                rot = it.find("rotation")
                fl = it.find("flashiness")
                rotate_flag = _read_bool(_read_xml_value(it, "rotate", "false"), False)
                si.siren_type = "ROTATOR" if rotate_flag else "FLASHER"

                seq_val = 0
                vis = "BOTH"
                if si.siren_type == "ROTATOR" and rot is not None:
                    seq_val = parse_u32(_read_xml_value(rot, "sequencer", 0))
                    vis = "ROTATOR"
                elif fl is not None:
                    seq_val = parse_u32(_read_xml_value(fl, "sequencer", 0))
                    vis = "FLASHER"

                if seq_val == 0:
                    si.pattern_source = "LIBRARY"
                    si.pattern_choice = off_key
                else:
                    matched_pattern = find_pattern_key_by_bits(s, int_to_bits(seq_val), vis)
                    if matched_pattern:
                        si.pattern_source = "LIBRARY"
                        si.pattern_choice = matched_pattern
                    else:
                        si.pattern_source = "CUSTOM"
                        si.custom_visibility = normalize_pattern_visibility(vis)
                        si.custom_value = str(seq_val)
                        si.custom_bits = int_to_bits(seq_val)

                col_hex = clean_color_value(_read_xml_value(it, "color", COLORS["GENERAL_WHITE"]))
                preset = find_color_key_by_value(s, col_hex)
                if preset != "COL_0" or col_hex == clean_color_value(COLORS["GENERAL_WHITE"]):
                    si.color_mode = "PRESET"
                    si.color_preset = preset
                else:
                    si.color_mode = "CUSTOM"
                    si.custom_color = color_to_rgb(col_hex)

                scale_factor = _read_xml_value(it, "scaleFactor", None)
                if imported_scale_factor is None and scale_factor is not None:
                    imported_scale_factor = normalize_import_scale_factor(scale_factor)
                apply_scale_to_siren(si, scale_factor)

                dir_val_txt = _read_xml_value(rot if rotate_flag and rot is not None else fl, "delta", 0.0)
                try:
                    imported_dir = float(dir_val_txt)
                except Exception:
                    imported_dir = 0.0
                preset_dir = direction_preset_from_value(imported_dir)
                if preset_dir:
                    si.direction_mode = "PRESET"
                    si.direction_preset = preset_dir
                    si.custom_direction = float(DIRECTIONS.get(preset_dir, 0.0))
                else:
                    si.direction_mode = "CUSTOM"
                    si.custom_direction = imported_dir
                si.sync_to_bpm = _read_bool(_read_xml_value(rot if rotate_flag and rot is not None else fl, "syncToBpm", "true"), True)
                si.start_delay = float(_read_xml_value(fl if fl is not None else rot, "start", 0.0) or 0.0)
                si.light_speed = float(_read_xml_value(fl if fl is not None else rot, "speed", 0.0) or 0.0)
                si.light_multiples = int(float(_read_xml_value(fl if fl is not None else rot, "multiples", 0) or 0))
                si.rotator_clockwise = _read_bool(_read_xml_value(rot, "direction", "true"), True) if rot is not None else True

                si.flash = _read_bool(_read_xml_value(it, "flash", "true"), True)
                si.light = _read_bool(_read_xml_value(it, "light", "false"), False)
                si.spot_light = _read_bool(_read_xml_value(it, "spotLight", "false"), False)
                si.cast_shadows = _read_bool(_read_xml_value(it, "castShadows", "false"), False)
                si.light_group = int(float(_read_xml_value(it, "lightGroup", 1) or 1))

                cor = it.find("corona")
                if cor is not None:
                    si.corona_intensity = float(_read_xml_value(cor, "intensity", si.corona_intensity) or si.corona_intensity)
                    si.corona_size = float(_read_xml_value(cor, "size", si.corona_size) or si.corona_size)
                    si.corona_pull = float(_read_xml_value(cor, "pull", si.corona_pull) or si.corona_pull)
                    si.corona_face_camera = _read_bool(_read_xml_value(cor, "faceCamera", si.corona_face_camera), si.corona_face_camera)

                update_rotator_settings(si, context)

            if imported_scale_factor is not None:
                apply_scale_to_settings(s, imported_scale_factor)

            off_key = off_pattern_key(s)
            s.left_head = normalize_pattern_key(s.left_head) if s.left_head else off_key
            s.right_head = normalize_pattern_key(s.right_head) if s.right_head else off_key
            s.left_tail = normalize_pattern_key(s.left_tail) if s.left_tail else off_key
            s.right_tail = normalize_pattern_key(s.right_tail) if s.right_tail else off_key

            for i, si in enumerate(s.sirens, start=1):
                si.index = i
                si.name = f"siren{i}"
                si.color_preset = normalize_color_key(si.color_preset)
                if getattr(si, "pattern_source", "LIBRARY") != "CUSTOM":
                    si.pattern_choice = normalize_pattern_key(si.pattern_choice or off_key)
                if si.siren_type == "ROTATOR":
                    update_rotator_settings(si, context)
                sync_siren_selector_controls(si)

            if not s.saved_config:
                s.saved_config = NO_SAVED_CFG
            clear_missing_associations(context.scene)
            try:
                current_id = int(s.vehicle_id)
            except Exception:
                current_id = 0
            if current_id <= 0:
                s.vehicle_id = generate_siren_id(s.vehicle_name)
        finally:
            resume_preview_updates()

        auto_detect_scene_sirens(context.scene, create_missing=False, sync_direction=False)
        apply_all_siren_directions(context.scene)
        s.preview_time_origin = _time.time()
        s.preview_dirty = True
        refresh_siren_preview_cache(context.scene)
        tag_all_ui_redraw()
        self.report({"INFO"}, f"Imported carcols: {fp}")
        return {"FINISHED"}

    def invoke(self, context, event):
        self.filepath = bpy.path.abspath("//")
        context.window_manager.fileselect_add(self)
        return {"RUNNING_MODAL"}


class NELS_MT_siren_actions(Menu):
    bl_label = "Siren Actions"
    bl_idname = "NELS_MT_siren_actions"

    def draw(self, context):
        l = self.layout
        s = getattr(context.scene, "nels", None)
        o = l.operator("nels.set_siren_count", text="Add 20 Sirens", icon="ADD")
        o.count = 20
        o = l.operator("nels.set_siren_count", text="Add 32 Sirens", icon="ADD")
        o.count = 32
        if s and len(s.sirens) == 20:
            o = l.operator("nels.set_siren_count", text="Add 12 Additional (21-32)", icon="ADD")
            o.count = 32
        if s and len(s.sirens) > 20:
            o = l.operator("nels.set_siren_count", text="Remove Sirens 21-32", icon="REMOVE")
            o.count = 20
        o = l.operator("nels.set_siren_count", text="Remove All Sirens", icon="TRASH")
        o.count = 0
        l.separator()
        l.operator("nels.swap_sirens", text="Swap Two Sirens", icon="FILE_REFRESH")

class NELS_MT_config_actions(Menu):
    bl_label = "Configuration Actions"
    bl_idname = "NELS_MT_config_actions"

    def draw(self, context):
        l = self.layout
        o = l.operator("nels.new_save_load", text="Save Configuration", icon="FILE_TICK")
        o.action = "SAVE"
        o = l.operator("nels.new_save_load", text="Reset Current to Default", icon="LOOP_BACK")
        o.action = "RESET"
        o = l.operator("nels.new_save_load", text="Delete Saved Configuration", icon="TRASH")
        o.action = "DELETE"
        l.operator("nels.export_config", text="Export Configuration", icon="EXPORT")
        l.operator("nels.import_config", text="Import Configuration", icon="IMPORT")
        l.operator("nels.import_carcols", text="Import carcols.meta", icon="FILEBROWSER")


class NELS_OT_choose_parent_skeleton(Operator):
    bl_idname = "nels.choose_parent_skeleton"
    bl_label = "Select Parent Skeleton"
    bl_options = {"REGISTER", "UNDO"}

    next_action: EnumProperty(items=[("BONE", "BONE", "")], default="BONE")
    skeleton_name: EnumProperty(items=scene_armature_items)

    def invoke(self, context, event):
        s = context.scene.nels
        arm = bpy.data.objects.get(s.armature_name) if s.armature_name else None
        if arm and arm.type == "ARMATURE":
            self.skeleton_name = arm.name
        else:
            arms = sorted({obj.name for obj in context.scene.objects if obj.type == "ARMATURE"}, key=str.lower)
            if not arms:
                msg = "Warning: Select or create a Parent Skeleton before placing a siren bone"
                s.status_message = msg
                self.report({"WARNING"}, msg)
                return {"CANCELLED"}
            self.skeleton_name = arms[0]
        return context.window_manager.invoke_props_dialog(self, width=360)

    def draw(self, context):
        l = self.layout
        l.label(text="Choose the armature that will receive the siren bone.")
        l.prop(self, "skeleton_name", text="Parent Skeleton")

    def execute(self, context):
        s = context.scene.nels
        if self.skeleton_name == "__NONE__":
            msg = "Warning: No armatures were found in the current scene"
            s.status_message = msg
            self.report({"WARNING"}, msg)
            return {"CANCELLED"}
        s.armature_name = self.skeleton_name
        s.status_message = f"Parent Skeleton set to {self.skeleton_name}"
        if self.next_action:
            return bpy.ops.nels.link_bone(action=self.next_action)
        return {"FINISHED"}


class NELS_OT_link_bone(Operator):
    bl_idname = "nels.link_bone"
    bl_label = "Link Object/Bone"
    bl_options = {"REGISTER", "UNDO"}
    action: EnumProperty(items=[("MARK", "MARK", ""), ("BONE", "BONE", ""), ("ORIGIN", "ORIGIN", "")])

    def execute(self, context):
        s = context.scene.nels
        if not s.sirens:
            return {"CANCELLED"}
        si = s.sirens[s.active_siren]
        obj = context.active_object

        if self.action == "MARK":
            if not obj:
                return {"CANCELLED"}
            nm = f"siren{si.index}"
            obj.name = nm
            si.object_name = nm
            si.enabled = True
            _store_rest_loc(obj, force=True)
            return {"FINISHED"}

        if self.action == "ORIGIN":
            sobj = siren_obj(si)
            if not sobj:
                msg = f"Warning: Assign a siren object to siren{si.index} before copying its origin"
                s.status_message = msg
                self.report({"WARNING"}, msg)
                return {"CANCELLED"}

            reference = pick_reference_object(context, si)
            if not reference:
                msg = "Warning: Select a separate helper object to copy its origin to the active siren"
                s.status_message = msg
                self.report({"WARNING"}, msg)
                return {"CANCELLED"}

            ok, msg = set_object_origin_from_reference(sobj, reference)
            s.status_message = msg
            if ok:
                si.anchor_name = reference.name
                self.report({"INFO"}, msg)
                return {"FINISHED"}
            self.report({"ERROR"}, msg)
            return {"CANCELLED"}

        arm = bpy.data.objects.get(s.armature_name) if s.armature_name else None
        if not arm or arm.type != "ARMATURE":
            scene_arms = sorted({o.name for o in context.scene.objects if o.type == "ARMATURE"}, key=str.lower)
            if not scene_arms:
                msg = "Warning: Select or create a Parent Skeleton before placing a siren bone"
                s.status_message = msg
                self.report({"WARNING"}, msg)
                return {"CANCELLED"}
            if len(scene_arms) == 1:
                s.armature_name = scene_arms[0]
                arm = bpy.data.objects.get(s.armature_name)
                s.status_message = f"Parent Skeleton set to {s.armature_name}"
            else:
                bpy.ops.nels.choose_parent_skeleton('INVOKE_DEFAULT', next_action=self.action)
                return {"FINISHED"}

        sobj = siren_obj(si)
        if not sobj:
            msg = f"Warning: Assign a siren object to siren{si.index} before placing its bone"
            s.status_message = msg
            self.report({"WARNING"}, msg)
            return {"CANCELLED"}

        anchor = pick_anchor_object(context, arm, si)
        if not anchor:
            msg = "Warning: Select an anchor object to place the siren bone"
            s.status_message = msg
            self.report({"WARNING"}, msg)
            return {"CANCELLED"}

        active = context.view_layer.objects.active
        mode = context.mode
        try:
            if mode != "OBJECT":
                bpy.ops.object.mode_set(mode="OBJECT")
            bpy.ops.object.select_all(action="DESELECT")
            arm.select_set(True)
            context.view_layer.objects.active = arm
            bpy.ops.object.mode_set(mode="EDIT")
            bn = f"siren{si.index}"
            eb = arm.data.edit_bones.get(bn) or arm.data.edit_bones.new(bn)
            head = arm.matrix_world.inverted() @ anchor.matrix_world.translation
            eb.head = head
            eb.tail = head + Vector((0.0, 0.05, 0.0))
            bpy.ops.object.mode_set(mode="OBJECT")
            wm = sobj.matrix_world.copy()
            sobj.parent = arm
            sobj.parent_type = "BONE"
            sobj.parent_bone = bn
            sobj.matrix_world = wm
            si.bone_name = bn
            si.anchor_name = anchor.name
            _store_rest_loc(sobj, force=True)
            s.status_message = f"Placed bone {bn} on {arm.name}"
        finally:
            if active and active.name in bpy.data.objects:
                context.view_layer.objects.active = active
            if mode != "OBJECT" and context.mode == "OBJECT":
                try:
                    bpy.ops.object.mode_set(mode=mode)
                except Exception:
                    pass
        return {"FINISHED"}
        if not s.armature_name:
            return {"CANCELLED"}
        arm = bpy.data.objects.get(s.armature_name)
        sobj = siren_obj(si)
        anchor = pick_anchor_object(context, arm, si)
        if not arm or arm.type != "ARMATURE" or not sobj or not anchor:
            return {"CANCELLED"}

        active = context.view_layer.objects.active
        mode = context.mode
        try:
            if mode != "OBJECT":
                bpy.ops.object.mode_set(mode="OBJECT")
            bpy.ops.object.select_all(action="DESELECT")
            arm.select_set(True)
            context.view_layer.objects.active = arm
            bpy.ops.object.mode_set(mode="EDIT")
            bn = f"siren{si.index}"
            eb = arm.data.edit_bones.get(bn) or arm.data.edit_bones.new(bn)
            head = arm.matrix_world.inverted() @ anchor.matrix_world.translation
            eb.head = head
            eb.tail = head + Vector((0.0, 0.05, 0.0))
            bpy.ops.object.mode_set(mode="OBJECT")
            wm = sobj.matrix_world.copy()
            sobj.parent = arm
            sobj.parent_type = "BONE"
            sobj.parent_bone = bn
            sobj.matrix_world = wm
            si.bone_name = bn
            si.anchor_name = anchor.name
            _store_rest_loc(sobj, force=True)
        finally:
            if active and active.name in bpy.data.objects:
                context.view_layer.objects.active = active
            if mode != "OBJECT" and context.mode == "OBJECT":
                try:
                    bpy.ops.object.mode_set(mode=mode)
                except Exception:
                    pass
        return {"FINISHED"}


class NELS_OT_sim(Operator):
    bl_idname = "nels.sim"
    bl_label = "Simulate"
    bl_options = {"REGISTER", "UNDO"}
    mode: EnumProperty(items=[("ON", "ON", ""), ("OFF", "OFF", "")])
    all: BoolProperty(default=False)

    def execute(self, context):
        scene = context.scene
        s = scene.nels
        sirens = list(s.sirens) if self.all else ([s.sirens[s.active_siren]] if s.sirens else [])
        if not sirens:
            return {"CANCELLED"}
        clear_preview_keyframes(scene, sirens)
        s.preview_generated = False
        s.preview_dirty = False
        s.auto_timeline_pending = False
        for si in sirens:
            apply_sim_state(scene, s, si, self.mode)
        try:
            bpy.context.view_layer.update()
        except Exception:
            pass
        return {"FINISHED"}


class NELS_OT_set_siren_scale_state(Operator):
    bl_idname = "nels.set_siren_scale_state"
    bl_label = "Set Siren Scale"
    bl_options = {"REGISTER", "UNDO"}

    mode: EnumProperty(items=[("ON", "On", ""), ("OFF", "Off", "")], default="ON")

    def execute(self, context):
        scene = context.scene
        s = getattr(scene, "nels", None)
        if not s or not s.sirens:
            self.report({"ERROR"}, "No sirens are available in the current configuration")
            return {"CANCELLED"}

        si = resolve_context_siren(scene, s, require_linked=True)
        if not si:
            self.report({"ERROR"}, "No linked siren could be resolved from the current selection")
            return {"CANCELLED"}

        ok, msg = bake_siren_scale_state(scene, s, si, self.mode)
        if not ok:
            self.report({"ERROR"}, msg)
            return {"CANCELLED"}
        self.report({"INFO"}, msg)
        return {"FINISHED"}


class NELS_OT_reset_siren_default_state(Operator):
    bl_idname = "nels.reset_siren_default_state"
    bl_label = "Reset Siren to Default"
    bl_options = {"REGISTER", "UNDO"}

    all: BoolProperty(default=False)

    def execute(self, context):
        scene = context.scene
        s = getattr(scene, "nels", None)
        if not s or not s.sirens:
            self.report({"ERROR"}, "No sirens are available in the current configuration")
            return {"CANCELLED"}

        sirens = list(s.sirens) if self.all else []
        if not self.all:
            si = resolve_context_siren(scene, s, require_linked=False)
            if not si:
                self.report({"ERROR"}, "No siren could be resolved from the current selection")
                return {"CANCELLED"}
            sirens = [si]

        clear_preview_keyframes(scene, sirens)
        restored = 0
        for si in sirens:
            restored += restore_siren_default_state(scene, si)
        s.preview_generated = False
        s.preview_dirty = False
        if hasattr(scene, "view_layers"):
            try:
                bpy.context.view_layer.update()
            except Exception:
                pass
        self.report({"INFO"}, f"Reset {len(sirens)} siren(s) to default state")
        return {"FINISHED"}


def _clear_action_animation(action, path_predicate):
    if not action:
        return 0

    removed = 0
    for fc in _iter_action_fcurves(action):
        data_path = str(getattr(fc, "data_path", ""))
        if not path_predicate(data_path):
            continue

        try:
            points = getattr(fc, "keyframe_points", None)
            if points is not None:
                removed += len(points)
                points.clear()
        except Exception:
            try:
                points = getattr(fc, "keyframe_points", None)
                if points is not None:
                    for kp in list(points):
                        points.remove(kp)
                        removed += 1
            except Exception:
                pass

        try:
            for m in list(fc.modifiers):
                if m.type == "CYCLES":
                    fc.modifiers.remove(m)
        except Exception:
            pass

        try:
            fc.update()
        except Exception:
            pass

    return removed
def clear_preview_keyframes(scene, sirens, frame_start=None, frame_end=None):
    cleared = 0

    for si in sirens:
        o = siren_obj(si)
        if o:
            cleared += _clear_action_animation(
                getattr(getattr(o, "animation_data", None), "action", None),
                lambda p: p in {"location", "rotation_euler", "scale"},
            )

        if getattr(si, "siren_type", "FLASHER") == "ROTATOR":
            for target in rotator_preview_targets(si):
                if not target or target == o:
                    continue
                cleared += _clear_action_animation(
                    getattr(getattr(target, "animation_data", None), "action", None),
                    lambda p: p == "rotation_euler",
                )

        arm, pb = siren_pose_bone(scene, si)
        if arm and pb:
            target_bones = {pb.name}
            if getattr(si, "siren_type", "FLASHER") == "ROTATOR":
                target_bones.update(child.name for child in rotator_preview_pose_bones(scene, si))
            cleared += _clear_action_animation(
                getattr(getattr(arm, "animation_data", None), "action", None),
                lambda p, target_bones=target_bones: any(
                    p.startswith(f'pose.bones["{bone}"].') and (p.endswith(".location") or p.endswith(".rotation_euler") or p.endswith(".scale"))
                    for bone in target_bones
                ),
            )

    return cleared


def generate_timeline_preview(scene, s, sirens):
    st = int(scene.frame_start)
    fps = max(1.0, scene.render.fps / max(scene.render.fps_base, 0.0001))
    step = preview_step_frames(s.bpm, fps)
    used = 0
    cycle_end = float(st)

    for si in sirens:
        if not siren_is_active(si):
            continue

        delay_frames = start_delay_frames(s.bpm, fps, si)

        if getattr(si, "siren_type", "FLASHER") == "ROTATOR":
            cycle_frames = rotator_cycle_frames(s.bpm, fps, si)
            sample_count = max(1, int(math.ceil(cycle_frames / max(step, 0.01))))
            seen_frames = set()
            cycle_end = max(cycle_end, st + delay_frames + cycle_frames)
            apply_sim_state(scene, s, si, "ON", turns=0.0, keyframe_frame=st)
            if delay_frames > 0.0:
                apply_sim_state(scene, s, si, "ON", turns=0.0, keyframe_frame=st + delay_frames)
            for i in range(1, sample_count + 1):
                frame_offset = min(cycle_frames, i * step)
                fr = st + delay_frames + frame_offset
                fr_key = round(float(fr), 6)
                if fr_key in seen_frames:
                    continue
                seen_frames.add(fr_key)
                turns = 0.0 if cycle_frames <= 0.0 else (frame_offset / cycle_frames)
                apply_sim_state(scene, s, si, "ON", turns=turns, keyframe_frame=fr)
        else:
            bits, _, _ = pattern_triplet(s, si)
            bit_count = max(1, len(bits))
            cycle_end = max(cycle_end, st + delay_frames + ((bit_count - 1) * step))
            if delay_frames > 0.0:
                apply_sim_state(scene, s, si, "OFF", turns=0.0, keyframe_frame=st)
            for i, ch in enumerate(bits):
                fr = st + delay_frames + (i * step)
                mode = "ON" if ch == "1" else "OFF"
                apply_sim_state(scene, s, si, mode, turns=0.0, keyframe_frame=fr)

        _set_preview_key_interpolation(scene, si)
        used += 1

    if used:
        scene.frame_end = max(int(scene.frame_start), int(math.ceil(cycle_end)))
    return used, cycle_end


class NELS_OT_preview_clear(Operator):
    bl_idname = "nels.preview_clear"
    bl_label = "Clear Timeline"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        s = context.scene.nels
        scene = context.scene
        cleared = clear_preview_keyframes(scene, list(s.sirens))
        s.preview_generated = False
        s.preview_dirty = False
        self.report({"INFO"}, f"Cleared {cleared} keyframes")
        return {"FINISHED"}


class NELS_OT_update_check(Operator):
    bl_idname = "nels.update_check"
    bl_label = "Check for Updates"
    bl_options = {"REGISTER"}

    def execute(self, context):
        if begin_update_operation("CHECK", automatic=False):
            self.report({"INFO"}, "Checking GitHub for updates")
            return {"FINISHED"}
        self.report({"WARNING"}, "An update task is already running")
        return {"CANCELLED"}


class NELS_OT_update_install(Operator):
    bl_idname = "nels.update_install"
    bl_label = "Install Update"
    bl_options = {"REGISTER"}

    def execute(self, context):
        s = getattr(context.scene, "nels", None)
        if not s:
            self.report({"ERROR"}, "No scene settings available")
            return {"CANCELLED"}
        if getattr(s, "update_install_in_progress", False) or getattr(s, "update_check_in_progress", False):
            self.report({"WARNING"}, "An update task is already running")
            return {"CANCELLED"}
        if not getattr(s, "update_available", False):
            self.report({"WARNING"}, "No newer update is currently available")
            return {"CANCELLED"}
        if begin_update_operation("INSTALL", automatic=False):
            self.report({"INFO"}, "Installing update from GitHub")
            return {"FINISHED"}
        self.report({"WARNING"}, "An update task is already running")
        return {"CANCELLED"}


class NELS_OT_refresh_pattern_previews(Operator):
    bl_idname = "nels.refresh_pattern_previews"
    bl_label = "Refresh Pattern Previews"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        scene = getattr(context, "scene", None)
        s = getattr(scene, "nels", None) if scene else None
        if not s:
            self.report({"ERROR"}, "No scene settings available")
            return {"CANCELLED"}

        queue_preview_refresh_feedback(scene)
        mark_preview_dirty(context, scene=scene, immediate=False)
        self.report({"INFO"}, "Preview refresh started")
        return {"FINISHED"}


class NELS_OT_preview(Operator):
    bl_idname = "nels.preview"
    bl_label = "Generate Siren Preview"
    bl_options = {"REGISTER", "UNDO"}

    scope: EnumProperty(items=[("ACTIVE", "ACTIVE", ""), ("ALL", "ALL", "")], default="ALL")

    def execute(self, context):
        s = context.scene.nels
        scene = context.scene

        if self.scope == "ACTIVE":
            if not s.sirens:
                return {"CANCELLED"}
            idx = max(0, min(s.active_siren, len(s.sirens) - 1))
            siren_list = [s.sirens[idx]]
        else:
            siren_list = list(s.sirens)

        clear_preview_keyframes(scene, siren_list)

        used, _cycle_end = generate_timeline_preview(scene, s, siren_list)
        if used:
            s.preview_generated = True
            s.preview_dirty = False
            return {"FINISHED"}
        return {"CANCELLED"}

def e(parent, tag, value=None):
    n = ET.SubElement(parent, tag)
    if value is not None:
        n.set("value", str(value))
    return n


def build_xml(s):
    root = ET.Element("CVehicleModelInfoVarGlobal")
    ss = ET.SubElement(root, "Sirens")
    top = ET.SubElement(ss, "Item")
    e(top, "id", s.vehicle_id)
    ET.SubElement(top, "name").text = s.vehicle_name
    e(top, "timeMultiplier", f8(s.time_multiplier))
    e(top, "lightFalloffMax", f8(s.light_falloff_max))
    e(top, "lightFalloffExponent", f8(s.light_falloff_exp))
    e(top, "lightInnerConeAngle", f8(s.light_inner_angle))
    e(top, "lightOuterConeAngle", f8(s.light_outer_angle))
    e(top, "lightOffset", f8(s.light_offset))
    ET.SubElement(top, "textureName").text = s.texture_name
    e(top, "sequencerBpm", int(s.bpm))

    for tn, key in [("leftHeadLight", s.left_head), ("rightHeadLight", s.right_head), ("leftTailLight", s.left_tail), ("rightTailLight", s.right_tail)]:
        x = ET.SubElement(top, tn)
        p = get_pattern(s, key)
        e(x, "sequencer", bits_to_int(p.bits) if p else 0)

    e(top, "leftHeadLightMultiples", s.left_head_mult)
    e(top, "rightHeadLightMultiples", s.right_head_mult)
    e(top, "leftTailLightMultiples", s.left_tail_mult)
    e(top, "rightTailLightMultiples", s.right_tail_mult)
    e(top, "useRealLights", b(s.use_real_lights))

    sir = ET.SubElement(top, "sirens")
    slots = s.siren_count if s.siren_count > 0 else 20
    for i in range(1, slots + 1):
        si = s.sirens[i - 1] if i - 1 < len(s.sirens) else None
        active = siren_has_output(s, si)
        sir.append(ET.Comment(f"siren{i}" if active else f"inactive siren{i}"))
        it = ET.SubElement(sir, "Item")
        if not active:
            for tag in ["rotation", "flashiness"]:
                sec = ET.SubElement(it, tag)
                e(sec, "delta", f8(0))
                e(sec, "start", f8(0))
                e(sec, "speed", f8(0))
                e(sec, "sequencer", 0)
                e(sec, "multiples", 0)
                e(sec, "direction", b(True))
                e(sec, "syncToBpm", b(True))
            c = ET.SubElement(it, "corona")
            e(c, "intensity", f8(0)); e(c, "size", f8(0)); e(c, "pull", f8(0.00000001)); e(c, "faceCamera", b(False))
            e(it, "color", "0xFFFF0000")
            e(it, "intensity", f8(0))
            e(it, "lightGroup", 0)
            e(it, "rotate", b(False)); e(it, "scale", b(True)); e(it, "scaleFactor", 0)
            e(it, "flash", b(True)); e(it, "light", b(True)); e(it, "spotLight", b(True)); e(it, "castShadows", b(False))
            continue

        _, seq, vis = pattern_triplet(s, si)
        d = dir_val(si)
        is_rot = si.siren_type == "ROTATOR"
        rot_speed_val = rot_speed(s.bpm, si) if is_rot else 0.0
        rot_seq = seq if is_rot and vis in {"BOTH", "ROTATOR"} else 0
        rot_mult = si.light_multiples if is_rot else 0
        rot_dir = bool(getattr(si, "rotator_clockwise", True)) if is_rot else True
        rot_delta = d if is_rot else 0.0

        rot = ET.SubElement(it, "rotation")
        e(rot, "delta", f8(rot_delta))
        e(rot, "start", f8(si.start_delay))
        e(rot, "speed", f8(rot_speed_val))
        e(rot, "sequencer", rot_seq)
        e(rot, "multiples", rot_mult)
        e(rot, "direction", b(rot_dir)); e(rot, "syncToBpm", b(si.sync_to_bpm))

        fl = ET.SubElement(it, "flashiness")
        if is_rot:
            e(fl, "delta", f8(rot_delta)); e(fl, "start", f8(si.start_delay)); e(fl, "speed", f8(rot_speed_val))
            e(fl, "sequencer", rot_seq)
            e(fl, "multiples", rot_mult); e(fl, "direction", b(rot_dir)); e(fl, "syncToBpm", b(si.sync_to_bpm))
        else:
            e(fl, "delta", f8(d)); e(fl, "start", f8(si.start_delay)); e(fl, "speed", f8(si.light_speed))
            e(fl, "sequencer", seq if vis in {"BOTH", "FLASHER"} else 0)
            e(fl, "multiples", si.light_multiples); e(fl, "direction", b(True)); e(fl, "syncToBpm", b(si.sync_to_bpm))

        c = ET.SubElement(it, "corona")
        e(c, "intensity", f8(si.corona_intensity)); e(c, "size", f8(si.corona_size)); e(c, "pull", f8(si.corona_pull)); e(c, "faceCamera", b(si.corona_face_camera))
        e(it, "color", color_hex(s, si)); e(it, "intensity", f8(si.light_intensity)); e(it, "lightGroup", si.light_group)
        e(it, "rotate", b(is_rot)); e(it, "scale", b(True)); e(it, "scaleFactor", f8(scale_val(si)))
        e(it, "flash", b(si.flash)); e(it, "light", b(si.light)); e(it, "spotLight", b(si.spot_light)); e(it, "castShadows", b(si.cast_shadows))
    return xml.dom.minidom.parseString(ET.tostring(root, encoding="utf-8")).toprettyxml(indent="\t")


class NELS_OT_export(Operator):
    bl_idname = "nels.export"
    bl_label = "Export carcols.meta"

    def execute(self, context):
        s = context.scene.nels
        fp = bpy.path.abspath(s.export_path)
        if not fp.lower().endswith(".meta"):
            fp += ".meta"
        out_dir = os.path.dirname(fp)
        if out_dir:
            os.makedirs(out_dir, exist_ok=True)
        with open(fp, "w", encoding="utf-8") as h:
            h.write(build_xml(s))
        s.status_message = f"Export complete: {fp}"
        self.report({"INFO"}, s.status_message)
        return {"FINISHED"}

class VIEW3D_MT_nels(Menu):
    bl_label = "GTA 000 Tools"
    bl_idname = "VIEW3D_MT_nels"

    def draw(self, context):
        l = self.layout
        l.menu("NELS_MT_siren_actions", icon="DOWNARROW_HLT")
        l.separator()
        o = l.operator("nels.sim", text="Simulate All Off"); o.all = True; o.mode = "OFF"
        o = l.operator("nels.sim", text="Simulate All On"); o.all = True; o.mode = "ON"
        l.operator("nels.export")

def draw_obj_menu(self, context):
    self.layout.separator()
    self.layout.menu(VIEW3D_MT_nels.bl_idname, icon="LIGHT")


def register_panel_icons():
    unregister_panel_icons()
    icons_dir = os.path.join(os.path.dirname(__file__), "icons")
    if not os.path.isdir(icons_dir):
        return

    pcoll = bpy.utils.previews.new()
    loaded_any = False
    for key, stem in PANEL_ICON_FILES.items():
        for ext in PANEL_ICON_EXTENSIONS:
            fp = os.path.join(icons_dir, stem + ext)
            if not os.path.isfile(fp):
                continue
            try:
                pcoll.load(key, fp, "IMAGE")
                loaded_any = True
                break
            except Exception:
                continue

    if not loaded_any:
        bpy.utils.previews.remove(pcoll)
        return

    _PREVIEW_COLLECTIONS["panel_icons"] = pcoll


def unregister_panel_icons():
    pcoll = _PREVIEW_COLLECTIONS.pop("panel_icons", None)
    if not pcoll:
        return
    try:
        bpy.utils.previews.remove(pcoll)
    except Exception:
        pass


def get_panel_icon_value(key):
    pcoll = _PREVIEW_COLLECTIONS.get("panel_icons")
    if not pcoll:
        return 0
    try:
        if key in pcoll:
            return pcoll[key].icon_id
    except Exception:
        pass
    return 0


def draw_panel_header_icon(layout, key):
    icon_value = get_panel_icon_value(key)
    if icon_value:
        layout.label(text="", icon_value=icon_value)
    else:
        layout.label(text="", icon=PANEL_FALLBACK_ICONS.get(key, "NONE"))


def siren_row_shows_status_icon(scene, si):
    s = getattr(scene, "nels", None) if scene else None
    if not s or not si:
        return True
    if getattr(si, "siren_type", "FLASHER") == "ROTATOR":
        return True
    bits, seq, vis = pattern_triplet(s, si)
    return bool(seq and vis in {"BOTH", "FLASHER"})


def siren_status_details(scene, si):
    if not si:
        return "ERROR", "Missing siren data"

    issues = []
    expected_name = f"siren{getattr(si, 'index', 0)}"
    scene_objects = list(getattr(scene, "objects", [])) if scene else []
    scene_object_names = {obj.name for obj in scene_objects}
    settings = getattr(scene, "nels", None) if scene else None

    mesh_name = str(getattr(si, "object_name", "") or "").strip()
    if mesh_name:
        mesh_obj = bpy.data.objects.get(mesh_name)
        if mesh_obj is None:
            issues.append(f"Missing mesh: linked object '{mesh_name}' was not found")
        elif mesh_obj.type != "MESH":
            issues.append(f"Invalid mesh link: '{mesh_name}' is not a mesh")
        elif scene and mesh_obj.name not in scene_object_names:
            issues.append(f"Missing mesh: linked object '{mesh_name}' is not in the current scene")
    else:
        fallback = bpy.data.objects.get(expected_name)
        if fallback is None or fallback.type != "MESH" or (scene and fallback.name not in scene_object_names):
            issues.append(f"Missing mesh: assign a mesh or rename it to '{expected_name}'")

    armature_name = str(getattr(settings, "armature_name", "") or "").strip() if settings else ""
    bone_name = str(getattr(si, "bone_name", "") or "").strip()
    armatures = [obj for obj in scene_objects if obj.type == "ARMATURE"]

    def bone_exists(name):
        if not name:
            return False
        for arm in armatures:
            if name in arm.data.bones:
                return True
        return False

    if armature_name:
        arm_obj = bpy.data.objects.get(armature_name)
        if arm_obj is None:
            issues.append(f"Missing parent skeleton: '{armature_name}' was not found")
        elif arm_obj.type != "ARMATURE":
            issues.append(f"Invalid parent skeleton: '{armature_name}' is not an armature")
        elif scene and arm_obj.name not in scene_object_names:
            issues.append(f"Missing parent skeleton: '{armature_name}' is not in the current scene")

    if bone_name:
        if not bone_exists(bone_name):
            issues.append(f"Missing bone: linked bone '{bone_name}' was not found")
    else:
        if not bone_exists(expected_name):
            issues.append(f"Missing bone: place or link bone '{expected_name}'")

    if issues:
        return "ERROR", "; ".join(dict.fromkeys(issues))
    return "LIGHT", "Configured: mesh and bone are linked"


class NELS_OT_siren_status_info(Operator):
    bl_idname = "nels.siren_status_info"
    bl_label = "Siren Status"
    bl_options = {"INTERNAL"}

    message: StringProperty(default="")

    @classmethod
    def description(cls, _context, properties):
        return str(getattr(properties, "message", "") or "Siren status")

    def execute(self, context):
        msg = str(getattr(self, "message", "") or "Siren status")
        self.report({"INFO"}, msg)
        return {"FINISHED"}


class NELS_UL_sirens(UIList):
    def draw_item(self, context, layout, data, item, icon, active_data, active_propname, index=0, flt_flag=0):
        if self.layout_type in {"DEFAULT", "COMPACT"}:
            row = layout.row(align=True)
            split = row.split(factor=0.85, align=True)
            left = split.row(align=True)
            scene = getattr(context, "scene", None)
            if siren_row_shows_status_icon(scene, item):
                icon_name, tooltip = siren_status_details(scene, item)
                op = left.operator("nels.siren_status_info", text="", icon=icon_name, emboss=False)
                op.message = tooltip
            else:
                left.label(text="", icon="BLANK1")
            left.label(text=f"siren{item.index}")
            right = split.row(align=True)
            if getattr(data, "list_flash_preview", True):
                right.prop(item, "preview_color_cache", text="")
            else:
                right.label(text="")
        else:
            layout.alignment = "CENTER"
            layout.label(text=str(item.index))


class NELS_UL_patterns(UIList):
    def draw_item(self, context, layout, data, item, icon, active_data, active_propname, index=0, flt_flag=0):
        if self.layout_type in {"DEFAULT", "COMPACT"}:
            row = layout.row(align=True)
            split = row.split(factor=0.82, align=True)
            left = split.row(align=True)
            if pattern_duplicate_indices(data, index):
                icon_name = "INFO" if pattern_duplicate_is_allowed(data, index) else "ERROR"
            else:
                icon_name = "FILE_TEXT"
            left.label(text=pattern_display_name(data, index), icon=icon_name)
        else:
            layout.alignment = "CENTER"
            layout.label(text=str(index + 1))


class VIEW3D_PT_nels(Panel):
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "Tool"
    bl_label = "Lightbar Configuration"
    bl_options = {"DEFAULT_CLOSED"}

    def draw_header(self, context):
        draw_panel_header_icon(self.layout, "lightbar")

    def draw(self, context):
        l = self.layout
        try:
            s = getattr(context.scene, "nels", None)
            if not s:
                l.label(text="No scene settings available")
                return

            b0 = l.box(); b0.label(text="Configuration")
            r = b0.row(align=True)
            r.prop(s, "saved_config", text="Saved")
            o = r.operator("nels.new_save_load", text="", icon="FILE_REFRESH"); o.action = "LOAD"
            r.menu("NELS_MT_config_actions", text="", icon="DOWNARROW_HLT")
            b0.prop(s, "config_name")
            b0.prop(s, "vehicle_name", text="vehicle_name")
            id_row = b0.row(align=True)
            id_row.prop(s, "vehicle_id", text="siren_id")
            id_row.operator("nels.generate_siren_id", text="", icon="FILE_REFRESH")
            b0.prop(s, "bpm")
            b0.prop(s, "scale_factor_choice", text="Scale Factor")
            if s.scale_factor_choice == "CUSTOM":
                b0.prop(s, "scale_factor_custom", text="Custom Scale Factor")
            preview_row = b0.row(align=True)
            preview_row.prop(s, "head_tail_preview", text="Head/Tail Flash Preview")
            preview_row.operator("nels.refresh_pattern_previews", text="", icon="FILE_REFRESH")

            b0.label(text="Headlight Flash Patterns")
            hr = b0.row(align=True)
            hsplit = hr.split(factor=0.85, align=True)
            hleft = hsplit.row(align=True)
            hleft.prop(s, "left_head", text="Left")
            hsw = hsplit.row(align=True); hsw.enabled = False; hsw.prop(s, "left_head_preview_cache", text="")

            hr2 = b0.row(align=True)
            hsplit2 = hr2.split(factor=0.85, align=True)
            hleft2 = hsplit2.row(align=True)
            hleft2.prop(s, "right_head", text="Right")
            hsw2 = hsplit2.row(align=True); hsw2.enabled = False; hsw2.prop(s, "right_head_preview_cache", text="")

            b0.label(text="Taillight Flash Patterns")
            tr = b0.row(align=True)
            tsplit = tr.split(factor=0.85, align=True)
            tleft = tsplit.row(align=True)
            tleft.prop(s, "left_tail", text="Left")
            tsw = tsplit.row(align=True); tsw.enabled = False; tsw.prop(s, "left_tail_preview_cache", text="")

            tr2 = b0.row(align=True)
            tsplit2 = tr2.split(factor=0.85, align=True)
            tleft2 = tsplit2.row(align=True)
            tleft2.prop(s, "right_tail", text="Right")
            tsw2 = tsplit2.row(align=True); tsw2.enabled = False; tsw2.prop(s, "right_tail_preview_cache", text="")

            r = b0.row(align=True)
            r.prop(s, "show_adv_main", text="Advanced Configurations", icon="TRIA_DOWN" if s.show_adv_main else "TRIA_RIGHT", emboss=False)
            if s.show_adv_main:
                for k in ["use_real_lights", "time_multiplier", "light_falloff_max", "light_falloff_exp", "light_inner_angle", "light_outer_angle", "light_offset", "texture_name", "left_head_mult", "right_head_mult", "left_tail_mult", "right_tail_mult"]:
                    b0.prop(s, k)

            b2 = l.box(); b2.label(text="Non-ELS Sirens")
            sh = b2.row(align=True)
            sh.menu("NELS_MT_siren_actions", text="Siren Actions", icon="DOWNARROW_HLT")
            sh.operator("nels.refresh_pattern_previews", text="", icon="FILE_REFRESH")
            sh.prop(s, "list_flash_preview", text="", icon="HIDE_OFF" if s.list_flash_preview else "HIDE_ON", toggle=True)
            sh.label(text=f"Count: {len(s.sirens)}")

            if s.sirens:
                b2.template_list("NELS_UL_sirens", "nels_sirens", s, "sirens", s, "active_siren", rows=8)
                idx = max(0, min(s.active_siren, len(s.sirens) - 1))
                si = s.sirens[idx]
                b2.label(text=f"Siren: siren{si.index}")
                b2.prop(si, "siren_type")
                if si.siren_type == "ROTATOR":
                    b2.prop(si, "rotator_speed_mode")
                    if si.rotator_speed_mode == "CUSTOM":
                        b2.prop(si, "rotator_custom_percent")
                    b2.prop(si, "rotator_clockwise", text="Clockwise Rotation")
                    speed_row = b2.row(); speed_row.enabled = False
                    speed_row.prop(si, "light_speed", text="Light Speed")
                else:
                    b2.prop(si, "pattern_select", text="Pattern")
                    if si.pattern_select in {UNSAVED_PATTERN_KEY, "__CUSTOM__"}:
                        save_row = b2.row(align=True)
                        save_row.label(text="Unsaved Pattern", icon="BOOKMARKS")
                        save_row.operator("nels.save_siren_pattern", text="Save to Library", icon="ADD")
                        b2.prop(si, "custom_bits")
                        tools_row = b2.row(align=True)
                        o = tools_row.operator("nels.pattern_tools", text="Repeat to 32"); o.action = "REPEAT"; o.scope = "SIREN"
                        o = tools_row.operator("nels.pattern_tools", text="Generate Opposite"); o.action = "INVERT"; o.scope = "SIREN"
                        vrow = b2.row()
                        vrow.prop(si, "custom_value", text="Sequencer")

                b2.prop(si, "color_select", text="Colour")
                if si.color_select == "__CUSTOM__":
                    b2.prop(si, "custom_color", text="Custom Colour")
                    b2.label(text=f"Output: {color_hex(s, si)}")

                frow = b2.row(align=True)
                split = frow.split(factor=0.85, align=True)
                left = split.row(align=True)
                left.prop(si, "flash_preview", text="Flash Preview")
                sw = split.row(align=True)
                sw.prop(si, "preview_color_cache", text="")

                b2.prop(si, "direction_select", text="Direction")
                if si.direction_select == "__CUSTOM__":
                    b2.prop(si, "custom_direction", text="Custom Direction")
                b2.prop(si, "sync_to_bpm")

                lb = b2.box(); lb.label(text="Object/Bone Linking")
                lb.prop_search(s, "armature_name", bpy.data, "objects", text="Parent Skeleton")
                lb.operator("nels.auto_detect", text="Auto-Detect Sirens/Bones", icon="VIEWZOOM")
                o = lb.operator("nels.link_bone", text="Assign Selected Object to Siren", icon="OUTLINER_OB_MESH"); o.action = "MARK"
                o = lb.operator("nels.link_bone", text="Place Bone at Selected Origin", icon="BONE_DATA"); o.action = "BONE"
                lb.prop(si, "object_name", text="Mesh")
                lb.prop(si, "bone_name", text="Bone")
                direction_warning = active_siren_direction_warning(context.scene)
                if direction_warning:
                    warn_box = lb.box()
                    warn_box.alert = True
                    warn_box.label(text=direction_warning, icon="ERROR")

                r = b2.row(align=True)
                r.prop(si, "show_advanced", text="Other Configurations", icon="TRIA_DOWN" if si.show_advanced else "TRIA_RIGHT", emboss=False)
                if si.show_advanced:
                    for k in ["flash", "light", "spot_light", "cast_shadows", "light_group", "start_delay", "light_speed", "light_multiples", "corona_intensity", "corona_size", "corona_pull", "light_intensity", "corona_face_camera"]:
                        b2.prop(si, k)
            else:
                b2.label(text="No sirens configured yet")

            b4 = l.box(); b4.label(text="Export")
            b4.prop(s, "export_path")
            b4.operator("nels.export", icon="EXPORT")

            if getattr(s, "status_message", ""):
                wb = l.box()
                msg = str(s.status_message)
                warn = msg.lower().startswith("warning") or msg.lower().startswith("error")
                wb.alert = warn
                wb.label(text=msg, icon="ERROR" if warn else "INFO")
        except Exception as ex:
            l.box().label(text=f"UI Error: {ex}")

class VIEW3D_PT_nels_patterns(Panel):
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "Tool"
    bl_label = "Flash Patterns Library"
    bl_options = {"DEFAULT_CLOSED"}

    def draw_header(self, context):
        draw_panel_header_icon(self.layout, "patterns")

    def draw(self, context):
        l = self.layout
        try:
            s = getattr(context.scene, "nels", None)
            if not s:
                l.label(text="No scene settings available")
                return

            row = l.row()
            row.template_list("NELS_UL_patterns", "nels_patterns", s, "patterns", s, "active_pattern", rows=5)
            col = row.column(align=True)
            o = col.operator("nels.pattern_tools", text="", icon="ADD"); o.action = "ADD"; o.scope = "LIB"
            o = col.operator("nels.pattern_tools", text="", icon="DUPLICATE"); o.action = "DUPLICATE"; o.scope = "LIB"
            o = col.operator("nels.pattern_tools", text="", icon="REMOVE"); o.action = "REMOVE"; o.scope = "LIB"

            lib = l.box(); lib.label(text="Pattern Library File")
            lib.prop(s, "pattern_library_path", text="")
            lr = lib.row(align=True)
            o = lr.operator("nels.pattern_library_io", text="Export Library", icon="EXPORT"); o.action = "EXPORT"
            o = lr.operator("nels.pattern_library_io", text="Import Library", icon="IMPORT"); o.action = "IMPORT"

            if not s.patterns:
                l.label(text="No patterns yet. Click + or initialize defaults.")
                l.operator("nels.initialize_defaults", icon="FILE_REFRESH")
                return

            p = s.patterns[s.active_pattern] if 0 <= s.active_pattern < len(s.patterns) else s.patterns[0]
            dup_matches = pattern_duplicate_indices(s, s.active_pattern)
            if dup_matches:
                dup_box = l.box()
                dup_allowed = pattern_duplicate_is_allowed(s, s.active_pattern)
                dup_box.alert = not dup_allowed
                dup_box.label(text=f"Duplicate pattern name: {p.name} ({len(dup_matches)} entries)", icon="INFO" if dup_allowed else "ERROR")
                dup_row = dup_box.row(align=True)
                if dup_allowed:
                    o = dup_row.operator("nels.pattern_duplicate_resolution", text="Warn Again")
                    o.action = "WARN"
                    o.index = s.active_pattern
                else:
                    o = dup_row.operator("nels.pattern_duplicate_resolution", text="Keep Both")
                    o.action = "ALLOW"
                    o.index = s.active_pattern
                o = dup_row.operator("nels.pattern_duplicate_resolution", text="Keep Selected Only")
                o.action = "KEEP_SELECTED"
                o.index = s.active_pattern
            l.prop(p, "name")
            l.prop(p, "bits")
            r = l.row(align=True)
            o = r.operator("nels.pattern_tools", text="Repeat to 32"); o.action = "REPEAT"; o.scope = "LIB"
            o = r.operator("nels.pattern_tools", text="Opposite Pattern"); o.action = "INVERT"; o.scope = "LIB"
            vrow = l.row()
            vrow.prop(p, "value", text="Sequencer")
        except Exception as ex:
            l.box().label(text=f"UI Error: {ex}")

class VIEW3D_PT_nels_colors(Panel):
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "Tool"
    bl_label = "Colours"
    bl_options = {"DEFAULT_CLOSED"}

    def draw_header(self, context):
        draw_panel_header_icon(self.layout, "colors")

    def draw(self, context):
        l = self.layout
        try:
            s = getattr(context.scene, "nels", None)
            if not s:
                l.label(text="No scene settings available")
                return

            row = l.row()
            row.template_list("UI_UL_list", "nels_colors", s, "colors", s, "active_color", rows=6)
            col = row.column(align=True)
            o = col.operator("nels.color_tools", text="", icon="ADD"); o.action = "ADD"
            o = col.operator("nels.color_tools", text="", icon="REMOVE"); o.action = "REMOVE"

            if not s.colors:
                l.label(text="No colours found. Initialize defaults.")
                l.operator("nels.initialize_defaults", icon="FILE_REFRESH")
                return

            idx = max(0, min(s.active_color, len(s.colors) - 1))
            c = s.colors[idx]
            l.prop(c, "name")
            l.prop(c, "rgb", text="Colour")
            vrow = l.row()
            vrow.enabled = False
            vrow.prop(c, "value", text="Output")
        except Exception as ex:
            l.box().label(text=f"UI Error: {ex}")

class VIEW3D_PT_nels_car_functions(Panel):
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "Tool"
    bl_label = "Car Functions"
    bl_options = {"DEFAULT_CLOSED"}

    def draw_header(self, context):
        draw_panel_header_icon(self.layout, "car_functions")

    def draw(self, context):
        l = self.layout
        try:
            s = getattr(context.scene, "nels", None)
            if not s:
                l.label(text="No scene settings available")
                return


            lights = l.box(); lights.label(text="Vehicle Lights")
            lights.prop(s, "car_headlights_on", text="Headlights")
            lights.prop(s, "car_taillights_on", text="Taillights")
            lights.prop(s, "car_left_indicator_on", text="Left Indicator")
            lights.prop(s, "car_right_indicator_on", text="Right Indicator")
            lights.prop(s, "car_extra_lights_on", text="Extra Lights")
            lr = lights.row(align=True)
            o = lr.operator("nels.car_lights_sim", text="Apply Light Simulation", icon="LIGHT"); o.action = "APPLY"
            o = lr.operator("nels.car_lights_sim", text="Reset Light Simulation", icon="LOOP_BACK"); o.action = "RESET"

            extra_box = l.box(); extra_box.label(text="Extras")
            extras = scene_extra_objects(context.scene)
            if not extras:
                extra_box.label(text="No extras found on scene objects")
                return

            top = extra_box.row(align=True)
            o = top.operator("nels.extras_visibility_all", text="Show All", icon="HIDE_OFF")
            o.show = True
            o = top.operator("nels.extras_visibility_all", text="Hide All", icon="HIDE_ON")
            o.show = False

            for obj in extras:
                visible = is_object_visible(obj)
                row = extra_box.row(align=True)
                row.label(text=extra_display_name(obj))
                o = row.operator("nels.extra_visibility", text="Hide" if visible else "Show")
                o.object_name = obj.name
                o.show = not visible
        except Exception as ex:
            l.box().label(text=f"UI Error: {ex}")


class VIEW3D_PT_nels_simulation(Panel):
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "Tool"
    bl_label = "Simulation Preview"
    bl_options = {"DEFAULT_CLOSED"}

    def draw_header(self, context):
        draw_panel_header_icon(self.layout, "simulation")

    def draw(self, context):
        l = self.layout
        try:
            s = getattr(context.scene, "nels", None)
            if not s:
                l.label(text="No scene settings available")
                return

            if s.sirens:
                idx = max(0, min(s.active_siren, len(s.sirens) - 1))
                si = s.sirens[idx]
                l.label(text=f"Scale Factor (from config): {format_scale_factor(scale_factor_from_siren(si, scene=context.scene))}")
                l.label(text=f"Active Siren: siren{si.index}")
                r = l.row(align=True)
                o = r.operator("nels.sim", text="Simulate Siren Off"); o.mode = "OFF"; o.all = False
                o = r.operator("nels.sim", text="Simulate Siren On"); o.mode = "ON"; o.all = False
            else:
                sf = max(0.0, float(getattr(s, "scale_factor", 0.5)))
                l.label(text=f"Scale Factor (from config): {format_scale_factor((1.0 / sf) if sf > 0.0 else 0.0)}")

            r = l.row(align=True)
            o = r.operator("nels.sim", text="Simulate All Sirens Off"); o.mode = "OFF"; o.all = True
            o = r.operator("nels.sim", text="Simulate All Sirens On"); o.mode = "ON"; o.all = True

            l.prop(s, "auto_timeline_preview", text="Auto Rebuild Timeline")
            l.operator("nels.preview_clear", text="Clear Timeline", icon="TRASH")
            o = l.operator("nels.preview", text="Generate Individual Siren Preview", icon="ANIM_DATA")
            o.scope = "ACTIVE"
            o = l.operator("nels.preview", text="Generate All Sirens Preview", icon="ANIM")
            o.scope = "ALL"
        except Exception as ex:
            l.box().label(text=f"UI Error: {ex}")


class VIEW3D_PT_nels_useful_tools(Panel):
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "Tool"
    bl_label = "Useful Tools"
    bl_options = {"DEFAULT_CLOSED"}

    def draw_header(self, context):
        draw_panel_header_icon(self.layout, "useful_tools")

    def draw(self, context):
        l = self.layout
        try:
            s = getattr(context.scene, "nels", None)
            if not s or not s.sirens:
                l.label(text="No sirens configured yet")
                return

            si = resolve_context_siren(context.scene, s, require_linked=False, update_active=False)
            if si:
                l.label(text=f"Working Siren: siren{si.index}")
            row = l.row(align=True)
            o = row.operator("nels.set_siren_scale_state", text="Set Siren Scale (Off)", icon="FULLSCREEN_EXIT")
            o.mode = "OFF"
            o = row.operator("nels.set_siren_scale_state", text="Set Siren Scale (On)", icon="FULLSCREEN_ENTER")
            o.mode = "ON"
            o = l.operator("nels.link_bone", text="Set Origin to Selected Object", icon="OBJECT_ORIGIN")
            o.action = "ORIGIN"
            o = l.operator("nels.reset_siren_default_state", text="Reset Active Siren", icon="LOOP_BACK")
            o.all = False
            o = l.operator("nels.reset_siren_default_state", text="Reset All Sirens", icon="FILE_REFRESH")
            o.all = True
        except Exception as ex:
            l.box().label(text=f"UI Error: {ex}")


class VIEW3D_PT_nels_updates(Panel):
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "Tool"
    bl_label = "Updates"
    bl_options = {"DEFAULT_CLOSED"}

    def draw_header(self, context):
        draw_panel_header_icon(self.layout, "updates")

    def draw(self, context):
        l = self.layout
        try:
            s = getattr(context.scene, "nels", None)
            if not s:
                l.label(text="No scene settings available")
                return

            current_version = version_to_str(addon_version_tuple())
            l.label(text=f"Current Version: {current_version}")
            l.label(text=f"Latest Version: {s.update_remote_version or 'Not checked yet'}")
            if getattr(s, "update_last_checked", ""):
                l.label(text=f"Last Checked: {s.update_last_checked}")
            l.prop(s, "update_check_on_startup", text="Check for Updates on Startup")

            status = str(getattr(s, "update_status", "") or "")
            if getattr(s, "update_restart_required", False):
                box = l.box()
                box.alert = True
                box.label(text=status or "Update installed. Restart Blender.", icon="ERROR")
            elif getattr(s, "update_available", False):
                box = l.box()
                box.alert = True
                box.label(text=status or "Update available", icon="IMPORT")
            elif status:
                icon = "TIME" if (getattr(s, "update_check_in_progress", False) or getattr(s, "update_install_in_progress", False)) else "INFO"
                l.label(text=status, icon=icon)

            row = l.row(align=True)
            row.enabled = not (getattr(s, "update_check_in_progress", False) or getattr(s, "update_install_in_progress", False))
            row.operator("nels.update_check", text="Check for Updates", icon="FILE_REFRESH")
            sub = row.row(align=True)
            sub.enabled = bool(getattr(s, "update_available", False))
            sub.operator("nels.update_install", text="Install Update", icon="IMPORT")

            open_row = l.row(align=True)
            open_row.operator("wm.url_open", text="Open GitHub Repo", icon="URL").url = UPDATE_REPO_URL
        except Exception as ex:
            l.box().label(text=f"UI Error: {ex}")


def init_all_scenes_defaults():
    scenes = getattr(bpy.data, "scenes", None)
    if scenes is None:
        return 0.25

    for sc in scenes:
        try:
            ensure_scene_defaults(sc)
        except Exception:
            pass
    return None


def update_auto_timeline_preview(self, context):
    if getattr(self, "auto_timeline_preview", False):
        self.auto_timeline_pending = True
        self.auto_timeline_requested_at = _time.time()
        mark_preview_dirty(context, immediate=False)
    else:
        self.auto_timeline_pending = False


def rebuild_auto_timeline_preview(scene):
    global _LIVE_PREVIEW_GUARD
    s = getattr(scene, "nels", None) if scene else None
    if not s or not getattr(s, "auto_timeline_preview", False):
        return False
    if preview_updates_suspended() or _LIVE_PREVIEW_GUARD:
        return False

    _LIVE_PREVIEW_GUARD = True
    try:
        sirens = list(getattr(s, "sirens", []))
        clear_preview_keyframes(scene, sirens)
        used, _cycle_end = generate_timeline_preview(scene, s, sirens)
        s.preview_generated = bool(used)
        s.preview_dirty = False
        s.auto_timeline_pending = False
        return bool(used)
    finally:
        _LIVE_PREVIEW_GUARD = False


def refresh_live_preview(scene):
    global _LIVE_PREVIEW_GUARD
    s = getattr(scene, "nels", None) if scene else None
    if not s or (not s.preview_generated) or (not s.preview_dirty):
        return False
    if not timeline_playing():
        return False
    if _LIVE_PREVIEW_GUARD:
        return False

    _LIVE_PREVIEW_GUARD = True
    try:
        clear_preview_keyframes(scene, list(s.sirens))
        used, _cycle_end = generate_timeline_preview(scene, s, list(s.sirens))
        if used:
            s.preview_dirty = False
            return True
        return False
    finally:
        _LIVE_PREVIEW_GUARD = False


def car_light_tick_required(s):
    if not s:
        return False
    return bool(
        getattr(s, "car_headlights_on", False)
        or getattr(s, "car_taillights_on", False)
        or getattr(s, "car_left_indicator_on", False)
        or getattr(s, "car_right_indicator_on", False)
        or getattr(s, "car_extra_lights_on", False)
    )


def preview_cache_required(scene, s=None):
    s = s if s is not None else (getattr(scene, "nels", None) if scene else None)
    if not s:
        return False
    if getattr(s, "preview_refresh_pending", False):
        return True
    if getattr(s, "head_tail_preview", True):
        return True
    if getattr(s, "list_flash_preview", True):
        return True
    return any(bool(getattr(si, "flash_preview", False)) for si in getattr(s, "sirens", []))


def preview_timer_interval(scenes=None):
    interval = 0.08
    scene_iter = scenes if scenes is not None else getattr(bpy.data, "scenes", None)
    if not scene_iter:
        return interval

    for sc in scene_iter:
        s = getattr(sc, "nels", None) if sc else None
        if not s:
            continue
        if not (preview_cache_required(sc, s) or car_light_tick_required(s)):
            continue
        bpm = max(1.0, float(getattr(s, "bpm", 800) or 800))
        step_seconds = 60.0 / bpm
        # Sample a few times per flash step without forcing full-screen redraws every frame.
        target = max(0.03, min(0.08, step_seconds / 3.0))
        interval = min(interval, target)
    return interval


def nels_preview_tick():
    scenes = getattr(bpy.data, "scenes", None)
    interval = preview_timer_interval(scenes)
    needs_redraw = False
    if scenes:
        now = _time.time()
        for sc in scenes:
            try:
                refresh_direction_warning(sc)
                s = getattr(sc, "nels", None)
                if not s:
                    continue
                if getattr(s, "auto_timeline_preview", False) and getattr(s, "auto_timeline_pending", False):
                    requested = float(getattr(s, "auto_timeline_requested_at", 0.0) or 0.0)
                    if (now - requested) >= 0.15:
                        needs_redraw = rebuild_auto_timeline_preview(sc) or needs_redraw
                needs_redraw = apply_update_job_result() or needs_redraw
                if car_light_tick_required(s):
                    apply_car_light_simulation(sc, s, blink_indicators=True)
                if preview_cache_required(sc, s):
                    needs_redraw = refresh_siren_preview_cache(sc) or needs_redraw
                needs_redraw = update_preview_refresh_feedback(sc) or needs_redraw
            except Exception:
                pass

    wm = getattr(bpy.context, "window_manager", None)
    if not wm:
        return interval

    if needs_redraw:
        tag_preview_ui_redraw()
    return interval


class VIEW3D_PT_nels_tool(VIEW3D_PT_nels, Panel):
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "Tool"
    bl_label = "Lightbar Configuration"
    bl_options = {"DEFAULT_CLOSED"}


class VIEW3D_PT_nels_patterns_tool(VIEW3D_PT_nels_patterns, Panel):
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "Tool"
    bl_label = "Flash Patterns Library"
    bl_options = {"DEFAULT_CLOSED"}


class VIEW3D_PT_nels_colors_tool(VIEW3D_PT_nels_colors, Panel):
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "Tool"
    bl_label = "Colours"
    bl_options = {"DEFAULT_CLOSED"}


class VIEW3D_PT_nels_car_functions_tool(VIEW3D_PT_nels_car_functions, Panel):
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "Tool"
    bl_label = "Car Functions"
    bl_options = {"DEFAULT_CLOSED"}


class VIEW3D_PT_nels_simulation_tool(VIEW3D_PT_nels_simulation, Panel):
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "Tool"
    bl_label = "Simulation Preview"
    bl_options = {"DEFAULT_CLOSED"}


class VIEW3D_PT_nels_useful_tools_tool(VIEW3D_PT_nels_useful_tools, Panel):
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "Tool"
    bl_label = "Useful Tools"
    bl_options = {"DEFAULT_CLOSED"}


class VIEW3D_PT_nels_updates_tool(VIEW3D_PT_nels_updates, Panel):
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "Tool"
    bl_label = "Updates"
    bl_options = {"DEFAULT_CLOSED"}


class VIEW3D_PT_nels_tab(VIEW3D_PT_nels, Panel):
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "GTA 000"
    bl_label = "Lightbar Configuration"
    bl_options = {"DEFAULT_CLOSED"}


class VIEW3D_PT_nels_patterns_tab(VIEW3D_PT_nels_patterns, Panel):
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "GTA 000"
    bl_label = "Flash Patterns Library"
    bl_options = {"DEFAULT_CLOSED"}


class VIEW3D_PT_nels_colors_tab(VIEW3D_PT_nels_colors, Panel):
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "GTA 000"
    bl_label = "Colours"
    bl_options = {"DEFAULT_CLOSED"}


class VIEW3D_PT_nels_car_functions_tab(VIEW3D_PT_nels_car_functions, Panel):
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "GTA 000"
    bl_label = "Car Functions"
    bl_options = {"DEFAULT_CLOSED"}


class VIEW3D_PT_nels_simulation_tab(VIEW3D_PT_nels_simulation, Panel):
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "GTA 000"
    bl_label = "Simulation Preview"
    bl_options = {"DEFAULT_CLOSED"}


class VIEW3D_PT_nels_useful_tools_tab(VIEW3D_PT_nels_useful_tools, Panel):
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "GTA 000"
    bl_label = "Useful Tools"
    bl_options = {"DEFAULT_CLOSED"}


class VIEW3D_PT_nels_updates_tab(VIEW3D_PT_nels_updates, Panel):
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "GTA 000"
    bl_label = "Updates"
    bl_options = {"DEFAULT_CLOSED"}

@persistent
def nels_load_post(_dummy):
    init_all_scenes_defaults()


OPERATOR_DESCRIPTIONS = {
    "nels.initialize_defaults": "Initialize GTA 000 Tools defaults for the current scene.",
    "nels.pattern_tools": "Add, duplicate, remove, repeat, or invert flash patterns.",
    "nels.save_siren_pattern": "Save the active siren's unsaved pattern to the flash pattern library.",
    "nels.pattern_duplicate_resolution": "Resolve duplicate flash pattern names in the pattern library.",
    "nels.pattern_library_io": "Import or export the flash pattern library as JSON.",
    "nels.color_tools": "Add or remove colour library entries.",
    "nels.other_attr_tools": "Add or remove entries in the Other Attributes list.",
    "nels.car_lights_sim": "Apply or reset the current car light simulation state in the scene.",
    "nels.wheel_simulation": "Simulate wheel visibility from wheel bone locations.",
    "nels.extra_visibility": "Show or hide the selected extra object.",
    "nels.extras_visibility_all": "Show or hide all detected extras in the current scene.",
    "nels.set_siren_count": "Set how many non-ELS sirens are present in the current configuration.",
    "nels.swap_sirens": "Swap two linked siren meshes and bones in the scene while keeping the siren configuration rows unchanged.",
    "nels.auto_detect": "Auto-detect siren meshes and bones from scene names and existing links.",
    "nels.generate_siren_id": "Generate a siren ID value for the current vehicle configuration.",
    "nels.new_save_load": "Create, save, load, delete, or reset Blender-side lightbar configurations.",
    "nels.export_config": "Export the current Blender-side lightbar configuration to a JSON file.",
    "nels.import_config": "Import a Blender-side lightbar configuration from a JSON file.",
    "nels.import_carcols": "Import a GTA V carcols.meta file into the current Blender scene.",
    "nels.choose_parent_skeleton": "Choose which armature should be used as the parent skeleton.",
    "nels.link_bone": "Assign the selected object to the siren, place a siren bone at the selected origin, or copy a helper object origin onto the active siren mesh.",
    "nels.sim": "Simulate active or all sirens in their shown or hidden state.",
    "nels.set_siren_scale_state": "Bake the resolved siren mesh so the current visible size becomes the correct shown or hidden state without moving its origin.",
    "nels.reset_siren_default_state": "Clear preview transforms and restore the resolved siren or all sirens to their stored default pose.",
    "nels.preview_clear": "Clear generated siren preview keyframes from the timeline.",
    "nels.update_check": "Check the GTA000Tools GitHub repository for a newer addon version.",
    "nels.update_install": "Download the latest addon zip from GitHub, replace the installed addon files, and prompt for a Blender restart.",
    "nels.refresh_pattern_previews": "Force-refresh all siren, headlight, and taillight preview swatches.",
    "nels.preview": "Generate a timeline preview for the active siren or for all sirens.",
    "nels.export": "Export the current setup as a carcols.meta file.",
    "nels.siren_status_info": "Show the current siren link status and any missing mesh or bone requirements.",
}


def apply_operator_descriptions():
    for cls in classes:
        try:
            if not issubclass(cls, Operator):
                continue
        except Exception:
            continue
        if "description" in cls.__dict__:
            continue
        if "bl_description" in cls.__dict__ and str(getattr(cls, "bl_description", "") or "").strip():
            continue
        desc = str(OPERATOR_DESCRIPTIONS.get(getattr(cls, "bl_idname", ""), "") or "").strip()
        if desc:
            cls.bl_description = desc


classes = (
    NELSPattern,
    NELSColor,
    NELSOtherAttribute,
    NELSSiren,
    NELSSettings,
    NELS_OT_pattern_tools,
    NELS_OT_save_siren_pattern,
    NELS_OT_pattern_library_io,
    NELS_OT_pattern_duplicate_resolution,
    NELS_OT_color_tools,
    NELS_OT_other_attr_tools,
    NELS_OT_car_lights_sim,
    NELS_OT_extra_visibility,
    NELS_OT_extras_visibility_all,
    NELS_OT_initialize_defaults,
    NELS_OT_set_siren_count,
    NELS_OT_swap_sirens,
    NELS_OT_auto_detect,
    NELS_OT_generate_siren_id,
    NELS_OT_new_save_load,
    NELS_OT_export_config,
    NELS_OT_import_config,
    NELS_OT_import_carcols,
    NELS_MT_siren_actions,
    NELS_MT_config_actions,
    NELS_OT_choose_parent_skeleton,
    NELS_OT_link_bone,
    NELS_OT_sim,
    NELS_OT_set_siren_scale_state,
    NELS_OT_reset_siren_default_state,
    NELS_OT_preview_clear,
    NELS_OT_update_check,
    NELS_OT_update_install,
    NELS_OT_refresh_pattern_previews,
    NELS_OT_preview,
    NELS_OT_export,
    NELS_OT_siren_status_info,
    VIEW3D_MT_nels,
    NELS_UL_sirens,
    NELS_UL_patterns,
    VIEW3D_PT_nels_tool,
    VIEW3D_PT_nels_patterns_tool,
    VIEW3D_PT_nels_colors_tool,
    VIEW3D_PT_nels_car_functions_tool,
    VIEW3D_PT_nels_simulation_tool,
    VIEW3D_PT_nels_useful_tools_tool,
    VIEW3D_PT_nels_updates_tool,
    VIEW3D_PT_nels_tab,
    VIEW3D_PT_nels_patterns_tab,
    VIEW3D_PT_nels_colors_tab,
    VIEW3D_PT_nels_car_functions_tab,
    VIEW3D_PT_nels_simulation_tab,
    VIEW3D_PT_nels_useful_tools_tab,
    VIEW3D_PT_nels_updates_tab,
)

apply_operator_descriptions()

def register():
    global _UPDATE_STARTUP_SCHEDULED
    _UPDATE_STARTUP_SCHEDULED = False
    register_panel_icons()
    apply_operator_descriptions()
    for c in classes:
        bpy.utils.register_class(c)
    bpy.types.Scene.nels = PointerProperty(type=NELSSettings)
    bpy.types.VIEW3D_MT_object.append(draw_obj_menu)

    if nels_load_post not in bpy.app.handlers.load_post:
        bpy.app.handlers.load_post.append(nels_load_post)

    try:
        if not bpy.app.timers.is_registered(init_all_scenes_defaults):
            bpy.app.timers.register(init_all_scenes_defaults, first_interval=0.1)
        if not bpy.app.timers.is_registered(nels_preview_tick):
            bpy.app.timers.register(nels_preview_tick, first_interval=0.2)
    except Exception:
        pass


def unregister():
    global _UPDATE_STARTUP_SCHEDULED
    _UPDATE_STARTUP_SCHEDULED = False
    try:
        bpy.types.VIEW3D_MT_object.remove(draw_obj_menu)
    except Exception:
        pass

    if hasattr(bpy.types.Scene, "nels"):
        del bpy.types.Scene.nels

    try:
        if bpy.app.timers.is_registered(init_all_scenes_defaults):
            bpy.app.timers.unregister(init_all_scenes_defaults)
        if bpy.app.timers.is_registered(nels_preview_tick):
            bpy.app.timers.unregister(nels_preview_tick)
    except Exception:
        pass

    if nels_load_post in bpy.app.handlers.load_post:
        bpy.app.handlers.load_post.remove(nels_load_post)

    for c in reversed(classes):
        bpy.utils.unregister_class(c)

    unregister_panel_icons()

if __name__ == "__main__":
    register()









































































































































































