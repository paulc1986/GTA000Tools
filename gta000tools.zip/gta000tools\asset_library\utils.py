from __future__ import annotations

import hashlib
import json
import os
import re
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path
from typing import Any, Iterable

import bpy

from . import constants


def ensure_directory(path: Path) -> Path:
    path.mkdir(parents=True, exist_ok=True)
    return path


def config_directory() -> Path:
    try:
        base = bpy.utils.user_resource("CONFIG", path=constants.ADDON_PACKAGE, create=False)
        return ensure_directory(Path(base))
    except Exception:
        base = str(Path(tempfile.gettempdir()) / constants.ADDON_PACKAGE / "config")
        return ensure_directory(Path(base))


def cache_directory() -> Path:
    try:
        base = bpy.utils.user_resource("CACHE", path=constants.ADDON_PACKAGE, create=False)
        return ensure_directory(Path(base))
    except Exception:
        base = str(Path(tempfile.gettempdir()) / constants.ADDON_PACKAGE / "cache")
        return ensure_directory(Path(base))


def thumbnails_directory() -> Path:
    return ensure_directory(cache_directory() / constants.THUMBNAIL_CACHE_DIR)


def library_assets_directory(root_path: Path, create: bool = False) -> Path:
    root = Path(root_path)
    candidate = root / constants.LIBRARY_ASSETS_DIR_NAME
    if candidate.exists() or create:
        return ensure_directory(candidate) if create else candidate
    return root


def library_textures_directory(root_path: Path, create: bool = False) -> Path:
    path = Path(root_path) / constants.LIBRARY_TEXTURES_DIR_NAME
    return ensure_directory(path) if create else path


def library_thumbnails_directory(root_path: Path, create: bool = False) -> Path:
    path = Path(root_path) / constants.LIBRARY_THUMBNAILS_DIR_NAME
    return ensure_directory(path) if create else path


def library_config_directory(root_path: Path, create: bool = False) -> Path:
    path = Path(root_path) / constants.LIBRARY_CONFIG_DIR_NAME
    return ensure_directory(path) if create else path


def _is_within(path: Path, directory: Path) -> bool:
    try:
        resolved_path = path.resolve()
        resolved_dir = directory.resolve()
    except Exception:
        return False
    return resolved_path == resolved_dir or resolved_dir in resolved_path.parents


def _move_legacy_file(source: Path, destination: Path) -> bool:
    if not source.exists():
        return False
    try:
        if source.resolve() == destination.resolve():
            return False
    except Exception:
        pass
    ensure_directory(destination.parent)
    try:
        if destination.exists():
            source_stat = source.stat()
            dest_stat = destination.stat()
            if source_stat.st_mtime > dest_stat.st_mtime or (source_stat.st_mtime == dest_stat.st_mtime and source_stat.st_size != dest_stat.st_size):
                try:
                    destination.unlink()
                except Exception:
                    pass
                source.replace(destination)
            else:
                source.unlink()
            return True
        source.replace(destination)
        return True
    except Exception:
        try:
            shutil.move(str(source), str(destination))
            return True
        except Exception:
            return False


def _file_digest(path: Path) -> str:
    digest = hashlib.sha1(usedforsecurity=False)
    with path.open('rb') as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b''):
            if not chunk:
                break
            digest.update(chunk)
    return digest.hexdigest()


def _files_identical(first: Path, second: Path) -> bool:
    try:
        if first.stat().st_size != second.stat().st_size:
            return False
    except Exception:
        return False
    try:
        return _file_digest(first) == _file_digest(second)
    except Exception:
        return False


def _current_open_blend_path() -> Path | None:
    filepath = str(getattr(bpy.data, 'filepath', '') or '').strip()
    if not filepath:
        return None
    try:
        return Path(filepath).resolve()
    except Exception:
        return Path(filepath)


def _is_legacy_preview_file(path: Path) -> bool:
    name = path.name.lower()
    if path.suffix.lower() not in {'.png', '.jpg', '.jpeg', '.webp'}:
        return False
    if '.bgal_preview.' in name:
        return True
    if name in {'preview.png', 'preview.jpg', 'preview.jpeg', 'thumbnail.png', 'thumbnail.jpg', 'thumb.png', 'thumb.jpg', 'cover.png', 'cover.jpg'}:
        return True
    return '_preview.' in name or '_thumb.' in name


def migrate_legacy_library_layout(root_path: Path) -> dict[str, int]:
    root = Path(root_path)
    if not root.exists():
        return {'configs': 0, 'previews': 0, 'asset_blends': 0}

    config_dir = library_config_directory(root, create=True)
    thumbnails_dir = library_thumbnails_directory(root, create=True)
    textures_dir = library_textures_directory(root, create=False)
    assets_dir = library_assets_directory(root, create=True)

    moved = {'configs': 0, 'previews': 0, 'asset_blends': 0}

    for legacy_name in (constants.CATEGORY_REGISTRY_FILE_NAME, constants.TAG_REGISTRY_FILE_NAME):
        source = root / legacy_name
        target = config_dir / legacy_name
        if source.exists() and _move_legacy_file(source, target):
            moved['configs'] += 1

    for source in root.rglob(f'*{constants.USER_OVERRIDE_SUFFIX}'):
        if _is_within(source, config_dir):
            continue
        if textures_dir.exists() and _is_within(source, textures_dir):
            continue
        if assets_dir.exists() and assets_dir != root and _is_within(source, assets_dir):
            continue
        relative_parent = source.relative_to(root).parent
        target = config_dir / relative_parent / source.name
        if _move_legacy_file(source, target):
            moved['configs'] += 1

    current_open_blend = _current_open_blend_path()
    for source in root.rglob('*'):
        if not source.is_file():
            continue
        if source.suffix.lower() != '.blend':
            continue
        if _is_within(source, config_dir) or _is_within(source, thumbnails_dir):
            continue
        if textures_dir.exists() and _is_within(source, textures_dir):
            continue
        if assets_dir.exists() and assets_dir != root and _is_within(source, assets_dir):
            continue
        try:
            resolved_source = source.resolve()
        except Exception:
            resolved_source = source
        if current_open_blend is not None and resolved_source == current_open_blend:
            continue
        relative = source.relative_to(root)
        target = assets_dir / relative
        ensure_directory(target.parent)
        try:
            source_size = source.stat().st_size
        except Exception:
            source_size = 0
        if not target.exists():
            try:
                source.replace(target)
                moved['asset_blends'] += 1
            except Exception:
                try:
                    shutil.move(str(source), str(target))
                    moved['asset_blends'] += 1
                except Exception:
                    pass
            continue
        try:
            target_size = target.stat().st_size
        except Exception:
            target_size = 0
        if target_size == 0 and source_size > 0:
            try:
                target.unlink(missing_ok=True)
            except Exception:
                pass
            try:
                source.replace(target)
                moved['asset_blends'] += 1
            except Exception:
                try:
                    shutil.move(str(source), str(target))
                    moved['asset_blends'] += 1
                except Exception:
                    pass
            continue
        if source_size > 0 and _files_identical(source, target):
            try:
                source.unlink()
                moved['asset_blends'] += 1
            except Exception:
                pass

    for source in root.rglob('*'):
        if not source.is_file():
            continue
        if not _is_legacy_preview_file(source):
            continue
        if _is_within(source, thumbnails_dir):
            continue
        if textures_dir.exists() and _is_within(source, textures_dir):
            continue
        if assets_dir.exists() and assets_dir != root and _is_within(source, assets_dir):
            continue
        relative_parent = source.relative_to(root).parent
        target = thumbnails_dir / relative_parent / source.name
        if _move_legacy_file(source, target):
            moved['previews'] += 1

    return moved

def inspect_library_layout(root_path: Path) -> dict[str, list[Path]]:
    root = Path(root_path)
    issues = {
        "legacy_configs": [],
        "legacy_previews": [],
        "legacy_blends": [],
        "zero_byte_blends": [],
    }
    if not root.exists():
        return issues

    config_dir = library_config_directory(root, create=False)
    thumbnails_dir = library_thumbnails_directory(root, create=False)
    textures_dir = library_textures_directory(root, create=False)
    assets_dir = library_assets_directory(root, create=False)

    for source in root.rglob("*"):
        if not source.is_file():
            continue

        if source.suffix.lower() == ".blend":
            try:
                size = source.stat().st_size
            except Exception:
                size = -1
            if size == 0:
                issues["zero_byte_blends"].append(source)
            if (
                not _is_within(source, assets_dir)
                and not _is_within(source, config_dir)
                and not _is_within(source, thumbnails_dir)
                and not _is_within(source, textures_dir)
            ):
                issues["legacy_blends"].append(source)
            continue

        if source.name in {constants.CATEGORY_REGISTRY_FILE_NAME, constants.TAG_REGISTRY_FILE_NAME} or source.name.endswith(constants.USER_OVERRIDE_SUFFIX):
            if not _is_within(source, config_dir):
                issues["legacy_configs"].append(source)
            continue

        if _is_legacy_preview_file(source) and not _is_within(source, thumbnails_dir):
            issues["legacy_previews"].append(source)

    for key, values in issues.items():
        unique = []
        seen = set()
        for value in values:
            try:
                resolved = value.resolve()
            except Exception:
                resolved = value
            marker = str(resolved).casefold()
            if marker in seen:
                continue
            seen.add(marker)
            unique.append(resolved)
        issues[key] = sorted(unique, key=lambda item: str(item).casefold())
    return issues


def library_relative_asset_path(root_path: Path, asset_path: Path) -> Path:
    root = Path(root_path).resolve()
    asset = Path(asset_path).resolve()
    assets_dir = root / constants.LIBRARY_ASSETS_DIR_NAME
    if assets_dir.exists():
        try:
            return asset.relative_to(assets_dir.resolve())
        except Exception:
            pass
    return asset.relative_to(root)


def library_thumbnail_cache_path(root_path: Path, asset_id: str, angle_mode: str = "DEFAULT") -> Path:
    base = library_thumbnails_directory(root_path, create=True) / f"{asset_id}_v6.png"
    if str(angle_mode or "DEFAULT").upper() == "OPPOSITE":
        return base.with_name(f"{base.stem}_opp{base.suffix}")
    return base


def library_manual_preview_path(root_path: Path, blend_path: Path, item_key: str = "", display_name: str = "") -> Path:
    relative = library_relative_asset_path(root_path, blend_path)
    blend_stem = safe_slug(Path(blend_path).stem)
    candidates = []
    for value in (display_name, item_key):
        slug = safe_slug(str(value or ""))
        if slug and slug.casefold() != blend_stem.casefold() and slug not in candidates:
            candidates.append(slug)
    suffix = f"__{candidates[0]}" if candidates else ""
    filename = f"{Path(blend_path).stem}{suffix}_preview.png"
    return library_thumbnails_directory(root_path, create=True) / relative.parent / filename


def index_file_path() -> Path:
    return config_directory() / constants.INDEX_FILE_NAME


def state_file_path() -> Path:
    return config_directory() / constants.STATE_FILE_NAME


def load_json(path: Path, default: Any) -> Any:
    if not path.exists():
        return default
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return default


def save_json(path: Path, payload: Any) -> None:
    ensure_directory(path.parent)
    path.write_text(json.dumps(payload, indent=2, sort_keys=True), encoding="utf-8")


def file_signature(path: Path) -> tuple[float, int, str]:
    stat = path.stat()
    signature = f"{stat.st_mtime_ns}:{stat.st_size}"
    return stat.st_mtime, stat.st_size, signature


def stable_asset_id(*parts: str) -> str:
    raw = "::".join(parts).encode("utf-8")
    return hashlib.sha1(raw, usedforsecurity=False).hexdigest()[:16]


def safe_slug(value: str) -> str:
    slug = re.sub(r"[^A-Za-z0-9]+", "_", value.strip())
    slug = slug.strip("_")
    return slug or "asset"


def sanitize_name(value: str) -> str:
    return value.replace("\\", "/").strip()


def dedupe_preserve_order(values: Iterable[str]) -> list[str]:
    seen: set[str] = set()
    result: list[str] = []
    for value in values:
        if not value:
            continue
        if value in seen:
            continue
        seen.add(value)
        result.append(value)
    return result


def split_tag_text(value: str) -> list[str]:
    if not value:
        return []
    parts = re.split(r"[;,]", value)
    return [part.strip() for part in parts if part.strip()]


def normalize_tags(values: Iterable[str] | str | None) -> list[str]:
    if values is None:
        return []
    if isinstance(values, str):
        return split_tag_text(values)
    result: list[str] = []
    for value in values:
        if value is None:
            continue
        text = str(value).strip()
        if text:
            result.append(text)
    return dedupe_preserve_order(result)


def resolve_relative_path(source: Path, value: str) -> str:
    if not value:
        return ""
    candidate = Path(value)
    if candidate.is_absolute():
        return normalized_blend_path(str(candidate))
    return normalized_blend_path(str((source.parent / candidate).resolve()))


def normalized_blend_path(value: str) -> str:
    if not value:
        return ""
    try:
        return str(Path(value).expanduser().resolve())
    except Exception:
        return str(Path(value))


def best_display_name(filepath: Path) -> str:
    return filepath.stem.replace("_", " ").replace("-", " ").strip() or filepath.stem


def open_in_file_browser(path: str) -> tuple[bool, str]:
    target = Path(path)
    try:
        if sys.platform.startswith("win"):
            os.startfile(str(target if target.is_dir() else target.parent))  # type: ignore[attr-defined]
        elif sys.platform == "darwin":
            subprocess.Popen(["open", "-R", str(target)])
        else:
            subprocess.Popen(["xdg-open", str(target if target.is_dir() else target.parent)])
    except Exception as exc:
        return False, str(exc)
    return True, ""


def open_blend_in_new_instance(filepath: str) -> tuple[bool, str]:
    try:
        subprocess.Popen([bpy.app.binary_path, filepath])
    except Exception as exc:
        return False, str(exc)
    return True, ""


def path_exists(value: str) -> bool:
    return bool(value) and Path(value).exists()


def readable_size(num_bytes: int) -> str:
    value = float(num_bytes)
    for suffix in ("B", "KB", "MB", "GB", "TB"):
        if value < 1024.0 or suffix == "TB":
            return f"{value:.1f} {suffix}"
        value /= 1024.0
    return f"{num_bytes} B"


def safe_remove_ids(ids_to_remove: Iterable[Any]) -> None:
    unique = []
    seen: set[int] = set()
    for item in ids_to_remove:
        if item is None:
            continue
        pointer = item.as_pointer()
        if pointer in seen:
            continue
        seen.add(pointer)
        unique.append(item)
    if not unique:
        return
    try:
        bpy.data.batch_remove(unique)
    except Exception:
        for item in reversed(unique):
            try:
                item.user_clear()
            except Exception:
                pass
            try:
                id_collection = getattr(bpy.data, item.__class__.__name__.lower() + "s", None)
                if id_collection is not None:
                    id_collection.remove(item)
            except Exception:
                pass
