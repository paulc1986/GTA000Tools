"""GTA 000 gizmo toolbar scaffold.

This package is intentionally self-contained so the main GTA 000 Tools addon
can import it later without needing any of the future gizmo modules to be
merged into the legacy code paths first.
"""

from __future__ import annotations

from . import operators, properties, runtime, transform_gizmos, ui

__all__ = ("register", "unregister")


def register() -> None:
    properties.register()
    runtime.register()
    operators.register()
    ui.register()
    transform_gizmos.register()


def unregister() -> None:
    transform_gizmos.unregister()
    ui.unregister()
    operators.unregister()
    runtime.unregister()
    properties.unregister()
