﻿from __future__ import annotations

from mathutils import Vector
from pathlib import Path
import hashlib
import shutil
import subprocess
import tempfile

import bpy
from bpy_extras import view3d_utils
from bpy.props import BoolProperty, EnumProperty, IntProperty, StringProperty
from bpy.types import Operator

from . import asset_creation, runtime, scanner
from .importer import import_asset
from .index_store import toggle_favorite
from .metadata import (
    clear_user_override_for_asset,
    remove_category_registry_entry,
    remove_subcategory_registry_entry,
    remove_tag_registry_entry,
    rename_category_registry_entry,
    rename_subcategory_registry_entry,
    rename_tag_registry_entry,
    save_category_registry_entry,
    save_tag_registry_entry,
    save_user_override_for_asset,
)
from .properties import (
    _all_thumbnail_cache_paths,
    _thumbnail_cache_path,
    asset_page_count,
    get_active_asset,
    refresh_category_manager_lists,
    refresh_tag_manager_lists,
    refresh_visible_assets,
    selected_manager_category,
    selected_manager_subcategory,
    selected_manager_tag,
    set_active_asset_id,
    load_asset_create_definition_editor,
    sync_editor_fields,
)
from .preview_cache import preview_manager
from .registration import safe_register_class, safe_unregister_class
from .scanner import scan_libraries
from .thumbnail_render import render_thumbnail_for_asset
from .utils import (
    library_manual_preview_path,
    library_textures_directory,
    open_blend_in_new_instance,
    open_in_file_browser,
    safe_remove_ids,
    safe_slug,
)
from .library_io import is_current_source_blend
from .validator import validate_asset
from . import constants
from .utils import inspect_library_layout, normalize_tags


def _resolve_asset_id(context: bpy.types.Context, operator_asset_id: str) -> str:
    if operator_asset_id:
        return operator_asset_id
    asset = get_active_asset(context)
    return asset.asset_id if asset else ""


def _addon_preferences(context: bpy.types.Context):
    addon = context.preferences.addons.get(constants.ADDON_PACKAGE)
    return addon.preferences if addon else None


def _resolve_category_root(context: bpy.types.Context, explicit_root_path: str, asset) -> Path | None:
    if explicit_root_path:
        return Path(bpy.path.abspath(explicit_root_path)).resolve()
    if asset is not None and asset.root_path:
        return Path(asset.root_path)
    prefs = _addon_preferences(context)
    if prefs is None or not prefs.library_roots:
        return None
    index = max(0, min(prefs.active_root_index, len(prefs.library_roots) - 1))
    directory = prefs.library_roots[index].directory
    if not directory:
        return None
    return Path(bpy.path.abspath(directory)).resolve()


def _refresh_after_category_change(context: bpy.types.Context) -> None:
    scan_libraries(context, force=True)
    refresh_visible_assets(context)
    refresh_category_manager_lists(context)
    refresh_tag_manager_lists(context)


def _ensure_tags_in_registry(root_path: Path, tags: list[str]) -> None:
    for tag in tags:
        if tag:
            save_tag_registry_entry(root_path, tag)


def _select_manager_category_by_name(browser, name: str) -> None:
    for index, item in enumerate(browser.manager_categories):
        if item.name == name:
            browser.manager_category_index = index
            break


def _select_manager_subcategory_by_name(browser, name: str) -> None:
    for index, item in enumerate(browser.manager_subcategories):
        if item.name == name:
            browser.manager_subcategory_index = index
            break


def _select_manager_tag_by_name(browser, name: str) -> None:
    for index, item in enumerate(browser.manager_tags):
        if item.name == name:
            browser.manager_tag_index = index
            break


def _browser_import_settings(context: bpy.types.Context, asset) -> tuple[str, bool, str, bool]:
    browser = context.window_manager.bgal_browser
    namespace_prefix = ""
    if browser.use_namespace:
        namespace_prefix = browser.namespace_prefix.strip() or asset.display_name
    return (
        browser.link_mode,
        browser.make_local_after_link,
        namespace_prefix,
        browser.place_as_collection_instance,
    )


def _current_file_matches_asset(asset) -> bool:
    if asset is None or not bpy.data.filepath:
        return False
    try:
        current_file = Path(bpy.data.filepath).resolve()
    except Exception:
        current_file = Path(bpy.data.filepath)
    try:
        asset_file = Path(asset.file_path).resolve()
    except Exception:
        asset_file = Path(asset.file_path)
    if asset_file == current_file:
        return True
    try:
        asset_root = Path(getattr(asset, 'root_path', '') or '').resolve()
    except Exception:
        asset_root = Path(getattr(asset, 'root_path', '') or '')
    return bool(asset_root and current_file.parent == asset_root and current_file.name.casefold() == asset_file.name.casefold())


def _current_file_asset_candidates(context: bpy.types.Context):
    del context
    if not bpy.data.filepath:
        return []
    try:
        current_file = Path(bpy.data.filepath).resolve()
    except Exception:
        current_file = Path(bpy.data.filepath)
    direct_matches = []
    alias_matches = []
    for asset in runtime.all_assets():
        try:
            asset_file = Path(asset.file_path).resolve()
        except Exception:
            asset_file = Path(asset.file_path)
        if asset_file == current_file:
            direct_matches.append(asset)
            continue
        try:
            asset_root = Path(getattr(asset, 'root_path', '') or '').resolve()
        except Exception:
            asset_root = Path(getattr(asset, 'root_path', '') or '')
        if asset_root and current_file.parent == asset_root and current_file.name.casefold() == asset_file.name.casefold():
            alias_matches.append(asset)
    matches = direct_matches or alias_matches
    matches.sort(key=lambda item: (item.display_name.casefold(), item.relative_path.casefold(), item.asset_id))
    return matches


def _current_file_asset_items(_self, context):
    items = []
    for asset in _current_file_asset_candidates(context):
        subtitle = asset.item_key or (asset.target_names[0] if asset.target_names else asset.relative_path)
        label = asset.display_name
        description = subtitle if subtitle and subtitle != label else asset.relative_path
        items.append((asset.asset_id, label, description))
    if not items:
        items.append(("", "No matching assets", "The current .blend file is not indexed as a library asset"))
    return items


def _asset_root_path(asset) -> Path | None:
    root_value = str(getattr(asset, "root_path", "") or "").strip()
    if not root_value:
        return None
    try:
        return Path(root_value).resolve()
    except Exception:
        return Path(root_value)



def _missing_texture_names(images) -> list[str]:
    names: list[str] = []
    for image in images:
        if image is None or getattr(image, 'source', 'FILE') not in {'FILE', 'SEQUENCE', 'MOVIE'}:
            continue
        filepath = getattr(image, 'filepath', '') or ''
        if not filepath:
            continue
        try:
            resolved = Path(bpy.path.abspath(filepath, library=image.library)).resolve()
        except Exception:
            resolved = Path(filepath)
        if resolved.exists():
            continue
        label = resolved.name or Path(filepath).name or image.name
        if label and label not in names:
            names.append(label)
    return sorted(names, key=str.casefold)

def _missing_textures_for_blend(blend_path: Path) -> tuple[list[str], str | None]:
    cleanup_images = []
    images = []
    try:
        if is_current_source_blend(str(blend_path)):
            images = list(bpy.data.images)
        else:
            with bpy.data.libraries.load(str(blend_path), link=True) as (data_from, data_to):
                data_to.images = list(data_from.images)
            images = [image for image in data_to.images if image is not None]
            cleanup_images = list(images)
        return _missing_texture_names(images), None
    except Exception as exc:
        return [], str(exc)
    finally:
        if cleanup_images:
            safe_remove_ids(cleanup_images)


def _texture_dictionary_name(source_path: Path) -> str:
    if source_path.is_dir():
        return source_path.name
    if source_path.suffix.lower() == ".dds":
        return source_path.parent.name
    name = source_path.name
    if name.lower().endswith(".xml"):
        name = name[:-4]
    return Path(name).stem


def _texture_dictionary_candidate_dirs(source_path: Path) -> list[Path]:
    source = Path(source_path)
    seen: set[str] = set()
    result: list[Path] = []

    def add_directory(path: Path | None) -> None:
        if path is None:
            return
        candidate = Path(path)
        if not candidate.exists() or not candidate.is_dir():
            return
        try:
            resolved = candidate.resolve()
        except Exception:
            resolved = candidate
        key = str(resolved).casefold()
        if key in seen:
            return
        seen.add(key)
        result.append(resolved)

    dictionary_name = _texture_dictionary_name(source)
    if source.is_dir():
        add_directory(source)
        base_dir = source.parent
    else:
        add_directory(source.parent)
        if source.suffix.lower() == ".dds":
            add_directory(source.parent)
        base_dir = source.parent

    bases: list[Path] = []
    current = base_dir
    for _ in range(3):
        if current is None:
            break
        bases.append(current)
        if current.parent == current:
            break
        current = current.parent

    for base in bases:
        add_directory(base / dictionary_name)
        add_directory(base / constants.LIBRARY_TEXTURES_DIR_NAME)
        add_directory(base / constants.LIBRARY_TEXTURES_DIR_NAME / dictionary_name)
        for folder_name in ("Codewalker RPF Output", "CodeWalker RPF Output"):
            add_directory(base / folder_name)
            add_directory(base / folder_name / dictionary_name)

    return result


def _path_literal(path: Path) -> str:
    return str(path).replace("\\", "\\\\")

def _asset_missing_thumbnail(asset, context: bpy.types.Context) -> bool:
    source_path = str(getattr(asset, 'thumbnail_source', '') or '').strip()
    if source_path and Path(source_path).exists():
        return False
    cache_path = _thumbnail_cache_path(asset, context)
    return not bool(cache_path and cache_path.exists())

def _relative_issue_path(root_path: Path, path: Path) -> str:
    try:
        return str(path.resolve().relative_to(root_path.resolve()))
    except Exception:
        return path.name

def _append_limited(lines: list[str], entries: list[str], title: str, limit: int = 8) -> None:
    if not entries:
        return
    lines.append(f"{title} ({len(entries)}):")
    for item in entries[:limit]:
        lines.append(f"- {item}")
    if len(entries) > limit:
        lines.append(f"- ... and {len(entries) - limit} more")

def _capture_preview_size(context: bpy.types.Context) -> int:
    prefs = _addon_preferences(context)
    try:
        return max(512, int(getattr(prefs, "asset_preview_size_px", 48) or 48) * 8)
    except Exception:
        return 512


def _capture_frame_begin(context: bpy.types.Context, override: dict | None):
    if override is None:
        return None
    space = override.get("space_data")
    region_3d = getattr(space, "region_3d", None) if space is not None else None
    scene = context.scene
    if region_3d is None or scene is None:
        return None

    camera_data = bpy.data.cameras.new("BGAL_CapturePreviewCamera")
    camera_object = bpy.data.objects.new(camera_data.name, camera_data)
    scene.collection.objects.link(camera_object)
    previous_camera = scene.camera
    previous_perspective = region_3d.view_perspective
    scene.camera = camera_object
    try:
        with context.temp_override(**override):
            bpy.ops.view3d.camera_to_view()
            region_3d.view_perspective = "CAMERA"
    except Exception:
        safe_remove_ids([camera_object, camera_data])
        scene.camera = previous_camera
        return None
    return {
        "scene": scene,
        "region_3d": region_3d,
        "previous_camera": previous_camera,
        "previous_perspective": previous_perspective,
        "camera_object": camera_object,
        "camera_data": camera_data,
    }


def _capture_frame_end(state) -> None:
    if not state:
        return
    try:
        state["region_3d"].view_perspective = state["previous_perspective"]
    except Exception:
        pass
    try:
        state["scene"].camera = state["previous_camera"]
    except Exception:
        pass
    safe_remove_ids([state.get("camera_object"), state.get("camera_data")])


def _find_view3d_override(context: bpy.types.Context):
    window = getattr(context, "window", None)
    screen = getattr(window, "screen", None) if window is not None else None
    if screen is None:
        return None
    areas = []
    current_area = getattr(context, "area", None)
    if current_area is not None and current_area.type == "VIEW_3D":
        areas.append(current_area)
    areas.extend(area for area in screen.areas if area.type == "VIEW_3D" and area not in areas)
    for area in areas:
        region = next((region for region in area.regions if region.type == "WINDOW"), None)
        space = next((space for space in area.spaces if space.type == "VIEW_3D"), None)
        if region is None or space is None:
            continue
        return {
            "window": window,
            "screen": screen,
            "area": area,
            "region": region,
            "space_data": space,
        }
    return None


def _manual_preview_output_path(asset) -> Path:
    source_path = Path(asset.file_path).resolve()
    root_path = _asset_root_path(asset)
    if root_path is None:
        return source_path.with_name(f"{source_path.stem}_preview.png")
    return library_manual_preview_path(
        root_path,
        source_path,
        item_key=str(getattr(asset, "item_key", "") or ""),
        display_name=str(getattr(asset, "display_name", "") or "").strip(),
    )


def _capture_target_objects(context: bpy.types.Context, asset) -> set:
    scene = getattr(context, 'scene', None)
    if scene is None or asset is None:
        return set()

    scene_names = {obj.name for obj in scene.objects}
    allowed = set()
    target_kind = str(getattr(asset, 'target_kind', '') or '').upper()
    target_names = list(getattr(asset, 'target_names', []) or [])

    if target_kind == 'COLLECTION':
        for collection_name in target_names:
            collection = bpy.data.collections.get(collection_name)
            if collection is None:
                continue
            for obj in collection.all_objects:
                if obj.name in scene_names:
                    allowed.add(obj)
    else:
        for object_name in target_names:
            obj = bpy.data.objects.get(object_name)
            if obj is not None and obj.name in scene_names:
                allowed.add(obj)

    expanded = set(allowed)
    for obj in list(allowed):
        current = getattr(obj, 'parent', None)
        while current is not None:
            if current.name in scene_names:
                expanded.add(current)
            current = getattr(current, 'parent', None)
        if getattr(obj, 'type', '') == 'MESH':
            for modifier in getattr(obj, 'modifiers', []):
                if getattr(modifier, 'type', '') != 'ARMATURE':
                    continue
                armature_obj = getattr(modifier, 'object', None)
                if armature_obj is not None and armature_obj.name in scene_names:
                    expanded.add(armature_obj)
                    current = getattr(armature_obj, 'parent', None)
                    while current is not None:
                        if current.name in scene_names:
                            expanded.add(current)
                        current = getattr(current, 'parent', None)
    return expanded


def _capture_isolation_begin(context: bpy.types.Context, asset):
    scene = getattr(context, 'scene', None)
    view_layer = getattr(context, 'view_layer', None)
    if scene is None or view_layer is None:
        return None

    allowed = _capture_target_objects(context, asset)
    if not allowed:
        return None

    state = []
    keep_types = {'LIGHT', 'CAMERA'}
    for obj in scene.objects:
        try:
            hidden = obj.hide_get(view_layer=view_layer)
        except Exception:
            hidden = obj.hide_get()
        state.append((obj, hidden))
        should_show = obj in allowed or getattr(obj, 'type', '') in keep_types
        try:
            obj.hide_set(not should_show, view_layer=view_layer)
        except Exception:
            obj.hide_set(not should_show)
    return (view_layer, state)


def _capture_isolation_end(state) -> None:
    if not state:
        return
    view_layer, items = state
    for obj, hidden in items:
        try:
            obj.hide_set(hidden, view_layer=view_layer)
        except Exception:
            try:
                obj.hide_set(hidden)
            except Exception:
                pass


def _view3d_context_from_window(window: bpy.types.Window, mouse_x: int, mouse_y: int):
    screen = window.screen
    if screen is None:
        return None, None, None
    for area in screen.areas:
        if area.type != "VIEW_3D":
            continue
        if not (area.x <= mouse_x < area.x + area.width and area.y <= mouse_y < area.y + area.height):
            continue
        for region in area.regions:
            if region.type != "WINDOW":
                continue
            if region.x <= mouse_x < region.x + region.width and region.y <= mouse_y < region.y + region.height:
                return area, region, area.spaces.active.region_3d
    return None, None, None


def _placement_location(context: bpy.types.Context, mouse_x: int, mouse_y: int) -> Vector | None:
    area, region, region_3d = _view3d_context_from_window(context.window, mouse_x, mouse_y)
    if area is None or region is None or region_3d is None:
        return None
    coord = (mouse_x - region.x, mouse_y - region.y)
    depsgraph = context.evaluated_depsgraph_get()
    origin = view3d_utils.region_2d_to_origin_3d(region, region_3d, coord)
    direction = view3d_utils.region_2d_to_vector_3d(region, region_3d, coord)
    hit, location, _normal, _index, _obj, _matrix = context.scene.ray_cast(depsgraph, origin, direction)
    if hit:
        return location

    plane_origin = context.scene.cursor.location.copy()
    plane_normal = Vector((0.0, 0.0, 1.0))
    denominator = direction.dot(plane_normal)
    if abs(denominator) < 1e-6:
        return plane_origin
    distance = (plane_origin - origin).dot(plane_normal) / denominator
    if distance < 0.0:
        return plane_origin
    return origin + direction * distance


class BGAL_OT_ImportAsset(Operator):
    bl_idname = "bgal.import_asset"
    bl_label = "Import Asset"
    bl_description = "Append or link the selected asset package into the current scene"
    bl_options = {"REGISTER", "UNDO"}

    asset_id: StringProperty()
    mode_override: EnumProperty(
        name="Mode",
        items=(
            ("USE_BROWSER", "Use Browser Setting", ""),
            ("APPEND", "Append", ""),
            ("LINK", "Link", ""),
        ),
        default="USE_BROWSER",
    )

    def execute(self, context):
        asset_id = _resolve_asset_id(context, self.asset_id)
        asset = runtime.get_asset(asset_id)
        browser = context.window_manager.bgal_browser
        if asset is None:
            self.report({"WARNING"}, "Select an asset first.")
            return {"CANCELLED"}

        link_mode = browser.link_mode if self.mode_override == "USE_BROWSER" else self.mode_override
        namespace_prefix = ""
        if browser.use_namespace:
            namespace_prefix = browser.namespace_prefix.strip() or asset.display_name

        success, message, _selection = import_asset(
            context,
            asset_id,
            link_mode=link_mode,
            make_local_after_link=browser.make_local_after_link,
            namespace_prefix=namespace_prefix,
            place_mode=browser.placement_mode,
            place_as_collection_instance=browser.place_as_collection_instance,
        )
        refresh_visible_assets(context)
        browser.status_text = message or f"Imported {asset.display_name}"
        if not success:
            self.report({"ERROR"}, message)
            return {"CANCELLED"}
        if message:
            self.report({"INFO"}, message)
        return {"FINISHED"}


class BGAL_OT_SelectAsset(Operator):
    bl_idname = "bgal.select_asset"
    bl_label = "Select Asset"
    bl_description = "Select this asset in the package browser"
    bl_options = {"INTERNAL"}

    asset_id: StringProperty()
    tooltip_text: StringProperty()

    @classmethod
    def description(cls, context, properties):
        return getattr(properties, "tooltip_text", "") or cls.bl_description

    def execute(self, context):
        asset_id = _resolve_asset_id(context, self.asset_id)
        if not asset_id:
            return {"CANCELLED"}
        set_active_asset_id(context, asset_id)
        return {"FINISHED"}


class BGAL_OT_MetadataHint(Operator):
    bl_idname = "bgal.metadata_hint"
    bl_label = "Asset Metadata"
    bl_description = "Show the full metadata text for this asset"
    bl_options = {"INTERNAL"}

    tooltip_text: StringProperty()

    @classmethod
    def description(cls, context, properties):
        return getattr(properties, "tooltip_text", "") or cls.bl_description

    def execute(self, context):
        return {"FINISHED"}


class BGAL_OT_SaveAssetOverrides(Operator):
    bl_idname = "bgal.save_asset_overrides"
    bl_label = "Save Library Overrides"
    bl_description = "Rename this asset for your library and assign custom category values"
    bl_options = {"REGISTER", "UNDO"}

    asset_id: StringProperty()

    def execute(self, context):
        asset_id = _resolve_asset_id(context, self.asset_id)
        asset = runtime.get_asset(asset_id)
        browser = context.window_manager.bgal_browser
        if asset is None:
            return {"CANCELLED"}

        display_name = browser.editor_display_name.strip() or asset.base_display_name
        if browser.editor_category == constants.ENUM_ADD_NEW_CATEGORY_IDENTIFIER:
            category = browser.editor_new_category_name.strip()
            if not category:
                self.report({"ERROR"}, "Enter a new category name before saving.")
                return {"CANCELLED"}
        else:
            category = "" if browser.editor_category == constants.ENUM_NONE_IDENTIFIER else browser.editor_category

        if browser.editor_subcategory == constants.ENUM_ADD_NEW_SUBCATEGORY_IDENTIFIER or (
            browser.editor_category == constants.ENUM_ADD_NEW_CATEGORY_IDENTIFIER and browser.editor_new_subcategory_name.strip()
        ):
            subcategory = browser.editor_new_subcategory_name.strip()
            if browser.editor_subcategory == constants.ENUM_ADD_NEW_SUBCATEGORY_IDENTIFIER and not subcategory:
                self.report({"ERROR"}, "Enter a new subcategory name before saving.")
                return {"CANCELLED"}
        else:
            subcategory = "" if browser.editor_subcategory == constants.ENUM_NONE_IDENTIFIER else browser.editor_subcategory

        if category and (
            browser.editor_category == constants.ENUM_ADD_NEW_CATEGORY_IDENTIFIER
            or browser.editor_subcategory == constants.ENUM_ADD_NEW_SUBCATEGORY_IDENTIFIER
        ):
            save_category_registry_entry(Path(asset.root_path), category, subcategory)
            registry = runtime.category_registry()
            values = list(registry.get(category, []))
            if subcategory and subcategory not in values:
                values.append(subcategory)
            registry[category] = values
            runtime.set_category_registry(registry)

        tags = normalize_tags(browser.editor_tags)
        if tags:
            _ensure_tags_in_registry(Path(asset.root_path), tags)
            runtime.set_tag_registry(sorted(set(runtime.tags()) | set(tags), key=str.casefold))

        save_user_override_for_asset(Path(asset.file_path), asset.item_key, {
            "display_name": display_name,
            "category": category,
            "subcategory": subcategory,
            "tags": tags,
        },
            root_path=Path(asset.root_path),
        )
        asset.display_name = display_name
        asset.category = category
        asset.subcategory = subcategory
        asset.tags = tags
        browser.editor_new_category_name = ""
        browser.editor_new_subcategory_name = ""
        refresh_visible_assets(context)
        refresh_tag_manager_lists(context)
        set_active_asset_id(context, asset_id)
        sync_editor_fields(context)
        self.report({"INFO"}, "Saved library overrides for the selected asset.")
        return {"FINISHED"}


class BGAL_OT_ClearAssetOverrides(Operator):
    bl_idname = "bgal.clear_asset_overrides"
    bl_label = "Clear Library Overrides"
    bl_description = "Revert the selected asset back to its source metadata"
    bl_options = {"REGISTER", "UNDO"}

    asset_id: StringProperty()

    def execute(self, context):
        asset_id = _resolve_asset_id(context, self.asset_id)
        asset = runtime.get_asset(asset_id)
        if asset is None:
            return {"CANCELLED"}

        clear_user_override_for_asset(Path(asset.file_path), asset.item_key, root_path=Path(asset.root_path))
        asset.display_name = asset.base_display_name
        asset.category = asset.base_category
        asset.subcategory = asset.base_subcategory
        asset.tags = list(asset.base_tags)
        refresh_visible_assets(context)
        refresh_tag_manager_lists(context)
        set_active_asset_id(context, asset_id)
        sync_editor_fields(context)
        self.report({"INFO"}, "Cleared library overrides for the selected asset.")
        return {"FINISHED"}


def _field_definition_from_browser_row(row) -> dict:
    field_type = str(getattr(row, "field_type", "STRING") or "STRING").upper()
    if field_type == "INT":
        default_value = int(getattr(row, "default_int", 0) or 0)
    elif field_type == "BOOL":
        default_value = bool(getattr(row, "default_bool", False))
    else:
        default_value = str(getattr(row, "default_string", "") or "")
    return {
        "name": str(getattr(row, "name", "") or "").strip(),
        "type": field_type,
        "default": default_value,
    }


def _definition_from_browser(browser, existing_id: str = "") -> dict:
    fields = []
    for row in getattr(browser, "asset_create_fields", []) or []:
        field = _field_definition_from_browser_row(row)
        if field["name"]:
            fields.append(field)
    return {
        "id": existing_id,
        "name": str(getattr(browser, "asset_create_type_name", "") or "").strip(),
        "category": str(getattr(browser, "asset_create_category_value", "") or "").strip(),
        "subcategory_field": str(getattr(browser, "asset_create_subcategory_field", "") or "").strip(),
        "fields": fields,
    }


def _sync_asset_creation_override_to_asset(context, asset, metadata: dict) -> None:
    category = str(metadata.get("category", "") or "").strip()
    subcategory = str(metadata.get("subcategory", "") or "").strip()
    tags = normalize_tags(metadata.get("tags"))
    if category:
        save_category_registry_entry(Path(asset.root_path), category, subcategory)
        registry = runtime.category_registry()
        values = list(registry.get(category, []))
        if subcategory and subcategory not in values:
            values.append(subcategory)
        registry[category] = values
        runtime.set_category_registry(registry)
    if tags:
        _ensure_tags_in_registry(Path(asset.root_path), tags)
        runtime.set_tag_registry(sorted(set(runtime.tags()) | set(tags), key=str.casefold))
    save_user_override_for_asset(
        Path(asset.file_path),
        asset.item_key,
        {
            "display_name": asset.display_name or asset.base_display_name,
            "category": category,
            "subcategory": subcategory,
            "tags": tags,
        },
        root_path=Path(asset.root_path),
    )
    asset.category = category
    asset.subcategory = subcategory
    asset.tags = tags
    refresh_visible_assets(context)
    refresh_category_manager_lists(context)
    refresh_tag_manager_lists(context)
    set_active_asset_id(context, asset.asset_id)
    sync_editor_fields(context)


class BGAL_OT_ApplyAssetCreationDefaults(Operator):
    bl_idname = "bgal.apply_asset_creation_defaults"
    bl_label = "Set Asset Creation Properties"
    bl_description = "Add the selected asset creation custom properties to this source blend scene"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        browser = context.window_manager.bgal_browser
        definition = asset_creation.definition_by_id(browser.asset_creation_type)
        if definition is None:
            self.report({"ERROR"}, "Select a valid asset type first.")
            return {"CANCELLED"}
        changed = asset_creation.apply_definition_to_scene(context.scene, definition)
        browser.status_text = f"Applied {definition['name']} asset creation properties."
        self.report({"INFO"}, f"Applied {len(changed)} asset creation properties.")
        return {"FINISHED"}


class BGAL_OT_SaveAssetCreationTags(Operator):
    bl_idname = "bgal.save_asset_creation_tags"
    bl_label = "Save Asset Creation Tags"
    bl_description = "Save the current scene asset creation properties as library category, subcategory, and tags"
    bl_options = {"REGISTER", "UNDO"}

    asset_id: StringProperty()

    def execute(self, context):
        asset_id = _resolve_asset_id(context, self.asset_id)
        asset = runtime.get_asset(asset_id)
        if asset is None:
            self.report({"ERROR"}, "Select an asset before saving asset creation tags.")
            return {"CANCELLED"}
        metadata = asset_creation.metadata_from_scene(context.scene)
        if not metadata.get("category"):
            self.report({"ERROR"}, "Set Asset Creation properties before saving tags.")
            return {"CANCELLED"}
        _sync_asset_creation_override_to_asset(context, asset, metadata)
        self.report({"INFO"}, "Saved asset creation properties to the selected asset override.")
        return {"FINISHED"}


class BGAL_OT_NewAssetCreateType(Operator):
    bl_idname = "bgal.new_asset_create_type"
    bl_label = "New Asset Create Type"
    bl_description = "Clear the editor so you can define a new custom asset creation type"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        browser = context.window_manager.bgal_browser
        browser.asset_create_config_selection = asset_creation.default_definition_id()
        browser.asset_create_type_name = "Custom Asset"
        browser.asset_create_category_value = "Custom Asset"
        browser.asset_create_subcategory_field = "Manufacture"
        browser.asset_create_fields.clear()
        browser.asset_create_field_index = 0
        self.report({"INFO"}, "Started a new asset create properties setup.")
        return {"FINISHED"}


class BGAL_OT_AddAssetCreateField(Operator):
    bl_idname = "bgal.add_asset_create_field"
    bl_label = "Add Property"
    bl_description = "Add a custom property to the asset creation type editor"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        browser = context.window_manager.bgal_browser
        name = str(getattr(browser, "asset_create_field_name", "") or "").strip()
        if not name:
            self.report({"ERROR"}, "Enter a property name first.")
            return {"CANCELLED"}
        if name == "Category" or name in asset_creation.INTERNAL_KEYS:
            self.report({"ERROR"}, "That property name is reserved.")
            return {"CANCELLED"}
        existing = {row.name.casefold() for row in browser.asset_create_fields}
        if name.casefold() in existing:
            self.report({"ERROR"}, f"'{name}' is already in this setup.")
            return {"CANCELLED"}
        row = browser.asset_create_fields.add()
        row.name = name
        row.field_type = browser.asset_create_field_type
        browser.asset_create_field_index = len(browser.asset_create_fields) - 1
        browser.asset_create_field_name = ""
        self.report({"INFO"}, f"Added asset creation property '{name}'.")
        return {"FINISHED"}


class BGAL_OT_RemoveAssetCreateField(Operator):
    bl_idname = "bgal.remove_asset_create_field"
    bl_label = "Remove Property"
    bl_description = "Remove a property from the asset creation type editor"
    bl_options = {"REGISTER", "UNDO"}

    index: IntProperty(default=-1)

    def execute(self, context):
        browser = context.window_manager.bgal_browser
        index = self.index if self.index >= 0 else int(getattr(browser, "asset_create_field_index", 0) or 0)
        if not (0 <= index < len(browser.asset_create_fields)):
            self.report({"ERROR"}, "Select a property to remove.")
            return {"CANCELLED"}
        name = browser.asset_create_fields[index].name
        browser.asset_create_fields.remove(index)
        browser.asset_create_field_index = max(0, min(index, len(browser.asset_create_fields) - 1))
        self.report({"INFO"}, f"Removed asset creation property '{name}'.")
        return {"FINISHED"}


class BGAL_OT_SaveAssetCreateType(Operator):
    bl_idname = "bgal.save_asset_create_type"
    bl_label = "Save Asset Create Properties"
    bl_description = "Save the current asset create properties setup as a reusable custom asset type"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        browser = context.window_manager.bgal_browser
        selected_id = str(getattr(browser, "asset_create_config_selection", "") or "")
        selected_definition = asset_creation.definition_by_id(selected_id)
        existing_custom = asset_creation.load_custom_definitions()
        existing_id = selected_id if selected_definition and not selected_definition.get("builtin") else ""
        definition = _definition_from_browser(browser, existing_id=existing_id)
        if not definition["name"]:
            self.report({"ERROR"}, "Enter an asset type name before saving.")
            return {"CANCELLED"}
        if not definition["category"]:
            definition["category"] = definition["name"]
        normalized = asset_creation.normalize_definition(
            definition,
            {item["id"] for item in asset_creation.BUILTIN_DEFINITIONS + tuple(existing_custom) if item.get("id") != existing_id},
        )
        if normalized is None:
            self.report({"ERROR"}, "The asset create properties setup is invalid.")
            return {"CANCELLED"}
        normalized["builtin"] = False
        updated = []
        replaced = False
        for item in existing_custom:
            if item["id"] == normalized["id"]:
                updated.append(normalized)
                replaced = True
            else:
                updated.append(item)
        if not replaced:
            updated.append(normalized)
        asset_creation.save_custom_definitions(updated)
        browser.asset_create_config_selection = normalized["id"]
        browser.asset_creation_type = normalized["id"]
        changed = asset_creation.apply_definition_to_scene(
            context.scene,
            normalized,
            overwrite_category=True,
            overwrite_values=True,
        )
        load_asset_create_definition_editor(context, normalized["id"])
        self.report(
            {"INFO"},
            f"Saved asset create properties setup '{normalized['name']}' and updated {len(changed)} scene properties.",
        )
        return {"FINISHED"}


class BGAL_OT_DeleteAssetCreateType(Operator):
    bl_idname = "bgal.delete_asset_create_type"
    bl_label = "Delete Asset Create Properties"
    bl_description = "Delete the selected custom asset create properties setup"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        browser = context.window_manager.bgal_browser
        selected_id = str(getattr(browser, "asset_create_config_selection", "") or "")
        selected_definition = asset_creation.definition_by_id(selected_id)
        if selected_definition is None:
            self.report({"ERROR"}, "Select an asset create properties setup first.")
            return {"CANCELLED"}
        if selected_definition.get("builtin"):
            self.report({"ERROR"}, "Built-in asset create property setups cannot be deleted.")
            return {"CANCELLED"}
        remaining = [item for item in asset_creation.load_custom_definitions() if item["id"] != selected_id]
        asset_creation.save_custom_definitions(remaining)
        browser.asset_create_config_selection = asset_creation.default_definition_id()
        browser.asset_creation_type = asset_creation.default_definition_id()
        load_asset_create_definition_editor(context, asset_creation.default_definition_id())
        self.report({"INFO"}, f"Deleted asset create properties setup '{selected_definition['name']}'.")
        return {"FINISHED"}


class BGAL_OT_AddCategoryDefinition(Operator):
    bl_idname = "bgal.add_category_definition"
    bl_label = "Add Category"
    bl_description = "Add a reusable category and optional subcategory to this library root"
    bl_options = {"REGISTER", "UNDO"}

    asset_id: StringProperty()
    root_path: StringProperty()

    def execute(self, context):
        asset_id = _resolve_asset_id(context, self.asset_id)
        asset = runtime.get_asset(asset_id) if asset_id else None
        browser = context.window_manager.bgal_browser
        root_path = _resolve_category_root(context, self.root_path, asset)
        if root_path is None:
            self.report({"WARNING"}, "Select or configure a target library root first.")
            return {"CANCELLED"}

        category = browser.manager_category_input.strip() or browser.new_category_name.strip()
        subcategory = ""

        if not category:
            self.report({"ERROR"}, "Enter a category name before adding it to the library.")
            return {"CANCELLED"}

        try:
            save_category_registry_entry(root_path, category, subcategory)
        except Exception as exc:
            self.report({"ERROR"}, str(exc))
            return {"CANCELLED"}

        registry = runtime.category_registry()
        values = list(registry.get(category, []))
        if subcategory and subcategory not in values:
            values.append(subcategory)
        registry[category] = values
        runtime.set_category_registry(registry)
        browser.new_category_name = ""
        browser.new_subcategory_name = ""
        _refresh_after_category_change(context)
        _select_manager_category_by_name(browser, category)
        browser.editor_category = category
        browser.editor_subcategory = constants.ENUM_NONE_IDENTIFIER
        browser.manager_category_input = ""
        browser.manager_subcategory_input = ""
        self.report({"INFO"}, f"Added category '{category}' to {root_path.name}.")
        return {"FINISHED"}


class BGAL_OT_AddSubcategoryDefinition(Operator):
    bl_idname = "bgal.add_subcategory_definition"
    bl_label = "Add Subcategory"
    bl_description = "Add a reusable subcategory under the selected category"
    bl_options = {"REGISTER", "UNDO"}

    root_path: StringProperty()

    def execute(self, context):
        browser = context.window_manager.bgal_browser
        category_name = selected_manager_category(browser)
        subcategory = browser.manager_subcategory_input.strip()
        root_path = _resolve_category_root(context, self.root_path, get_active_asset(context))
        if root_path is None:
            self.report({"WARNING"}, "Select or configure a target library root first.")
            return {"CANCELLED"}
        if not category_name:
            self.report({"ERROR"}, "Choose a category first.")
            return {"CANCELLED"}
        if not subcategory:
            self.report({"ERROR"}, "Enter a subcategory name before adding it.")
            return {"CANCELLED"}
        try:
            save_category_registry_entry(root_path, category_name, subcategory)
        except Exception as exc:
            self.report({"ERROR"}, str(exc))
            return {"CANCELLED"}
        _refresh_after_category_change(context)
        _select_manager_category_by_name(browser, category_name)
        _select_manager_subcategory_by_name(browser, subcategory)
        browser.manager_subcategory_input = ""
        self.report({"INFO"}, f"Added subcategory '{subcategory}' to '{category_name}'.")
        return {"FINISHED"}


class BGAL_OT_RenameCategoryDefinition(Operator):
    bl_idname = "bgal.rename_category_definition"
    bl_label = "Rename Category"
    bl_description = "Rename the selected reusable category in the target library"
    bl_options = {"REGISTER", "UNDO"}

    root_path: StringProperty()

    def execute(self, context):
        browser = context.window_manager.bgal_browser
        old_name = selected_manager_category(browser)
        new_name = browser.manager_category_input.strip()
        root_path = _resolve_category_root(context, self.root_path, get_active_asset(context))
        if root_path is None:
            self.report({"WARNING"}, "Select or configure a target library root first.")
            return {"CANCELLED"}
        if not old_name or old_name == constants.ENUM_NONE_IDENTIFIER:
            self.report({"ERROR"}, "Choose a category to rename.")
            return {"CANCELLED"}
        if not new_name:
            self.report({"ERROR"}, "Enter the new category name first.")
            return {"CANCELLED"}
        try:
            rename_category_registry_entry(root_path, old_name, new_name)
        except Exception as exc:
            self.report({"ERROR"}, str(exc))
            return {"CANCELLED"}
        _refresh_after_category_change(context)
        _select_manager_category_by_name(browser, new_name)
        browser.manager_category_input = new_name
        browser.manager_subcategory_input = ""
        self.report({"INFO"}, f"Renamed category '{old_name}' to '{new_name}'.")
        return {"FINISHED"}


class BGAL_OT_RemoveCategoryDefinition(Operator):
    bl_idname = "bgal.remove_category_definition"
    bl_label = "Remove Category"
    bl_description = "Remove the selected reusable category from the target library"
    bl_options = {"REGISTER", "UNDO"}

    root_path: StringProperty()

    def execute(self, context):
        browser = context.window_manager.bgal_browser
        category_name = selected_manager_category(browser)
        root_path = _resolve_category_root(context, self.root_path, get_active_asset(context))
        if root_path is None:
            self.report({"WARNING"}, "Select or configure a target library root first.")
            return {"CANCELLED"}
        if not category_name or category_name == constants.ENUM_NONE_IDENTIFIER:
            self.report({"ERROR"}, "Choose a category to remove.")
            return {"CANCELLED"}
        try:
            remove_category_registry_entry(root_path, category_name)
        except Exception as exc:
            self.report({"ERROR"}, str(exc))
            return {"CANCELLED"}
        _refresh_after_category_change(context)
        browser.manager_category_input = ""
        browser.manager_subcategory_input = ""
        self.report({"INFO"}, f"Removed category '{category_name}'.")
        return {"FINISHED"}


class BGAL_OT_RenameSubcategoryDefinition(Operator):
    bl_idname = "bgal.rename_subcategory_definition"
    bl_label = "Rename Subcategory"
    bl_description = "Rename the selected reusable subcategory in the target library"
    bl_options = {"REGISTER", "UNDO"}

    root_path: StringProperty()

    def execute(self, context):
        browser = context.window_manager.bgal_browser
        category_name = selected_manager_category(browser)
        old_name = selected_manager_subcategory(browser)
        new_name = browser.manager_subcategory_input.strip()
        root_path = _resolve_category_root(context, self.root_path, get_active_asset(context))
        if root_path is None:
            self.report({"WARNING"}, "Select or configure a target library root first.")
            return {"CANCELLED"}
        if not category_name or category_name == constants.ENUM_NONE_IDENTIFIER:
            self.report({"ERROR"}, "Choose a category first.")
            return {"CANCELLED"}
        if not old_name or old_name == constants.ENUM_NONE_IDENTIFIER:
            self.report({"ERROR"}, "Choose a subcategory to rename.")
            return {"CANCELLED"}
        if not new_name:
            self.report({"ERROR"}, "Enter the new subcategory name first.")
            return {"CANCELLED"}
        try:
            rename_subcategory_registry_entry(root_path, category_name, old_name, new_name)
        except Exception as exc:
            self.report({"ERROR"}, str(exc))
            return {"CANCELLED"}
        _refresh_after_category_change(context)
        _select_manager_category_by_name(browser, category_name)
        _select_manager_subcategory_by_name(browser, new_name)
        browser.manager_subcategory_input = new_name
        self.report({"INFO"}, f"Renamed subcategory '{old_name}' to '{new_name}'.")
        return {"FINISHED"}


class BGAL_OT_RemoveSubcategoryDefinition(Operator):
    bl_idname = "bgal.remove_subcategory_definition"
    bl_label = "Remove Subcategory"
    bl_description = "Remove the selected reusable subcategory from the target library"
    bl_options = {"REGISTER", "UNDO"}

    root_path: StringProperty()

    def execute(self, context):
        browser = context.window_manager.bgal_browser
        category_name = selected_manager_category(browser)
        subcategory_name = selected_manager_subcategory(browser)
        root_path = _resolve_category_root(context, self.root_path, get_active_asset(context))
        if root_path is None:
            self.report({"WARNING"}, "Select or configure a target library root first.")
            return {"CANCELLED"}
        if not category_name or category_name == constants.ENUM_NONE_IDENTIFIER:
            self.report({"ERROR"}, "Choose a category first.")
            return {"CANCELLED"}
        if not subcategory_name or subcategory_name == constants.ENUM_NONE_IDENTIFIER:
            self.report({"ERROR"}, "Choose a subcategory to remove.")
            return {"CANCELLED"}
        try:
            remove_subcategory_registry_entry(root_path, category_name, subcategory_name)
        except Exception as exc:
            self.report({"ERROR"}, str(exc))
            return {"CANCELLED"}
        _refresh_after_category_change(context)
        browser.manager_subcategory_input = ""
        self.report({"INFO"}, f"Removed subcategory '{subcategory_name}'.")
        return {"FINISHED"}


class BGAL_OT_AddTagDefinition(Operator):
    bl_idname = "bgal.add_tag_definition"
    bl_label = "Add Tag"
    bl_description = "Add a reusable tag to the target library"
    bl_options = {"REGISTER", "UNDO"}

    root_path: StringProperty()

    def execute(self, context):
        browser = context.window_manager.bgal_browser
        tag_name = browser.manager_tag_input.strip()
        root_path = _resolve_category_root(context, self.root_path, get_active_asset(context))
        if root_path is None:
            self.report({"WARNING"}, "Select or configure a target library root first.")
            return {"CANCELLED"}
        if not tag_name:
            self.report({"ERROR"}, "Enter a tag name before adding it.")
            return {"CANCELLED"}
        try:
            save_tag_registry_entry(root_path, tag_name)
        except Exception as exc:
            self.report({"ERROR"}, str(exc))
            return {"CANCELLED"}
        _refresh_after_category_change(context)
        _select_manager_tag_by_name(browser, tag_name)
        browser.manager_tag_input = ""
        self.report({"INFO"}, f"Added tag '{tag_name}'.")
        return {"FINISHED"}


class BGAL_OT_RenameTagDefinition(Operator):
    bl_idname = "bgal.rename_tag_definition"
    bl_label = "Rename Tag"
    bl_description = "Rename the selected reusable tag in the target library"
    bl_options = {"REGISTER", "UNDO"}

    root_path: StringProperty()

    def execute(self, context):
        browser = context.window_manager.bgal_browser
        old_name = selected_manager_tag(browser)
        new_name = browser.manager_tag_input.strip()
        root_path = _resolve_category_root(context, self.root_path, get_active_asset(context))
        if root_path is None:
            self.report({"WARNING"}, "Select or configure a target library root first.")
            return {"CANCELLED"}
        if not old_name:
            self.report({"ERROR"}, "Choose a tag to rename.")
            return {"CANCELLED"}
        if not new_name:
            self.report({"ERROR"}, "Enter the new tag name first.")
            return {"CANCELLED"}
        try:
            rename_tag_registry_entry(root_path, old_name, new_name)
        except Exception as exc:
            self.report({"ERROR"}, str(exc))
            return {"CANCELLED"}
        _refresh_after_category_change(context)
        _select_manager_tag_by_name(browser, new_name)
        browser.manager_tag_input = new_name
        self.report({"INFO"}, f"Renamed tag '{old_name}' to '{new_name}'.")
        return {"FINISHED"}


class BGAL_OT_RemoveTagDefinition(Operator):
    bl_idname = "bgal.remove_tag_definition"
    bl_label = "Remove Tag"
    bl_description = "Remove the selected reusable tag from the target library"
    bl_options = {"REGISTER", "UNDO"}

    root_path: StringProperty()

    def execute(self, context):
        browser = context.window_manager.bgal_browser
        tag_name = selected_manager_tag(browser)
        root_path = _resolve_category_root(context, self.root_path, get_active_asset(context))
        if root_path is None:
            self.report({"WARNING"}, "Select or configure a target library root first.")
            return {"CANCELLED"}
        if not tag_name:
            self.report({"ERROR"}, "Choose a tag to remove.")
            return {"CANCELLED"}
        try:
            remove_tag_registry_entry(root_path, tag_name)
        except Exception as exc:
            self.report({"ERROR"}, str(exc))
            return {"CANCELLED"}
        _refresh_after_category_change(context)
        browser.manager_tag_input = ""
        self.report({"INFO"}, f"Removed tag '{tag_name}'.")
        return {"FINISHED"}


class BGAL_OT_PlaceAssetInteractive(Operator):
    bl_idname = "bgal.place_asset_interactive"
    bl_label = "Place Asset In View"
    bl_description = "Click in a 3D View to place the selected asset package"
    bl_options = {"REGISTER", "UNDO", "BLOCKING"}

    asset_id: StringProperty()

    def _finish(self, context):
        if context.workspace:
            context.workspace.status_text_set(None)

    def execute(self, context):
        asset_id = _resolve_asset_id(context, self.asset_id)
        asset = runtime.get_asset(asset_id)
        if asset is None:
            self.report({"WARNING"}, "Select an asset first.")
            return {"CANCELLED"}
        link_mode, make_local_after_link, namespace_prefix, place_as_collection_instance = _browser_import_settings(
            context, asset
        )
        success, message, _selection = import_asset(
            context,
            asset_id,
            link_mode=link_mode,
            make_local_after_link=make_local_after_link,
            namespace_prefix=namespace_prefix,
            place_mode="CURSOR",
            place_as_collection_instance=place_as_collection_instance,
        )
        context.window_manager.bgal_browser.status_text = message or f"Placed {asset.display_name} at the cursor"
        if not success:
            self.report({"ERROR"}, message)
            return {"CANCELLED"}
        if message:
            self.report({"INFO"}, message)
        refresh_visible_assets(context)
        sync_editor_fields(context)
        return {"FINISHED"}

    def invoke(self, context, event):
        asset_id = _resolve_asset_id(context, self.asset_id)
        asset = runtime.get_asset(asset_id)
        if asset is None:
            self.report({"WARNING"}, "Select an asset first.")
            return {"CANCELLED"}
        self.asset_id = asset_id
        if context.workspace:
            context.workspace.status_text_set("Click inside a 3D View to place the asset. Esc cancels.")
        context.window_manager.modal_handler_add(self)
        return {"RUNNING_MODAL"}

    def modal(self, context, event):
        if event.type in {"ESC", "RIGHTMOUSE"}:
            self._finish(context)
            return {"CANCELLED"}

        if event.type == "LEFTMOUSE" and event.value == "PRESS":
            asset = runtime.get_asset(self.asset_id)
            if asset is None:
                self._finish(context)
                return {"CANCELLED"}

            location = _placement_location(context, event.mouse_x, event.mouse_y)
            if location is None:
                self.report({"INFO"}, "Move the cursor over a 3D View and click to place the asset.")
                return {"RUNNING_MODAL"}

            browser = context.window_manager.bgal_browser
            link_mode, make_local_after_link, namespace_prefix, place_as_collection_instance = _browser_import_settings(
                context, asset
            )
            original_cursor = context.scene.cursor.location.copy()
            try:
                context.scene.cursor.location = location
                success, message, _selection = import_asset(
                    context,
                    self.asset_id,
                    link_mode=link_mode,
                    make_local_after_link=make_local_after_link,
                    namespace_prefix=namespace_prefix,
                    place_mode="CURSOR",
                    place_as_collection_instance=place_as_collection_instance,
                )
            finally:
                context.scene.cursor.location = original_cursor

            self._finish(context)
            refresh_visible_assets(context)
            sync_editor_fields(context)
            browser.status_text = message or f"Placed {asset.display_name}"
            if not success:
                self.report({"ERROR"}, message)
                return {"CANCELLED"}
            if message:
                self.report({"INFO"}, message)
            return {"FINISHED"}

        return {"RUNNING_MODAL"}


class BGAL_OT_AssetPageStep(Operator):
    bl_idname = "bgal.asset_page_step"
    bl_label = "Change Asset Page"
    bl_description = "Move to the previous or next page of asset previews"
    bl_options = {"INTERNAL"}

    direction: IntProperty(default=1)

    def execute(self, context):
        browser = context.window_manager.bgal_browser
        total_pages = asset_page_count(browser)
        if total_pages <= 1:
            browser.asset_page_index = 0
            return {"CANCELLED"}
        current = int(getattr(browser, "asset_page_index", 0) or 0)
        target = max(0, min(current + int(self.direction or 0), total_pages - 1))
        if target == current:
            return {"CANCELLED"}
        browser.asset_page_index = target
        screen = getattr(context, "screen", None)
        if screen is not None:
            for area in screen.areas:
                area.tag_redraw()
        return {"FINISHED"}


class BGAL_OT_ToggleFavorite(Operator):
    bl_idname = "bgal.toggle_favorite"
    bl_label = "Toggle Favorite"
    bl_description = "Mark the selected asset as a favorite"
    bl_options = {"REGISTER", "UNDO"}

    asset_id: StringProperty()

    def execute(self, context):
        asset_id = _resolve_asset_id(context, self.asset_id)
        asset = runtime.get_asset(asset_id)
        if asset is None:
            return {"CANCELLED"}
        asset.is_favorite = toggle_favorite(asset_id)
        refresh_visible_assets(context)
        return {"FINISHED"}


class BGAL_OT_RevealAsset(Operator):
    bl_idname = "bgal.reveal_asset"
    bl_label = "Reveal In Explorer"
    bl_description = "Reveal the source file or folder in the system file browser"

    asset_id: StringProperty()

    def execute(self, context):
        asset_id = _resolve_asset_id(context, self.asset_id)
        asset = runtime.get_asset(asset_id)
        if asset is None:
            return {"CANCELLED"}
        success, message = open_in_file_browser(asset.file_path)
        if not success:
            self.report({"ERROR"}, message)
            return {"CANCELLED"}
        return {"FINISHED"}


class BGAL_OT_OpenSourceBlend(Operator):
    bl_idname = "bgal.open_source_blend"
    bl_label = "Open Source Blend"
    bl_description = "Open the source .blend file in a new Blender instance"

    asset_id: StringProperty()

    def execute(self, context):
        asset_id = _resolve_asset_id(context, self.asset_id)
        asset = runtime.get_asset(asset_id)
        if asset is None:
            return {"CANCELLED"}
        success, message = open_blend_in_new_instance(asset.file_path)
        if not success:
            self.report({"ERROR"}, message)
            return {"CANCELLED"}
        return {"FINISHED"}


def _resolve_capture_target_asset(context: bpy.types.Context, explicit_asset_id: str = "", selected_asset_id: str = ""):
    for candidate_id in (selected_asset_id, explicit_asset_id):
        if not candidate_id:
            continue
        asset = runtime.get_asset(candidate_id)
        if asset is not None:
            return asset
    candidates = _current_file_asset_candidates(context)
    return candidates[0] if candidates else None


def _refresh_asset_entry(context: bpy.types.Context, asset_id: str, *, rescan: bool = False) -> None:
    if rescan:
        scan_libraries(context, force=True)
    preview_manager.invalidate(asset_id)
    refresh_visible_assets(context)
    if runtime.get_asset(asset_id) is not None:
        set_active_asset_id(context, asset_id)
        sync_editor_fields(context)


class BGAL_OT_CaptureManualPreview(Operator):
    bl_idname = "bgal.capture_manual_preview"
    bl_label = "Capture Preview From Viewport"
    bl_description = "Save the current 3D viewport as a manual preview image for the selected asset"

    asset_id: StringProperty()
    selected_asset_id: EnumProperty(name="Asset", items=_current_file_asset_items)
    show_dialog: BoolProperty(default=False, options={"SKIP_SAVE"})
    show_capture_frame: BoolProperty(
        name="Show Capture Frame",
        description="Temporarily switch the active 3D View into a square camera frame during capture",
        default=True,
    )

    def invoke(self, context, event):
        del event
        candidates = _current_file_asset_candidates(context)
        if not candidates and bpy.data.filepath:
            try:
                scan_libraries(context, force=False)
                refresh_visible_assets(context)
            except Exception:
                pass
            candidates = _current_file_asset_candidates(context)
        if self.asset_id and not self.selected_asset_id:
            self.selected_asset_id = self.asset_id
        if not self.selected_asset_id and candidates:
            self.selected_asset_id = candidates[0].asset_id
        should_prompt = self.show_dialog or (not self.asset_id and len(candidates) > 1)
        if should_prompt:
            return context.window_manager.invoke_props_dialog(self, width=360)
        return self.execute(context)

    def draw(self, context):
        layout = self.layout
        candidates = _current_file_asset_candidates(context)
        if len(candidates) > 1 or not self.asset_id:
            layout.prop(self, "selected_asset_id", text="Asset")
        layout.prop(self, "show_capture_frame")
        layout.label(text="Uses the current 3D View and saves into the library thumbnails folder.", icon="INFO")

    def execute(self, context):
        asset = _resolve_capture_target_asset(context, self.asset_id, self.selected_asset_id)
        if asset is None and bpy.data.filepath:
            try:
                scan_libraries(context, force=False)
                refresh_visible_assets(context)
            except Exception:
                pass
            asset = _resolve_capture_target_asset(context, self.asset_id, self.selected_asset_id)
        if asset is None:
            self.report({"ERROR"}, "No library asset from the current .blend file could be resolved for preview capture.")
            return {"CANCELLED"}
        if not _current_file_matches_asset(asset):
            self.report({"ERROR"}, "Open the selected asset source blend first, frame it in a 3D View, then capture the preview.")
            return {"CANCELLED"}
        override = _find_view3d_override(context)
        if override is None:
            self.report({"ERROR"}, "Open a 3D View to capture a manual preview.")
            return {"CANCELLED"}

        output_path = _manual_preview_output_path(asset)
        output_path.parent.mkdir(parents=True, exist_ok=True)
        scene = context.scene
        original_filepath = scene.render.filepath
        original_format = scene.render.image_settings.file_format
        original_x = int(scene.render.resolution_x)
        original_y = int(scene.render.resolution_y)
        original_percentage = int(scene.render.resolution_percentage)
        capture_size = _capture_preview_size(context)
        capture_isolation_state = _capture_isolation_begin(context, asset)
        capture_frame_state = _capture_frame_begin(context, override) if self.show_capture_frame else None
        try:
            scene.render.filepath = str(output_path)
            scene.render.image_settings.file_format = "PNG"
            scene.render.resolution_x = capture_size
            scene.render.resolution_y = capture_size
            scene.render.resolution_percentage = 100
            with context.temp_override(**override):
                bpy.ops.render.opengl(write_still=True, view_context=True)
        except Exception as exc:
            self.report({"ERROR"}, str(exc))
            return {"CANCELLED"}
        finally:
            scene.render.filepath = original_filepath
            scene.render.image_settings.file_format = original_format
            scene.render.resolution_x = original_x
            scene.render.resolution_y = original_y
            scene.render.resolution_percentage = original_percentage
            _capture_frame_end(capture_frame_state)
            _capture_isolation_end(capture_isolation_state)

        try:
            _refresh_asset_entry(context, asset.asset_id, rescan=True)
        except Exception:
            pass
        self.report({"INFO"}, f"Saved manual preview to {output_path.name}.")
        return {"FINISHED"}


class BGAL_OT_ValidateAsset(Operator):
    bl_idname = "bgal.validate_asset"
    bl_label = "Validate Asset Package"
    bl_description = "Check the asset package for missing targets, previews, and external textures"

    asset_id: StringProperty()

    def execute(self, context):
        asset_id = _resolve_asset_id(context, self.asset_id)
        asset = runtime.get_asset(asset_id)
        if asset is None:
            return {"CANCELLED"}
        report = validate_asset(asset_id)
        refresh_visible_assets(context)
        if report.warnings:
            self.report({"WARNING"}, "; ".join(report.warnings[:4]))
        else:
            self.report({"INFO"}, f"{asset.display_name} validated successfully.")
        return {"FINISHED"}




class BGAL_OT_LibraryHealthCheck(Operator):
    bl_idname = "bgal.library_health_check"
    bl_label = "Library Health Check"
    bl_description = "Check enabled asset libraries for missing textures, missing thumbnails, stale legacy files, and zero-byte blend files"

    def execute(self, context):
        roots = scanner.enabled_root_definitions(context)
        if not roots:
            self.report({"ERROR"}, "Add and enable at least one library root first.")
            return {"CANCELLED"}

        scan_libraries(context, force=False)
        browser = getattr(context.window_manager, "bgal_browser", None)
        root_lookup = {str(Path(root["path"]).resolve()): root for root in roots}
        assets = []
        for asset in runtime.all_assets():
            root_path = _asset_root_path(asset)
            if root_path is None:
                continue
            if str(root_path.resolve()) in root_lookup:
                assets.append(asset)

        assets.sort(key=lambda item: (item.display_name.casefold(), item.relative_path.casefold(), item.asset_id))
        library_word = "library" if len(roots) == 1 else "libraries"

        assets_by_file = {}
        for asset in assets:
            assets_by_file.setdefault(str(Path(asset.file_path)), []).append(asset)

        missing_texture_entries: list[str] = []
        texture_failure_entries: list[str] = []
        for file_path, file_assets in sorted(assets_by_file.items(), key=lambda item: item[0].casefold()):
            names, error = _missing_textures_for_blend(Path(file_path))
            sample_asset = file_assets[0] if file_assets else None
            label = sample_asset.relative_path if sample_asset is not None and sample_asset.relative_path else Path(file_path).name
            if error:
                texture_failure_entries.append(f"{label}: {error}")
                continue
            if names:
                preview = ", ".join(names[:4])
                if len(names) > 4:
                    preview += " ..."
                missing_texture_entries.append(f"{label}: {preview}")

        missing_thumbnail_entries = [
            f"{asset.display_name} ({Path(asset.file_path).name})"
            for asset in assets
            if _asset_missing_thumbnail(asset, context)
        ]

        stale_legacy_entries: list[str] = []
        zero_byte_entries: list[str] = []
        for root in roots:
            root_path = Path(root["path"])
            label = root.get("label") or root_path.name
            issues = inspect_library_layout(root_path)
            stale_entries = issues["legacy_configs"] + issues["legacy_previews"] + issues["legacy_blends"]
            stale_legacy_entries.extend(
                f"{label}: {_relative_issue_path(root_path, path)}"
                for path in stale_entries
            )
            zero_byte_entries.extend(
                f"{label}: {_relative_issue_path(root_path, path)}"
                for path in issues["zero_byte_blends"]
            )

        issue_count = (
            len(missing_texture_entries)
            + len(missing_thumbnail_entries)
            + len(stale_legacy_entries)
            + len(zero_byte_entries)
            + len(texture_failure_entries)
        )
        if issue_count:
            summary = (
                f"Health check found issues across {len(roots)} {library_word} and {len(assets)} assets. "
                f"Missing textures: {len(missing_texture_entries)}. "
                f"Missing thumbnails: {len(missing_thumbnail_entries)}. "
                f"Stale legacy files: {len(stale_legacy_entries)}. "
                f"Zero-byte blends: {len(zero_byte_entries)}."
            )
        else:
            summary = f"Health check passed for {len(roots)} {library_word} and {len(assets)} assets."

        detail_lines = [
            f"Libraries checked: {len(roots)}",
            f"Assets checked: {len(assets)}",
        ]
        _append_limited(detail_lines, missing_texture_entries, "Missing textures")
        _append_limited(detail_lines, missing_thumbnail_entries, "Missing thumbnails")
        _append_limited(detail_lines, stale_legacy_entries, "Stale legacy files")
        _append_limited(detail_lines, zero_byte_entries, "Zero-byte blend files")
        _append_limited(detail_lines, texture_failure_entries, "Texture checks failed")
        if not issue_count:
            detail_lines.append("No issues found.")

        if browser is not None:
            browser.status_text = summary
            browser.health_report_summary = summary
            browser.health_report_details = "\n".join(detail_lines)
            browser.health_report_has_issues = bool(issue_count)

        popup_lines = list(detail_lines)
        popup_icon = "CHECKMARK" if not issue_count else "ERROR"

        def _draw_popup(menu, _context):
            col = menu.layout.column(align=True)
            col.label(text=summary, icon=popup_icon)
            for line in popup_lines[:14]:
                col.label(text=line)
            if len(popup_lines) > 14:
                col.label(text=f"... and {len(popup_lines) - 14} more")

        context.window_manager.popup_menu(_draw_popup, title="Library Health Check", icon=popup_icon)
        self.report({"INFO" if not issue_count else "WARNING"}, summary)
        return {"FINISHED"}

class BGAL_OT_AutoLocateAssetTextures(Operator):
    bl_idname = "bgal.auto_locate_asset_textures"
    bl_label = "Auto Locate Textures"
    bl_description = "Search the library textures folder for missing images used by the selected asset and remap them"

    asset_id: StringProperty()

    def execute(self, context):
        asset_id = _resolve_asset_id(context, self.asset_id)
        asset = runtime.get_asset(asset_id)
        if asset is None:
            return {"CANCELLED"}

        blend_path = Path(asset.file_path)
        root_path = _asset_root_path(asset)
        if not blend_path.exists() or root_path is None:
            self.report({"ERROR"}, "Asset source file or library root was not found.")
            return {"CANCELLED"}

        texture_dir = library_textures_directory(root_path, create=False)
        if not texture_dir.exists():
            self.report({"ERROR"}, "The library textures folder does not exist for this asset root.")
            return {"CANCELLED"}

        script_text = f"""
from pathlib import Path
import bpy

TEXTURE_ROOT = Path(r"{str(texture_dir)}")

candidates = {{}}
for path in TEXTURE_ROOT.rglob('*'):
    if not path.is_file():
        continue
    candidates.setdefault(path.name.casefold(), str(path))

found = 0
remapped = 0
missing = 0

for image in bpy.data.images:
    if image is None or getattr(image, 'source', 'FILE') != 'FILE':
        continue
    if getattr(image, 'packed_file', None) is not None:
        continue
    filepath = getattr(image, 'filepath', '') or ''
    if not filepath:
        continue
    try:
        source = Path(bpy.path.abspath(filepath, library=image.library)).resolve()
    except Exception:
        source = Path(filepath)
    if source.exists():
        continue
    match = candidates.get(source.name.casefold())
    if not match:
        missing += 1
        continue
    found += 1
    new_path = bpy.path.relpath(match)
    if image.filepath != new_path:
        image.filepath = new_path
        try:
            image.reload()
        except Exception:
            pass
        remapped += 1

if remapped:
    bpy.ops.wm.save_mainfile()
print(f"BGAL_AUTOLOCATE_RESULT found={{found}} remapped={{remapped}} missing={{missing}}")
""".strip()

        working_dir = Path(__file__).resolve().parents[2] / "Working Files"
        working_dir.mkdir(parents=True, exist_ok=True)
        handle, script_name = tempfile.mkstemp(prefix=f"_autolocate_{asset.asset_id}_", suffix=".py", dir=str(working_dir))
        try:
            script_path = Path(script_name)
            try:
                Path(script_name).unlink(missing_ok=True)
            except Exception:
                pass
            script_path.write_text(script_text, encoding="utf-8")
            result = subprocess.run(
                [bpy.app.binary_path, "-b", str(blend_path), "-P", str(script_path)],
                capture_output=True,
                text=True,
                check=False,
            )
        except Exception as exc:
            self.report({"ERROR"}, str(exc))
            return {"CANCELLED"}
        finally:
            try:
                Path(script_name).unlink(missing_ok=True)
            except Exception:
                pass

        output = "\n".join(part for part in [result.stdout, result.stderr] if part)
        if result.returncode != 0:
            message = output.strip().splitlines()[-1] if output.strip() else "Failed to auto locate textures."
            self.report({"ERROR"}, message)
            return {"CANCELLED"}

        found = remapped = missing = 0
        for line in output.splitlines():
            if not line.startswith("BGAL_AUTOLOCATE_RESULT"):
                continue
            parts = dict(chunk.split("=", 1) for chunk in line.split()[1:] if "=" in chunk)
            found = int(parts.get("found", 0) or 0)
            remapped = int(parts.get("remapped", 0) or 0)
            missing = int(parts.get("missing", 0) or 0)
            break

        try:
            _refresh_asset_entry(context, asset.asset_id, rescan=True)
            for cache_path in _all_thumbnail_cache_paths(asset):
                if cache_path.exists():
                    cache_path.unlink(missing_ok=True)
            render_thumbnail_for_asset(context, asset.asset_id)
            refresh_visible_assets(context)
        except Exception:
            pass

        self.report({"INFO"}, f"Auto located textures for {asset.display_name}. Found: {found}, remapped: {remapped}, still missing: {missing}.")
        return {"FINISHED"}


class BGAL_OT_ImportAssetTexturesFromYTD(Operator):
    bl_idname = "bgal.import_asset_textures_from_ytd"
    bl_label = "Import Textures From YTD"
    bl_description = "Copy matching DDS files from a selected GTA V texture dictionary into the library textures folder and remap missing images"

    asset_id: StringProperty()
    filepath: StringProperty(subtype="FILE_PATH")
    filter_glob: StringProperty(
        default="*.ytd;*.ytd.xml;*.dds",
        options={"HIDDEN"},
    )

    def invoke(self, context, event):
        del event
        if not self.filepath:
            context.window_manager.fileselect_add(self)
            return {"RUNNING_MODAL"}
        return self.execute(context)

    def execute(self, context):
        asset_id = _resolve_asset_id(context, self.asset_id)
        asset = runtime.get_asset(asset_id)
        if asset is None:
            return {"CANCELLED"}

        if not self.filepath:
            self.report({"ERROR"}, "Select a GTA V texture dictionary first.")
            return {"CANCELLED"}

        blend_path = Path(asset.file_path)
        root_path = _asset_root_path(asset)
        if not blend_path.exists() or root_path is None:
            self.report({"ERROR"}, "Asset source file or library root was not found.")
            return {"CANCELLED"}

        try:
            source_path = Path(bpy.path.abspath(self.filepath)).resolve()
        except Exception:
            source_path = Path(self.filepath)
        if not source_path.exists():
            self.report({"ERROR"}, "The selected texture dictionary path does not exist.")
            return {"CANCELLED"}

        missing_names, error = _missing_textures_for_blend(blend_path)
        if error:
            self.report({"ERROR"}, f"Could not inspect missing textures: {error}")
            return {"CANCELLED"}
        if not missing_names:
            self.report({"INFO"}, f"No missing textures were found for {asset.display_name}.")
            return {"FINISHED"}

        candidate_dirs = _texture_dictionary_candidate_dirs(source_path)
        if not candidate_dirs:
            self.report({"ERROR"}, "No accessible texture dictionary folders were found near the selected path.")
            return {"CANCELLED"}

        texture_dir = library_textures_directory(root_path, create=True)
        candidate_dirs_literal = repr([str(path) for path in candidate_dirs])
        script_text = f"""
from pathlib import Path
import hashlib
import shutil
import bpy


TEXTURE_ROOTS = [Path(path) for path in {candidate_dirs_literal}]
TEXTURE_DEST = Path(r"{_path_literal(texture_dir)}")


def file_digest(path: Path) -> str:
    digest = hashlib.sha1(usedforsecurity=False)
    with path.open('rb') as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b''):
            if not chunk:
                break
            digest.update(chunk)
    return digest.hexdigest()


def files_identical(first: Path, second: Path) -> bool:
    try:
        if first.stat().st_size != second.stat().st_size:
            return False
    except Exception:
        return False
    try:
        return file_digest(first) == file_digest(second)
    except Exception:
        return False


_destinations_by_source = {{}}


def unique_destination(initial: Path, source: Path) -> Path:
    try:
        key = str(source.resolve()).casefold()
    except Exception:
        key = str(source).casefold()
    existing = _destinations_by_source.get(key)
    if existing is not None:
        return existing

    candidate = initial
    stem = initial.stem
    suffix = initial.suffix
    index = 1
    while candidate.exists():
        if files_identical(candidate, source):
            _destinations_by_source[key] = candidate
            return candidate
        candidate = initial.with_name(f"{{stem}}_{{index:03d}}{{suffix}}")
        index += 1

    _destinations_by_source[key] = candidate
    return candidate


def candidate_labels(image, source: Path, filepath: str) -> list[str]:
    values = []
    for raw in (
        source.name,
        Path(filepath).name if filepath else "",
        getattr(image, "name", "") or "",
    ):
        raw = str(raw or "").strip()
        if not raw:
            continue
        if raw not in values:
            values.append(raw)
        raw_path = Path(raw)
        if raw_path.suffix.lower() != ".dds":
            dds_name = raw_path.with_suffix(".dds").name
            if dds_name not in values:
                values.append(dds_name)
    return values


candidates = {{}}
for root in TEXTURE_ROOTS:
    if not root.exists() or not root.is_dir():
        continue
    for path in root.rglob("*.dds"):
        if not path.is_file():
            continue
        candidates.setdefault(path.name.casefold(), str(path))

TEXTURE_DEST.mkdir(parents=True, exist_ok=True)

found = 0
copied = 0
remapped = 0
missing = 0

for image in bpy.data.images:
    if image is None or getattr(image, 'source', 'FILE') != 'FILE':
        continue
    if getattr(image, 'packed_file', None) is not None:
        continue
    filepath = getattr(image, 'filepath', '') or ''
    if not filepath:
        continue
    try:
        source = Path(bpy.path.abspath(filepath, library=image.library)).resolve()
    except Exception:
        source = Path(filepath)
    if source.exists():
        continue

    match_path = None
    for label in candidate_labels(image, source, filepath):
        match = candidates.get(label.casefold())
        if match:
            match_path = Path(match)
            break

    if match_path is None:
        missing += 1
        continue

    found += 1
    dest = unique_destination(TEXTURE_DEST / match_path.name, match_path)
    if not dest.exists():
        shutil.copy2(str(match_path), str(dest))
        copied += 1

    new_path = bpy.path.relpath(str(dest))
    if image.filepath != new_path:
        image.filepath = new_path
        try:
            image.reload()
        except Exception:
            pass
        remapped += 1

if copied or remapped:
    bpy.ops.wm.save_mainfile()

print(f"BGAL_IMPORT_YTD_RESULT found={{found}} copied={{copied}} remapped={{remapped}} missing={{missing}}")
""".strip()

        working_dir = Path(__file__).resolve().parents[2] / "Working Files"
        working_dir.mkdir(parents=True, exist_ok=True)
        _handle, script_name = tempfile.mkstemp(prefix=f"_import_ytd_{asset.asset_id}_", suffix=".py", dir=str(working_dir))
        try:
            script_path = Path(script_name)
            try:
                script_path.unlink(missing_ok=True)
            except Exception:
                pass
            script_path.write_text(script_text, encoding="utf-8")
            result = subprocess.run(
                [bpy.app.binary_path, "-b", str(blend_path), "-P", str(script_path)],
                capture_output=True,
                text=True,
                check=False,
            )
        except Exception as exc:
            self.report({"ERROR"}, str(exc))
            return {"CANCELLED"}
        finally:
            try:
                Path(script_name).unlink(missing_ok=True)
            except Exception:
                pass

        output = "\n".join(part for part in [result.stdout, result.stderr] if part)
        if result.returncode != 0:
            message = output.strip().splitlines()[-1] if output.strip() else "Failed to import textures from the selected texture dictionary."
            self.report({"ERROR"}, message)
            return {"CANCELLED"}

        found = copied = remapped = missing = 0
        for line in output.splitlines():
            if not line.startswith("BGAL_IMPORT_YTD_RESULT"):
                continue
            parts = dict(chunk.split("=", 1) for chunk in line.split()[1:] if "=" in chunk)
            found = int(parts.get("found", 0) or 0)
            copied = int(parts.get("copied", 0) or 0)
            remapped = int(parts.get("remapped", 0) or 0)
            missing = int(parts.get("missing", 0) or 0)
            break

        try:
            _refresh_asset_entry(context, asset.asset_id, rescan=True)
        except Exception:
            pass

        for cache_path in _all_thumbnail_cache_paths(asset):
            if not cache_path.exists():
                continue
            try:
                cache_path.unlink()
            except Exception:
                pass
        try:
            render_thumbnail_for_asset(context, asset_id)
            refresh_visible_assets(context)
        except Exception:
            pass

        source_label = source_path.name
        if found == 0 and missing > 0:
            self.report(
                {"WARNING"},
                f"No matching DDS files were found near {source_label}. Select a CodeWalker-exported dictionary or an extracted DDS folder if you are starting from a raw .ytd.",
            )
            return {"CANCELLED"}

        self.report(
            {"INFO"},
            f"Imported textures from {source_label} for {asset.display_name}. Found: {found}, copied: {copied}, remapped: {remapped}, still missing: {missing}.",
        )
        return {"FINISHED"}


class BGAL_OT_CollectAssetTextures(Operator):
    bl_idname = "bgal.collect_asset_textures"
    bl_label = "Collect External Textures"
    bl_description = "Copy external image files into the library textures folder and remap the blend to use relative paths"

    asset_id: StringProperty()

    def execute(self, context):
        asset_id = _resolve_asset_id(context, self.asset_id)
        asset = runtime.get_asset(asset_id)
        if asset is None:
            return {"CANCELLED"}

        blend_path = Path(asset.file_path)
        root_path = _asset_root_path(asset)
        if not blend_path.exists() or root_path is None:
            self.report({"ERROR"}, "Asset source file or library root was not found.")
            return {"CANCELLED"}

        texture_dir = library_textures_directory(root_path, create=True)
        script_text = f"""
from pathlib import Path
import shutil
import bpy


def unique_destination(initial: Path, source: Path) -> Path:
    candidate = initial
    stem = initial.stem
    suffix = initial.suffix
    index = 1
    while candidate.exists():
        try:
            if candidate.resolve() == source.resolve():
                return candidate
        except Exception:
            pass
        candidate = initial.with_name(f"{{stem}}_{{index:03d}}{{suffix}}")
        index += 1
    return candidate


texture_dir = Path(r"{str(texture_dir)}")
texture_dir.mkdir(parents=True, exist_ok=True)

copied = []
remapped = []
missing = []

for image in bpy.data.images:
    if image is None or getattr(image, 'source', 'FILE') != 'FILE':
        continue
    if getattr(image, 'packed_file', None) is not None:
        continue
    filepath = getattr(image, 'filepath', '') or ''
    if not filepath:
        continue
    try:
        source = Path(bpy.path.abspath(filepath, library=image.library)).resolve()
    except Exception:
        source = Path(filepath)
    if not source.exists():
        missing.append(image.name)
        continue
    dest = unique_destination(texture_dir / source.name, source)
    if dest.resolve() != source.resolve() and not dest.exists():
        shutil.copy2(str(source), str(dest))
        copied.append(dest.name)
    new_path = bpy.path.relpath(str(dest))
    if image.filepath != new_path:
        image.filepath = new_path
        try:
            image.reload()
        except Exception:
            pass
        remapped.append(image.name)

bpy.ops.wm.save_mainfile()
print(f"BGAL_COLLECT_RESULT copied={{len(copied)}} remapped={{len(remapped)}} missing={{len(missing)}}")
if missing:
    print("BGAL_COLLECT_MISSING " + "; ".join(missing[:20]))
""".strip()

        working_dir = Path(__file__).resolve().parents[2] / "Working Files"
        working_dir.mkdir(parents=True, exist_ok=True)
        handle, script_name = tempfile.mkstemp(prefix=f"_collect_{asset.asset_id}_", suffix=".py", dir=str(working_dir))
        try:
            script_path = Path(script_name)
            try:
                Path(script_name).unlink(missing_ok=True)
            except Exception:
                pass
            script_path.write_text(script_text, encoding="utf-8")
            result = subprocess.run(
                [bpy.app.binary_path, "-b", str(blend_path), "-P", str(script_path)],
                capture_output=True,
                text=True,
                check=False,
            )
        except Exception as exc:
            self.report({"ERROR"}, str(exc))
            return {"CANCELLED"}
        finally:
            try:
                Path(script_name).unlink(missing_ok=True)
            except Exception:
                pass

        output = "\n".join(part for part in [result.stdout, result.stderr] if part)
        if result.returncode != 0:
            message = output.strip().splitlines()[-1] if output.strip() else "Failed to collect external textures."
            self.report({"ERROR"}, message)
            return {"CANCELLED"}

        copied = remapped = missing = 0
        for line in output.splitlines():
            if line.startswith("BGAL_COLLECT_RESULT"):
                parts = dict(
                    chunk.split("=", 1)
                    for chunk in line.split()[1:]
                    if "=" in chunk
                )
                copied = int(parts.get("copied", 0) or 0)
                remapped = int(parts.get("remapped", 0) or 0)
                missing = int(parts.get("missing", 0) or 0)
                break

        try:
            _refresh_asset_entry(context, asset.asset_id, rescan=True)
        except Exception:
            pass

        for cache_path in _all_thumbnail_cache_paths(asset):
            if not cache_path.exists():
                continue
            try:
                cache_path.unlink()
            except Exception:
                pass
        try:
            render_thumbnail_for_asset(context, asset_id)
            refresh_visible_assets(context)
        except Exception:
            pass

        self.report(
            {"INFO"},
            f"Collected textures for {asset.display_name}. Copied: {copied}, remapped: {remapped}, missing: {missing}.",
        )
        return {"FINISHED"}


class BGAL_OT_RefreshPreview(Operator):
    bl_idname = "bgal.refresh_preview"
    bl_label = "Refresh Preview"
    bl_description = "Refresh the selected asset preview from the current thumbnail or cached render"

    asset_id: StringProperty()

    def execute(self, context):
        asset_id = _resolve_asset_id(context, self.asset_id)
        asset = runtime.get_asset(asset_id)
        if asset is None:
            asset = _resolve_capture_target_asset(context)
            if asset is None:
                return {"CANCELLED"}
            asset_id = asset.asset_id
        try:
            _refresh_asset_entry(context, asset_id, rescan=True)
        except Exception as exc:
            self.report({"ERROR"}, str(exc))
            return {"CANCELLED"}
        self.report({"INFO"}, f"Refreshed preview for {runtime.get_asset(asset_id).display_name if runtime.get_asset(asset_id) else asset_id}.")
        return {"FINISHED"}


class BGAL_OT_RegenerateThumbnail(Operator):
    bl_idname = "bgal.regenerate_thumbnail"
    bl_label = "Regenerate Thumbnail"
    bl_description = "Render and cache a fresh preview thumbnail for the selected asset"

    asset_id: StringProperty()

    def execute(self, context):
        asset_id = _resolve_asset_id(context, self.asset_id)
        asset = runtime.get_asset(asset_id)
        if asset is None:
            return {"CANCELLED"}
        cache_path = _thumbnail_cache_path(asset, context)
        if cache_path is not None and cache_path.exists():
            try:
                cache_path.unlink()
            except Exception:
                pass
        preview_manager.invalidate(asset_id)
        success, message = render_thumbnail_for_asset(context, asset_id)
        refresh_visible_assets(context)
        if not success:
            self.report({"ERROR"}, message)
            return {"CANCELLED"}
        self.report({"INFO"}, f"Thumbnail regenerated for {asset.display_name}.")
        return {"FINISHED"}


CLASSES = (
    BGAL_OT_ImportAsset,
    BGAL_OT_SelectAsset,
    BGAL_OT_MetadataHint,
    BGAL_OT_SaveAssetOverrides,
    BGAL_OT_ClearAssetOverrides,
    BGAL_OT_ApplyAssetCreationDefaults,
    BGAL_OT_SaveAssetCreationTags,
    BGAL_OT_NewAssetCreateType,
    BGAL_OT_AddAssetCreateField,
    BGAL_OT_RemoveAssetCreateField,
    BGAL_OT_SaveAssetCreateType,
    BGAL_OT_DeleteAssetCreateType,
    BGAL_OT_AddCategoryDefinition,
    BGAL_OT_AddSubcategoryDefinition,
    BGAL_OT_RenameCategoryDefinition,
    BGAL_OT_RemoveCategoryDefinition,
    BGAL_OT_RenameSubcategoryDefinition,
    BGAL_OT_RemoveSubcategoryDefinition,
    BGAL_OT_AddTagDefinition,
    BGAL_OT_RenameTagDefinition,
    BGAL_OT_RemoveTagDefinition,
    BGAL_OT_AssetPageStep,
    BGAL_OT_ToggleFavorite,
    BGAL_OT_RevealAsset,
    BGAL_OT_OpenSourceBlend,
    BGAL_OT_CaptureManualPreview,
    BGAL_OT_ValidateAsset,
    BGAL_OT_LibraryHealthCheck,
    BGAL_OT_AutoLocateAssetTextures,
    BGAL_OT_ImportAssetTexturesFromYTD,
    BGAL_OT_CollectAssetTextures,
    BGAL_OT_RefreshPreview,
    BGAL_OT_RegenerateThumbnail,
)


def register() -> None:
    for cls in CLASSES:
        safe_register_class(cls)


def unregister() -> None:
    for cls in reversed(CLASSES):
        safe_unregister_class(cls)








