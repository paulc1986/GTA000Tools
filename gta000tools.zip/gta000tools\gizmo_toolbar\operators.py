"""Core transform operators for the GTA 000 gizmo toolbar."""

from __future__ import annotations

import math

import bpy
from bpy.props import BoolProperty, EnumProperty, FloatProperty
from bpy.types import Operator
from mathutils import Matrix, Vector

from . import runtime


AXIS_ITEMS = (
    ("X", "X", "Use the X axis"),
    ("Y", "Y", "Use the Y axis"),
    ("Z", "Z", "Use the Z axis"),
)


def active_mesh_object(context):
    obj = getattr(context, "active_object", None)
    if obj and getattr(obj, "type", "") == "MESH":
        return obj
    return None


def ensure_single_user_mesh(obj):
    data = getattr(obj, "data", None)
    if data is None:
        raise RuntimeError("The active object has no mesh datablock")
    if getattr(data, "users", 1) > 1:
        obj.data = data.copy()
    return obj.data


def axis_vector(axis):
    return {
        "X": Vector((1.0, 0.0, 0.0)),
        "Y": Vector((0.0, 1.0, 0.0)),
        "Z": Vector((0.0, 0.0, 1.0)),
    }.get(str(axis or "X"), Vector((1.0, 0.0, 0.0)))


def object_axis_world_vector(obj, axis_name, use_local_space=True):
    axis = axis_vector(axis_name)
    if not use_local_space:
        return axis
    basis = obj.matrix_world.to_3x3()
    world_axis = basis @ axis
    if world_axis.length <= 0.000001:
        return axis
    return world_axis.normalized()


def move_mesh_keep_origin(obj, delta_world):
    if not obj or getattr(obj, "type", "") != "MESH":
        raise RuntimeError("Select a mesh object first")
    delta_world = Vector(delta_world)
    if delta_world.length <= 0.000001:
        return

    mesh = ensure_single_user_mesh(obj)
    local_delta = obj.matrix_world.to_3x3().inverted_safe() @ delta_world
    mesh.transform(Matrix.Translation(local_delta))
    if hasattr(mesh, "update"):
        mesh.update()


def rotate_mesh_keep_origin(obj, angle_radians, axis_name, use_local_space=True):
    if not obj or getattr(obj, "type", "") != "MESH":
        raise RuntimeError("Select a mesh object first")
    if abs(float(angle_radians)) <= 0.000001:
        return

    mesh = ensure_single_user_mesh(obj)
    if use_local_space:
        local_rotation = Matrix.Rotation(float(angle_radians), 4, str(axis_name or "X"))
    else:
        world_rotation = Matrix.Rotation(float(angle_radians), 3, str(axis_name or "X"))
        basis = obj.matrix_world.to_3x3()
        local_rotation = (basis.inverted_safe() @ world_rotation @ basis).to_4x4()
    mesh.transform(local_rotation)
    if hasattr(mesh, "update"):
        mesh.update()


def move_origin_keep_geometry(obj, world_point):
    if not obj or getattr(obj, "type", "") != "MESH":
        raise RuntimeError("Select a mesh object first")

    point = Vector(world_point)
    old_world = obj.matrix_world.copy()
    new_world = old_world.copy()
    new_world.translation = point
    transform = new_world.inverted() @ old_world

    mesh = ensure_single_user_mesh(obj)
    mesh.transform(transform)
    if hasattr(mesh, "update"):
        mesh.update()
    obj.matrix_world = new_world


def rotate_origin_keep_geometry(obj, angle_radians, axis_name, use_local_space=True):
    if not obj or getattr(obj, "type", "") != "MESH":
        raise RuntimeError("Select a mesh object first")
    if abs(float(angle_radians)) <= 0.000001:
        return

    old_world = obj.matrix_world.copy()
    old_location = old_world.translation.copy()
    old_basis = old_world.to_3x3()

    if use_local_space:
        rotation = Matrix.Rotation(float(angle_radians), 3, str(axis_name or "X"))
        new_basis = old_basis @ rotation
    else:
        rotation = Matrix.Rotation(float(angle_radians), 3, str(axis_name or "X"))
        new_basis = rotation @ old_basis

    new_world = new_basis.to_4x4()
    new_world.translation = old_location
    transform = new_world.inverted() @ old_world

    mesh = ensure_single_user_mesh(obj)
    mesh.transform(transform)
    if hasattr(mesh, "update"):
        mesh.update()
    obj.matrix_world = new_world


class GTA000_OT_move_mesh_keep_origin(Operator):
    bl_idname = "gta000.move_mesh_keep_origin"
    bl_label = "Move Mesh Keep Origin"
    bl_description = "Move only the mesh geometry while keeping the object origin fixed"
    bl_options = {"REGISTER", "UNDO"}

    axis: EnumProperty(name="Axis", items=AXIS_ITEMS, default="X")
    distance: FloatProperty(name="Distance", default=0.0, precision=4)
    use_local_space: BoolProperty(name="Use Local Space", default=True)

    @classmethod
    def poll(cls, context):
        return active_mesh_object(context) is not None

    def invoke(self, context, event):
        del event
        settings = runtime.get_settings(context)
        if settings is not None:
            self.use_local_space = bool(getattr(settings, "use_local_space", True))
        return context.window_manager.invoke_props_dialog(self)

    def execute(self, context):
        obj = active_mesh_object(context)
        if obj is None:
            self.report({"ERROR"}, "Select a mesh object first")
            return {"CANCELLED"}

        delta_world = object_axis_world_vector(obj, self.axis, self.use_local_space) * float(self.distance)
        try:
            move_mesh_keep_origin(obj, delta_world)
            runtime.set_status(context, f"Moved mesh on {self.axis} by {self.distance:.4f}")
        except Exception as ex:
            self.report({"ERROR"}, str(ex))
            runtime.set_status(context, f"Move Mesh Keep Origin failed: {ex}", level="ERROR")
            return {"CANCELLED"}
        return {"FINISHED"}


class GTA000_OT_rotate_mesh_keep_origin(Operator):
    bl_idname = "gta000.rotate_mesh_keep_origin"
    bl_label = "Rotate Mesh Keep Origin"
    bl_description = "Rotate only the mesh geometry while keeping the object origin fixed"
    bl_options = {"REGISTER", "UNDO"}

    axis: EnumProperty(name="Axis", items=AXIS_ITEMS, default="Z")
    angle_degrees: FloatProperty(name="Angle", default=0.0, precision=3)
    use_local_space: BoolProperty(name="Use Local Space", default=True)

    @classmethod
    def poll(cls, context):
        return active_mesh_object(context) is not None

    def invoke(self, context, event):
        del event
        settings = runtime.get_settings(context)
        if settings is not None:
            self.use_local_space = bool(getattr(settings, "use_local_space", True))
            self.angle_degrees = float(getattr(settings, "snap_increment", 15.0))
        return context.window_manager.invoke_props_dialog(self)

    def execute(self, context):
        obj = active_mesh_object(context)
        if obj is None:
            self.report({"ERROR"}, "Select a mesh object first")
            return {"CANCELLED"}

        try:
            rotate_mesh_keep_origin(
                obj,
                math.radians(float(self.angle_degrees)),
                self.axis,
                self.use_local_space,
            )
            runtime.set_status(context, f"Rotated mesh {self.angle_degrees:.2f}° around {self.axis}")
        except Exception as ex:
            self.report({"ERROR"}, str(ex))
            runtime.set_status(context, f"Rotate Mesh Keep Origin failed: {ex}", level="ERROR")
            return {"CANCELLED"}
        return {"FINISHED"}


_CLASSES = (
    GTA000_OT_move_mesh_keep_origin,
    GTA000_OT_rotate_mesh_keep_origin,
)


def register():
    for cls in _CLASSES:
        bpy.utils.register_class(cls)


def unregister():
    for cls in reversed(_CLASSES):
        try:
            bpy.utils.unregister_class(cls)
        except RuntimeError:
            pass
