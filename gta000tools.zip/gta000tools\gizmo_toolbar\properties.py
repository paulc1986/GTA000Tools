"""Property groups and constants for the GTA 000 gizmo toolbar scaffold."""

from __future__ import annotations

import bpy
from bpy.props import BoolProperty, EnumProperty, FloatProperty, PointerProperty, StringProperty
from bpy.types import PropertyGroup


GIZMO_MODE_DATA = (
    ("CURSOR", "Cursor", "3D cursor control"),
    ("ORIGIN", "Origin", "Object origin controls"),
    ("MESH", "Mesh", "Object-space mesh edits"),
)

GIZMO_MODE_ITEMS = tuple((identifier, label, description) for identifier, label, description in GIZMO_MODE_DATA)
GIZMO_MODE_LABELS = {identifier: label for identifier, label, _description in GIZMO_MODE_DATA}
GIZMO_MODE_ORDER = tuple(identifier for identifier, _label, _description in GIZMO_MODE_DATA)

GIZMO_MODE_GROUPS = (
    ("Implemented", ("CURSOR", "ORIGIN", "MESH")),
)

GIZMO_BUILD_ORDER = (
    "Top viewport GTA toolbar and floating overlay strip",
    "3D Cursor Move Gizmo",
    "Origin Move Gizmo",
    "Origin Rotate Gizmo",
    "Move Mesh Keep Origin",
    "Rotate Mesh Keep Origin",
    "Axis Constraint system",
    "Door Hinge Gizmo",
    "Door Swing Arc Gizmo",
    "Dummy / Locator tool",
    "Mirror Placement",
    "Export Readiness Overlay",
)


def _notify_runtime(context, text: str, level: str = "INFO") -> None:
    from . import runtime

    runtime.set_status(context, text, level=level)


def _update_mode(self, context) -> None:
    _notify_runtime(context, f"Mode: {GIZMO_MODE_LABELS.get(self.active_mode, self.active_mode.title())}")


def _update_overlay(self, context) -> None:
    _notify_runtime(context, "Overlay settings updated")


class GTA000PG_GizmoToolbarSettings(PropertyGroup):
    active_mode: EnumProperty(
        name="Active Mode",
        description="Current high-level gizmo toolbar mode",
        items=GIZMO_MODE_ITEMS,
        default="CURSOR",
        update=_update_mode,
    )
    show_header_strip: BoolProperty(
        name="Show Header Strip",
        description="Show the compact gizmo toolbar in the 3D View header",
        default=True,
        update=_update_overlay,
    )
    show_overlay: BoolProperty(
        name="Show Floating Overlay",
        description="Draw the compact floating overlay strip in the viewport",
        default=True,
        update=_update_overlay,
    )
    overlay_scale: FloatProperty(
        name="Overlay Scale",
        description="Scale the floating overlay strip",
        default=1.0,
        min=0.75,
        max=2.0,
        update=_update_overlay,
    )
    overlay_position: EnumProperty(
        name="Overlay Position",
        description="Anchor the floating overlay strip inside the viewport",
        items=(
            ("TOP_LEFT", "Top Left", "Draw the strip in the top-left corner"),
            ("TOP_CENTER", "Top Center", "Draw the strip centered at the top"),
            ("TOP_RIGHT", "Top Right", "Draw the strip in the top-right corner"),
        ),
        default="TOP_LEFT",
        update=_update_overlay,
    )
    show_mode_labels: BoolProperty(
        name="Show Mode Labels",
        description="Draw readable labels for each mode in the overlay strip",
        default=True,
        update=_update_overlay,
    )
    show_status_text: BoolProperty(
        name="Show Status Text",
        description="Show the current active status in the toolbar and overlay",
        default=True,
        update=_update_overlay,
    )
    snap_increment: FloatProperty(
        name="Snap Increment",
        description="Default angular snap increment for future gizmo tools",
        default=15.0,
        min=0.1,
        max=180.0,
    )
    use_local_space: BoolProperty(
        name="Use Local Space",
        description="Future gizmo tools can default to local-space movement",
        default=True,
    )
    preserve_origin: BoolProperty(
        name="Preserve Origin",
        description="Keep the current object origin fixed when future mesh tools move geometry",
        default=True,
    )
    last_action: StringProperty(
        name="Last Action",
        description="Human-readable status line for the toolbar",
        default="Ready",
        options={"SKIP_SAVE"},
    )
    last_warning: StringProperty(
        name="Last Warning",
        description="Latest warning or error message from the toolbar scaffold",
        default="",
        options={"SKIP_SAVE"},
    )


class GTA000PG_GizmoToolbarRuntimeState(PropertyGroup):
    status_text: StringProperty(
        name="Status Text",
        description="Current runtime status message for the overlay and header",
        default="Ready",
        options={"SKIP_SAVE"},
    )
    status_level: EnumProperty(
        name="Status Level",
        description="Severity level for the runtime status",
        items=(
            ("INFO", "Info", "Informational status"),
            ("WARN", "Warning", "Warning status"),
            ("ERROR", "Error", "Error status"),
        ),
        default="INFO",
        options={"SKIP_SAVE"},
    )
    queued_task: StringProperty(
        name="Queued Task",
        description="Reserved for future worker or gizmo build tasks",
        default="",
        options={"SKIP_SAVE"},
    )
    overlay_dirty: BoolProperty(
        name="Overlay Dirty",
        description="Signal that the overlay should be redrawn",
        default=False,
        options={"SKIP_SAVE"},
    )


_CLASSES = (
    GTA000PG_GizmoToolbarSettings,
    GTA000PG_GizmoToolbarRuntimeState,
)


def register() -> None:
    for cls in _CLASSES:
        bpy.utils.register_class(cls)

    bpy.types.Scene.gta000_gizmo_toolbar = PointerProperty(type=GTA000PG_GizmoToolbarSettings)
    bpy.types.WindowManager.gta000_gizmo_toolbar_runtime = PointerProperty(type=GTA000PG_GizmoToolbarRuntimeState)


def unregister() -> None:
    if hasattr(bpy.types.Scene, "gta000_gizmo_toolbar"):
        del bpy.types.Scene.gta000_gizmo_toolbar
    if hasattr(bpy.types.WindowManager, "gta000_gizmo_toolbar_runtime"):
        del bpy.types.WindowManager.gta000_gizmo_toolbar_runtime

    for cls in reversed(_CLASSES):
        try:
            bpy.utils.unregister_class(cls)
        except RuntimeError:
            pass
