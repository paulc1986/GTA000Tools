"""Initial gizmo groups for GTA 000 transform workflows."""

from __future__ import annotations

import math

import bpy
from bpy.types import GizmoGroup
from mathutils import Matrix, Vector

from . import runtime
from . import operators as gt_ops


def _axis_rotation(axis_name):
    axis = gt_ops.axis_vector(axis_name)
    return Vector((0.0, 0.0, 1.0)).rotation_difference(axis).to_matrix().to_4x4()


def _axis_color(axis_name):
    return {
        "X": (0.92, 0.20, 0.20),
        "Y": (0.25, 0.80, 0.25),
        "Z": (0.25, 0.45, 0.95),
    }.get(axis_name, (0.85, 0.85, 0.85))


class _LinearAxisHandler:
    def __init__(self, axis_name, origin_getter, apply_delta):
        self.axis_name = axis_name
        self.origin_getter = origin_getter
        self.apply_delta = apply_delta
        self.last_value = 0.0

    def get(self):
        return self.last_value

    def set(self, value):
        value = float(value)
        delta = value - self.last_value
        if abs(delta) <= 0.000001:
            return
        self.last_value = value
        self.apply_delta(self.axis_name, delta)

    def maybe_reset(self, gizmo):
        if not getattr(gizmo, "is_highlight", False) and abs(self.last_value) > 0.000001:
            self.last_value = 0.0


class _AngularAxisHandler:
    def __init__(self, axis_name, apply_delta):
        self.axis_name = axis_name
        self.apply_delta = apply_delta
        self.last_value = 0.0

    def get(self):
        return self.last_value

    def set(self, value):
        value = float(value)
        delta = value - self.last_value
        if abs(delta) <= 0.000001:
            return
        self.last_value = value
        self.apply_delta(self.axis_name, delta)

    def maybe_reset(self, gizmo):
        if not getattr(gizmo, "is_highlight", False) and abs(self.last_value) > 0.000001:
            self.last_value = 0.0


class GTA000_GGT_cursor_move(GizmoGroup):
    bl_idname = "GTA000_GGT_cursor_move"
    bl_label = "GTA 000 Cursor Move"
    bl_space_type = "VIEW_3D"
    bl_region_type = "WINDOW"
    bl_options = {"3D", "PERSISTENT"}

    @classmethod
    def poll(cls, context):
        settings = runtime.get_settings(context)
        return settings is not None and getattr(settings, "active_mode", "CURSOR") == "CURSOR"

    def setup(self, context):
        self._handlers = []
        for axis_name in ("X", "Y", "Z"):
            gizmo = self.gizmos.new("GIZMO_GT_arrow_3d")
            color = _axis_color(axis_name)
            gizmo.color = color
            gizmo.alpha = 0.85
            gizmo.color_highlight = tuple(min(1.0, c + 0.15) for c in color)
            gizmo.alpha_highlight = 1.0
            gizmo.scale_basis = 0.22
            gizmo.line_width = 2.0
            gizmo.draw_style = "BOX"

            handler = _LinearAxisHandler(
                axis_name=axis_name,
                origin_getter=lambda ctx=context: ctx.scene.cursor.location.copy(),
                apply_delta=self._apply_delta,
            )
            gizmo.target_set_handler("offset", get=handler.get, set=handler.set)
            self._handlers.append((gizmo, handler, axis_name))

    def _apply_delta(self, axis_name, delta):
        context = bpy.context
        cursor = context.scene.cursor
        direction = gt_ops.axis_vector(axis_name)
        cursor.location = cursor.location + direction * float(delta)
        runtime.set_status(context, f"Cursor moved on {axis_name}")

    def refresh(self, context):
        location = context.scene.cursor.location.copy()
        for gizmo, handler, axis_name in self._handlers:
            gizmo.matrix_basis = Matrix.Translation(location) @ _axis_rotation(axis_name)
            handler.maybe_reset(gizmo)


class GTA000_GGT_origin_move(GizmoGroup):
    bl_idname = "GTA000_GGT_origin_move"
    bl_label = "GTA 000 Origin Move"
    bl_space_type = "VIEW_3D"
    bl_region_type = "WINDOW"
    bl_options = {"3D", "PERSISTENT"}

    @classmethod
    def poll(cls, context):
        settings = runtime.get_settings(context)
        obj = gt_ops.active_mesh_object(context)
        return settings is not None and getattr(settings, "active_mode", "") == "ORIGIN" and obj is not None

    def setup(self, context):
        self._handlers = []
        for axis_name in ("X", "Y", "Z"):
            gizmo = self.gizmos.new("GIZMO_GT_arrow_3d")
            color = _axis_color(axis_name)
            gizmo.color = color
            gizmo.alpha = 0.85
            gizmo.color_highlight = tuple(min(1.0, c + 0.15) for c in color)
            gizmo.alpha_highlight = 1.0
            gizmo.scale_basis = 0.24
            gizmo.line_width = 2.0
            gizmo.draw_style = "BOX"

            handler = _LinearAxisHandler(
                axis_name=axis_name,
                origin_getter=lambda ctx=context: gt_ops.active_mesh_object(ctx).matrix_world.translation.copy(),
                apply_delta=self._apply_delta,
            )
            gizmo.target_set_handler("offset", get=handler.get, set=handler.set)
            self._handlers.append((gizmo, handler, axis_name))

    def _apply_delta(self, axis_name, delta):
        context = bpy.context
        obj = gt_ops.active_mesh_object(context)
        if obj is None:
            return
        settings = runtime.get_settings(context)
        use_local_space = bool(getattr(settings, "use_local_space", True)) if settings else True
        direction = gt_ops.object_axis_world_vector(obj, axis_name, use_local_space)
        target = obj.matrix_world.translation + (direction * float(delta))
        gt_ops.move_origin_keep_geometry(obj, target)
        runtime.set_status(context, f"Origin moved on {axis_name}")

    def refresh(self, context):
        obj = gt_ops.active_mesh_object(context)
        if obj is None:
            return
        location = obj.matrix_world.translation.copy()
        settings = runtime.get_settings(context)
        use_local_space = bool(getattr(settings, "use_local_space", True)) if settings else True
        for gizmo, handler, axis_name in self._handlers:
            if use_local_space:
                axis_world = gt_ops.object_axis_world_vector(obj, axis_name, True)
                rotation = Vector((0.0, 0.0, 1.0)).rotation_difference(axis_world).to_matrix().to_4x4()
            else:
                rotation = _axis_rotation(axis_name)
            gizmo.matrix_basis = Matrix.Translation(location) @ rotation
            handler.maybe_reset(gizmo)


class GTA000_GGT_origin_rotate(GizmoGroup):
    bl_idname = "GTA000_GGT_origin_rotate"
    bl_label = "GTA 000 Origin Rotate"
    bl_space_type = "VIEW_3D"
    bl_region_type = "WINDOW"
    bl_options = {"3D", "PERSISTENT"}

    @classmethod
    def poll(cls, context):
        settings = runtime.get_settings(context)
        obj = gt_ops.active_mesh_object(context)
        return settings is not None and getattr(settings, "active_mode", "") == "ORIGIN" and obj is not None

    def setup(self, context):
        self._handlers = []
        for axis_name in ("X", "Y", "Z"):
            gizmo = self.gizmos.new("GIZMO_GT_dial_3d")
            color = _axis_color(axis_name)
            gizmo.color = color
            gizmo.alpha = 0.45
            gizmo.color_highlight = tuple(min(1.0, c + 0.15) for c in color)
            gizmo.alpha_highlight = 0.9
            gizmo.scale_basis = 0.34
            gizmo.line_width = 2.0

            handler = _AngularAxisHandler(axis_name=axis_name, apply_delta=self._apply_delta)
            gizmo.target_set_handler("offset", get=handler.get, set=handler.set)
            self._handlers.append((gizmo, handler, axis_name))

    def _apply_delta(self, axis_name, delta):
        context = bpy.context
        obj = gt_ops.active_mesh_object(context)
        if obj is None:
            return
        settings = runtime.get_settings(context)
        use_local_space = bool(getattr(settings, "use_local_space", True)) if settings else True
        gt_ops.rotate_origin_keep_geometry(obj, float(delta), axis_name, use_local_space)
        runtime.set_status(context, f"Origin rotated on {axis_name}")

    def refresh(self, context):
        obj = gt_ops.active_mesh_object(context)
        if obj is None:
            return
        location = obj.matrix_world.translation.copy()
        settings = runtime.get_settings(context)
        use_local_space = bool(getattr(settings, "use_local_space", True)) if settings else True
        for gizmo, handler, axis_name in self._handlers:
            if use_local_space:
                axis_world = gt_ops.object_axis_world_vector(obj, axis_name, True)
                rotation = Vector((0.0, 0.0, 1.0)).rotation_difference(axis_world).to_matrix().to_4x4()
            else:
                rotation = _axis_rotation(axis_name)
            gizmo.matrix_basis = Matrix.Translation(location) @ rotation
            handler.maybe_reset(gizmo)


_CLASSES = (
    GTA000_GGT_cursor_move,
    GTA000_GGT_origin_move,
    GTA000_GGT_origin_rotate,
)


def register():
    for cls in _CLASSES:
        bpy.utils.register_class(cls)


def unregister():
    for cls in reversed(_CLASSES):
        try:
            bpy.utils.unregister_class(cls)
        except RuntimeError:
            pass
