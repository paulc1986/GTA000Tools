from __future__ import annotations

import json
from pathlib import Path
from typing import Any

import bpy

from .utils import dedupe_preserve_order, safe_slug


INTERNAL_TYPE_ID_KEY = "GTA000 Asset Type ID"
INTERNAL_TYPE_NAME_KEY = "GTA000 Asset Type"
INTERNAL_SUBCATEGORY_FIELD_KEY = "GTA000 Asset Subcategory Field"
INTERNAL_SOURCE_KEY = "GTA000 Asset Creation Source"
INTERNAL_KEYS = {
    INTERNAL_TYPE_ID_KEY,
    INTERNAL_TYPE_NAME_KEY,
    INTERNAL_SUBCATEGORY_FIELD_KEY,
    INTERNAL_SOURCE_KEY,
    "_RNA_UI",
}

FIELD_TYPE_ITEMS = (
    ("STRING", "String", "Create a text custom property"),
    ("INT", "Integer", "Create a whole-number custom property"),
    ("BOOL", "Boolean", "Create a true/false custom property"),
)

BUILTIN_DEFINITIONS: tuple[dict[str, Any], ...] = (
    {
        "id": "builtin_vehicle",
        "name": "Vehicle",
        "category": "Vehicle",
        "subcategory_field": "Manufacture",
        "builtin": True,
        "fields": [
            {"name": "Manufacture", "type": "STRING", "default": ""},
            {"name": "Make", "type": "STRING", "default": ""},
            {"name": "Model", "type": "STRING", "default": ""},
            {"name": "Year", "type": "INT", "default": 0},
            {"name": "Author", "type": "STRING", "default": ""},
            {"name": "Developer Model", "type": "BOOL", "default": False},
        ],
    },
    {
        "id": "builtin_emergency_lighting",
        "name": "Emergency Lighting",
        "category": "Emergency Lighting",
        "subcategory_field": "Manufacture",
        "builtin": True,
        "fields": [
            {"name": "Manufacture", "type": "STRING", "default": ""},
            {"name": "Make", "type": "STRING", "default": ""},
            {"name": "Model", "type": "STRING", "default": ""},
            {"name": "Author", "type": "STRING", "default": ""},
            {"name": "Developer Model", "type": "BOOL", "default": False},
        ],
    },
)


def config_file_path() -> Path:
    base = Path(bpy.utils.user_resource("CONFIG")) / "gta000tools"
    base.mkdir(parents=True, exist_ok=True)
    return base / "asset_create_properties.json"


def _clean_field(payload: dict[str, Any]) -> dict[str, Any] | None:
    name = str(payload.get("name", "")).strip()
    if not name or name in INTERNAL_KEYS or name == "Category":
        return None
    field_type = str(payload.get("type", "STRING") or "STRING").upper()
    if field_type not in {"STRING", "INT", "BOOL"}:
        field_type = "STRING"
    default = payload.get("default", "")
    if field_type == "INT":
        try:
            default = int(default)
        except Exception:
            default = 0
    elif field_type == "BOOL":
        default = bool(default)
    else:
        default = str(default or "")
    return {"name": name, "type": field_type, "default": default}


def _definition_id(name: str, existing_ids: set[str] | None = None) -> str:
    existing_ids = existing_ids or set()
    base = safe_slug(name or "custom_asset_type").replace("-", "_").lower()
    if not base:
        base = "custom_asset_type"
    candidate = f"custom_{base}"
    suffix = 2
    while candidate in existing_ids or candidate in {item["id"] for item in BUILTIN_DEFINITIONS}:
        candidate = f"custom_{base}_{suffix}"
        suffix += 1
    return candidate


def normalize_definition(payload: dict[str, Any], existing_ids: set[str] | None = None) -> dict[str, Any] | None:
    name = str(payload.get("name", "")).strip()
    if not name:
        return None
    category = str(payload.get("category", "") or name).strip() or name
    subcategory_field = str(payload.get("subcategory_field", "Manufacture") or "").strip()
    raw_id = str(payload.get("id", "")).strip()
    definition_id = raw_id if raw_id else _definition_id(name, existing_ids)
    fields = []
    seen = set()
    for item in payload.get("fields", []) or []:
        if not isinstance(item, dict):
            continue
        field = _clean_field(item)
        if not field or field["name"].casefold() in seen:
            continue
        seen.add(field["name"].casefold())
        fields.append(field)
    return {
        "id": definition_id,
        "name": name,
        "category": category,
        "subcategory_field": subcategory_field,
        "builtin": bool(payload.get("builtin", False)),
        "fields": fields,
    }


def load_custom_definitions() -> list[dict[str, Any]]:
    path = config_file_path()
    if not path.exists():
        return []
    try:
        payload = json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return []
    raw_items = payload.get("types", []) if isinstance(payload, dict) else []
    results: list[dict[str, Any]] = []
    existing_ids = {item["id"] for item in BUILTIN_DEFINITIONS}
    for item in raw_items:
        if not isinstance(item, dict):
            continue
        normalized = normalize_definition(item, existing_ids)
        if normalized is None:
            continue
        normalized["builtin"] = False
        existing_ids.add(normalized["id"])
        results.append(normalized)
    return results


def save_custom_definitions(definitions: list[dict[str, Any]]) -> str:
    cleaned: list[dict[str, Any]] = []
    existing_ids = {item["id"] for item in BUILTIN_DEFINITIONS}
    for definition in definitions:
        if definition.get("builtin"):
            continue
        normalized = normalize_definition(definition, existing_ids)
        if normalized is None:
            continue
        normalized["builtin"] = False
        existing_ids.add(normalized["id"])
        cleaned.append(normalized)
    path = config_file_path()
    path.write_text(json.dumps({"version": 1, "types": cleaned}, indent=2, sort_keys=True), encoding="utf-8")
    return str(path)


def all_definitions() -> list[dict[str, Any]]:
    return [dict(item) for item in BUILTIN_DEFINITIONS] + load_custom_definitions()


def definition_by_id(definition_id: str) -> dict[str, Any] | None:
    for definition in all_definitions():
        if definition["id"] == definition_id:
            return definition
    return None


def default_definition_id() -> str:
    return BUILTIN_DEFINITIONS[0]["id"]


def enum_items() -> list[tuple[str, str, str]]:
    items = []
    for index, definition in enumerate(all_definitions()):
        icon = "AUTO" if definition.get("builtin") else "GREASEPENCIL"
        items.append((definition["id"], definition["name"], f"Use {definition['name']} asset creation defaults", icon, index))
    if not items:
        items.append((default_definition_id(), "Vehicle", "Use vehicle asset creation defaults", 0, 0))
    return items


def value_is_empty(value: Any) -> bool:
    if value is None:
        return True
    if isinstance(value, str):
        return not value.strip()
    return False


def _default_value_for_field(field: dict[str, Any]) -> Any:
    field_type = str(field.get("type", "STRING")).upper()
    if field_type == "INT":
        try:
            return int(field.get("default", 0))
        except Exception:
            return 0
    if field_type == "BOOL":
        return bool(field.get("default", False))
    return str(field.get("default", "") or "")


def apply_definition_to_scene(
    scene: bpy.types.Scene,
    definition: dict[str, Any],
    *,
    overwrite_category: bool = True,
    overwrite_values: bool = False,
) -> list[str]:
    changed: list[str] = []
    if scene is None:
        return changed
    category = str(definition.get("category", definition.get("name", "")) or "").strip()
    subcategory_field = str(definition.get("subcategory_field", "") or "").strip()
    scene[INTERNAL_TYPE_ID_KEY] = definition.get("id", "")
    scene[INTERNAL_TYPE_NAME_KEY] = definition.get("name", "")
    scene[INTERNAL_SUBCATEGORY_FIELD_KEY] = subcategory_field
    scene[INTERNAL_SOURCE_KEY] = "GTA 000 Tools"
    changed.extend([INTERNAL_TYPE_ID_KEY, INTERNAL_TYPE_NAME_KEY, INTERNAL_SUBCATEGORY_FIELD_KEY, INTERNAL_SOURCE_KEY])
    if overwrite_category or "Category" not in scene:
        scene["Category"] = category
        changed.append("Category")
    for field in definition.get("fields", []) or []:
        name = str(field.get("name", "")).strip()
        if not name:
            continue
        if overwrite_values or name not in scene or value_is_empty(scene.get(name)):
            scene[name] = _default_value_for_field(field)
            changed.append(name)
    return dedupe_preserve_order(changed)


def public_asset_creation_props_from_idblock(idblock) -> dict[str, Any]:
    props: dict[str, Any] = {}
    if idblock is None:
        return props
    try:
        keys = list(idblock.keys())
    except Exception:
        return props
    for key in keys:
        if key in INTERNAL_KEYS:
            continue
        try:
            value = idblock[key]
        except Exception:
            continue
        if key == "Category" or key in known_public_field_names() or not key.startswith("_"):
            props[str(key)] = value
    for internal_key in (INTERNAL_TYPE_ID_KEY, INTERNAL_TYPE_NAME_KEY, INTERNAL_SUBCATEGORY_FIELD_KEY):
        try:
            if internal_key in idblock:
                props[internal_key] = idblock[internal_key]
        except Exception:
            pass
    return props


def known_public_field_names() -> set[str]:
    names = {"Category"}
    for definition in all_definitions():
        names.add(str(definition.get("subcategory_field", "") or ""))
        for field in definition.get("fields", []) or []:
            names.add(str(field.get("name", "") or ""))
    return {name for name in names if name}


def _tag_value(value: Any) -> str:
    if value is None:
        return ""
    if isinstance(value, bool):
        return ""
    if isinstance(value, float) and value.is_integer():
        return str(int(value))
    return str(value).strip()


def metadata_from_custom_props(props: dict[str, Any]) -> dict[str, Any]:
    category = str(props.get("Category", "") or "").strip()
    subcategory_field = str(props.get(INTERNAL_SUBCATEGORY_FIELD_KEY, "") or "").strip() or "Manufacture"
    subcategory = str(props.get(subcategory_field, "") or "").strip()
    author = str(props.get("Author", "") or "").strip()
    tags = []
    for key, value in props.items():
        if key in INTERNAL_KEYS or key in {"Category", subcategory_field}:
            continue
        if isinstance(value, bool):
            if value:
                tags.append(key)
            continue
        tag = _tag_value(value)
        if tag:
            tags.append(tag)
    return {
        "category": category,
        "subcategory": subcategory,
        "author": author,
        "tags": dedupe_preserve_order(tags),
    }


def metadata_from_scene(scene: bpy.types.Scene) -> dict[str, Any]:
    return metadata_from_custom_props(public_asset_creation_props_from_idblock(scene))
